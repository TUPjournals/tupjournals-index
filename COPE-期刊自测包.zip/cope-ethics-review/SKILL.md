---
name: cope-ethics-review
description: 依据 COPE《学术出版透明度与最佳实践原则》（17 项原则）审查期刊 Ethics 及政策页面完备性的技能。当用户要求检查某期刊的 Ethics 页面 / 出版伦理政策 / 透明度合规是否完备、对照 COPE 原则逐项评估期刊政策页面（伦理、审稿、费用、版权、编委会等）时使用。触发词：COPE 审查、伦理页面完备性、透明度原则、publication ethics 页面检查、期刊政策页面审查。与 esci-journal-review / doaj-journal-review / scopus-journal-review 配合使用可覆盖期刊数据库申请前的全面自查。
agent_created: true
---

# COPE 透明度原则 · 期刊 Ethics 页面完备性审查

## Overview

对期刊的 Ethics 及政策页面（Publishing ethics、Submission guidelines、About、Editorial board、APC 等）逐项比对 COPE/DOAJ/OASPA/WAME 联合发布的《Principles of Transparency and Best Practice in Scholarly Publishing》（DOI: 10.24318/cope.2019.1.12）17 项原则，输出 RAG 评级、逐项证据与分级整改建议的 HTML 报告。

## Workflow

### Step 1 — 采集证据

定位期刊的政策页面。SciOpen/TUP 期刊用 ISSN 直接抓取，其他平台需用户提供 URL 或由 WorkBuddy 先浏览官网定位相关页面。

```bash
C:/Users/86135/.workbuddy/binaries/python/envs/default/Scripts/python.exe <skill_dir>/scripts/evidence.py --issn <ISSN> [--urls <额外页面URL>...] [--out <输出目录>]
```

- SciOpen 期刊：脚本自动抓取主页面、编委会页并做政策链接发现
- 非 SciOpen 期刊：用 `--base-url <期刊官网>` 让脚本做同站政策链接发现，必要时用 WebFetch 逐页获取
- 若脚本抓取失败（动态渲染站点），改用 WebFetch 逐页获取页面内容，人工整理为文本证据

### Step 2 — 逐项比对 17 项原则

加载 `references/criteria.md`（完整检查清单 + 高频故障速查），对每项原则：

1. 在证据文本中定位对应内容
2. 逐条核对检查点，**特别核查跨页面一致性**（盲审模式、费用日期、链接指向、术语口径）
3. 评级并摘录原文证据（含出处 URL）：
   - **绿** = 完备且与其他页面一致
   - **黄** = 有表述但缺项/模糊/跨页矛盾
   - **红** = 缺失
4. 共享模板出版商（多刊共用同一套模板页面）重点使用 criteria.md 末尾的"高频故障速查"：错误链接指向姊妹刊、医学模板残留、AI 抓取禁令与 CC BY 冲突、个人邮箱联系方式等

### Step 3 — 生成报告

复制 `assets/report-template.html`，替换占位符（{{JOURNAL_NAME}}、{{DATE}}、{{ROWS}}、{{FIX_P0/P1/P2}}、计数与得分），按 P0（缺失或矛盾的核心政策）/ P1（模糊或不一致）/ P2（优化项）给出可执行的整改建议。保存为 `<期刊名>_COPE透明度审查报告.html` 并交付用户。

### Step 4 — 结论表述

报告结论区分三个层次：① Ethics 页面本身的完备度（17 项中红/黄/绿分布）；② 与 COPE 会员标准的差距（该文件是 COPE/DOAJ/OASPA/WAME 会员基础标准，不合规需向组织解释）；③ 与数据库申请的联动（红项往往是 DOAJ/ESCI/Scopus 申请的硬性材料缺口，提示与对应 skill 的评估结果交叉引用）。

## Notes

- 评级只针对"是否完备、一致"，不评判政策内容本身的学术取向
- 单页抓取不完整时须在报告"方法说明与局限"中注明，避免误判为红项
- 该原则文件英文版为最新权威版本；中文页面的措辞以英文版原则为准判断

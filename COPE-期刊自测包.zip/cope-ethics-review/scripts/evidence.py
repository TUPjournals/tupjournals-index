#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evidence fetcher for COPE transparency review.

Fetches a journal's policy/ethics pages and Crossref metadata, saving plain-text
evidence files for the audit. Works with any journal site; has built-in page
guesses for SciOpen (Tsinghua University Press) journals.

Usage:
    python evidence.py --issn 3006-9203 [--base-url URL] [--urls URL1 URL2 ...] [--out DIR]

Outputs (in --out, default ./cope_evidence):
    crossref_meta.json   journal metadata from Crossref (title, publisher, ISSN)
    page_<n>.txt         extracted plain text of each fetched page
    links_index.md       list of all fetched pages + outgoing policy links found
"""
import argparse
import json
import os
import re
import sys
import urllib.request

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
TIMEOUT = 30

SCIOPEN_GUESSES = [
    # common SciOpen journal sub-pages (issn substituted)
    "https://www.sciopen.com/journal/{issn}",
    "https://www.sciopen.com/journal/1000/details",
    "https://www.sciopen.com/journal/join_journal/editorial_board?issn={issn}",
    "https://www.sciopen.com/journal/1005/detail?issn={issn}",  # about/aims (may 404)
]


def fetch(url: str) -> str | None:
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            ctype = r.headers.get("Content-Type", "")
            if r.status != 200 or "text/html" not in ctype:
                return None
            return r.read().decode("utf-8", errors="replace")
    except Exception as e:
        print(f"  [skip] {url} -> {e}", file=sys.stderr)
        return None


def html_to_text(html: str) -> str:
    html = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", html)
    # capture hrefs before stripping tags
    hrefs = re.findall(r'href=["\']([^"\']+)["\']', html)
    # keep table structure hints
    html = re.sub(r"(?i)</(p|div|li|tr|h[1-6]|br)>", "\n", html)
    html = re.sub(r"(?i)<(td|th)[^>]*>", " | ", html)
    text = re.sub(r"<[^>]+>", " ", html)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n", text)
    return text.strip(), hrefs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--issn", help="eISSN of the journal")
    ap.add_argument("--base-url", help="journal homepage URL (used to seed link discovery)")
    ap.add_argument("--urls", nargs="*", default=[], help="extra explicit page URLs to fetch")
    ap.add_argument("--out", default="./cope_evidence")
    ap.add_argument("--max-pages", type=int, default=12)
    args = ap.parse_args()

    if not (args.issn or args.base_url or args.urls):
        ap.error("provide --issn, --base-url and/or --urls")

    os.makedirs(args.out, exist_ok=True)
    targets = []

    if args.issn:
        # Crossref metadata
        try:
            req = urllib.request.Request(
                f"https://api.crossref.org/journals/{args.issn}", headers=UA
            )
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                meta = json.loads(r.read().decode("utf-8"))
            with open(os.path.join(args.out, "crossref_meta.json"), "w", encoding="utf-8") as f:
                json.dump(meta.get("message", {}), f, ensure_ascii=False, indent=2)
            print(f"[ok] crossref: {meta['message'].get('title', [args.issn])[0]}")
        except Exception as e:
            print(f"[warn] crossref failed: {e}", file=sys.stderr)

        for u in SCIOPEN_GUESSES:
            targets.append(u.format(issn=args.issn))
    if args.base_url:
        targets.append(args.base_url)
    targets.extend(args.urls)

    # dedupe, keep order
    seen, ordered = set(), []
    for u in targets:
        if u and u not in seen:
            seen.add(u)
            ordered.append(u)

    index_lines = ["# Fetched pages\n"]
    n = 0
    keyword = re.compile(
        r"(ethic|policy|policies|guideline|instruction|author|editorial|board|"
        r"apc|fee|charge|open.?access|licen[cs]e|copyright|about|scope|peer|review|"
        r"retract|corrigend|errata|complaint|appeal|malpractice|preserv|archive)",
        re.I,
    )
    i = 0
    while i < len(ordered) and n < args.max_pages:
        url = ordered[i]
        i += 1
        html = fetch(url)
        if not html:
            continue
        n += 1
        text, hrefs = html_to_text(html)
        fname = f"page_{n:02d}.txt"
        with open(os.path.join(args.out, fname), "w", encoding="utf-8") as f:
            f.write(f"URL: {url}\n\n{text}")
        print(f"[ok] {fname} <- {url} ({len(text)} chars)")
        index_lines.append(f"- {fname}: {url}")

        # discover policy-ish sub-links on same host (one level)
        base_host = re.sub(r"^(https?://[^/]+).*$", r"\1", url)
        for h in hrefs:
            if h.startswith("/"):
                h = base_host + h
            if h.startswith("http") and base_host in h and keyword.search(h):
                if h.split("#")[0].rstrip("/") not in seen:
                    seen.add(h.split("#")[0].rstrip("/"))
                    ordered.append(h.split("#")[0].rstrip("/"))

    with open(os.path.join(args.out, "links_index.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(index_lines) + "\n")
    print(f"\nDone: {n} pages -> {os.path.abspath(args.out)}/links_index.md")
    if n == 0:
        print("No pages fetched. Check URLs or use --urls explicitly.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()

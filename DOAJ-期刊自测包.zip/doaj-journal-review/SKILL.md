---
name: doaj-journal-review
description: 评估期刊是否适合申请 DOAJ（开放获取期刊目录）收录。当用户询问某期刊适不适合进 DOAJ、要求按 DOAJ 申请指南逐条核对（开放获取定义、费用透明、版权许可、同行评审、内源性比例等）、准备申请材料或分析被拒原因时使用。触发词：DOAJ 收录评估、DOAJ 申请、开放获取期刊目录、OA 期刊目录。
agent_created: true
---

# DOAJ 期刊收录适配性评估

对任意一本开放获取期刊（给定官网 URL 或 ISSN）完成"是否适合申请 DOAJ"的完整评估，产出单页 HTML 报告。评估依据唯一权威清单见 `references/criteria.md`（DOAJ Application Guide v2.9），判定前必须加载。

## 流程

### 1. 采集证据（先采集，后判定）

- 抓取期刊官网：主页、Aims & Scope、Editorial Board、Submission Guidelines、Publishing Ethics/Editorial Policies、全部卷期页（发文量、卷期节奏、连续出版 vs 定期声明）、抽样 2–3 篇文章页（许可声明/版权行/日期/基金）。
- 运行 `python scripts/evidence.py --issn <ISSN>` 获取 DOAJ 当前收录状态（应确认 total=0，避免重复申请）、Crossref 年发文量与 license/funder 字段完整度。
- 与出版社姊妹刊交叉核对政策文本，提取共用模板错误。

### 2. 逐条判定

- 先核硬门槛（`references/criteria.md` 第 1 节）：年 ≥5 篇研究论文、新刊 1 年历史或 ≥10 篇 OA 文章、完全 OA 无禁运、ISSN 确认。
- 再按第 2–4 节核对网站公示项、同行评审要求（**每篇 ≥2 名独立审稿人**、编委 ≥5、内源性 ≤25%）、许可与版权（**"All rights reserved" 绝不适用**、条款不得互相矛盾）。
- 第 6 节最佳实践逐项给 绿/黄（影响评审印象，不修也能过，但申请表会问到）。
- 高频模板错误清单：评审模式两页矛盾、"编辑替代第二审稿人"条款、APC 日期跨页不一致、AI 禁令与 CC BY 冲突、错链指向姊妹刊、缺自存档政策。

### 3. 结论与建议

- 结论先行 + P0/P1/P2 整改清单（P0 = 触碰硬门槛或会导致自动拒绝项）。
- 操作提示：官方邮箱注册；申请表答案与网站逐字一致；审核最长 6 个月、问答 1 个月内回复否则拒；拒后 6 个月禁重申；虚假信息最长禁 3 年。

### 4. 报告产出

- 复制 `assets/report-template.html` 填充生成报告，present_files 交付；语言与用户一致（默认中文）。

## 配套技能

`esci-journal-review`（ESCI/WoS）、`scopus-journal-review`（Scopus）。DOAJ 通常是三个库中最快的背书信号；政策整改项三个库高度重叠，先修 DOAJ 的 P0/P1，再分别提交 Scopus 与 ESCI。

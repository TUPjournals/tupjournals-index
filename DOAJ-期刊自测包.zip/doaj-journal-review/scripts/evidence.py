#!/usr/bin/env python3
"""采集期刊收录评估所需的第三方数据证据（Crossref + DOAJ）。

用法:
    python evidence.py --issn 3008-1203 [--output out.json]

输出 JSON 包含:
  - crossref.journal : 期刊级元数据（题名、出版方、逐年发文量、总量、ISSN 列表）
  - crossref.recent  : 最近 20 篇文章的日期/许可/基金字段完整度（用于评估 deposit 质量）
  - doaj.journal     : DOAJ 期刊收录状态（total=0 即未收录）
  - doaj.articles    : DOAJ 文章总数

依赖: 仅标准库 urllib。网络不可用时各 section 返回 {"error": "..."}，不中断整体。
"""
import argparse
import json
import sys
import urllib.request
import urllib.error

UA = {"User-Agent": "journal-db-readiness-audit/1.0 (mailto:editorial-audit@example.com)"}


def get_json(url, timeout=30):
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        return {"error": f"{type(exc).__name__}: {exc}"}


def crossref_journal(issn):
    d = get_json(f"https://api.crossref.org/journals/{issn}")
    if "error" in d:
        return d
    m = d.get("message", {})
    return {
        "title": m.get("title"),
        "publisher": m.get("publisher"),
        "issns": m.get("issn-type", []),
        "counts_by_year": m.get("counts", {}).get("breakdowns", {})
        .get("dois-by-issued-year", []),
        "total_dois": m.get("counts", {}).get("total-dois"),
        "coverage": m.get("coverage"),
    }


def crossref_recent(issn, rows=20):
    d = get_json(
        f"https://api.crossref.org/journals/{issn}/works"
        f"?rows={rows}&sort=published&order=desc&select=DOI,title,published,license,funder,type"
    )
    if "error" in d:
        return d
    out = []
    for it in d.get("message", {}).get("items", []):
        out.append(
            {
                "doi": it.get("DOI"),
                "type": it.get("type"),
                "published": it.get("published", {}).get("date-parts"),
                "has_license": bool(it.get("license")),
                "license_urls": [l.get("URL") for l in it.get("license", [])][:2],
                "has_funder": bool(it.get("funder")),
            }
        )
    return out


def doaj_status(issn):
    j = get_json(f"https://doaj.org/api/search/journals/issn:{issn}")
    a = get_json(f"https://doaj.org/api/search/articles/issn:{issn}?pageSize=1")
    jr = j.get("results", [])
    return {
        "indexed": j.get("total", 0) > 0,
        "journal_record": (
            {
                "title": jr[0]["bibjson"].get("title"),
                "publisher": jr[0]["bibjson"].get("publisher", {}).get("name"),
                "license": jr[0]["bibjson"].get("license"),
                "apc": jr[0]["bibjson"].get("apc"),
                "languages": jr[0]["bibjson"].get("language"),
            }
            if jr
            else None
        ),
        "article_total": a.get("total", 0) if "error" not in a else None,
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--issn", required=True, help="期刊 ISSN（印刷版或电子版均可）")
    ap.add_argument("--output", help="输出 JSON 文件路径（默认打印到 stdout）")
    args = ap.parse_args()

    result = {
        "issn": args.issn,
        "crossref": {"journal": crossref_journal(args.issn), "recent": crossref_recent(args.issn)},
        "doaj": doaj_status(args.issn),
    }
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"saved -> {args.output}")
    else:
        print(text)


if __name__ == "__main__":
    main()

---
name: esci-journal-review
description: 评估期刊是否适合申请 Clarivate Web of Science 核心合集 ESCI 收录。当用户询问某期刊适不适合申请 ESCI/WoS、要求按 24 项质量标准逐条评估、分析被拒风险/整改建议/申请时机，或提到 SCIE/SSCI/AHCI 升级路径时使用。触发词：ESCI、Web of Science 收录评估、SCIE、SSCI、AHCI、Clarivate 期刊评估、核心合集。
agent_created: true
---

# ESCI 期刊收录适配性评估

对任意一本期刊（给定官网 URL 或 ISSN）完成"是否适合申请 ESCI"的完整评估，产出单页 HTML 报告。评估依据唯一权威清单见 `references/criteria.md`，判定前必须加载。

## 流程

### 1. 采集证据（先采集，后判定）

- 抓取期刊官网：主页（题名/ISSN/eISSN/出版方/联系方式/创刊卷期）、Aims & Scope、Editorial Board（人数/国别/学科覆盖）、Submission Guidelines、Publishing Ethics（或 Editorial Policies）、**全部卷期页**（逐期文章数与出版日期 → 发文量与卷期节奏）、抽样 2–3 篇文章页（文章类型标签/Received/Accepted/Published 日期/许可/基金/各项声明）。
- 运行 `python scripts/evidence.py --issn <ISSN>`（标准库实现，无需安装依赖）获取 Crossref 年发文量、license/funder 字段完整度与 DOAJ 收录状态。
- 若该刊与已评估过的姊妹刊共用出版社模板，交叉核对两刊政策页，提取模板级错误。

### 2. 逐条判定

- 加载 `references/criteria.md`，对 24 项质量标准逐条给出 绿/黄/红 + 一句依据；4 项影响力标准单独说明（不用于 ESCI 准入，仅作升级展望）。
- 判定纪律：每条判定必须对应实际抓取到的页面或数据，不得凭印象；黄 = 可修复的表述/结构问题，红 = 按字面标准不满足。
- 对 `references/criteria.md` 第 7 节"高频失分点核查清单"逐项过一遍（共用模板期刊几乎必中若干项）。

### 3. 结论与建议

- 结论先行：适合 / 修后适合 / 不适合 + 核心理由。
- 整改清单按 P0（触碰硬性标准）/ P1（表述与结构）/ P2（最佳实践）分级，每项标注对应的标准条目号。
- 申请时机必须结合：**质量评估失败 → 重投禁限至少两年**；**1 月 1 日前被收录才有资格进当年 6 月 JCR**；ESCI→SCIE 升级由 Clarivate 主动发起、出版方不可申请。

### 4. 报告产出

- 复制 `assets/report-template.html` 填充生成报告（结构：结论先行 → 现状快照 → 逐条判定表 → P0/P1/P2 清单 → 时间表），用 present_files 交付。
- 报告语言与用户一致（默认中文）；判定依据每格一句，细节留给对话正文。

## 配套技能

用户同时评估多个数据库时，提示配套技能：`doaj-journal-review`（DOAJ）、`scopus-journal-review`（Scopus）。三个库的政策整改项高度重叠（同行评审描述、费用声明、许可一致性、出版节奏），先做一套统一整改再分别提交。

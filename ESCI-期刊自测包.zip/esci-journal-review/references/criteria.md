# ESCI（Web of Science 核心合集）收录标准全文

> 来源：Clarivate《Journal evaluation process and selection criteria》官方页面。本文件为评估依据的唯一权威清单，逐条判定时必须打开本文件对照。

## 1. 制度框架

- **28 条标准 = 24 项质量标准（quality）+ 4 项影响力标准（impact）**。
- 通过 24 项质量标准 → 进入 **ESCI**；再通过 4 项影响力标准 → 进入 **SCIE/SSCI/AHCI**（旗舰库）。
- **当前政策：所有新申请期刊仅用 24 项质量标准评估**，通过即入 ESCI（Clarivate 明确"重点评质量而非影响力"）。
- ESCI 期刊同样获得 **JIF**，与 SCIE/SSCI 统一排名。
- 动态收录：质量不达标即除名；旗舰刊影响力下滑降入 ESCI；ESCI 升旗舰由 Clarivate 依 JCR 数据**主动**发起，出版方不可申请影响力重评。

## 2. 三阶段流程与失败后果

| 阶段 | 内容 | 失败后果 |
|---|---|---|
| Stage 1 初审（Initial Triage，7 条） | 期刊身份与可及性 | 可立即重投，无禁限 |
| Stage 2 编辑分诊（Editorial Triage，9 条） | 是否值得全面评估 | 首次失败可立即重投；**连续第二次失败禁限 1 年** |
| Stage 3 编辑质量评估（8 条） | 一致性与编辑严谨性 | **重投禁限至少两年** |
| 影响力评估（4 条） | 仅升级旗舰库时 | 未通过留在 ESCI，持续监测 |

**JCR 时间规则**：1 月 1 日前被收录且 3 月 JCR 生产时仍在库 → 有资格进入当年 6 月 JCR 并获得 JIF/JCI。

## 3. Stage 1 · Initial Triage（7 条）

1. **ISSN**：在 portal.issn.org 可验证；在文章/期/刊/网站各层级一致展示；如同时有印刷与电子 ISSN，两者都须提供。
2. **Journal Title**：题名独特，与 ISSN、声明 scope、已发表内容、社群构成（编委与作者）相符。
3. **Journal Publisher**：出版方名称明确、有可验证实体办公地址（不能是 P.O. Box）；学会主办/所有权须说明。
4. **Journal URL**：在线期刊须提供 URL 与现刊全文访问方式。
5. **Content Access**：WoS 编辑团队须能完整访问已发表内容。
6. **Presence of Peer Review Policy**：有易获取、清晰的同行评审/编辑把关承诺；原创研究须经外部评审。
7. **Contact Details**：提供编辑与出版核心岗位的直接联系方式。

## 4. Stage 2 · Editorial Triage（9 条）

8. **Scholarly Content**：以原创学术内容为主，水平匹配研究生/博后/专业研究者。
9. **Article Titles and Abstracts in English**：所有文章题名与摘要须有准确英文版。
10. **Bibliographic Information in Roman Script**：参考文献、姓名、单位须以罗马字母发表。
11. **Clarity of Language**：英文文本清晰、全球读者可理解。
12. **Timeliness and/or Publication Volume**：须声明出版频率（定期/不定期/连续）**并遵守该声明**；年发文量须证明社群关注与可持续性；须有足够内容覆盖 scope 宽度以便全面评估。
13. **Website Functionality/Journal Format**：网站信息准确、导航清晰；期刊站与出版社站双向链接。
14. **Presence of Ethics Statements**：伦理要求透明；引用 COPE/WAME/赫尔辛基宣言等须全文呈现并署来源或有效链接。
15. **Editorial Affiliation Details**：全体编辑团队（含特刊客座编辑）姓名+机构+国家；鼓励 ORCID/ResearcherID。
16. **Author Affiliation Details**：所有作者姓名+机构+国家；通讯作者应有邮箱。

## 5. Stage 3 · Editorial Evaluation — Quality（8 条）

17. **Editorial Board Composition**：编委机构、地理分布、发表记录须与 scope 和已发表内容一致；**编委会规模须与发文量和覆盖广度匹配**。
18. **Validity of Statements**：已发表内容须兑现期刊页面声明的各项政策；网站信息准确、最新；虚假声明会被调查。
19. **Peer Review**：内容须反映充分有效的同行评审（缺乏严谨性、超 scope、引文不相关均为缺陷信号）。
20. **Content Relevance**：scope 界定清晰、有聚焦；内容与题名、scope、特刊一致。
21. **Grant Support Details**：有资助惯例的学科应恰当标注基金来源。
22. **Adherence to Community Standards**：政策与 COPE 等最佳实践一致；文章符合学科规范。
23. **Author Distribution**：作者机构、地理分布与发表记录须证明其属于 scope 所在学术共同体。
24. **Appropriate Citations to the Literature**：恰当引用相关文献。

## 6. 影响力标准（4 条，仅用于 SCIE/SSCI/AHCI）

1. **Comparative Citation Analysis**：同类期刊比较；数量+来源+稳定性。
2. **Author Citation Analysis**：多数作者在 WoS 有可辨发表史，引用网络与学科匹配。
3. **EBM Citation Analysis**：多数编委在 WoS 有可辨发表史，引用网络与学科匹配。
4. **Content Significance**：内容对目标读者与 WoS 用户有重要性/独特性/区域焦点等价值。

## 7. 高频失分点核查清单（评估任何期刊必查）

共用模板出版社（如 TUP SciOpen 多刊）的高频错误——若目标期刊与已审计姊妹刊同源，逐项核对：

- [ ] 同一政策页内/两页之间**评审模式矛盾**（single-blind vs double-blind vs 实际操作）
- [ ] "**编辑可充当第二审稿人或单份报告定稿**"类条款（与外部评审要求冲突）
- [ ] **APC/免费期限在不同页面日期不一致**（指南页 vs 伦理页 vs 新闻稿）
- [ ] 医学/理科模板残留：公卫例外免评审、植物标本馆凭证标本、NMR/EDS 截图要求等与期刊领域无关的条款
- [ ] 政策页**错链**指向姊妹刊（URL 中的 journalId/issn 是别的刊）
- [ ] "AI 禁止爬取/训练（含 OA 内容）"与 CC BY 许可的**条款冲突**
- [ ] 预印本引用规则矛盾（伦理页要求必引 vs 参考文献规则"仅收录已发表/已录用"）
- [ ] 卷期节奏：期次标注 "In Progress" 的持续时间；1 期跨越多月；声明频率与实际不符
- [ ] 文章页是否显示 Received/Accepted/Published 三日期；Crossref 是否有 license/funder 字段
- [ ] eISSN 是否注册并在官网展示（初始分诊要求两版 ISSN 都提供）
- [ ] 编委会规模/学科覆盖 vs scope 宣称宽度的匹配（编委缺位某子领域是常见黄项）
- [ ] 内源性：主编/编委署名文章占比（历史卷期会被翻查；处理编辑是否标注）

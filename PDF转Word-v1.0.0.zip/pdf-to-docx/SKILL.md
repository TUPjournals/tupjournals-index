---
name: pdf-to-docx
description: 将 PDF 转换为适合后续审校的可编辑 Word（.docx），按页面恢复文字、字符形式、自然段、真实标题样式、原生脚注及图表公式。用于 PDF 转 Word、论文文字还原和转换噪声清理；不承担论文审校、纠错、润色或学术规范化。
metadata:
  developer: "凌峰若初"
  version: "1.0.0"
  updated: "2026-11-23"
---

# PDF 转 Word

开发者：凌峰若初  
版本号：1.0.0  
更新日期：2026-11-23

## 核心原则

转换必须忠实于 PDF 页面原文：保留原文内容与错误，仅修复有页面证据的转换错误。

转换只还原内容，不进行审校、纠错、润色或规范化。不自动调用论文编辑与审校类技能。可使用 PDF、documents 技能的解析、OOXML 与渲染技术；其中的改写、美化、标点统一、标题重写、默认模板和纯 ASCII 字符偏好不适用。

## 文件职责

| 文件 | 职责与读取时机 |
| --- | --- |
| [references/fidelity.md](references/fidelity.md) | 转换前读取：内容、字符、空格及原文错误的保留边界。 |
| [references/reconstruction.md](references/reconstruction.md) | 重建时读取：解析诊断、段落与阅读顺序、标题、图表公式。 |
| [references/notes.md](references/notes.md) | 源文含脚注或尾注时读取：原生注释、原标记、锚点与内部 ID。 |
| [references/verification.md](references/verification.md) | 构建验收时读取：来源核对、结构审计、渲染排查及交付门槛。 |
| `scripts/inspect_pdf.py` | 导出原始字符、坐标、字体、绘图线索和可选页图，不直接生成正文。 |
| `scripts/audit_docx.py` | 只读检查 Word 结构、注释关系和可选来源清单，不修改文本。 |
| `agents/openai.yaml` | 技能展示信息和默认调用提示。 |

## 执行流程

1. **定位与诊断**：定位源 PDF，检查页数、文本层、分栏、扫描页、图表公式及注释。使用当前环境的 workspace dependency loader 获取运行时与工具路径，不写死用户名、版本或历史路径。可运行 `scripts/inspect_pdf.py INPUT.pdf --output-dir TASK_TMP --render` 辅助诊断。
2. **建立来源映射**：按 `fidelity.md` 和 `reconstruction.md` 重建内容。每个输出段落、表格、图像和公式均可回查源页区域；技术修复、页眉页码排除项及不确定项记录在临时目录。
3. **恢复 Word 结构**：采用原生段落、真实表格和相应标题样式。一级、二级标题必须分别使用 `Heading 1`、`Heading 2`，原有标题文字及编号不变，不追加自动编号。图表公式按证据重建，无法可靠编辑化时保留原图。
4. **恢复注释**：脚注、尾注必须使用 Word 原生结构，原序号或符号及锚点位置不变。为每条注释分配独立内部 ID，逐条核对“正文锚点—原标记—注释全文”；不得只比较条数。实现细节见 `notes.md`。
5. **验证交付**：执行 `verification.md`，覆盖全部源页与全部输出页，核对文字、段落顺序、标题、图表公式、每条注释、参考文献和英文内容。结构审计不能替代源页核对与渲染验收。

## 命名与交付

- 交付标记使用“转换结果”，默认文件名为 `<PDF原文件名>_转换结果.docx`；用户指定名称时从其要求。
- 不在交付文件名、正文、封面、标题、批注或交付说明中添加“忠实”“忠实转换”等字样。
- 源 PDF 保持不变，技术记录留在临时目录。仅交付请求的 Word；必要的局部限制在交付说明中指出，不写入论文正文。

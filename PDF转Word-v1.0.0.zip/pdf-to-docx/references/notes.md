# 原标记脚注与尾注

## 原生结构与原始标记

脚注必须转换为 Word 原生脚注，不能以页脚、普通正文、文本框或文末注释清单替代；尾注保留为原生尾注。

- 建立“源页 + 注释顺序 + 原标记 + 正文锚点 + 完整注释文本”的逐条映射。
- 原序号或符号逐字保留，包括按页重启的序号；内部 ID 唯一，显示标记不必唯一。不用 Word 自动编号覆盖原标记。
- 锚点保留在原字词及标点的相对位置，并保留上标形式。作者简介星号对应原作者，不能转挂到题名。
- 同一注释的跨页续文合为同一条；不同注释即使同为①也不能合并。保留注释内的文字、标点、空格、引用和上下标。
- 正文参考文献引用序号不因形似上标而转成脚注。

## 对应关系先于版面

先记录原始位置与完整注释。例如同一份 PDF 的第 2 页①和第 5 页①是不同对象；内部 ID 可为 2、7，显示仍均为①。不要把 PDF 页码当作 Word 重排后的自动编号重启规则。

真实脚注的构成：

- `word/document.xml` 中的 `w:footnoteReference`。
- `word/footnotes.xml` 中相同 ID 的 `w:footnote`，通常另有 ID -1/0 的分隔符条目。
- `word/_rels/document.xml.rels` 中的 footnotes relationship。
- `[Content_Types].xml` 中的 footnotes content type。

正文的锚点和完整注释必须一一对应。不允许孤立引用、孤立注释、重复 ID 或跨注释错配。

## 自定义标记示意

以①为例，Word 支持下面的表示。实际写入路径需经目标 Word/渲染器验证；不要把 XML 看起来正确当作显示已验证。

正文锚点（标记紧随 reference）：

```xml
<w:r>
  <w:rPr><w:vertAlign w:val="superscript"/></w:rPr>
  <w:footnoteReference w:id="7" w:customMarkFollows="1"/>
  <w:t>①</w:t>
</w:r>
```

注释正文：

```xml
<w:footnote w:id="7">
  <w:p>
    <w:pPr><w:pStyle w:val="FootnoteText"/></w:pPr>
    <w:r><w:footnoteRef/></w:r>
    <w:r><w:t>注释原文……</w:t></w:r>
  </w:p>
</w:footnote>
```

`w:footnoteRef` 负责显示关联标记，不在其后再写一个字面①。注释开头同时存在自动标记和字面标记时，LibreOffice 可能显示“①①”。用相同办法处理原始星号等自定义符号。不要把自动数字与字面标记叠加。

`FootnoteText` 是样式 ID，显示名称可为 `Footnote Text`。仅创建样式不能创建真实脚注。使用 python-docx 时可通过 OPC Part/relationship 建立整个注释部件；也可用经过验证的 OOXML helper。不要把注释放在 `footer*.xml`。

尾注使用 `endnoteReference`、`endnotes.xml`、`endnoteRef` 和对应 relationship/content type。原文尾注不因排版便利而改成脚注。

## 三层验收

1. **结构**：关系和内容类型齐全；ID 唯一；每个普通注释均有正确锚点；每个锚点都能解析到注释。正文引文序号不被误识别为脚注。
2. **内容**：按来源逐条比较原标记、正文锚点前后文字和注释全文。保留注释内上/下标、斜体和跨页续文。注释数只是一项辅助核对。
3. **显示**：渲染后查全部正文标记和注释开头，确认原标记一致、只显示一次、大小与上标正确、未截断、未串注。同一输出页中重复①若来自不同源页，可为正确结果。

审计清单的 `notes` 可以用内部 ID 作为键，包含 `marker`、`text`、`anchor_before`、`anchor_after`；其中 `text` 不再包含自动显示的开头标记。锚点上下文按正文 XML 文本记录，必要时跨 run 聚合，不凭单一 run 判断。

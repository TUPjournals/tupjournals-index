#!/usr/bin/env python3
"""Inspect DOCX structure and optionally compare a source-verified manifest; never edit it."""
import argparse
import collections
import json
import posixpath
from pathlib import Path
import re
import unicodedata
from zipfile import ZipFile
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
R = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'
NS = {'w': W, 'm': M, 'r': R, 'ct': CT}
PARSER = etree.XMLParser(resolve_entities=False, no_network=True)


def tag(name):
    return '{' + W + '}' + name


def text_of(element):
    result = []
    for item in element.iter():
        if item.tag in (tag('t'), '{' + M + '}t'):
            result.append(item.text or '')
        elif item.tag == tag('tab'):
            result.append('\t')
        elif item.tag in (tag('br'), tag('cr')):
            result.append('\n')
    return ''.join(result)


def first_marker(text):
    if not text:
        return ''
    match = re.match(r'\d+', text)
    if match:
        return match.group()
    end = 1
    while end < len(text) and (unicodedata.combining(text[end]) or text[end] in '\ufe0e\ufe0f'):
        end += 1
    return text[:end]


def context(reference, kind):
    paragraph = reference
    while paragraph is not None and paragraph.tag != tag('p'):
        paragraph = paragraph.getparent()
    if paragraph is None:
        return '', '', ''
    before, after = [], []
    seen = False
    for item in paragraph.iter():
        if item is reference:
            seen = True
        elif item.tag in (tag('t'), '{' + M + '}t'):
            (after if seen else before).append(item.text or '')
    following = ''.join(after)
    custom = reference.get(tag('customMarkFollows')) in ('1', 'true', 'on')
    marker = first_marker(following) if custom else None
    return ''.join(before), following[len(marker):] if marker else following, marker


def audit(path, manifest=None):
    report = {'file': str(path.resolve()), 'errors': [], 'warnings': [], 'comparisons': []}
    errors, warnings = report['errors'], report['warnings']
    with ZipFile(path) as package:
        members = set(package.namelist())
        def read(name):
            return etree.fromstring(package.read(name), PARSER)
        document = read('word/document.xml')
        styles = read('word/styles.xml')
        relations = read('word/_rels/document.xml.rels')
        content_types = read('[Content_Types].xml')
        body = document.find('w:body', NS)
        paragraphs = [p for p in body.iter(tag('p')) if text_of(p)]
        body_texts = [text_of(p) for p in paragraphs]
        style_map = {s.get(tag('styleId')): s for s in styles.findall('w:style', NS)}
        headings = []
        for paragraph in paragraphs:
            style_id = paragraph.xpath('string(w:pPr/w:pStyle/@w:val)', namespaces=NS)
            if re.fullmatch(r'Heading[1-9]', style_id):
                level = int(style_id[-1])
                headings.append({'level': level, 'text': text_of(paragraph)})
                chain, visited = [paragraph], set()
                while style_id and style_id not in visited:
                    visited.add(style_id)
                    st = style_map.get(style_id)
                    if st is None:
                        break
                    chain.append(st)
                    style_id = st.xpath('string(w:basedOn/@w:val)', namespaces=NS)
                if any(e.find('w:pPr/w:numPr', NS) is not None for e in chain):
                    warnings.append('Heading has automatic numbering; compare against the printed source: ' + text_of(paragraph))
        report['body_paragraph_count'] = len(paragraphs)
        report['headings'] = headings
        report['table_count'] = len(body.findall('.//w:tbl', NS))
        report['manual_break_count'] = len(body.findall('.//w:br', NS)) + len(body.findall('.//w:cr', NS))
        report['native_math_count'] = len(body.findall('.//m:oMath', NS))
        report['drawing_count'] = len(body.findall('.//w:drawing', NS))
        if report['manual_break_count']:
            warnings.append('Manual breaks exist; verify they are logical breaks, not PDF physical line wrapping.')
        if manifest and 'body_paragraphs' in manifest:
            report['comparisons'].append('body_paragraphs')
            expected = manifest['body_paragraphs']
            if expected != body_texts:
                for i in range(max(len(expected), len(body_texts))):
                    a = expected[i] if i < len(expected) else None
                    b = body_texts[i] if i < len(body_texts) else None
                    if a != b:
                        errors.append({'body_paragraph': i + 1, 'expected': a, 'actual': b})
        if manifest and 'headings' in manifest:
            report['comparisons'].append('headings')
            if manifest['headings'] != headings:
                errors.append({'headings_mismatch': True})
        all_text = list(body_texts)
        for kind, part, manifest_key in [('footnote', 'word/footnotes.xml', 'notes'), ('endnote', 'word/endnotes.xml', 'endnotes')]:
            references = document.findall('.//w:' + kind + 'Reference', NS)
            ids = [r.get(tag('id')) for r in references]
            duplicate_refs = [i for i, count in collections.Counter(ids).items() if count > 1]
            if duplicate_refs:
                errors.append({kind + '_duplicate_reference_ids': duplicate_refs})
            if part not in members:
                if ids or manifest and manifest.get(manifest_key):
                    errors.append(kind + ' part missing')
                report[manifest_key] = {}
                continue
            root = read(part)
            entries = [e for e in root.findall('w:' + kind, NS)
                       if e.get(tag('type')) not in ('separator', 'continuationSeparator', 'continuationNotice')]
            note_ids = [e.get(tag('id')) for e in entries]
            if len(note_ids) != len(set(note_ids)):
                errors.append(kind + ' duplicate note IDs')
            if set(ids) != set(note_ids):
                errors.append({kind + '_unmatched_ids': {'references_only': sorted(set(ids) - set(note_ids)),
                                                       'notes_only': sorted(set(note_ids) - set(ids))}})
            matching_rels = [r for r in relations if r.get('Type', '').endswith('/' + kind + 's')]
            if not any(posixpath.normpath(posixpath.join('word', r.get('Target', ''))).lstrip('/') == part
                       or r.get('Target', '').lstrip('/') == part for r in matching_rels):
                errors.append(kind + ' relationship missing or incorrect')
            if not any(c.get('PartName') == '/' + part and c.get('ContentType', '').endswith('.' + kind + 's+xml')
                       for c in content_types):
                errors.append(kind + ' content type missing or incorrect')
            notes = {}
            for entry in entries:
                note_id = entry.get(tag('id'))
                refs = [r for r in references if r.get(tag('id')) == note_id]
                before, after, marker = context(refs[0], kind) if refs else ('', '', None)
                content = '\n'.join(text_of(p) for p in entry.findall('w:p', NS))
                notes[note_id] = {'marker': marker, 'text': content,
                                  'anchor_before': before, 'anchor_after': after}
                all_text.append(content)
                if marker and content.startswith(marker):
                    warnings.append({kind + '_possible_duplicate_marker': note_id,
                                     'reason': 'Literal marker starts note text; inspect rendered output.'})
            report[manifest_key] = notes
            if manifest and manifest_key in manifest:
                report['comparisons'].append(manifest_key)
                expected = manifest[manifest_key]
                if set(expected) != set(notes):
                    errors.append(kind + ' manifest ID set differs')
                for note_id, fields in expected.items():
                    actual = notes.get(note_id)
                    if actual is None:
                        continue
                    for field in ('marker', 'text'):
                        if field in fields and fields[field] != actual[field]:
                            errors.append({kind: note_id, 'field': field,
                                           'expected': fields[field], 'actual': actual[field]})
                    if 'anchor_before' in fields and not actual['anchor_before'].endswith(fields['anchor_before']):
                        errors.append({kind: note_id, 'field': 'anchor_before', 'mismatch': True})
                    if 'anchor_after' in fields and not actual['anchor_after'].startswith(fields['anchor_after']):
                        errors.append({kind: note_id, 'field': 'anchor_after', 'mismatch': True})
        for member in sorted(members):
            if re.fullmatch(r'word/(?:header|footer)\d+\.xml', member):
                all_text.append(text_of(read(member)))
        combined = '\n'.join(all_text)
        suspicious = sorted({c for c in combined if c == '\ufffd' or unicodedata.category(c) == 'Co'})
        if suspicious:
            warnings.append({'character_review_required': [{'char': c, 'codepoint': f'U+{ord(c):04X}'} for c in suspicious]})
        if not manifest:
            warnings.append('No source-verified manifest supplied; content fidelity and anchor placement have not been compared.')
    report['passed'] = not errors
    report['notice'] = 'Structural diagnostics only. Warnings require source-page review; no text has been corrected.'
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('docx', type=Path)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--output-json', type=Path)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding='utf-8')) if args.manifest else None
    report = audit(args.docx, manifest)
    serialized = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(serialized, encoding='utf-8')
        print(json.dumps({'passed': report['passed'], 'errors': len(report['errors']),
                          'warnings': len(report['warnings']), 'output': str(args.output_json.resolve())}, ensure_ascii=False))
    else:
        print(serialized)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

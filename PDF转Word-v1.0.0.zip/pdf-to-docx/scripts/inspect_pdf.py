#!/usr/bin/env python3
"""Read-only PDF inventory. Output is diagnostic evidence, never final prose."""
import argparse
import collections
import json
from pathlib import Path
import unicodedata


def private_use(text):
    return any(unicodedata.category(c) == 'Co' for c in text)


def inventory(source, destination, render=False, scale=1.8):
    import pdfplumber
    renderer = None
    if render:
        import pypdfium2
        renderer = pypdfium2.PdfDocument(str(source))
    destination.mkdir(parents=True, exist_ok=True)
    result = {'source': str(source.resolve()), 'pages': [],
              'notice': 'Raw characters and origin groups require visual verification; no normalization or correction applied.'}
    with pdfplumber.open(source) as pdf:
        for number, page in enumerate(pdf.pages, 1):
            glyphs = []
            groups = []
            for index, char in enumerate(page.chars):
                matrix = char.get('matrix')
                origin_y = page.height - matrix[5] if matrix else None
                glyph = {'index': index, 'text': char['text'],
                         'x0': char['x0'], 'x1': char['x1'],
                         'top': char['top'], 'bottom': char['bottom'],
                         'size': char['size'], 'font': char['fontname'],
                         'matrix': matrix, 'origin_y': origin_y,
                         'upright': char.get('upright'),
                         'whitespace': char['text'].isspace()}
                glyphs.append(glyph)
                if origin_y is None or glyph['whitespace']:
                    continue
                matching = [g for g in groups if abs(g['origin_y'] - origin_y) <= .8]
                if matching:
                    group = min(matching, key=lambda g: abs(g['origin_y'] - origin_y))
                else:
                    group = {'origin_y': origin_y, 'indices': []}
                    groups.append(group)
                group['indices'].append(index)
            for group in groups:
                group['indices'].sort(key=lambda i: glyphs[i]['x0'])
                group['raw_text_without_whitespace'] = ''.join(glyphs[i]['text'] for i in group['indices'])
            groups.sort(key=lambda g: g['origin_y'])
            font_counts = collections.Counter((g['font'], round(g['size'], 2)) for g in glyphs)
            short_paths = [dict(x0=line['x0'], x1=line['x1'], top=line['top'],
                                bottom=line['bottom'], width=line['width'], linewidth=line.get('linewidth'))
                           for line in page.lines if line['height'] < .15 and 0 < line['width'] <= 24]
            page_data = {'page': number, 'width': page.width, 'height': page.height,
                         'characters': glyphs, 'lines_by_origin': groups,
                         'image_count': len(page.images), 'line_count': len(page.lines),
                         'curve_count': len(page.curves),
                         'fonts': [{'name': f, 'size': s, 'count': count} for (f, s), count in font_counts.items()],
                         'private_use_indices': [g['index'] for g in glyphs if private_use(g['text'])],
                         'short_horizontal_paths': short_paths}
            (destination / f'page-{number}.json').write_text(json.dumps(page_data, ensure_ascii=False, indent=2), encoding='utf-8')
            summary = {k: page_data[k] for k in ['page', 'width', 'height', 'image_count', 'line_count', 'curve_count']}
            summary.update(character_count=len(glyphs), private_use_count=len(page_data['private_use_indices']),
                           origin_group_count=len(groups), short_horizontal_path_count=len(short_paths))
            if renderer:
                rendered_page = renderer[number - 1]
                bitmap = rendered_page.render(scale=scale)
                bitmap.to_pil().save(destination / f'page-{number}.png')
                bitmap.close()
                rendered_page.close()
            result['pages'].append(summary)
    if renderer:
        renderer.close()
    (destination / 'inventory.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--scale', type=float, default=1.8)
    args = parser.parse_args()
    if args.scale <= 0:
        parser.error('--scale must be positive')
    result = inventory(args.pdf, args.output_dir, args.render, args.scale)
    print(json.dumps({'pages': len(result['pages']), 'output_dir': str(args.output_dir.resolve()),
                      'characters': sum(p['character_count'] for p in result['pages'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()

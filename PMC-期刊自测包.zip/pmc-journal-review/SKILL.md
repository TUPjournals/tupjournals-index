---
name: pmc-journal-review
description: 评估期刊是否适合申请 PMC（PubMed Central）收录。当用户询问某期刊适不适合进 PMC、要求按 PMC 参与指南逐条核对（范围、语言、同行评审、协议类型、禁运、XML 技术要求等）、判断 NLM/MEDLINE 收录状态、选择 Full Participation / NIH Portfolio / Selective Deposit 协议、准备申请材料或分析被拒原因时使用。触发词：PMC 收录评估、PMC 申请、PubMed Central、NLM 收录、MEDLINE 期刊申请。
agent_created: true
---

# PMC 期刊收录适配性评估

对任意一本期刊（给定官网 URL 或 ISSN）完成"是否适合申请 PMC"的完整评估，产出单页 HTML 报告。评估依据唯一权威清单见 `references/criteria.md`（PMC Policies，pmc.ncbi.nlm.nih.gov/about/guidelines/，2026-08 版），判定前必须加载。

PMC 的核心特点是**先查现状再谈申请**：已收录 MEDLINE 的期刊一般免科学审查可直接进 PMC，未收录的须走完整评估且受严格语言门槛限制。所以评估的第一步永远是查 NLM Catalog。

## 流程

### 1. 采集证据（先采集，后判定）

- 运行 `python scripts/evidence.py --issn <ISSN>`，一次性获取：
  - **NLM Catalog**：`currently_indexed_for_medline`（"Currently indexed for MEDLINE"）与 `in_pmc`（"In: PubMed: ..., PMC"）→ 直接决定评估路径（见第 2 步）。
  - **Crossref**：近三年发文量（评估出版节奏与两年主要内容要求）、最近 20 篇文章的 license/funder 字段（评估 OA 模式与 NIH 资助比例）。
- 抓取期刊官网：主页、Aims & Scope、Editorial Board、Peer Review Policy（PMC 四要素之核心）、Editorial Policies、投稿指南、许可/版权条款、订阅或访问方式（机构访问 vs 注册墙）、抽样 2–3 篇文章页（文章类型、基金、许可声明）。

### 2. 按现状分流（三条路径）

- **路径 A：已参与 PMC**（in_pmc=True）→ 不是"是否申请"问题，而是"持续合规"问题：核对协议类型、禁运是否 ≤12 个月、技术数据质量、出版节奏，提示变更通报义务。
- **路径 B：已收录 MEDLINE 但未进 PMC** → 最优路径：免科学质量审查，可选三种协议（NIH Portfolio 需 NIH 资助文章占比）；重点核对语言之外的运营与技术要求。
- **路径 C：未收录 MEDLINE** → 须走全新申请：先核硬门槛——学科在 NLM Collection 范围（生物医学/生命科学）、**主要内容以英文为主**（除非西班牙语）、电子期刊访问方式合规；再按 PMC Scope 四要素与科学质量评审逐条判定，周期最长、拒后 2 年禁重申。

### 3. 逐条判定

- 先核第 1–2 节硬门槛（范围、语言、访问方式、同行评审政策公示、期刊掌控评审流程）。
- 再核对第 3 节协议类型适配：Full / NIH Portfolio / Selective Deposit 各自资格条件，结合 funder 数据给推荐。
- 第 4–7 节科学质量、技术质量（XML/JATS、高分辨率图、PDF、补充材料——多数中小刊的技术短板）、出版节奏（**两年无主要内容即终止**）、变更通报。
- 第 9–12 节存入政策要点（更正/撤稿即时公开、赞助增刊文内披露、禁运 ≤12 个月、OA 文章不设禁运）逐项给 绿/黄/红。
- 出版方层面红线单独提示：违反行业最佳实践 → 出版社**至少 3 年**不得向 NLM 任何文献库申请（伤及姊妹刊）。

### 4. 结论与建议

- 结论先行 + P0/P1/P2 整改清单（P0 = 触碰硬门槛或会导致自动拒绝/终止的项）。
- 明确告知流程代价：申请 2 年未完成即过期；初审/科学审查未通过 2 年禁重申、技术评估未通过 1 年禁重申；因质量/范围重申须先发表 ≥20 篇主要同行评审文章；决定一般不可上诉。
- 若结论为"暂不建议申请 PMC"，给替代路径建议（如先修 MEDLINE 评估、或先走 DOAJ/ESCI，见配套技能）。

### 5. 报告产出

- 复制 `assets/report-template.html` 填充生成报告，present_files 交付；语言与用户一致（默认中文）。
- 判定表按"现状分流 → 硬门槛 → 协议适配 → 运营/技术 → 存入政策"分阶段分组。

## 配套技能

`esci-journal-review`（ESCI/WoS）、`scopus-journal-review`（Scopus）、`doaj-journal-review`（DOAJ）、`cope-ethics-review`（出版伦理完备性）。与 ESCI/Scopus 不同：PMC 不看影响因子与引用指标，看的是 NLM Collection 范围与运营规范；且 MEDLINE 收录与否是 PMC 的分水岭。COPE 伦理审查结果可直接支撑 PMC 的 Publisher Practices 判定。若期刊尚未进 MEDLINE，通常先走 DOAJ（最轻量）夯实政策合规，再评估 MEDLINE/PMC。

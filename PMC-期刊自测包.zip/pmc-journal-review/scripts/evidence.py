#!/usr/bin/env python3
"""采集期刊 PMC 申请评估所需的第三方数据证据（Crossref + NLM Catalog）。

用法:
    python evidence.py --issn 1660-4601 [--output out.json]

输出 JSON 包含:
  - nlm.catalog      : NLM Catalog 记录原文摘录（Current Indexing Status / In: PubMed 行）
                       —— 由此判定 MEDLINE 收录与 PMC 参与状态：
                          "Currently indexed for MEDLINE" = 已收录 MEDLINE
                          "In: PubMed: ..., PMC" = 已参与 PMC
  - nlm.esummary     : NLM Catalog 结构化摘要（题名、出版方、ISSN、起始年）
  - crossref.journal : Crossref 期刊级元数据（题名、出版方、逐年发文量、DOI 总量）
                       —— 用于评估出版节奏与两年内主要内容产出
  - crossref.recent  : 最近 20 篇文章的类型/日期/许可/基金字段完整度
                       —— funder 比例用于评估 NIH Portfolio / Selective Deposit 适配度

依赖: 仅标准库 urllib。网络不可用时各 section 返回 {"error": "..."}，不中断整体。
"""
import argparse
import json
import sys
import urllib.request

UA = {"User-Agent": "pmc-journal-review/1.0 (mailto:editorial-audit@example.com)"}


def get_text(url, timeout=30):
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8")
    except Exception as exc:  # noqa: BLE001
        return f"__ERROR__ {type(exc).__name__}: {exc}"


def get_json(url, timeout=30):
    t = get_text(url, timeout)
    if t.startswith("__ERROR__"):
        return {"error": t[len("__ERROR__ "):]}
    try:
        return json.loads(t)
    except Exception as exc:  # noqa: BLE001
        return {"error": f"JSONDecodeError: {exc}"}


def nlm_catalog(issn):
    # NLM Catalog 支持按 ISSN 检索，可能命中多卷/多版记录
    s = get_json(
        "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
        f"?db=nlmcatalog&term={issn}%5BISSN%5D&retmode=json"
    )
    if "error" in s:
        return s
    ids = s.get("esearchresult", {}).get("idlist", [])
    out = {"record_ids": ids, "records": []}
    for uid in ids[:3]:
        text = get_text(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
            f"?db=nlmcatalog&id={uid}&retmode=text"
        )
        rec = {"uid": uid}
        if text.startswith("__ERROR__"):
            rec["error"] = text[len("__ERROR__ "):]
        else:
            keep = (
                "Title Abbreviation", "Title(s):", "ISSN:", "Publisher:",
                "Publication Start Year", "Publication End Year",
                "Current Indexing Status", "In: PubMed", "Fully Indexed In",
                "Current Subset", "Language:", "Country of Publication",
                "Electronic Links",
            )
            rec["excerpt"] = [
                ln.strip() for ln in text.splitlines()
                if any(ln.strip().startswith(k) for k in keep)
            ]
            rec["currently_indexed_for_medline"] = (
                "Currently indexed for MEDLINE" in text
            )
            rec["in_pmc"] = bool("PMC" in text.replace("PubMed Central", "PMC")
                                 and "In: PubMed" in text)
            rec["full_text"] = text[:4000]
        out["records"].append(rec)
    # 结构化摘要（取第一个 id）
    if ids:
        sm = get_json(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
            f"?db=nlmcatalog&id={ids[0]}&retmode=json"
        )
        if "error" not in sm:
            d = sm.get("result", {}).get(ids[0], {})
            out["esummary"] = {
                "title_abbrev": d.get("titlemainsort") or "",
                "title": (d.get("titlemainlist") or [{}])[0].get("title", ""),
                "issns": [
                    {"issn": i.get("issn"), "type": i.get("issntype")}
                    for i in d.get("issnlist", [])
                ],
                "start_year": d.get("startyear"),
                "end_year": d.get("endyear"),
            }
    return out


def _works_total(issn, year):
    d = get_json(
        f"https://api.crossref.org/works?filter=issn:{issn}"
        f",from-pub-date:{year}-01-01,until-pub-date:{year}-12-31&rows=0"
    )
    if "error" in d:
        return None
    return d.get("message", {}).get("total-results")


def crossref_journal(issn):
    d = get_json(f"https://api.crossref.org/journals/{issn}")
    if "error" in d:
        return d
    m = d.get("message", {})
    import datetime
    y = datetime.date.today().year
    counts = {str(yy): _works_total(issn, yy) for yy in (y, y - 1, y - 2)}
    return {
        "title": m.get("title"),
        "publisher": m.get("publisher"),
        "issns": m.get("issn-type", []),
        "counts_recent_years": counts,
        "total_dois": m.get("counts", {}).get("total-dois"),
    }


def crossref_recent(issn, rows=20):
    d = get_json(
        f"https://api.crossref.org/journals/{issn}/works"
        f"?rows={rows}&sort=published&order=desc"
        "&select=DOI,title,published,license,funder,type"
    )
    if "error" in d:
        return d
    out = []
    for it in d.get("message", {}).get("items", []):
        out.append(
            {
                "doi": it.get("DOI"),
                "type": it.get("type"),
                "published": it.get("published", {}).get("date-parts"),
                "has_license": bool(it.get("license")),
                "license_urls": [l.get("URL") for l in it.get("license", [])][:2],
                "funders": [
                    f.get("name") for f in it.get("funder", [])
                ][:5],
            }
        )
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--issn", required=True, help="期刊 ISSN（印刷版或电子版均可）")
    ap.add_argument("--output", help="输出 JSON 文件路径（默认打印到 stdout）")
    args = ap.parse_args()

    result = {
        "issn": args.issn,
        "nlm_catalog": nlm_catalog(args.issn),
        "crossref": {"journal": crossref_journal(args.issn),
                     "recent": crossref_recent(args.issn)},
    }
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"saved -> {args.output}")
    else:
        print(text)


if __name__ == "__main__":
    sys.exit(main())

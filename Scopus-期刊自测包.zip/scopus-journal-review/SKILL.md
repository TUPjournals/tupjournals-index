---
name: scopus-journal-review
description: 评估期刊是否适合申请 Elsevier Scopus 收录。当用户询问某期刊适不适合进 Scopus、要求按 CSAB 五大标准/技术资格条件逐条评估、分析被拒风险/整改建议/申请时机，或讨论 Title Suggestion Form 提交流程时使用。触发词：Scopus 收录评估、CSAB、Scopus 申请、Elsevier 期刊索引、Scopus Title Evaluation。
agent_created: true
---

# Scopus 期刊收录适配性评估

对任意一本期刊（给定官网 URL 或 ISSN）完成"是否适合申请 Scopus"的完整评估，产出单页 HTML 报告。评估依据唯一权威清单见 `references/criteria.md`，判定前必须加载。

## 流程

### 1. 采集证据（先采集，后判定）

- 抓取期刊官网：主页（题名/ISSN/出版方/英文界面）、Aims & Scope、Editorial Board（人数/国别/机构）、Submission Guidelines（同行评审类型与流程描述）、Publishing Ethics / PEAMS 相关声明、**全部卷期页**（逐期文章数与出版日期 → 出版规律性）、抽样 2–3 篇文章页（摘要质量/参考文献罗马字母/Received-Accepted-Published 日期）。
- 运行 `python scripts/evidence.py --issn <ISSN>` 获取 Crossref 年发文量、license/funder 完整度与 DOAJ 收录状态（DOAJ/其他数据库收录是第三方背书信号）。
- 与出版社姊妹刊交叉核对政策文本，提取共用模板错误。

### 2. 逐条判定

- 先核 `references/criteria.md` 第 1 节的 **5 项技术资格条件**（任一不满足则不具备申请资格，直接给出整改项）。
- 再按第 2 节 **CSAB 五大评审标准**逐类给出 绿/黄/红 + 一句依据；对"期刊地位"区分"被引短板"（时间可解）与"编辑声望"（可主动强化）。
- 对第 5 节"高频失分点核查清单"逐项过一遍；判定必须对应实际抓取的证据。

### 3. 结论与建议

- 结论先行 + P0/P1/P2 整改清单（标注对应标准）。
- 申请时机结合：无明确年限门槛但需"可供评审的出版历史"；**被拒不公开禁投期、上诉窗口仅 6 周且仅限事实错误**；重大变更（刊名/ISSN/编辑权）视为新刊——避免在申请前后做此类调整。
- 提示双通道：常规 Title Suggestion Form + 出版社与 Elsevier 的主动纳入管道。

### 4. 报告产出

- 复制 `assets/report-template.html` 填充生成报告（结论先行 → 现状快照 → 逐条判定表 → 问题清单 → 时间表），present_files 交付；语言与用户一致（默认中文）。

## 配套技能

`doaj-journal-review`（DOAJ）、`esci-journal-review`（ESCI/WoS）。三个库的政策整改项高度重叠，先做一套统一整改再分别提交；推荐顺序通常为 DOAJ → Scopus → ESCI。

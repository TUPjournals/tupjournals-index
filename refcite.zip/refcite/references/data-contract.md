# 后台数据约定

由 `scan.py 提取.json --init-ledger -o 台账.json` 生成实际源文件的骨架，不手工假造来源哈希或覆盖清单。JSON保持UTF-8，日期记录真实检索时点；人工判断不能由脚本填空推定完成。

## 核查台账

顶层：`source/source_sha256`、`extraction/extraction_sha256`、`scope`、`profile_status`、`inventory`、`coverage`、`candidates`、`references`、`citations`、`issues`、`delivery`。

- `scope`：`full_document`或`reference_list_only`等真实范围。仅列表输入的文内引用数可为0，但必须在delivery.limitations写明输入不足，不报告“无文内漏引”。
- `inventory`：独立人工确认的条目/引文原子数量，以及references_complete、citations_complete、reverse_review_complete。范围不适用时注明限定范围完成，不伪称全文。
- `coverage`：一个实际文本单元一行，附加图内/OCR单元允许另加。state为checked/excluded/unreadable；每轮完成才设true。排除/不可读填写reason，后者关联issue_ids。
- `candidates`：scan生成的每个候选均保留，decision为citation/not_citation/unresolved_noted，填写reason；citation关联citation_ids，未解决关联issue_ids。人工发现的无括号引文也进入citations。

## 文末条目

```json
{
  "id": "r001", "raw": "保留完整原题录", "location": "文末第1条",
  "authors": ["person:001", "person:002"], "identities_verified": true,
  "year": "2021", "suffix": "a", "version": "实际引用版本说明",
  "verified_group_id": null, "issue_ids": [],
  "verification": {
    "status": "verified", "reason": "目标版本与关键字段相符",
    "searches": [{"source_family": "publisher", "query": "公开题名+作者", "date": "实际日期", "outcome": "找到目标版本"}],
    "evidence": [{"url": "可复核来源地址", "locator": "文章首页/目录位置", "retrieved_at": "实际检索时点"}],
    "field_checks": {"authors": "相符", "title": "相符", "year": "相符", "version": "已确认"}
  },
  "usage": {"status": "cited", "citation_ids": ["c001"]}
}
```

evidence可用local_source替代url并写明本地原始页位置。authors中是核准的实体键，不能填未经核实的首姓缩写假装已消歧。verified_group_id仅用于核准的同一版本双语题录；paired条目另记usage.representative_id。uncited须理由和issue_ids，allowed_uncited须basis。

## 文内引文原子

```json
{
  "id": "c001", "occurrence_id": "o001", "raw": "保留原引文",
  "location": "源单元ID与精确范围", "authors": ["person:001"],
  "etal": true, "identities_verified": true, "year": "2021", "suffix": "a",
  "issue_ids": [],
  "crosscheck": {"status": "matched", "reference_ids": ["r001"], "reason": "身份、年份、后缀与版本均已核定"},
  "relevance": {"status": "not_flagged", "report": false}
}
```

crosscheck状态详见crosscheck.md。一个matched原子指向一个代表版本，反向usage必须列此原子。作者、年份或后缀与严格匹配结果不符而经人工核准成立时，在crosscheck.manual_override填写reason及evidence（可复核来源/版本依据），不得仅为通过验收写“人工确认”。直接引文页码单独保留，不混入year。无日期年份用`n.d.`等统一内部键，原表述留raw。初始扫描候选不删除、不改变原文范围，只改变裁决与关联；未解决状态必须关联confirmed/query的有效问题，不能链接已拒绝意见掩盖差异。

relevance默认not_flagged，只代表轻量筛查未触发。触发后才填trigger、level、reason、locator。要报告内容问题还须report=true、clear_evidence=true及问题ID；一般不确定性留后台。

## 问题与交付

issue字段：`id`、`order`（稳定物理顺序）、`category`、`location`、`original`、`comment`（可直接写入批注）、`reason`（证据/冲突说明）、`decision`（confirmed/query/rejected/resolved）、`annotation_status`（written/linked_anchor/failed_disclosed），以及可选sources/旧意见去向。

delivery记录annotations_complete、source_preserved、visual_checked及limitations。只在实际检查后写true；机械检查成功不意味着视觉检查已完成。failed_disclosed是明确披露的能力限制，不代表批注已写入。

## 批注计划

```json
{
  "source_sha256": "实际源哈希", "reviewer": "文献核查",
  "annotations": [{
    "issue_id": "i001", "part": "word/document.xml", "paragraph": 12,
    "start": 4, "end": 8, "expected": "实际原文", "comment": "具体核查意见"
  }]
}
```

DOCX偏移为Unicode字符，start从0开始，end不包含末字符。脚本只处理安全的正文普通run，拒绝复杂结构后须按annotations.md走替代定位。PDF每条改用page（从1开始）、char_start（PDFium索引，从0开始）、char_count、expected、kind（query/confirmed）。自定义quads还须visually_verified、reason，扫描区增加image_only=true。定位不可靠时不强行写入。

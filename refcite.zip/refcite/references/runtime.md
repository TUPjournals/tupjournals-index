# 后台运行说明

这些命令服务执行者，不需让普通用户手工运行。将`SKILL_DIR`替换为实际技能目录，`python`替换为具备相应依赖的Python 3.10+。工作文件留在项目`work/refcite-private/`。

## 最小流程

```bash
python SKILL_DIR/scripts/extract.py 稿件.docx -o work/refcite-private/extracted.json
python SKILL_DIR/scripts/scan.py work/refcite-private/extracted.json --init-ledger -o work/refcite-private/ledger.json
```

人工依data-contract.md补录并裁决，不把空骨架当成果。

```bash
python SKILL_DIR/scripts/match.py work/refcite-private/ledger.json -o work/refcite-private/matches.json
python SKILL_DIR/scripts/lookup.py --doi 10.xxxx/公开标识符 --cache-dir work/refcite-private/cache -o work/refcite-private/evidence.json
python SKILL_DIR/scripts/lookup.py --query "公开题名 作者" --cache-dir work/refcite-private/cache -o work/refcite-private/evidence.json
```

检索脚本需要网络权限，失败时改用可用的网络检索工具；不能因某一接口失败宣布未检得。只有公开题录字段可传给外部查询。不从示例命令中的占位标识符发起真实检索。

```bash
python SKILL_DIR/scripts/annotate.py add 稿件.docx work/refcite-private/plan.json -o 批注稿.docx --receipt work/refcite-private/receipt.json
python SKILL_DIR/scripts/annotate.py pdf-chars 稿件.pdf --page 1 -o work/refcite-private/page1-chars.json
python SKILL_DIR/scripts/annotate.py add 稿件.pdf work/refcite-private/plan.json -o 批注稿.pdf --receipt work/refcite-private/receipt.json
python SKILL_DIR/scripts/audit.py work/refcite-private/ledger.json -o work/refcite-private/audit.json --report work/refcite-private/report.md
python SKILL_DIR/scripts/report_docx.py work/refcite-private/ledger.json -o 核查报告.docx
```

`audit.py`未闭环时退出码2，报告标为未完成验收。它校验数量、来源、双向链接、证据字段和处置状态，不能判断检索是否充分、内容是否真实或视觉定位是否正确。前台报告使用中文状态名，不显示候选日志；最终Word报告遵循墨蓝标题、黑色正文、宋体与Times New Roman。

## 依赖和边界

提取DOCX/TXT、扫描、匹配、检索、审计、DOCX批注为Python标准库。PDF需要pypdf和pypdfium2；Word报告需要python-docx。组件缺失时优先使用现有运行时，不把本机运行时绝对路径写进分发包。不依赖另四个审稿技能安装。

DOCX复杂审阅结构由文档原生能力补位；PDF旋转/非零裁切框需适配几何，不静默忽略。无可靠原文件批注能力时仍做核查与定位报告，明确哪些问题未能写入原生批注。

新安装可运行：`python -m unittest discover -s SKILL_DIR/tests -v`。PDF测试在组件不可用时明确skip；运行报告中须区分已测试与未测试。测试只用合成样本和模拟网络响应，不上传真实稿件、不需要联网。

#!/usr/bin/env python3
"""Add native comments to a new DOCX/PDF; reject unsafe or stale anchors explicitly."""
from __future__ import annotations
import argparse
import io
import math
import statistics
import uuid
import zipfile
from pathlib import Path
from xml.dom import minidom as dom
from xml.etree import ElementTree as ET
from common import W, q, digest, load, write, require_distinct, atomic_bytes, visible

REL = 'http://schemas.openxmlformats.org/package/2006/relationships'
CTYPE = 'http://schemas.openxmlformats.org/package/2006/content-types'
COMMENTS_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments'

def local(node):
    return node.localName if node.nodeType == node.ELEMENT_NODE else None

def children(node):
    return [n for n in node.childNodes if n.nodeType == n.ELEMENT_NODE]

def el(doc, name, attrs=None, text=None):
    node = doc.createElementNS(W, 'w:' + name)
    for k, v in (attrs or {}).items():
        node.setAttributeNS(W, 'w:' + k, str(v))
    if text is not None:
        node.appendChild(doc.createTextNode(text))
    return node

def text_run(doc, text, props=None):
    r = el(doc, 'r')
    if props is not None:
        r.appendChild(props.cloneNode(True))
    t = el(doc, 't', text=text)
    t.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:space', 'preserve')
    r.appendChild(t)
    return r

def run_text(run):
    return ''.join(t.firstChild.data if t.firstChild else ''
                   for t in children(run) if local(t) == 't')

def annotate_docx(source, plan, output):
    with zipfile.ZipFile(source) as z:
        entries = [(i, z.read(i.filename)) for i in z.infolist()]
    files = {i.filename: data for i, data in entries}
    if 'word/document.xml' not in files:
        raise ValueError('Missing document.xml')
    document = dom.parseString(files['word/document.xml'])
    # DOM keeps original prefix declarations, including mc:Ignorable bindings.
    paragraphs = list(document.getElementsByTagNameNS(W, 'p'))
    original_visible = [visible(p) for p in ET.fromstring(files['word/document.xml']).iter(q('p'))]
    if 'word/comments.xml' in files:
        comments = dom.parseString(files['word/comments.xml'])
    else:
        comments = dom.parseString(f'<w:comments xmlns:w="{W}"/>')
    existing = [int(n.getAttributeNS(W, 'id')) for n in comments.getElementsByTagNameNS(W, 'comment')]
    next_id = max(existing, default=-1) + 1
    annotations = plan['annotations']
    # Insert right-to-left so earlier Unicode offsets remain valid; ranges may not overlap.
    by_para = {}
    for a in annotations:
        if a.get('part', 'word/document.xml') != 'word/document.xml':
            raise ValueError(f"{a['issue_id']}: complex story part requires native document tool/linked anchor")
        i = a['paragraph']
        if not isinstance(i, int) or i < 0 or i >= len(paragraphs):
            raise ValueError('Paragraph outside document')
        by_para.setdefault(i, []).append(a)
    for i, items in by_para.items():
        ascending = sorted(items, key=lambda a: a['start'])
        for a, b in zip(ascending, ascending[1:]):
            if a['end'] > b['start']:
                raise ValueError('Overlapping ranges require native document tool or separate anchors')
        p = paragraphs[i]
        if any(local(n) not in {'pPr', 'r'} for n in children(p)):
            raise ValueError(f'Paragraph {i}: existing marks, fields, hyperlinks or complex content; use linked anchor')
        original_runs = [n for n in children(p) if local(n) == 'r']
        if any(any(local(n) not in {'rPr', 't'} for n in children(r)) for r in original_runs):
            raise ValueError(f'Paragraph {i}: non-text run requires native tool')
        raw = ''.join(run_text(r) for r in original_runs)
        if raw != original_visible[i]:
            raise ValueError('Final-view text differs from direct run text')
        for a in sorted(items, key=lambda a: a['start'], reverse=True):
            start, end = a['start'], a['end']
            if not (isinstance(start, int) and isinstance(end, int) and 0 <= start < end <= len(raw)):
                raise ValueError('Invalid Unicode range')
            if raw[start:end] != a['expected']:
                raise ValueError(f"{a['issue_id']}: expected text mismatch")
            cid = next_id
            next_id += 1
            # Split only runs touched by endpoints; preserve run properties.
            offset = 0
            for run in list(children(p)):
                if local(run) != 'r' or any(local(n) == 'commentReference' for n in children(run)):
                    continue
                text = run_text(run)
                length = len(text)
                cuts = sorted({0, length} | {v-offset for v in (start, end) if offset < v < offset+length})
                if len(cuts) > 2:
                    props = next((n for n in children(run) if local(n) == 'rPr'), None)
                    for left, right in zip(cuts, cuts[1:]):
                        p.insertBefore(text_run(document, text[left:right], props), run)
                    p.removeChild(run)
                offset += length
            offset, first, after = 0, None, None
            for run in children(p):
                if local(run) != 'r' or any(local(n) == 'commentReference' for n in children(run)):
                    continue
                text = run_text(run)
                if offset == start:
                    first = run
                if offset + len(text) == end:
                    after = run
                offset += len(text)
            if first is None or after is None:
                raise ValueError('Failed to resolve exact run boundary')
            p.insertBefore(el(document, 'commentRangeStart', {'id': cid}), first)
            stop = el(document, 'commentRangeEnd', {'id': cid})
            p.insertBefore(stop, after.nextSibling)
            ref = el(document, 'r')
            ref.appendChild(el(document, 'commentReference', {'id': cid}))
            p.insertBefore(ref, stop.nextSibling)
            comment = el(comments, 'comment', {'id': cid, 'author': plan.get('reviewer', '文献核查')})
            for line in (a['comment'].splitlines() or ['']):
                cp = el(comments, 'p')
                cp.appendChild(text_run(comments, line))
                comment.appendChild(cp)
            comments.documentElement.appendChild(comment)
    files['word/document.xml'] = document.toxml(encoding='utf-8')
    files['word/comments.xml'] = comments.toxml(encoding='utf-8')
    relpath = 'word/_rels/document.xml.rels'
    rels = dom.parseString(files.get(relpath, f'<Relationships xmlns="{REL}"/>'.encode()))
    relationships = list(rels.getElementsByTagNameNS(REL, 'Relationship'))
    cr = [r for r in relationships if r.getAttribute('Type') == COMMENTS_REL]
    if cr and any(r.getAttribute('Target') not in {'comments.xml', '/word/comments.xml'} for r in cr):
        raise ValueError('Nonstandard comments target; use native document tool')
    if not cr:
        used = {r.getAttribute('Id') for r in relationships}
        rid = 1
        while f'rId{rid}' in used:
            rid += 1
        r = rels.createElementNS(REL, 'Relationship')
        for k, v in {'Id': f'rId{rid}', 'Type': COMMENTS_REL, 'Target': 'comments.xml'}.items():
            r.setAttribute(k, v)
        rels.documentElement.appendChild(r)
    files[relpath] = rels.toxml(encoding='utf-8')
    types = dom.parseString(files['[Content_Types].xml'])
    if not any(n.getAttribute('PartName') == '/word/comments.xml'
               for n in types.getElementsByTagNameNS(CTYPE, 'Override')):
        n = types.createElementNS(CTYPE, 'Override')
        n.setAttribute('PartName', '/word/comments.xml')
        n.setAttribute('ContentType', 'application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml')
        types.documentElement.appendChild(n)
    files['[Content_Types].xml'] = types.toxml(encoding='utf-8')
    after_visible = [visible(p) for p in ET.fromstring(files['word/document.xml']).iter(q('p'))]
    if after_visible != original_visible:
        raise ValueError('Visible source text changed; output refused')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        existing_names = set()
        for info, data in entries:
            z.writestr(info, files[info.filename])
            existing_names.add(info.filename)
        for name, data in files.items():
            if name not in existing_names:
                z.writestr(name, data)
    atomic_bytes(output, buf.getvalue())
    return {'added': len(annotations), 'existing_comments': len(existing),
            'visible_text_preserved': True, 'visual_qa_required': True}

def pdf_chars(source, page_number):
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(str(source))
    page = doc[page_number-1]
    tp = page.get_textpage()
    out = []
    for i in range(tp.count_chars()):
        out.append({'index': i, 'text': tp.get_text_range(i, 1), 'box': list(tp.get_charbox(i))})
    tp.close()
    page.close()
    doc.close()
    return {'page': page_number, 'index_system': 'PDFium character index, not Python string offset', 'characters': out}

def char_quads(tp, start, count, expected):
    if not isinstance(start, int) or not isinstance(count, int) or count < 1 or start < 0 or start+count > tp.count_chars():
        raise ValueError('Invalid PDFium character range')
    if tp.get_text_range(start, count) != expected:
        raise ValueError('PDFium expected text mismatch')
    boxes = []
    for i in range(start, start+count):
        char = tp.get_text_range(i, 1)
        if not char.strip():
            continue
        box = tp.get_charbox(i)
        if box[2] > box[0] and box[3] > box[1]:
            boxes.append(box)
    if not boxes:
        raise ValueError('No visible glyph boxes; use verified image-region anchor')
    typical = statistics.median(b[3]-b[1] for b in boxes)
    lines = []
    for box in boxes:
        center = (box[1]+box[3])/2
        if lines and abs(center-lines[-1]['center']) < typical*0.65 and box[0]-lines[-1]['boxes'][-1][2] < typical*3:
            lines[-1]['boxes'].append(box)
        else:
            lines.append({'center': center, 'boxes': [box]})
    result = []
    for line in lines:
        bs = line['boxes']
        l, b, r, t = min(x[0] for x in bs), min(x[1] for x in bs), max(x[2] for x in bs), max(x[3] for x in bs)
        result.append([l, t, r, t, l, b, r, b])
    return result

def annotate_pdf(source, plan, output):
    import pypdfium2 as pdfium
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import DictionaryObject, NameObject, ArrayObject, FloatObject, TextStringObject
    reader = PdfReader(str(source))
    if reader.is_encrypted:
        raise ValueError('Encrypted PDF needs explicit supported handling')
    writer = PdfWriter()
    writer.clone_document_from_reader(reader)
    pdf = pdfium.PdfDocument(str(source))
    try:
        for a in plan['annotations']:
            page_number = a['page']
            if not isinstance(page_number, int) or not 1 <= page_number <= len(reader.pages):
                raise ValueError('PDF page outside document')
            page = reader.pages[page_number-1]
            if int(page.get('/Rotate', 0)) % 360 or list(page.cropbox) != list(page.mediabox) or any(float(v) != 0 for v in page.mediabox.lower_left):
                raise ValueError('Rotated/cropped/translated page requires adapted geometry')
            pp = pdf[page_number-1]
            tp = pp.get_textpage()
            try:
                if 'char_start' in a:
                    quads = char_quads(tp, a['char_start'], a['char_count'], a['expected'])
                else:
                    if not a.get('visually_verified') or not a.get('reason'):
                        raise ValueError('Explicit quads require visual verification and reason')
                    quads = a['quads']
                    if not a.get('image_only'):
                        selected = ''.join(tp.get_text_bounded(min(x[0::2]), min(x[1::2]), max(x[0::2]), max(x[1::2])) for x in quads)
                        if ''.join(selected.split()) != ''.join(a['expected'].split()):
                            raise ValueError('Explicit quad selection does not equal expected text')
                for quad in quads:
                    if len(quad) != 8 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in quad):
                        raise ValueError('Invalid PDF quad')
                    if any(x < 0 or x > float(page.mediabox.width) for x in quad[0::2]) or any(y < 0 or y > float(page.mediabox.height) for y in quad[1::2]):
                        raise ValueError('Quad outside page')
                coords = [v for quad in quads for v in quad]
                xs, ys = coords[0::2], coords[1::2]
                color = [0.68, 0.85, 0.90] if a.get('kind', 'query') == 'query' else [0.77, 0.88, 0.69]
                annot = DictionaryObject({NameObject('/Type'): NameObject('/Annot'),
                    NameObject('/Subtype'): NameObject('/Highlight'),
                    NameObject('/Rect'): ArrayObject([FloatObject(v) for v in [min(xs), min(ys), max(xs), max(ys)]]),
                    NameObject('/QuadPoints'): ArrayObject([FloatObject(v) for v in coords]),
                    NameObject('/Contents'): TextStringObject(a['comment']),
                    NameObject('/T'): TextStringObject(plan.get('reviewer', '文献核查')),
                    NameObject('/NM'): TextStringObject('refcite-' + a['issue_id'] + '-' + uuid.uuid4().hex),
                    NameObject('/C'): ArrayObject([FloatObject(v) for v in color])})
                writer.add_annotation(page_number-1, annot)
            finally:
                tp.close()
                pp.close()
    finally:
        pdf.close()
    buf = io.BytesIO()
    writer.write(buf)
    data = buf.getvalue()
    check = PdfReader(io.BytesIO(data))
    if len(check.pages) != len(reader.pages):
        raise ValueError('Page count changed')
    for src, dst in zip(reader.pages, check.pages):
        if list(src.mediabox) != list(dst.mediabox) or list(src.cropbox) != list(dst.cropbox):
            raise ValueError('Page boxes changed')
        sc, dc = src.get_contents(), dst.get_contents()
        if (sc.get_data() if sc else b'') != (dc.get_data() if dc else b'') or src.extract_text() != dst.extract_text():
            raise ValueError('PDF contents changed')
    atomic_bytes(output, data)
    return {'added': len(plan['annotations']), 'body_streams_preserved': True, 'visual_qa_required': True}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    chars = sub.add_parser('pdf-chars')
    chars.add_argument('source')
    chars.add_argument('--page', type=int, required=True)
    chars.add_argument('-o', '--output', required=True)
    add = sub.add_parser('add')
    add.add_argument('source')
    add.add_argument('plan')
    add.add_argument('-o', '--output', required=True)
    add.add_argument('--receipt', required=True)
    a = p.parse_args()
    if a.command == 'pdf-chars':
        write(a.output, pdf_chars(a.source, a.page))
        return
    require_distinct(a.source, a.output)
    plan = load(a.plan)
    if digest(a.source) != plan['source_sha256']:
        raise ValueError('Source hash differs from annotation plan')
    if len({x['issue_id'] + ':' + str(x.get('page', x.get('paragraph'))) + ':' + str(x.get('start', x.get('char_start', x.get('quads')))) for x in plan['annotations']}) != len(plan['annotations']):
        raise ValueError('Duplicate annotation anchors')
    fn = annotate_docx if Path(a.source).suffix.lower() == '.docx' else annotate_pdf
    result = fn(a.source, plan, a.output)
    result.update({'source_sha256': digest(a.source), 'output_sha256': digest(a.output)})
    write(a.receipt, result)

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Check ledger closure and generate a concise report, not scholarly correctness."""
from __future__ import annotations
import argparse
from collections import Counter
from pathlib import Path
from common import load, write, digest, atomic_bytes
from scan import candidates as scan_candidates
from match import author_match

AUTH = {'verified', 'metadata_conflict', 'not_found', 'access_limited', 'version_uncertain'}
CROSS = {'matched', 'missing_reference', 'ambiguous', 'exempt'}
RELEVANCE = {'not_flagged', 'supported', 'partial', 'unsupported', 'contradicted', 'uncertain'}

def audit(l):
    errors, limits = [], list(l.get('delivery', {}).get('limitations', []))
    def need(condition, message):
        if not condition:
            errors.append(message)
    def unique(items, label):
        ids = [x.get('id') for x in items]
        need(all(isinstance(i, str) and i for i in ids), f'{label}: missing ID')
        need(len(ids) == len(set(ids)), f'{label}: duplicate ID')
        return {x.get('id'): x for x in items}
    refs = unique(l.get('references', []), 'references')
    cites = unique(l.get('citations', []), 'citations')
    issues = unique(l.get('issues', []), 'issues')
    candidates = unique(l.get('candidates', []), 'candidates')
    try:
        need(digest(l['source']) == l['source_sha256'], 'Source hash mismatch')
        need(digest(l['extraction']) == l['extraction_sha256'], 'Extraction snapshot changed')
        e = load(l['extraction'])
        need(e['source_sha256'] == l['source_sha256'], 'Extraction belongs to another source')
        expected_units = {u['id'] for u in e['units']}
        for initial in scan_candidates(e):
            current = candidates.get(initial['id'], {})
            need(all(current.get(k) == initial[k] for k in ('id', 'unit_id', 'start', 'end', 'raw')),
                 f'{initial["id"]}: initial candidate deleted or altered')
    except (KeyError, OSError, ValueError) as exc:
        expected_units = set()
        errors.append(f'Cannot verify source/extraction: {exc}')
    covered = [u.get('unit_id') for u in l.get('coverage', [])]
    need(len(covered) == len(set(covered)), 'Coverage contains duplicate units')
    need(expected_units.issubset(set(covered)), 'Coverage omits extracted units')
    need(bool(covered), 'No coverage units')
    for c in l.get('coverage', []):
        label = c.get('unit_id')
        need(c.get('state') in {'checked', 'excluded', 'unreadable'}, f'{label}: coverage pending')
        if c.get('state') == 'checked':
            need(all(c.get(k) is True for k in ('citation_scan', 'missing_citation_review', 'visual_review')),
                 f'{label}: review pass missing')
        else:
            need(bool(c.get('reason')), f'{label}: excluded/unreadable requires reason')
        if c.get('state') == 'unreadable':
            need(bool(c.get('issue_ids')), f'{label}: unreadable content needs an issue')
            limits.append(f'{label}: {c.get("reason", "unreadable")}')
        need(all(i in issues for i in c.get('issue_ids', [])), f'{label}: missing coverage issue')
    inv = l.get('inventory', {})
    for flag in ('references_complete', 'citations_complete', 'reverse_review_complete'):
        need(inv.get(flag) is True, f'Inventory not confirmed: {flag}')
    need(type(inv.get('expected_references')) is int and inv['expected_references'] == len(refs), 'Reference count not independently confirmed')
    need(type(inv.get('expected_citations')) is int and inv['expected_citations'] == len(cites), 'Citation atom count not independently confirmed')
    if l.get('scope') != 'full_document':
        limits.append('Input scope is limited; correspondence and relevance may not be fully assessable')
    for c in candidates.values():
        need(c.get('decision') in {'citation', 'not_citation', 'unresolved_noted'}, f'{c.get("id")}: candidate undecided')
        need(bool(c.get('reason')), f'{c.get("id")}: candidate decision needs reason')
        if c.get('decision') == 'citation':
            need(bool(c.get('citation_ids')) and all(i in cites for i in c['citation_ids']), f'{c.get("id")}: candidate atoms missing')
        elif c.get('decision') == 'unresolved_noted':
            need(bool(c.get('issue_ids')) and all(i in issues for i in c['issue_ids']), f'{c.get("id")}: unresolved candidate issue missing')
    def linked_issues(record, label, required=False):
        ids = record.get('issue_ids', [])
        need(all(i in issues for i in ids), f'{label}: unknown issue link')
        if required:
            need(any(i in issues and issues[i].get('decision') in {'confirmed', 'query'} for i in ids),
                 f'{label}: no active issue recorded')
    for rid, r in refs.items():
        need(bool(r.get('raw')) and bool(r.get('location')), f'{rid}: original/location missing')
        v = r.get('verification', {})
        need(v.get('status') in AUTH, f'{rid}: authenticity pending')
        need(bool(v.get('reason')), f'{rid}: verification reasoning missing')
        need(bool(v.get('searches')), f'{rid}: no search history')
        for search in v.get('searches', []):
            need(all(search.get(k) for k in ('source_family', 'query', 'date', 'outcome')), f'{rid}: incomplete search record')
        if v.get('status') in {'verified', 'metadata_conflict'}:
            ev = v.get('evidence', [])
            need(bool(ev) and bool(v.get('field_checks')), f'{rid}: evidence/field checks missing')
            for item in ev:
                need(bool(item.get('url') or item.get('local_source')) and bool(item.get('locator')) and bool(item.get('retrieved_at')),
                     f'{rid}: incomplete evidence record')
        if v.get('status') == 'not_found':
            need(len({s.get('source_family') for s in v.get('searches', [])}) >= 2, f'{rid}: no alternative source family searched')
        linked_issues(r, rid, v.get('status') != 'verified')
        usage = r.get('usage', {})
        need(usage.get('status') in {'cited', 'uncited', 'paired', 'allowed_uncited'}, f'{rid}: reverse mapping pending')
        if usage.get('status') == 'cited':
            ids = usage.get('citation_ids', [])
            need(bool(ids) and all(i in cites and rid in cites[i].get('crosscheck', {}).get('reference_ids', [])
                                   and cites[i].get('crosscheck', {}).get('status') == 'matched' for i in ids), f'{rid}: stale reverse citation links')
        elif usage.get('status') == 'paired':
            other = refs.get(usage.get('representative_id'), {})
            need(bool(r.get('verified_group_id')) and r.get('verified_group_id') == other.get('verified_group_id')
                 and other.get('usage', {}).get('status') == 'cited', f'{rid}: invalid bilingual group')
        else:
            need(bool(usage.get('reason')), f'{rid}: uncited disposition requires reason')
            linked_issues(r, rid, usage.get('status') == 'uncited')
            if usage.get('status') == 'allowed_uncited':
                need(bool(usage.get('basis')), f'{rid}: allowed uncited needs configuration/user basis')
    for cid, c in cites.items():
        need(bool(c.get('raw')) and bool(c.get('location')), f'{cid}: original/location missing')
        cross = c.get('crosscheck', {})
        need(cross.get('status') in CROSS and bool(cross.get('reason')), f'{cid}: crosscheck not disposed')
        if cross.get('status') == 'matched':
            ids = cross.get('reference_ids', [])
            need(len(ids) == 1 and ids[0] in refs, f'{cid}: atom must identify one representative version')
            for rid in ids:
                if rid in refs:
                    need(cid in refs[rid].get('usage', {}).get('citation_ids', []), f'{cid}: reverse link absent')
                    r = refs[rid]
                    consistent = (author_match(c, r) and bool(c.get('year')) and c.get('year') == r.get('year')
                                  and c.get('suffix', '') == r.get('suffix', ''))
                    override = cross.get('manual_override', {})
                    justified = bool(override.get('reason') and override.get('evidence'))
                    need(consistent or justified, f'{cid}: matched identity/year/suffix differs without evidence-based override')
            need(c.get('identities_verified') is True, f'{cid}: author identity unverified')
        elif cross.get('status') == 'exempt':
            need(bool(cross.get('basis')), f'{cid}: exemption basis missing')
        else:
            linked_issues(c, cid, True)
        rel = c.get('relevance', {})
        need(rel.get('status') in RELEVANCE, f'{cid}: lightweight content screening not recorded')
        if rel.get('status') != 'not_flagged':
            need(bool(rel.get('trigger')) and rel.get('level') in {'fulltext', 'abstract', 'metadata', 'unavailable'}
                 and bool(rel.get('reason')), f'{cid}: triggered content check lacks basis')
        if rel.get('report'):
            need(rel.get('clear_evidence') is True and bool(rel.get('locator')),
                 f'{cid}: content concern below high-precision reporting threshold')
            linked_issues(c, cid, True)
        linked_issues(c, cid)
    for iid, issue in issues.items():
        need(issue.get('decision') in {'confirmed', 'query', 'rejected', 'resolved'}, f'{iid}: decision pending')
        need(all(issue.get(k) for k in ('category', 'original', 'comment', 'reason', 'location')), f'{iid}: incomplete issue')
        if issue.get('decision') in {'confirmed', 'query'}:
            need(issue.get('annotation_status') in {'written', 'linked_anchor', 'failed_disclosed'}, f'{iid}: no annotation disposition')
            if issue.get('annotation_status') == 'failed_disclosed':
                limits.append(f'{iid}: comment was not written; see report')
    for k in ('annotations_complete', 'source_preserved', 'visual_checked'):
        need(l.get('delivery', {}).get(k) is True, f'Delivery check incomplete: {k}')
    statistics = {'references': len(refs), 'citation_atoms': len(cites),
                  'authenticity': dict(Counter(r.get('verification', {}).get('status', 'pending') for r in refs.values())),
                  'crosscheck': dict(Counter(c.get('crosscheck', {}).get('status', 'pending') for c in cites.values())),
                  'reported_issues': sum(i.get('decision') in {'confirmed', 'query'} for i in issues.values())}
    return {'mechanical_closure': not errors, 'errors': errors, 'limitations': list(dict.fromkeys(limits)),
            'statistics': statistics, 'note': 'Closure is not proof that all facts or content support are verified.'}

def report(l, result):
    s = result['statistics']
    lines = ['# 参考文献与引文核查结果', '',
             f'参考文献 {s["references"]} 条；文内引文原子 {s["citation_atoms"]} 个；需处理问题 {s["reported_issues"]} 项。', '',
             '真实性状态：' + '；'.join(f'{k} {v}' for k, v in s['authenticity'].items()), '',
             '## 需要处理的事项', '']
    for i in sorted(l.get('issues', []), key=lambda x: x.get('order', 0)):
        if i.get('decision') not in {'confirmed', 'query'}:
            continue
        lines += [f'### {i["id"]} {i["category"]}', '', f'位置：{i["location"]}', '',
                  f'原文：{i["original"]}', '', i['comment'], '', f'依据：{i["reason"]}', '']
    if result['limitations']:
        lines += ['## 核查范围与待确认事项', ''] + [f'- {x}' for x in result['limitations']] + ['']
    if result['errors']:
        lines += ['本报告尚未完成验收，不作为最终核查结论。', '']
    return '\n'.join(lines)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('ledger')
    p.add_argument('-o', '--output', required=True)
    p.add_argument('--report')
    a = p.parse_args()
    l = load(a.ledger)
    result = audit(l)
    write(a.output, result)
    if a.report:
        atomic_bytes(a.report, report(l, result).encode('utf-8'))
    raise SystemExit(0 if result['mechanical_closure'] else 2)

if __name__ == '__main__':
    main()

"""Shared local I/O and visible-text handling. No network or mutations on import."""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
ET.register_namespace('w', W)

def q(name):
    return '{' + W + '}' + name

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(data, ensure_ascii=False, indent=2) + '\n'
    atomic_bytes(path, raw.encode('utf-8'))

def atomic_bytes(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.refcite-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)

def visible(element):
    """Final-view text; nested paragraphs are extracted as separate units."""
    out = []
    def walk(node, is_root=False):
        if node.tag in {q('del'), q('moveFrom')}:
            return
        if not is_root and node.tag == q('p'):
            return
        if node.tag == q('t'):
            out.append(node.text or '')
        elif node.tag == q('tab'):
            out.append('\t')
        elif node.tag in {q('br'), q('cr')}:
            out.append('\n')
        else:
            for child in node:
                walk(child)
    walk(element, True)
    return ''.join(out)

def require_distinct(source, output):
    if Path(source).resolve() == Path(output).resolve():
        raise ValueError('Output must be a new file; refusing to overwrite source')

def xml_bytes(root):
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)

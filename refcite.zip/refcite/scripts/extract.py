#!/usr/bin/env python3
"""Extract stable text units; boundaries and coverage still require human review."""
from __future__ import annotations
import argparse
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from common import NS, q, visible, digest, write

def docx_units(path):
    units, regions, warnings = [], [], []
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        parts = [n for n in names if re.fullmatch(
            r'word/(document|footnotes|endnotes|header\d+|footer\d+)\.xml', n)]
        parts.sort(key=lambda n: (n != 'word/document.xml', n))
        for part in parts:
            root = ET.fromstring(z.read(part))
            parents = {c: p for p in root.iter() for c in p}
            count = 0
            for index, p in enumerate(root.iter(q('p'))):
                ancestors, node = [], p
                while node in parents:
                    node = parents[node]
                    ancestors.append(node.tag)
                if q('del') in ancestors or q('moveFrom') in ancestors:
                    continue
                if part.endswith(('footnotes.xml', 'endnotes.xml')):
                    tag = 'footnote' if part.endswith('footnotes.xml') else 'endnote'
                    note = p
                    while note is not None and note.tag != q(tag):
                        note = parents.get(note)
                    if note is not None and note.get(q('type')) in {'separator', 'continuationSeparator'}:
                        continue
                text = visible(p)
                region = 'textbox' if q('txbxContent') in ancestors else (
                    'table' if q('tc') in ancestors else Path(part).stem)
                uid = f'{part}#p{index:06d}'
                units.append({'id': uid, 'part': part, 'paragraph': index,
                              'region': region, 'text': text})
                count += 1
                if next(p.iter(q('drawing')), None) is not None or next(p.iter(q('pict')), None) is not None:
                    warnings.append({'unit_id': uid, 'kind': 'image_or_shape',
                                     'action': 'Inspect image/shape text and source labels visually'})
            regions.append({'id': part, 'unit_count': count})
        for n in names:
            if n.startswith('word/media/'):
                warnings.append({'asset': n, 'kind': 'media',
                                 'action': 'Account for image content in coverage; no automatic OCR'})
        if any(n in names for n in ('word/comments.xml', 'word/commentsExtended.xml')):
            warnings.append({'kind': 'existing_comments', 'action': 'Preserve and reconcile existing review'})
    return units, regions, warnings, None

def pdf_units(path):
    try:
        import pypdfium2 as pdfium
    except ImportError as exc:
        raise SystemExit('PDF extraction requires pypdfium2; use available PDF runtime') from exc
    units, regions, warnings = [], [], []
    doc = pdfium.PdfDocument(str(path))
    try:
        page_count = len(doc)
        for i in range(page_count):
            page = doc[i]
            tp = page.get_textpage()
            text = tp.get_text_range()
            units.append({'id': f'pdf#page{i+1:04d}', 'page': i+1, 'region': 'page',
                          'text': text, 'width': page.get_width(), 'height': page.get_height()})
            regions.append({'id': f'page{i+1}', 'unit_count': 1})
            warnings.append({'unit_id': units[-1]['id'], 'kind': 'visual_review_required',
                             'action': 'Check columns, images, notes, reading order and OCR needs'})
            tp.close()
            page.close()
    finally:
        doc.close()
    return units, regions, warnings, page_count

def extract(path):
    path = Path(path).resolve()
    suffix = path.suffix.lower()
    if suffix == '.docx':
        units, regions, warnings, pages = docx_units(path)
    elif suffix == '.pdf':
        units, regions, warnings, pages = pdf_units(path)
    elif suffix in {'.txt', '.md'}:
        units = [{'id': f'text#line{i+1:06d}', 'region': 'text', 'text': line}
                 for i, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines())]
        regions, warnings, pages = [{'id': 'text', 'unit_count': len(units)}], [], None
    else:
        raise ValueError('Supported inputs: .docx, .pdf, .txt, .md')
    return {'schema_version': '1.0', 'source': str(path), 'source_sha256': digest(path),
            'page_count': pages, 'units': units, 'regions': regions, 'warnings': warnings}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source')
    p.add_argument('-o', '--output', required=True)
    a = p.parse_args()
    write(a.output, extract(a.source))

if __name__ == '__main__':
    main()

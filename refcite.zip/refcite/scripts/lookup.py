#!/usr/bin/env python3
"""Retrieve public bibliographic evidence candidates, never verify automatically."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from common import write, load

def build_request(doi=None, query=None):
    if doi:
        doi = re.sub(r'^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)', '', doi.strip(), flags=re.I)
        if not re.fullmatch(r'10\.\d{4,9}/\S+', doi):
            raise ValueError('Invalid DOI syntax; do not silently repair its suffix')
        url = 'https://doi.org/' + urllib.parse.quote(doi, safe='/')
        accept = 'application/vnd.citationstyles.csl+json'
    else:
        if not query or not query.strip():
            raise ValueError('A public bibliographic query is required')
        url = 'https://api.crossref.org/works?' + urllib.parse.urlencode({'query.bibliographic': query, 'rows': 5})
        accept = 'application/json'
    return urllib.request.Request(url, headers={'Accept': accept, 'User-Agent': 'refcite/1.0.0 (bibliographic-audit)'})

def retrieve(request, opener=urllib.request.urlopen):
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    result = {'requested_url': request.full_url, 'retrieved_at': now,
              'decision': 'candidate_only', 'note': 'Neither a hit nor a failed lookup proves authenticity.'}
    try:
        with opener(request, timeout=25) as response:
            result.update({'status': 'retrieved', 'final_url': response.geturl(),
                           'http_status': response.status, 'metadata': load_response(response)})
    except urllib.error.HTTPError as exc:
        result.update({'status': 'http_error', 'http_status': exc.code,
                       'reason': 'Retry later or use an alternative source; not an absence finding'})
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        result.update({'status': 'access_or_parse_error', 'reason': str(exc)})
    return result

def load_response(response):
    import json
    raw = response.read(8_000_001)
    if len(raw) > 8_000_000:
        raise ValueError('Response exceeds metadata size limit')
    return json.loads(raw.decode('utf-8'))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--doi')
    g.add_argument('--query', help='Public title/author fields only; do not pass manuscript or private rules')
    p.add_argument('--cache-dir', required=True)
    p.add_argument('--refresh', action='store_true', help='Re-query instead of reusing prior evidence')
    p.add_argument('-o', '--output', required=True)
    a = p.parse_args()
    req = build_request(a.doi, a.query)
    key = hashlib.sha256(req.full_url.encode()).hexdigest()
    cache = Path(a.cache_dir) / (key + '.json')
    if cache.exists() and not a.refresh:
        result = load(cache)
        result['cache_reused'] = True
    else:
        result = retrieve(req)
        write(cache, result)
    write(a.output, result)

if __name__ == '__main__':
    main()

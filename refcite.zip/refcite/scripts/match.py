#!/usr/bin/env python3
"""Match only human-verified identity keys. Output remains candidates for review."""
from __future__ import annotations
import argparse
from common import load, write

def author_match(c, r):
    ca, ra = c.get('authors', []), r.get('authors', [])
    if not ca or not ra or not c.get('identities_verified') or not r.get('identities_verified'):
        return False
    if c.get('etal'):
        return len(ca) <= len(ra) and ca == ra[:len(ca)]
    return ca == ra

def match(ledger):
    refs = ledger['references']
    results, candidate_cited = [], set()
    for c in ledger['citations']:
        same_author = [r for r in refs if author_match(c, r)]
        same_year = [r for r in same_author if r.get('year') == c.get('year')]
        exact = [r for r in same_year if r.get('suffix', '') == c.get('suffix', '')]
        groups = {}
        for r in exact:
            # Grouping is opt-in after checking bilingual records of the same version.
            key = r.get('verified_group_id') or r['id']
            groups.setdefault(key, []).append(r['id'])
        ids = [r['id'] for r in exact]
        if len(groups) == 1:
            status = 'unique_candidate'
            candidate_cited.update(ids)
        elif len(groups) > 1:
            status = 'ambiguous'
        elif same_year:
            status = 'suffix_conflict'
        elif same_author:
            status = 'year_or_version_conflict'
        elif not c.get('identities_verified'):
            status = 'identity_unverified'
        else:
            status = 'missing_reference_candidate'
        results.append({'citation_id': c['id'], 'status': status, 'candidate_reference_ids': ids,
                        'same_year_ids': [r['id'] for r in same_year],
                        'same_author_ids': [r['id'] for r in same_author]})
    return {'note': 'Candidates only; matching is neither authenticity verification nor editorial judgment.',
            'citation_to_reference': results,
            'reference_without_unique_candidate': [r['id'] for r in refs if r['id'] not in candidate_cited]}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('ledger')
    p.add_argument('-o', '--output', required=True)
    a = p.parse_args()
    write(a.output, match(load(a.ledger)))

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Create a concise front-facing report with the requested Chinese/Latin typography."""
from __future__ import annotations
import argparse
from pathlib import Path
from common import load, require_distinct
from audit import audit

STATUS = {'verified': '已核实', 'metadata_conflict': '题录冲突', 'not_found': '暂未检得',
          'access_limited': '访问受限', 'version_uncertain': '版本待确认', 'pending': '待核查'}

def set_font(style, size, color='000000', bold=False):
    from docx.shared import Pt, RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    style.font.name = 'Times New Roman'
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string(color)
    style.font.bold = bold
    rp = style.element.get_or_add_rPr()
    fonts = rp.find(qn('w:rFonts'))
    if fonts is None:
        fonts = OxmlElement('w:rFonts')
        rp.insert(0, fonts)
    for key, value in [('ascii', 'Times New Roman'), ('hAnsi', 'Times New Roman'), ('cs', 'Times New Roman'), ('eastAsia', '宋体')]:
        fonts.set(qn('w:' + key), value)
    for key in ('asciiTheme', 'hAnsiTheme', 'eastAsiaTheme', 'cstheme'):
        fonts.attrib.pop(qn('w:' + key), None)

def styled_document():
    from docx import Document
    from docx.shared import Cm, Pt
    from docx.oxml.ns import qn
    doc = Document()
    # Some bundled defaults carry title borders or theme font substitutions.
    for style in doc.styles:
        for border in list(style.element.iter(qn('w:pBdr'))):
            border.getparent().remove(border)
    s = doc.sections[0]
    s.page_width, s.page_height = Cm(21), Cm(29.7)
    s.top_margin, s.bottom_margin = Cm(2.1), Cm(2.1)
    s.left_margin, s.right_margin = Cm(2.3), Cm(2.3)
    set_font(doc.styles['Normal'], 11)
    doc.styles['Normal'].paragraph_format.line_spacing = 1.25
    doc.styles['Normal'].paragraph_format.space_after = Pt(5)
    for name, size in [('Title', 18), ('Heading 1', 13), ('Heading 2', 11.5), ('Heading 3', 11)]:
        set_font(doc.styles[name], size, '17365D', True)
        pf = doc.styles[name].paragraph_format
        pf.space_before = Pt(10 if name != 'Title' else 0)
        pf.space_after = Pt(5 if name != 'Title' else 8)
        pf.keep_with_next = True
    return doc

def build(ledger, output):
    result = audit(ledger)
    if not result['mechanical_closure']:
        raise ValueError('Ledger closure failed; finish backend work before generating final report')
    doc = styled_document()
    doc.add_paragraph('参考文献与引文核查报告', 'Title')
    s = result['statistics']
    doc.add_paragraph(f'参考文献{s["references"]}条，文内引文{s["citation_atoms"]}个，需处理问题{s["reported_issues"]}项。')
    doc.add_paragraph('；'.join(f'{STATUS.get(k, k)}{v}条' for k, v in s['authenticity'].items()) + '。')
    relevant = [i for i in ledger.get('issues', []) if i.get('decision') in {'confirmed', 'query'}]
    if relevant:
        doc.add_heading('需要处理的事项', level=1)
        for number, i in enumerate(sorted(relevant, key=lambda x: x.get('order', 0)), 1):
            doc.add_heading(f'{number} {i["category"]}', level=2)
            doc.add_paragraph(f'位置：{i["location"]}')
            doc.add_paragraph(f'原文：{i["original"]}')
            doc.add_paragraph(i['comment'])
            doc.add_paragraph(f'依据：{i["reason"]}')
    else:
        doc.add_paragraph('本次可核查范围内未发现达到报告阈值的问题。')
    if result['limitations']:
        doc.add_heading('核查范围与待确认事项', level=1)
        for limit in result['limitations']:
            doc.add_paragraph(limit)
    doc.core_properties.author = ledger.get('reviewer', '文献核查')
    doc.core_properties.title = '参考文献与引文核查报告'
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('ledger')
    p.add_argument('-o', '--output', required=True)
    a = p.parse_args()
    ledger = load(a.ledger)
    require_distinct(ledger['source'], a.output)
    build(ledger, a.output)

if __name__ == '__main__':
    main()

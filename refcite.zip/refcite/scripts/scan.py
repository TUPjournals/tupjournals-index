#!/usr/bin/env python3
"""Generate broad citation candidates and an uncompleted ledger. Never infer matches."""
from __future__ import annotations
import argparse
import re
from pathlib import Path
from common import load, write, digest

YEAR = re.compile(r'(?<!\d)(?:1\d{3}|20\d{2}|21\d{2})[a-z]?(?!\d)|\bn\.?\s*d\.?\b|待刊|无日期|in press|forthcoming', re.I)
PARENS = re.compile(r'\([^()\r\n]*\)|（[^（）\r\n]*）')

def candidates(extraction):
    result = []
    for u in extraction['units']:
        text = u['text']
        for m in PARENS.finditer(text):
            if not YEAR.search(m.group()):
                continue
            # Prefix is context, not a parsed author: avoid greedy false identity matching.
            prefix_start = max(0, m.start()-60)
            result.append({'id': f'cand{len(result)+1:06d}', 'unit_id': u['id'],
                           'start': m.start(), 'end': m.end(), 'raw': m.group(),
                           'left_context': text[prefix_start:m.start()],
                           'right_context': text[m.end():m.end()+60], 'decision': 'pending'})
    return result

def initialize(extraction_path):
    e = load(extraction_path)
    return {
        'schema_version': '1.0', 'skill_version': '1.0.0',
        'source': e['source'], 'source_sha256': e['source_sha256'],
        'extraction': str(Path(extraction_path).resolve()), 'extraction_sha256': digest(extraction_path),
        'scope': 'full_document', 'profile_status': 'unconfigured',
        'inventory': {'references_complete': False, 'citations_complete': False,
                      'reverse_review_complete': False, 'expected_references': None,
                      'expected_citations': None},
        'coverage': [{'unit_id': u['id'], 'state': 'pending', 'reason': '',
                      'citation_scan': False, 'missing_citation_review': False,
                      'visual_review': False, 'issue_ids': []} for u in e['units']],
        'candidates': candidates(e), 'references': [], 'citations': [], 'issues': [],
        'delivery': {'annotations_complete': False, 'source_preserved': False,
                     'visual_checked': False, 'limitations': []}}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('extraction')
    p.add_argument('-o', '--output', required=True)
    p.add_argument('--init-ledger', action='store_true')
    a = p.parse_args()
    e = load(a.extraction)
    write(a.output, initialize(a.extraction) if a.init_ledger else {'candidates': candidates(e)})

if __name__ == '__main__':
    main()

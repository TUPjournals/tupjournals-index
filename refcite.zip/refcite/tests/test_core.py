"""Synthetic regression cases; no private examples, network or external writes."""
from __future__ import annotations
import copy
import io
import json
import sys
import tempfile
import unittest
import urllib.error
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from common import W, q, digest, write, visible
from extract import extract
from scan import candidates, initialize
from match import match
from audit import audit
from lookup import build_request, retrieve
from annotate import annotate_docx, annotate_pdf, pdf_chars

def make_docx(path, paragraphs, extra=None):
    from xml.sax.saxutils import escape
    rs = ''.join('<w:p>' + ''.join(f'<w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">{escape(t)}</w:t></w:r>' for t in p) + '</w:p>' for p in paragraphs)
    files = {'word/document.xml': f'<w:document xmlns:w="{W}"><w:body>{rs}</w:body></w:document>',
             '[Content_Types].xml': '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'}
    files.update(extra or {})
    with zipfile.ZipFile(path, 'w') as z:
        for k, v in files.items():
            z.writestr(k, v)

class Core(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
    def tearDown(self):
        self.tmp.cleanup()

    def test_extract_final_view_and_nested_regions(self):
        path = self.root/'x.docx'
        xml = f'''<w:document xmlns:w="{W}"><w:body><w:p><w:r><w:t>Visible</w:t></w:r><w:del><w:r><w:delText>Deleted</w:delText></w:r></w:del><w:ins><w:r><w:t>New</w:t></w:r></w:ins><w:r><w:drawing><w:txbxContent><w:p><w:r><w:t>Box（甲，2020）</w:t></w:r></w:p></w:txbxContent></w:drawing></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>Table（乙，2021）</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>'''
        make_docx(path, [], {'word/document.xml': xml,
            'word/footnotes.xml': f'<w:footnotes xmlns:w="{W}"><w:footnote w:id="-1" w:type="separator"><w:p/></w:footnote><w:footnote w:id="1"><w:p><w:r><w:t>Note</w:t></w:r></w:p></w:footnote></w:footnotes>'})
        e = extract(path)
        self.assertEqual([u['text'] for u in e['units']], ['VisibleNew', 'Box（甲，2020）', 'Table（乙，2021）', 'Note'])
        self.assertEqual([u['region'] for u in e['units']][:3], ['document', 'textbox', 'table'])

    def test_scan_preserves_group_for_manual_atomization(self):
        text = '甲（2010，2020a）与（乙，2021；丙，2022：4）及（2020—2023样本）'
        result = candidates({'units': [{'id': 'u1', 'text': text}]})
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['raw'], '（2010，2020a）')
        for c in result:
            self.assertEqual(text[c['start']:c['end']], c['raw'])
        self.assertNotIn('authors', result[0])

    def test_matching_ambiguity_suffix_versions_and_bilingual_groups(self):
        refs = [{'id': i, 'authors': au, 'year': year, 'suffix': su, 'identities_verified': True}
                for i, au, year, su in [('r1',['smith:a','lee:b'],'2020','a'),
                                      ('r2',['smith:a','liu:c'],'2020','b'),
                                      ('r3',['smith:d'],'2020','a')]]
        cites = [{'id': 'c1', 'authors':['smith:a'], 'etal':True, 'year':'2020','suffix':'a','identities_verified':True},
                 {'id': 'c2', 'authors':['smith:a'], 'etal':True, 'year':'2020','suffix':'','identities_verified':True},
                 {'id': 'c3', 'authors':['smith:d'], 'year':'2019','suffix':'a','identities_verified':True}]
        m = match({'references': refs, 'citations': cites})['citation_to_reference']
        self.assertEqual(m[0]['candidate_reference_ids'], ['r1'])
        self.assertEqual(m[1]['status'], 'suffix_conflict')
        self.assertEqual(m[2]['status'], 'year_or_version_conflict')
        refs.append(dict(refs[0], id='r4'))
        self.assertEqual(match({'references':refs,'citations':cites})['citation_to_reference'][0]['status'], 'ambiguous')
        refs[0]['verified_group_id'] = refs[-1]['verified_group_id'] = 'same-version-group'
        self.assertEqual(match({'references':refs,'citations':cites})['citation_to_reference'][0]['status'], 'unique_candidate')

    def test_docx_comments_split_runs_preserve_old_comments_and_text(self):
        src, out = self.root/'src.docx', self.root/'out.docx'
        make_docx(src, [['甲乙', '2020', '丙丁2021']], {
            'word/comments.xml': f'<w:comments xmlns:w="{W}"><w:comment w:id="7" w:author="Existing"><w:p><w:r><w:t>Old</w:t></w:r></w:p></w:comment></w:comments>'})
        plan = {'reviewer':'文献核查', 'annotations':[
            {'issue_id':'i1','paragraph':0,'start':2,'end':6,'expected':'2020','comment':'核对年份'},
            {'issue_id':'i2','paragraph':0,'start':8,'end':12,'expected':'2021','comment':'核对另一个年份'}]}
        result = annotate_docx(src, plan, out)
        self.assertEqual(result['added'], 2)
        self.assertEqual(extract(src)['units'][0]['text'], extract(out)['units'][0]['text'])
        with zipfile.ZipFile(out) as z:
            comments = ET.fromstring(z.read('word/comments.xml'))
            self.assertEqual([n.get(q('id')) for n in comments], ['7','8','9'])
            self.assertIn(b'Old', z.read('word/comments.xml'))
            self.assertNotIn(q('date'), comments[1].attrib)
            root = ET.fromstring(z.read('word/document.xml'))
            self.assertEqual(len(list(root.iter(q('commentRangeStart')))), 2)
        stale = copy.deepcopy(plan)
        stale['annotations'][0]['expected'] = '2019'
        with self.assertRaises(ValueError):
            annotate_docx(src, stale, self.root/'bad.docx')
        self.assertFalse((self.root/'bad.docx').exists())

    def test_complex_docx_rejected_without_partial_output(self):
        src, out = self.root/'complex.docx', self.root/'bad.docx'
        xml = f'<w:document xmlns:w="{W}"><w:body><w:p><w:hyperlink><w:r><w:t>2020</w:t></w:r></w:hyperlink></w:p></w:body></w:document>'
        make_docx(src, [], {'word/document.xml':xml})
        with self.assertRaises(ValueError):
            annotate_docx(src, {'annotations':[{'issue_id':'i1','paragraph':0,'start':0,'end':4,'expected':'2020','comment':'核查'}]}, out)
        self.assertFalse(out.exists())

    def test_lookup_is_candidate_only_and_handles_missing_access(self):
        request = build_request(doi='https://doi.org/10.1234/test(1)')
        self.assertIn('%28', request.full_url)
        with self.assertRaises(ValueError):
            build_request(doi='https://example.org/private')
        def failed(req, timeout):
            raise urllib.error.HTTPError(req.full_url,404,'missing',{},None)
        self.assertEqual(retrieve(request, failed)['status'], 'http_error')
        class Fake(io.BytesIO):
            status=200
            def geturl(self):
                return 'https://doi.org/10.1234/test'
        def opened(req, timeout):
            return Fake(b'{"title":"Synthetic record"}')
        r = retrieve(request, opened)
        self.assertEqual(r['decision'], 'candidate_only')
        self.assertNotIn('verified', r)

    def valid_ledger(self):
        src, ep = self.root/'source.txt', self.root/'extracted.json'
        src.write_text('Synthetic text', encoding='utf-8')
        write(ep, extract(src))
        l = initialize(ep)
        l['inventory'] = {'references_complete': True, 'citations_complete': True,
                          'reverse_review_complete': True, 'expected_references': 1, 'expected_citations': 1}
        l['coverage'][0].update(state='checked',citation_scan=True,missing_citation_review=True,visual_review=True)
        l['references'] = [{'id':'r1','raw':'Synthetic bibliographic record','location':'u1',
            'authors':['p1'],'identities_verified':True,'year':'2020',
            'verification':{'status':'verified','reason':'Synthetic test evidence',
                'searches':[{'source_family':'publisher','query':'Synthetic','date':'2026-11-11','outcome':'hit'}],
                'evidence':[{'local_source':'fixture','locator':'page1','retrieved_at':'2026-11-11'}],
                'field_checks':{'authors':'same','year':'same'}},
            'usage':{'status':'cited','citation_ids':['c1']}}]
        l['citations'] = [{'id':'c1','raw':'P1 (2020)','location':'u1', 'authors':['p1'],'year':'2020','identities_verified':True,
            'crosscheck':{'status':'matched','reference_ids':['r1'],'reason':'Confirmed'},
            'relevance':{'status':'not_flagged','report':False}}]
        l['delivery'].update(annotations_complete=True,source_preserved=True,visual_checked=True)
        return l

    def test_audit_rejects_omissions_stale_reverse_links_and_low_precision_flags(self):
        good = self.valid_ledger()
        self.assertTrue(audit(good)['mechanical_closure'])
        changed = copy.deepcopy(good)
        changed['coverage'] = []
        self.assertFalse(audit(changed)['mechanical_closure'])
        changed = copy.deepcopy(good)
        changed['references'][0]['usage']['citation_ids'] = []
        self.assertFalse(audit(changed)['mechanical_closure'])
        changed = copy.deepcopy(good)
        changed['citations'][0]['relevance'] = {'status':'uncertain','level':'metadata','reason':'title differs',
            'trigger':'title differs','report':True,'clear_evidence':False}
        self.assertFalse(audit(changed)['mechanical_closure'])
        changed = copy.deepcopy(good)
        changed['references'][0]['verification'].update(status='not_found')
        self.assertFalse(audit(changed)['mechanical_closure'])

    def test_audit_rejects_stale_match_hidden_issue_and_removed_candidates(self):
        good = self.valid_ledger()
        changed = copy.deepcopy(good)
        changed['references'][0].update(authors=['someone-else'],year='1999')
        self.assertFalse(audit(changed)['mechanical_closure'])
        changed = copy.deepcopy(good)
        changed['citations'][0]['crosscheck'] = {'status':'missing_reference','reason':'No entry'}
        changed['citations'][0]['issue_ids'] = ['i1']
        changed['references'][0]['usage'] = {'status':'allowed_uncited','reason':'Special bibliography','basis':'Explicit user instruction'}
        changed['issues'] = [{'id':'i1','category':'missing','original':'P1 (2020)','comment':'Add entry',
                             'reason':'Missing','location':'u1','decision':'rejected'}]
        self.assertFalse(audit(changed)['mechanical_closure'])
        changed = copy.deepcopy(good)
        Path(changed['source']).write_text('甲（2020）',encoding='utf-8')
        write(changed['extraction'], extract(changed['source']))
        changed['source_sha256'] = digest(changed['source'])
        changed['extraction_sha256'] = digest(changed['extraction'])
        self.assertFalse(audit(changed)['mechanical_closure'])

    def test_pdf_native_highlight_preserves_contents(self):
        try:
            from reportlab.pdfgen.canvas import Canvas
            from pypdf import PdfReader
            import pypdfium2
        except ImportError:
            self.skipTest('PDF dependencies unavailable')
        src, out = self.root/'source.pdf', self.root/'annotated.pdf'
        c = Canvas(str(src))
        c.drawString(60, 750, 'Example (Author, 2020).')
        c.save()
        chars = pdf_chars(src, 1)['characters']
        start = next(x['index'] for x in chars if x['text'] == '2')
        result = annotate_pdf(src, {'annotations':[{'issue_id':'i1','page':1,'char_start':start,'char_count':4,
            'expected':'2020','comment':'Check year','kind':'query'}]}, out)
        self.assertTrue(result['body_streams_preserved'])
        r = PdfReader(out)
        self.assertEqual(len(r.pages[0]['/Annots']),1)
        self.assertEqual(str(r.pages[0]['/Annots'][0].get_object()['/Contents']), 'Check year')

if __name__ == '__main__':
    unittest.main()

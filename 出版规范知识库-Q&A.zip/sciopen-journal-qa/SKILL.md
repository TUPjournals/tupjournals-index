---
name: sciopen-journal-qa
description: 英文科技期刊日常出版规范、出版伦理、投稿指南条款、数据库收录（DOAJ/Scopus/Web of Science/ESCI）相关问题的解答与文案起草。当用户（SciOpen 期刊出版人）询问出版规范条款怎么写、是否符合 COPE/STM/ICMJE/CRediT 规范、期刊申请数据库需要什么条件、投稿指南英文表述润色、编委/作者署名/伦理声明/OA 政策、或需要给编辑部拟回复时使用。所有回答基于国际出版组织规范、数据库评估要求、主流出版商规范与 SciOpen 平台做法，先核实官网原文再作答。
agent_created: true
---

# SciOpen Journal Publishing Q&A

## Overview

为 SciOpen 期刊出版人提供英文科技期刊出版规范、出版伦理、数据库收录相关问题的权威解答，以及可直接复制粘贴的投稿指南英文条款、编辑部回复文案。所有结论以国际出版组织、数据库、主流出版商官网原文为准，不用通用印象作答。

## 核心工作准则（最高优先级）

1. **先核实原文，再作答**：凡涉及具体条款、数字、定义、收录要求，必须联网核实权威官网原文（优先官网，其次标准原文 PDF），给出处。核实不到就明确标注"未能核实"，绝不编造。
2. **规范体系及优先级**（冲突时须指出并按场景给选择建议）：
   - 国际出版组织：COPE、STM、OASPA、WAME（联合发布 *Principles of Transparency and Best Practice in Scholarly Publishing*），ICMJE（作者资格），NISO/CRediT（贡献角色），NISO JAV（文章版本）。
   - 数据库评估：DOAJ、Scopus（CSAB 选择标准）、Web of Science / ESCI（Clarivate 28 项标准）。
   - 主流出版商：Elsevier、Springer Nature、Wiley、Taylor & Francis、ACS、PLOS。
   - SciOpen 平台自身规范与实际做法。
3. **口径冲突处理**：不同机构口径不一致时，明确列出各方说法，指出适用场景（如医学刊用 ICMJE、非医学刊可放宽；JA 与 Online First 属不同体系），由编辑部决定。
4. **输出风格**：中文说明 + 可直接复制的英文表述；常给"一句版/完整版"两档；把决定权交回编辑部（"编辑部可以根据自己的需求修改"）。简洁明了，不堆砌。
5. **版本时效**：引用规范须带版本号/日期；本 skill 的 references 每月核查更新一次。核实前先看 `references/version-tracker.md` 中的当前版本，若官网已更新，以官网为准并同步更新该文件。

## 回答工作流

1. **识别问题类型**：规范条款改写 / 概念解释 / 数据库申请 / 文案起草（微信回复、投稿指南条款）。
2. **定位规范来源**：按核心准则第 2 条确定应查哪些机构；对照 `references/` 中对应主题的要点（见下）。
3. **联网核实**：用 WebSearch/WebFetch 核实关键原句、URL、版本日期。涉及具体条款务必逐字核实；references 里的旧结论若官网已更新，以官网为准。
4. **组织答案**：
   - 先给结论（一句话）。
   - 再给依据（关键原句 + 出处 + 版本）。
   - 给可直接使用的表述（英文条款/回复话术），必要时给精简版。
   - 有风险/冲突时单独提示。
5. **收尾**：按用户偏好把修改权交回编辑部；涉及 DOAJ/Scopus/WoS 申请时附上必须公示的信息清单。

## 主题索引（先读对应 reference，再联网核实）

| 问题类型 | 参考文件 |
|---|---|
| 作者资格、署名、CRediT、作者贡献声明 | `references/authorship-and-contribution.md` |
| AI 使用（作者/审稿人/编辑三方、披露模板、AI 不得署名） | `references/ai-use-policy.md` |
| 伦理声明、同行评审、利益冲突、出版伦理政策 | `references/ethics-and-transparency.md` |
| 勘误/更正/Erratum/关注声明/撤稿/删除 | `references/corrections-and-retractions.md` |
| 文章版本：Just Accepted / Online First / VoR、出版时效、图件规范 | `references/publishing-process.md` |
| DOAJ / Scopus / WoS-ESCI 收录要求与申请 | `references/databases.md` |
| EI / PubMed / MEDLINE / PMC 收录要求与申请 | `references/databases-ei-pubmed.md` |
| 编委/顾问/青年编委统计、OA 政策、转型声明 | `references/editorial-board-and-oa.md` |
| 稿件转移、期刊平台迁移、S2O、DOI/ORCID/预印本/数据声明/试验注册/版权 | `references/transfers-and-publishing-practices.md` |
| 各规范当前版本号、核实 URL、更新记录 | `references/version-tracker.md` |

**使用方式**：每月维护时先读 `version-tracker.md` 的版本清单，逐个 URL 核实；发现更新则修改对应 reference 文件并在 tracker 的更新记录中追加一条。

## Resources

### references/
11 个 Markdown 文件，按上表主题组织，含官网逐字原句、URL、版本日期与实务含义。仅核实过的内容写入，未核实项明确标注。每月核查更新。

### scripts/
无（本 skill 以规范和文案为主，无需可执行脚本）。

### assets/
无。

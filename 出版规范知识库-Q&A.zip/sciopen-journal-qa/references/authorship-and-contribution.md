# 作者资格、署名、CRediT 与作者贡献声明

> 最后核实：2026-11-17。回答前先看 `version-tracker.md` 确认版本，涉及具体条款再联网核实官网原文。

## 1. ICMJE 四条作者资格标准

**来源**：https://www.icmje.org/recommendations/browse/roles-and-responsibilities/defining-the-role-of-authors-and-contributors.html （Updated January 2026）

**逐字原句**：
> "The ICMJE recommends that authorship be based on the following 4 criteria:
> - Substantial contributions to the conception or design of the work; or the acquisition, analysis, or interpretation of data for the work; AND
> - Drafting the work or reviewing it critically for important intellectual content; AND
> - Final approval of the version to be published; AND
> - Agreement to be accountable for all aspects of the work in ensuring that questions related to the accuracy or integrity of any part of the work are appropriately investigated and resolved."

**Section II.A.3 非作者贡献（逐字）**：
> "Examples of activities that alone (without other contributions) do not qualify a contributor for authorship are acquisition of funding; general supervision of a research group or general administrative support; and writing assistance, technical editing, language editing, and proofreading."

**实务**：四条须全部满足；只拿经费、一般监督/行政、写作协助、语言编辑/校对者不能署名，只能致谢。

## 2. CRediT（NISO）

**来源**：https://www.niso.org/publications/z39104-2022-credit ；https://credit.niso.org/ ；https://credit.niso.org/contributor-roles-defined/
**版本**：ANSI/NISO Z39.104-2022（ANSI 批准 2022-01-14，发布 2022-02-08），DOI 10.3789/ansi.niso.z39.104-2022，CC BY 4.0。

**标准号逐字**："ANSI/NISO Z39.104-2022, CRediT, Contributor Roles Taxonomy"

**14 个官方角色（逐字）**：
1. Conceptualization
2. Data curation
3. Formal analysis
4. Funding acquisition
5. Investigation
6. Methodology
7. Project administration
8. Resources
9. Software
10. Supervision
11. Validation
12. Visualization
13. Writing – original draft
14. Writing – review & editing

**免责原句（关键）**：
> "While CRediT is being used by publishers to capture information about the specific contributions of its authors, it is not designed to determine authorship; publishers adhere to strict guidelines around what qualifies as authorship."

**实务**：CRediT 只描述"谁做了什么"，不判定作者资格；两者在投稿指南里必须分开写，不能用 and 并列让人误以为一回事。

## 3. 主流出版商 CRediT 做法

### Elsevier
**URL**：https://www.elsevier.com/researcher/author/policies-and-guidelines/credit-author-statement
**原句**：
> "CRediT in no way changes the journal's criteria to qualify for authorship"
> "The corresponding author is responsible for ensuring that the descriptions are accurate and agreed by all authors"
> "CRediT statements should be provided during the submission process and will appear above the acknowledgment section of the published paper"

示例格式（姓名在前、角色在后）：`Zhang San: Conceptualization, Methodology, Software.`

### Wiley
**URL**：https://authorservices.wiley.com/author-resources/Journal-Authors/open-access/credit.html
**原句**：
> "Journals mandating CRediT (Contributor Roles Taxonomy) will enable authors to provide information on submission... If not provided on submission, this information can be provided at subsequent revision stages"
> "The submitting author is responsible for ensuring that contributions of all authors are correct."

程度词示例：`Kerys Jones: Conceptualization (lead)... writing – review and editing (equal)`；`Jinnie Wu: Conceptualization (supporting)...`（lead / equal / supporting）

### Springer Nature
**URL**：https://www.springernature.com/.../editorial-policies ；https://www.nature.com/npjdigipubhealth/editorial-policies/authorship （稿约示例更新 2026-06-10）
**原句**：
> "We believe that every author's contribution to a research paper should be clearly credited. We achieve this by requiring authors to include a statement in the manuscript that specifies the contribution of each author."

作者标准改编自 McNutt et al., PNAS 2018（DOI 10.1073/pnas.1715374115），并增列 "or the creation of new software used in the work"。稿约示例："Please provide your and your co-authors' contribution to the research, according to the CRediT taxonomy defined in the table below. Please use initials to refer to each author's contribution."

### PLOS（例外：McNutt 2018，非 ICMJE）
**URL**：https://journals.plos.org/ploscompbiol/s/authorship ；https://theplosblog.plos.org?p=21285
**原句**：
> "Most PLOS journals transitioned in May 2023 to follow the authorship guidance discussed in McNutt et al. (2018)..."
> "all PLOS journals except PLOS Medicine now apply the authorship criteria put forth in a 2018 PNAS article by Marcia McNutt et al. (PLOS Medicine is an ICMJE member and continues to apply ICMJE authorship criteria.)"
> "PLOS has adopted the CRediT Taxonomy to describe each author's individual contributions to the work."

**实务**：多数 PLOS 期刊用更宽松的 McNutt 2018（承认软件贡献、写作本身可独立构成作者），PLOS Medicine 仍用 ICMJE。

## 4. COPE 与 WAME 的作者底线

### COPE Authorship Discussion Document
**URL**：https://publicationethics.org/guidance/discussion-document/authorship （2019-09，DOI 10.24318/cope.2019.3.3）
**原句**：
> "Two minimum requirements define authorship across all definitions: making a substantial contribution to the work and being accountable for the work and its published form."
> "Acknowledgements can be used to denote contributions to the work that do not meet the criteria of authorship."
> "Journals should have a process for handling authorship issues and disputes identified or raised during the review and publication process, and after publication."

### WAME Authorship（医学刊）
**URL**：https://wame.org/authorship
**原句**：
> "Everyone who has made substantial intellectual contributions to the study on which the article is based... should be an author."
> "Performing technical services, translating text, identifying patients for study, supplying materials, and providing funding or administrative oversight over facilities where the work was done are not, in themselves, sufficient for authorship, although these contributions may be acknowledged in the manuscript..."
> "One author (a 'guarantor') should take responsibility for the integrity of the work as a whole."

**实务**：COPE 只设两条底线（实质贡献 + 对作品负责），各学科可自定细则；医学刊可参照 WAME 的 guarantor 概念。

## 5. AI 与署名

- COPE 联合原则 v5.0："Current scholarly consensus is that AI cannot qualify for authorship. However, if a journal accepts AI as an author, that should be stated."
- WAME（2023-05-31）："Chatbots cannot be authors."（理由：无法满足 final approval 与 accountability）
- STM（Dec 2023）："AI must not be credited as an author"，并要求披露使用方式。
- COPE v5.0 要求期刊明示作者对 AI 用于内容生成（研究设计、方法、结果、数据分析、图表、引言、讨论、引用）的披露政策。

**实务**：投稿指南应写明"AI 工具不得列为作者，使用情况须另行声明"。

## 6. 投稿指南条款要点（博物馆式清单，供起草时对照）

- 用 CRediT 14 角色描述贡献，角色名按官方拼写（`Writing – original draft`，注意是 en dash）。
- 明确"CRediT 不决定作者资格"，作者资格另按期刊标准（医学刊用 ICMJE；非医学刊可用 COPE 底线或 McNutt 2018）。
- 只拿经费/一般监督/行政支持者不署名，写入致谢。
- 通讯作者负责声明准确、全体同意。
- 末句覆盖 ICMJE 第 3、4 条：`All authors have read and approved the final version of the manuscript and agree to be accountable for all aspects of the work.`
- 不规定声明在正文中的具体位置（各家冲突），位置交编辑部/排版决定。
- 示例中的 `Author 1/2/3` 换成真实姓名或 initials；`writing manuscript` → `Writing – original draft`；`experimental design` 不是 CRediT 角色，归入 Conceptualization / Methodology。

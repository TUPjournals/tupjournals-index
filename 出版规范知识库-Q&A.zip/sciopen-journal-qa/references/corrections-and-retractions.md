# 勘误、更正、关注声明与撤稿

> 最后核实：2026-11-17。**COPE 撤稿指南已升级 V3（2025-08）**，旧 2019 V2 表述需更新。回答前联网核实官网最新版。

## 1. 术语体系（先分清）

| 类型 | 适用情形 | 权威定义来源 |
|---|---|---|
| **Correction / Corrigendum** | 有错误但不影响结论，需更正 | Elsevier: 作者错误且不影响结果结论；Springer: 影响准确性但不实质推翻结论 |
| **Erratum** | 出版方在出版环节造成的错误 | Elsevier: "correct an error made during the publication of an article" |
| **Expression of Concern (EoC)** | 有重大可信关切但尚不满足撤稿，或一时无法取得定论 | COPE EoC 指南（2025-08-27） |
| **Retraction（撤稿）** | 内容/数据严重缺陷，发现与结论不可依赖 | COPE Retraction Guidelines V3（2025-08） |
| **Removal / Withdrawal（删除/撤回）** | 极少例外（诽谤、法院令、严重健康风险），且不删书目信息 | Elsevier / Springer / Wiley |

**关键**：COPE/ICMJE 官网**无** Erratum vs Corrigendum 的权威区分，该区分来自出版商政策（Elsevier 原句见上）。写投稿指南时若要区分，注明依据出版商惯例。

## 2. COPE Retraction Guidelines V3（2025-08）

**URL**：https://publicationethics.org/guidance/guideline/retraction-guidelines ；PDF https://publicationethics.org/files/retraction%20guidelines_0.pdf ；立场文 https://publicationethics.org/guidance/cope-position/issuing-retractions
**版本**：Version 3, August 2025，DOI 10.24318/cope.2019.1.4（前版 V2, Nov 2019）；立场文 DOI 10.24318/RYpiIFib

**撤稿定义与目的（原句）**：
> "Retraction is a mechanism for correcting the literature and alerting readers to articles that have such seriously flawed or erroneous content or data that their findings and conclusions cannot be relied upon."
> "The purpose of retraction is to correct the literature and ensure its integrity, not to punish the authors."

**应更正而非撤稿（原句）**：
> "If only a small part of an article reports flawed data or content, this may be best rectified by a correction. Partial retractions are not helpful because they make it difficult to determine the status of the article and which parts may be relied upon."

**应撤稿情形（原句）**：
> "Retraction might be warranted if there is clear evidence of major errors, irregularities in the data or images, or any form of misrepresentation (eg, fraud, identity theft or fictitious authorship) that compromise the reliability of the findings."
> "Retractions might be necessary for unethical research practices, compromised peer review, or undisclosed conflicts of interest that could bias interpretation of the work or recommendations by peer reviewers."

**不宜撤稿（原句）**：
> "Retractions are not usually appropriate if: … The main findings of the work are still reliable and correction could sufficiently address errors or concerns … An editor has inconclusive evidence to support retraction …"
> "If an editor is uncertain about the reliability of a publication because of insufficient information, delays, or inability to obtain information, for example, retraction might not be appropriate."

**撤稿通知要素（原句）**：
> "Notices of retraction should link to the retracted article, clearly identify it with title and authors, and be published promptly and be freely accessible to all readers."
> "Who is retracting the article should be stated (for example, the editor or publisher), along with the reasons and basis for retraction so that readers understand why the article is unreliable."
> "Editors should proceed with retraction and publication of the retraction notice even if the authors do not agree or cannot be contacted."

**不可删除（原句）**：
> "These amendments should be accessible, indexable items that should not be removed from the scholarly record."

**未能核实**：COPE 未把 DOI 或利益冲突声明列为撤稿通知的强制要素（COI 仅作为撤稿事由）。

## 3. COPE Expression of Concern 指南（2025-08-27）

**URL**：https://publicationethics.org/guidance/guideline/expressions-concern ；DOI 10.24318/mw2J3661
**原句**：
> "An expression of concern might be warranted if there are major and credible concerns about the reliability of a publication which do not meet the criteria for a retraction, or conclusive evidence cannot be obtained for some time."
> "Expression of concern notices should link to the affected article, clearly identify it, state the reasons for the concern, and be freely available to all readers."；"be objective, factual, and avoid inflammatory language."
> "An expression of concern can be used as an interim notice and followed up with either a correction or retraction, or it could the final outcome for an article that will not be updated further."

**实务**：证据未定或调查未结时用 EoC 占位；写明理由、链接原文、客观中立；可以是临时措施，也可作为最终结果。

## 4. STM 立场：保留而非删除

**URL**：https://stm-assoc.org/what-we-do/strategic-areas/research-integrity ；CUSAP https://stm-assoc.org/what-we-do/strategic-areas/standards-technology/cusap
**原句**：
> "Taking timely action when potential issues arise, including managing investigations, post-publication corrections (including retractions), and communicating transparently with the scientific community whilst respecting confidentiality where it is needed."
> "Articles that have been published should remain extant, exact and unaltered to the maximum extent possible."
> "STM supports the principle of favouring 'retraction' (erratum) over 'removal' in virtually all cases."
> "Even in these circumstances, bibliographic information about the 'removed' article should be retained for the scientific record, and an explanation given, however brief, about the circumstances of its removal."

**实务**：默认更正/撤稿优于删除；删除仅限法律或健康风险等例外，且须保留书目信息并说明原因。**STM《Preservation of the Objective Record of Science》官方 PDF 地址未能核实**；STM 对撤稿率的量化要求未能核实。

## 5. ICMJE：错误、造假与撤稿

**URL**：https://www.icmje.org/recommendations/browse/publishing-and-editorial-issues/corrections-and-version-control.html ；https://www.icmje.org/recommendations/browse/publishing-and-editorial-issues/scientific-misconduct-expressions-of-concern-and-retraction.html
**原句**：
> "Honest errors are a part of science and publishing and require publication of a correction when they are detected."；"Matters of debate and evolving science and methods are not errors."
> "Errors serious enough to invalidate a paper's results and conclusions may require retraction."
> "Scientific misconduct in research and non-research publications includes but is not necessarily limited to data fabrication; data falsification including deceptive manipulation of images; purposeful failure to disclose relationships and activities; and plagiarism"
> "If the investigation proves scientific misconduct, publish a retraction of the article."
> "Online, the retraction and original article should be linked in both directions and the retracted article should be clearly labelled as retracted in all its forms (Abstract, full text, PDF)."
> "Retracted articles should remain in the public domain and be clearly labelled as retracted."
> "The text of the retraction should explain why the article is being retracted and include a complete citation reference to that article."

**实务**：诚实错误→更正；结论失效→撤稿；造假经调查证实→撤稿；全文各版本（摘要/全文/PDF）均标注 RETRACTED，与撤稿声明双向链接，永久保留。

## 6. 主流出版商操作差异

### Elsevier（Article Correction, Retraction and Removal Policy）
**URL**：https://www.elsevier.com/about/policies-and-standards/article-withdrawal
> "A Corrigendum will be published where it is required to correct an error or omission, but the results and conclusions of the article are not impacted by the error."
> "On rare occasions the Publisher may need to correct an error made during the publication of an article. Where this is the case, the journal will issue an Erratum to correct the error."
> "A retraction notice titled 'Retraction: [article title]' signed by the editor and, if appropriate, by the authors is published in a subsequent issue of the journal, is paginated and is listed in the table of contents."
> "The original article is retained unchanged except for a watermark on the .pdf indicating on each page that it is 'retracted.'"
> "removal of an article is rare and will only occur where it is determined that: … defamatory … court order … serious health risk."

### Springer Nature
**URL**：https://link.springer.com/brands/bmc/editorial-policies ；https://link.springer.com/brands/springer/journal-policies
> "Errors in published articles that affect the accuracy of the article, but do not substantially invalidate the conclusion, will, at the Editor(s)' discretion, be corrected via publication of a Correction that is indexed and bidirectionally linked to the original article."
> "Retractions are designed to be a neutral tool to correct the literature and should not be viewed as punitive."
> "The original article is watermarked as retracted, and the title is amended with the prefix 'Retracted article:'"
> "EEoCs are published online and are bidirectionally linked to the published paper. They receive a DOI and are indexed in major scholarly databases such as PubMed, Web of Science and Scopus."
> "Removal may be temporary or permanent. Bibliographic metadata (e.g. title and authors) will be retained…"

**注**：Springer 官方正文统一用 `Correction`，独立的"Erratum vs Correction"专页未能核实。

### Wiley
**URL**：https://www.wiley.com/en-us/publishing/article/editors-and-reviewers/resources/managing-corrections-to-published-articles ；https://authors.wiley.com/asset/Best-Practice-Guidelines-on-Publishing-Ethics-2ed.pdf
> "It's transparent. Neither the article being corrected nor the changes that have been made to it are hidden or obscured, and the correction is dated."
> "Corrections that have published separately should be in front of the paywall and accessible to all readers."
> "Withdrawal or removal of articles is strongly discouraged."
> "Even in these circumstances, a retraction statement must still be published to ensure that bibliographic information about the removed article is retained for the scientific record"
> "the title of a Retraction or Expression of Concern should include the words 'Retraction' or 'Expression of Concern' as well as information to identify the article that it refers to."

## 7. 五家共同底线（可直接给用户）

**保留、链接、不删除、理由透明、免费可读。** 撤稿不是惩罚作者，而是纠正文献；小错用更正而非部分撤稿；证据未定用 EoC；删除是最后手段且保留书目信息。

## 8. PubMed 的标注联动（见 databases-ei-pubmed.md）

撤稿/更正声明须用正确出版类型（Retraction Notice / Retracted Publication / Published Erratum / Expression of Concern / Corrected and Republished Article），并通过 `hasretractionin` / `haserratumin` 等字段与原文双向链接。

# 数据库收录：EI 与 PubMed 体系

> 最后核实：2026-11-17。收录标准常变，回答申请类问题务必联网核实官网最新版。DOAJ/Scopus/WoS 见 `databases.md`。

## 1. EI / Engineering Village（Elsevier 工程索引）

**URL**：https://www.elsevier.com/products/engineering-village/databases/selection-criteria ；https://www.elsevier.com/products/engineering-village/databases/compendex
**版本**：页面未标日期，检索 2026-11-17，来源表文件 COMPENDEX_Source-list-082026.xlsx（2026-08）

### 选刊标准（原句）
> "Selections for new publications and content are made, in part, with the advice of external, independent reviewers, based on their professional expertise and background."
> "Engineering publications that are selected contain articles predominantly on core engineering subjects."

**最低门槛（原句逐条）**：`Valid, Registered ISSN` / `Peer-review` / `English Abstracts` / `Regular Publication` / `Publication Ethics Statement (COPE)` / `Digital Preservation Policy (PORTICO)`

**评审维度（原句）**：
> "Broad geographic distribution of editors" / "Broad geographic distribution of authors" / "Citedness of journal articles, including self-citation rate" / "Quality and conformity with stated aims & scope"

**语言（原句）**：
> "Engineering publications must have an English-language title and publish English-language abstracts for all engineering research articles. However, full-text articles can be in any language."
> "Publications must consist of peer-reviewed engineering content and have a publicly available description of the peer review process."

**实务**：按刊整体遴选；硬门槛是有效 ISSN、同行评审、英文题名与摘要、定期出版、COPE 伦理声明、PORTICO 长期保存政策；另看编委/作者地域分布、自引率、与 aims & scope 的契合。全文可为非英文。

### Compendex 与 Page One
**原句**：现行官网仅见 "Compendex is Elsevier's flagship engineering-focused database"；现行官网**已无** "Page One" 字样。
**实务**：不要再向编辑部讲"核心版/Page One 非核心版"的区分——官网已取消该口径。

### 申请与查询
**原句**："You have the option to suggest a journal or a conference title:"；"You may submit journal suggestions for Ei Compendex and/or GEOBASE."
**URL**：http://suggestor.ei.engineeringvillage.com/ （Title Suggestion Form）
**实务**：通过官方推荐表提交期刊/会议；是否被收录以官方 source list 及 Engineering Village 中按 Source title/ISSN 检索为准。

### 会议录与不选类型
**原句**：
> "Initial eligibility of conference proceedings will be evaluated on adherence to the following minimum criteria: Valid, Registered ISSN/ISBN, Peer-review, Full-text Papers with English Abstracts, Content Accessible Online, Publication Ethics Statement"
> "Engineering publications that consist primarily of content from reprinted articles, reports of association activities, abstracts of engineering literature, news items, or book reviews, will typically not be considered for selection."

**实务**：会议录单列标准（全文+英文摘要+伦理声明）；转载/资讯/书评类出版物通常不收。**特刊（special issue）专门条款未能核实**。

## 2. PubMed / MEDLINE / PMC（NLM/NIH）

### 三者关系（原句，务必区分）
**URL**：https://pubmed.ncbi.nlm.nih.gov/about （Last update: March 11, 2025）
> "PubMed is a free resource supporting the search and retrieval of biomedical and life sciences literature"；"It does not include full text journal articles"
> "MEDLINE is the largest component of PubMed and consists primarily of citations from journals selected for MEDLINE"
> "PMC is a full text archive that includes articles from journals reviewed and selected by NLM for archiving"

**实务**：PubMed = 免费检索系统（不含全文）；MEDLINE = 其核心书目数据库（经选刊）；PMC = 全文开放仓储。三者不可混称，"被 PubMed 收录"通常指进入 MEDLINE。

### MEDLINE 选刊标准
**URL**：https://www.nlm.nih.gov/medline/medline_journal_selection.html （Last Reviewed July 24, 2026）；https://www.nlm.nih.gov/medline/medline_how_to_include.html ；https://www.nlm.nih.gov/medline/medline_policies.html（含 As of June 2025）
**原句**：
> "The National Library of Medicine (NLM) decides whether the scientific and editorial character and quality of a journal merit its inclusion in MEDLINE."
> "At least two consultants, usually one scientist ... and one medical librarian review each journal."

**五大评审要素**：`Scope and Coverage` / `Editorial Policies and Processes` / `Scientific Rigor/Methodological Rigor` / `Production and Administration` / `Impact`

**硬门槛（原句）**：
> "The journal must have a properly registered ISSN"、"a minimum of 40 primary, peer-reviewed articles"、"published for at least 12 months"、"publish abstracts for all peer-reviewed content"
> "all primary articles (i.e. peer-reviewed articles) must have English abstracts and titles."

**实务**：按刊整体评审；ISSN、≥40 篇原始同行评审文章、出版≥12 个月、全部同行评审内容有英文摘要和英文题名为硬门槛；至少两名顾问（科学家+医学图书馆员）评审。

### PMC 路径与 OA
**URL**：https://pmc.ncbi.nlm.nih.gov/about/intro/ （March 9, 2026）；https://grants.nih.gov/policy-and-compliance/policy-topics/public-access（June 23, 2025）
**原句**：
> "PMC is a free full-text archive of biomedical and life sciences journal literature"
> "PMC also contains author manuscripts deposited through the NIH Manuscript Submission System (NIHMS)"
> "PMC makes all content free to read (in some cases, following an embargo period)"
> "The 2024 NIH Public Access Policy requires Author Accepted Manuscripts ... on or after July 1, 2025, to be submitted to PubMed Central upon acceptance for publication, for public availability without embargo upon the Official Date of Publication."

**实务**：三条路径——期刊整期存缴、选择性存缴、作者稿经 NIHMS 存缴；全部免费阅读（部分有禁运期）；NIH 资助论文须在接收后存缴接收稿、正式发表日无禁运开放。

### 文章元数据要求
**URL**：https://www.ncbi.nlm.nih.gov/books/NBK3828/ （NLM XML Help）；https://www.nlm.nih.gov/medline/medline_journal_selection.html
**原句**：
> "The XML you submit must match the published article's version of record."
> DOI："Submit it in the standard format, e.g., 10.xxx/xxx."
> 结构化摘要："For structured abstracts with section headings (for example, OBJECTIVE, DESIGN), format each heading as: Fully capitalized, followed by a colon and a space"
> 作者："Use the EqualContrib attribute value 'Y' to indicate equal contribution among authors."；"The Source attribute specifies which authority issued it (e.g., ORCID, ROR, Ringgold)"
> 参考文献："We encourage publishers to include reference lists using the <ReferenceList> element."
> 利益冲突："The Conflict of Interest statement associated with this article."
> 伦理："Are statements regarding approval from an ethics committee ... and informed consent present in all relevant articles?"

**实务**：NLM XML 须与 VoR 一致；DOI、结构化摘要、参考文献、ORCID、COI 均有明确字段；伦理委员会批准与知情同意属期刊评审要点。独立"数据可用性声明"字段**未能核实**。

### 更正与撤稿的标注
**URL**：https://pubmed.ncbi.nlm.nih.gov/help/ （Last update September 30, 2026）；https://www.ncbi.nlm.nih.gov/books/NBK3828/
**出版类型（原句）**：`Corrected and Republished Article` / `Expression of Concern` / `Published Erratum` / `Retracted Publication` / `Retraction Notice`
**关联字段（原句）**：`Corrected and republished in: hascorrectedrepublishedin` / `Erratum in: haserratumin` / `Expression of concern in: hasexpressionofconcernin` / `Retraction in: hasretractionin`
> "Citations for expressions of concern, errata, and retractions must use the correct PublicationType values"

**实务**：以出版类型 + 双向链接标注更正/撤稿，原文保留不删除。注意：常见说法 "Retraction of Publication" **不是**现行官网逐字项，现行作 `Retraction Notice` / `Retracted Publication`。

## 3. 三大体系横向对照（给用户一句话版）

- **EI**：工程类，重英文题名/摘要、ISSN、同行评审、伦理声明与长期保存政策；不收纯资讯/转载类。
- **PubMed 体系**：生物医学，PubMed 检索 / MEDLINE 书目 / PMC 全文三段分开；MEDLINE 硬门槛是 ISSN+40 篇+12 个月+英文摘要题名。
- **与 DOAJ 差异**：DOAJ 强制开放许可（CC 或等效）且拒 hybrid/bronze；EI 与 MEDLINE 不要求期刊 OA，但 PMC 存缴内容须免费可读。

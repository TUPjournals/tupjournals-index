# 数据库收录要求：DOAJ / Scopus / Web of Science-ESCI

> 最后核实：2026-11-17。收录标准常变，回答申请类问题务必联网核实官网最新版。

## 1. DOAJ

**URL**：https://doaj.org/apply/guide/ （Guide v2.9）；https://doaj.org/apply/copyright-and-licensing/ （v2.1, Jan 2026）；https://doaj.org/apply/transparency

### OA 定义与拒绝 bronze
**原句**：
> "We define these as journals where the copyright holder of a scholarly work grants usage rights to others using an open license (Creative Commons or equivalent). This allows for immediate free access to the work..."
> "The full text of all content must be available for free and open access without delay."
> "We do not accept free-to-read journals that restrict reuse of their content to 'fair use' only, also known as 'Bronze journals'."

**实务**：必须 CC 或等效开放许可、无延迟无注册墙；仅"免费阅读"（free access / free to read）不算 DOAJ 意义的 OA。

### 只收完全 OA / 不收 hybrid
**原句**：
> "DOAJ only accepts open access journals."
> "DOAJ does not index hybrid journals, i.e., journals that publish open access articles together with articles accessible only with subscription, payment, or registration."

**实务**：hybrid 刊不可申请；不要在申请或官网文案里写 "articles are hybrid"（会被判为 hybrid 刊）。Guide 当前版未逐字出现 "only accepts fully open access journals" 整句（该短语仅见于 Flipped journals 条款），但实质口径一致。

### 编委要求
**原句**：
> "The editorial board must be listed on the website."
> "The name and affiliation of all editors and board members must be included."
> "The editorial board for the journal should consist of at least five editors with appropriate qualifications and expertise. It is recommended that board members should not all come from the same institution."

**实务**：编委至少 5 人、逐人列姓名+单位、宜跨机构。"名单保持更新/成员须同意任职"的逐字句在 Guide v2.9 无（旧版条款），但在 COPE 联合原则 v5.0 有 "The list should be up to date, and members must agree to serve"。

### Flipped journals（转型期刊）
**原句**：
> "The date of the change to fully open access"
> "The availability of the archive material (open access, free, or paywalled)"
> "Reuse rights of the archive material (all rights reserved or open license)"
> "All content published after the flipped date must be completely open access."

**实务**：须公示转型日期、存档内容获取状态（OA/free/paywalled）、存档重用权（all rights reserved 或开放许可）；转型后内容全 OA。DOAJ 考虑 flipped journals 的条件：出版史>1年 或 已发表≥10 篇 fully OA 研究论文。
**已验证的简洁表述**（用户采用版）：`This journal transitioned to fully open access on 1 January 2025 (Volume 29 onwards). All articles published before this date are free to read in the journal archive, with all rights reserved.`
**注意**：`with all rights reserved` 只适用于转型前的旧文章（非 OA 内容）；若旧文章已挂 CC 许可须改。主页还须另配一段符合 BOAI/libre OA 定义的完整 OA 声明，申请表 "Link to the journal's open access statement" 填该页链接。

### Endogeny（自家发文）25%
**原句**：
> "The proportion of published research papers where at least one of the authors is an editor, editorial board member, or reviewer must not exceed 25% in either of the latest two issues."

连续出版："endogeny must not exceed 25% in the last calendar year (minimum 5 articles per year)"。

### Integrity and Ethics 审查五方面
**原句**：
> "Presence of clear and reliable key information on the journal's website" / "Composition of the journal's editorial board" / "Signs of poor peer review processes" / "Reputation of the journal, including any association with paper mills, excluded journals or publishers, or other disreputable organisations" / "Journal management and operation"

### DOAJ 官网必列信息（主页可进入）
Open access policy / Aims and scope / Editorial board（含单位）/ Instructions for authors / Editorial process (peer review) / Licensing terms / Copyright terms / Author charges（无也要声明）/ Publisher information / ISSN。

## 2. Scopus（CSAB）

**URL**：https://www.elsevier.com/products/scopus/content/content-policy-and-selection

**五类标准（原句要点）**：
> "Journal policy — Convincing editorial policy / Type of peer review / Broad geographical distribution of editors / Broad geographical distribution of authors"
> "Content — Academic contribution to the field / Clarity of abstracts / Quality of and conformity to the stated aims and scope of the journal / Readability of articles"
> "Journal standing — Citedness of journal articles in Scopus / Editor standing"
> "Publishing regularity — No delays or interruptions in the publication schedule"
> "Online availability — Full journal content available online / English language journal home page available / Quality of journal homepage"

技术门槛原句："Have a publicly available publication ethics and publication malpractice statement"；"Consist of peer-reviewed content and have a publicly available description of its peer review process"。

**实务**：按政策/内容/声望/规律性/在线五类准备；强调编委地域广度、公开伦理声明与评审流程。
**未能核实**：Scopus 官网未检出"编委须列单位"或"对 misleading/inactive/honorary 编委态度"的逐字条款。

## 3. Web of Science / ESCI（Clarivate）

**URL**：https://clarivate.com/academia-government/scientific-and-academic-research/research-discovery-and-referencing/web-of-science/web-of-science-core-collection/editorial-selection-process/journal-evaluation-process-selection-criteria/

**28 项标准（原句）**：
> "We use a single set of 28 criteria to evaluate journals; these are divided into 24 quality criteria designed to select for editorial rigor and best practice at the journal level, and four impact criteria designed to select the most impactful journals in their respective fields using citation activity as the primary indicator of impact."

**编委要求（原句）**：
> "Names and institutional affiliations – including country/region – of all members of the editorial team are required (such as Editor-in-Chief, Editorial Board Members, Associate Editors, Regional Editors etc.)."
> "Editor and Editorial Board Member affiliations, geographic diversity, and publication records must be consistent with the stated scope and published content of the journal. The size and composition of the Editorial Board must be consistent with the volume and breadth of publication output."
> "The journal must be transparent about their ethical requirements for authors and published works."
> "Published content must reflect adequate and effective peer review and/or editorial oversight."

**ESCI vs 旗舰库（原句）**：
> "Journals that meet the quality criteria enter Emerging Sources Citation Index (ESCI). Journals that meet the additional impact criteria enter Science Citation Index Expanded (SCIE), Social Sciences Citation Index (SSCI) or Arts & Humanities Citation Index (AHCI) depending on their subject area."
> "All new submissions are evaluated using the 24 quality criteria only, and if selected for coverage are added to ESCI."
> "Ranking alone is not sufficient for a journal to be added to SCIE, SSCI, or AHCI – journals must continue to pass all 24 quality criteria as well as meet all 4 impact criteria."

**实务**：新刊先过 24 项质量关进 ESCI，再满足 4 项影响力标准才能进 SCIE/SSCI/AHCI；编委须逐人列姓名+单位（含国家/地区），地域多样、规模与产出匹配，动态升降。

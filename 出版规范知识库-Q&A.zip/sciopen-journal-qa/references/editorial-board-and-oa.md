# 编委统计、OA 政策与转型声明

> 最后核实：2026-11-17。涉及收录申请时先联网核实数据库官网最新版。

## 1. 顾问算不算编委统计

**结论：一般不算。** 顾问（Advisory Board / Advisory Committee）与编委（Editorial Board）是两个并列、分列统计的群体，但两者都必须在官网公开姓名和单位。

**规范依据**：
| 来源 | 原文/做法 | 含义 |
|---|---|---|
| COPE 联合原则 v5.0 第 12 条 | 标题 `Editorial Board/advisory body`；"Journals must have editorial boards **or other advisory bodies**... The full names and affiliations of the members must be provided... The list should be up to date, and members must agree to serve." | 编委会与顾问机构同条并列、透明度要求相同；用 `or` 说明是两类 bodies |
| DOAJ Guide v2.9 | "The editorial board... should consist of at least five editors with appropriate qualifications and expertise"；列全部 editors 和 board members 姓名单位 | 5 人下限算 editors/board members，不能用顾问充数 |
| Clarivate WoS | "Names and institutional affiliations... of all members of the editorial team are required (such as Editor-in-Chief, Editorial Board Members, Associate Editors, Regional Editors etc.)" | 按 editorial team 实际角色统计 |
| SciOpen 官网实际做法 | 各刊编委页分栏：`Editors-in-Chief / Associate Editors / Advisory Board Members / Editorial Board Members` 或 `Advisory Committee` 单列 | 平台自身分开展示、分别计数 |

**实操口径**：
- 计入编委：主编、执行主编、副主编（Associate/Deputy EIC）、Editorial Board Members（有稿件处理或决策职责）。
- 单列不计：Advisory Board / Advisory Committee、荣誉顾问、Senior Advisor 等咨询性头衔。
- 对外报数两个都报、不混算：`The journal has X editorial board members and Y advisory board members.`
- 禁忌：为凑 5 人或凑国际多样性把顾问算作编委——Scopus/WoS 评估看的就是官网名单构成，混算属透明度问题。
- 青年编委同样单列（SciOpen《Ocean》青年编委有聘期和审稿职责但独立招募），除非明确赋予决策编辑权限。
- 无论是否计入，顾问也须本人同意任职、公开姓名单位、名单保持最新（COPE 第 12 条）。

## 2. OA 声明与转型声明

### DOAJ 对 OA 声明的要求
**原句**（DOAJ 申请表示例）：
> "This is an open access journal which means that all content is freely available without charge to the user or his/her institution. Users are allowed to read, download, copy, distribute, print, search, or link to the full texts of the articles, or use them for any other lawful purpose, without asking prior permission from the publisher or the author. This is in accordance with the BOAI definition of open access."

**实务**：只有一句"本刊是 OA 刊"不够，必须有符合 BOAI/libre OA 定义的完整声明；OA 声明页链接填申请表 `Link to the journal's open access statement`。

### 转型声明（flipped journal）标准表述
**简洁版（用户已采用）**：
> This journal transitioned to fully open access on 1 January 2025 (Volume 29 onwards). All articles published before this date are free to read in the journal archive, with all rights reserved.

**更严谨版（限定对象，避免读者误读成整刊版权政策）**：
> This journal transitioned to fully open access on 1 January 2025 (Volume 29 onwards). Articles published before this date remain free to read in the journal archive; these archived articles are "all rights reserved" and are not covered by an open license.

**完整版 OA policy 页（含标准 OA 声明 + 转型说明）**：
> **Open access and archive policy.** This is an open access journal. All content published from 2025 onwards is freely available without charge to users and their institutions. Users are allowed to read, download, copy, distribute, print, search, or link to the full texts of the articles, or use them for any other lawful purpose, without asking prior permission from the publisher or the author, in accordance with the BOAI definition of open access. All such content is distributed under the terms of the [CC BY 4.0] license.
> This journal transitioned to a fully open access model on 1 January 2025, beginning with Volume 29. Articles published before the transition remain freely accessible in the journal archive. These articles are "all rights reserved"; no open license applies to them, and reuse is subject to copyright law.

**三处按实际情况确认**：
1. `[CC BY 4.0]` 换实际许可（DOAJ 接受六种 CC 及 CC0；出版社自有许可须写清条款且大致等效 CC）。
2. `all rights reserved` 必须符合旧文章实际版权标注；若旧文章已挂 CC 许可，改成对应许可名。
3. 版权归属（作者保留 vs 归出版社）按实际写，与许可条款不矛盾；"All rights reserved" 绝不用于 OA 内容。

## 3. OA 术语辨析（高频误区）

- **Gold OA**：期刊层面全 OA，通常 APC 模式，DOAJ 收录。
- **Hybrid**：订阅刊中部分文章 OA —— DOAJ **不收录**。
- **Bronze**：免费读但无开放许可（restrict reuse to fair use）—— DOAJ **不接受**。
- **Green**：机构/学科仓储自存档，不算期刊 OA 模式。
- **Diamond/Platinum OA**：免费读且作者免费发表，由机构/学会资助。
- **Free access / free to read**：只描述"获取免费"，不等于 OA；必须同时有开放许可才构成 DOAJ 定义的 OA。

# 出版伦理与透明原则

> 最后核实：2026-11-17。回答前先确认 `version-tracker.md` 中版本，涉及条款再联网核实。

## 1. COPE/DOAJ/OASPA/WAME 联合《透明与最佳实践原则》v5.0

**来源**：https://publicationethics.org/resources/guidelines/principles-transparency-and-best-practice-scholarly-publishing ；DOI 10.24318/cope.2019.1.12
**版本**：v5.0，2026-10-29（替代 v4.0 / 2022-09）

**v5.0 关键新要求（逐字）**：
> "Journals must have clear requirements for authorship and contributorship that allow for transparency around who contributed to the work and in what capacity, and who takes responsibility for the work. Processes for managing potential authorship disputes should also be stated."
> "Journals must state their policy on use of AI by authors for content correction and generation (including, but not limited to, development of study design, methods, results, data analysis, generation of figures and tables, introduction, discussion, and citations), and how that should be disclosed."
> "Current scholarly consensus is that AI cannot qualify for authorship. However, if a journal accepts AI as an author, that should be stated."
> "Peer review means getting advice and recommendations on manuscripts from independent scholars who are experts in the manuscript's subject area and/or methods. Those individuals must not be part of the journal's editorial office."
> "Journals must have editorial boards or other advisory bodies whose members are recognised experts in the subject areas stated in the journal's aims and scope. The full names and affiliations of the members must be provided on the journal's website. The list should be up to date, and members must agree to serve."
> "Journals should periodically review their board to ensure it is still relevant and appropriate."

**实务**：投稿指南须公开署名/贡献要求+争议处理流程、AI 披露政策；审稿人不得是编辑部成员；编委须列全名与单位、名单更新、本人同意任职、定期审查。

## 2. COPE 出版伦理核心实践（期刊应制定的政策清单）

联合原则 v5.0 第 7 条要求期刊官网明示的政策（逐字要点）：
- 作者资格与贡献政策（authorship and contributorship）
- 投诉与申诉处理（complaints and appeals）
- 研究不端指控处理（research misconduct allegations）
- 利益冲突（conflicts of interest）
- 数据共享与可重复性（data sharing and reproducibility）
- 伦理监督（ethical oversight）
- 知识产权（intellectual property）
- 发表后讨论（post-publication discussions）
- 更正与撤稿（corrections and retractions）

**原句**："Editors and publishers are responsible for ensuring the integrity of the scholarly literature in their journals and should ensure they outline their policies and procedures for handling such issues when they arise."
**原句**："Neither the journal's policies nor the statements of its editors may encourage or permit misconduct – for example, plagiarism, citation manipulation, data falsification/fabrication, or manipulation of peer review..."

## 3. 利益冲突（COPE v5.0 第 7 条）

**原句**：
> "Editors and reviewers who have significant conflicts of interest for particular manuscripts must recuse themselves from reviewing, and in the case of editors, from decision making."
> "Journals must declare what conflicts of interest must be declared and by whom. They must state how, to whom, and when they should be declared."
> "Editors and staff must not receive compensation based on the acceptance of articles."

## 4. STM 生成式 AI 立场

**URL**：https://stm-assoc.org/publishing_decoded/research-integrity-ethics/
**关联文件**：*Ethical and Practical Guidelines for the use of GenAI in the publication process*（Dec 2023）
**原句**：
> "While AI tools may support research and writing, they cannot be held accountable for the work they generate. That's why emerging guidelines emphasize that AI must not be credited as an author. Researchers are encouraged to clearly disclose when and how AI tools were used in the research or manuscript process."

## 5. WAME Chatbots 建议（医学刊）

**URL**：https://wame.org/page3.php?id=106 （2023-05-31 修订）
**原句**：
> "WAME Recommendation 1: Chatbots cannot be authors."
> "Chatbots do not meet the International Committee of Medical Journal Editors (ICMJE) authorship criteria, particularly that of being able to give 'final approval of the version to be published' and 'to be accountable for all aspects of the work...'"

## 6. OASPA 商业模式透明

**URL**：https://oaspa.org/principles-of-transparency-and-best-practice-in-scholarly-publishing/
**原句**：
> "Business models or revenue sources (eg, author fees, subscriptions, advertising, reprints, institutional support, and organizational support) shall be clearly stated or otherwise evident on the journal's Web site."

## 7. 致谢与伦理声明条款体例（SciOpen 用户偏好）

用户投稿指南的既有体例：`The content of X is ...` → 具体要求 → 禁止事项。
- 致谢段原文参考："Acknowledgements. The content of Acknowledgments is a list of people who contributed to the work in the manuscript but are not named in the author list, and a list of funding sources that supported the research presented. The names of funding organizations should be written in full. Do not include acknowledgements on the title page, as a footnote to the title or otherwise."
- 伦理声明应参照此体例写：定义内容 → 委员会全称+批准号+遵循指南+知情同意 → 不得放标题页 → 示例用占位符而非具体机构名。
- 不规定声明在正文中的具体位置（各家冲突：PLOS 紧跟首次引用段落、ICMJE 单独一页、Elsevier 文末/单独文件、Wiley 投稿系统字段），位置交编辑部/排版决定。

## 8. 常见问答速记

- **AI 能不能署名**：不能（COPE/STM/WAME/ICMJE 一致）；使用须披露。
- **审稿人能不能是编委**：联合原则明确审稿人须是"independent scholars... not part of the journal's editorial office"；但同行评审类型各家可自定，需在官网写明是谁评审（外部专家或编委）。
- **投稿指南该写多少政策**：至少第 7 条列出的 9 类伦理政策 + AI 披露 + 署名/贡献 + 申诉流程。

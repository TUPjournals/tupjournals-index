# 出版流程、文章版本、时效与图件规范

> 最后核实：2026-11-17。注意 NISO JAV 已升级为 RP-8-2026；回答前确认 `version-tracker.md`。

## 1. NISO JAV 文章版本

**当前版本**：NISO RP-8-2026（2026-10-05 发布，DOI 10.3789/niso-rp-8-2026，取代 RP-8-2008）；URL https://www.niso.org/publications/rp-8-2026-jav
**2008 版 URL**（术语定义仍可参考，须注明已被取代）：https://niso.org/sites/default/files/2017-08/RP-8-2008.pdf

**7 个版本缩写（2008 版逐字）**：
> "AO = Author's Original; SMUR = Submitted Manuscript Under Review; AM = Accepted Manuscript; P = Proof; VoR = Version of Record; CVoR = Corrected Version of Record; EVoR = Enhanced Version of Record."

**Accepted Manuscript 定义（逐字）**：
> "The version of a journal article that has been accepted for publication in a journal. A second party (the 'publisher') takes permanent responsibility for the article. Content and layout follow publisher's submission requirements."

**Version of Record 定义（逐字）**：
> "A fixed version of a journal article that has been made available by any organization that acts as a publisher by formally and exclusively declaring the article 'published'... This does not include any 'early release' article that has not yet been 'fixed' by processes that are still to be applied, such as copy-editing, proof corrections, layout, and typesetting."

**关键句**："A Proof that is corrected and published becomes a Version of Record."

**实务**：AM 是被接受但未经编辑加工/排版的版本；VoR 是经全部出版流程固定、正式宣布发表的版本；early release 不等于 VoR。

## 2. ACS Just Accepted 与 Springer Online First 的区别（易混淆）

### ACS "Just Accepted"（标准免责声明模板）
**URL**：https://pubsapp.acs.org/paragonplus/submission/popups/... ；实例见 ACS 期刊 PDF 首页
**逐字原文**：
> "'Just Accepted' manuscripts have been fully peer reviewed, but should not be considered the official version of record. They are accessible to all readers and citable by the Digital Object Identifier (DOI®)... After a manuscript is technically edited and formatted, it will be removed from the 'Just Accepted' Web site and published as an ASAP article."

**要点**：可引用、但不是 VoR；经技术编辑后被 ASAP 正式版替换；同一 DOI 延续引用。

### Springer "Online First"
**URL**：https://www.springer.com/br/statistics/become-an-author ；https://link.springer.com/article/10.1007%2Fs006050200042
**逐字原文**：
> "Once the initial proof of your article has been corrected and finalized, the article is ready for Online First publication. Articles are searchable and citable by their DOI (Digital Object Identifier)."
> "Online First articles appear in their final form. Therefore, papers cannot be changed or withdrawn after electronic publication. Any corrections that might be necessary have to be made in an Erratum, which will be hyperlinked to the article."

**要点**：校样定稿后上线即正式版本（final form），按 DOI 引用；电子发表后不可改动/撤稿，只能刊 Erratum。

### 两者冲突的根源与修法（用户场景）
- 问题文本常把两家模板拼接：7.3 改写自 ACS Just Accepted（但漏掉 "should not be considered the official version of record"），7.4/7.5 源自 Springer Online First（"Erratum, which will be hyperlinked to the article"）。
- 后果：两处都写"可用 DOI 引用"、且 7.5 写 "official first publication"，读起来像"一文两次首发"。
- 修法：7.3 补回 "should not be considered the official version of record"，写明 DOI 不变、JA 版被正式版替换；7.5 删 "first"，改 "official version of record"；7.4 的 "After online publication" 改为 "After publication of the version of record"（否则 JA 上线后所有编辑加工按字面都得走 Erratum）。
- **上线描述推荐句**（已核实符合 NISO/Springer）：`The article will be published online after the corrected proofs have been received. This version constitutes the official version of record and can be cited by its DOI. After the print version is published, the article can also be cited by its volume, issue and page numbers.`
- 前提：7.3 已补限定句；若 SciOpen 实际是 JA 版与正式版长期并存，把 "will be replaced" 改成 "will remain accessible alongside" 并加"引用以正式版为准"。

## 3. 出版时效指标用中值（median）

**Springer Nature 期刊页实例**（2026-11 访问）：
- "Submission to first decision (median) 22 days"（例：Natural Products and Bioprospecting）
- "Submission to first decision (median) 19 days"（例：Molecular Imaging and Biology）
- URL 示例：https://www.springer.com/life%20sciences/biochemistry%20&%20biophysics/journal/13659

**Elsevier**（Journal Insights / 支持中心）：
- "The median number of days it takes for an article to go from submission to first editorial decision (e.g., desk reject, desk invite your paper, or invite the first reviewer)."
- URL：https://service.elsevier.com/app/answers/detail/a_id/6029/c/10527/supporthub/publishing/role/author/

**实务**：对外报中值并标 "median days"（注意 Springer 标签是 "Submission to first decision" 而非 "Time to first decision"）；内部监控可平均值+中值并列。统计范围写明按稿件还是按轮次、剔除哪些情况。

## 4. 图件（Artwork）技术分类与图注

### 图件分类（Springer 投稿指南）
**URL 示例**：https://www.springer.com/journal/11224/submission-guidelines ；https://link.springer.com/journal/10052/submission-guidelines
**逐字原文**：
> "Scanned line drawings and line drawings in bitmap format should have a minimum resolution of 1200 dpi."
> "Halftones should have a minimum resolution of 300 dpi."
> "Combination artwork should have a minimum resolution of 600 dpi."
> "Color illustrations should be submitted as RGB (8 bits per channel)."
> "Vector graphics containing fonts must have the fonts embedded in the files."

**实务**：Line Art 指纯黑白无灰度的线条图（流程图、结构式、电路图等），1200 dpi 只约束扫描件/位图，矢量图不受 dpi 限制但须嵌字体；有灰度/阴影的图属 Halftone/Combination。

### 图注条款（Springer 原文为 "depict"，建议改写）
**Springer 原文**："Each figure should have a concise caption describing accurately what the figure depicts."
**推荐改写**（depict 换 describe，避免 describing/depicts 语义叠床架屋）：
> "Each figure should have a concise caption that accurately describes its content, defining all symbols, abbreviations and scale bars used. Captions should be supplied in the manuscript text file and must not be embedded in the figure files."
**实务**：只规定"随稿件文本文件提供、不得嵌进图片文件"，不规定图注在正文中的具体位置（各家冲突）。

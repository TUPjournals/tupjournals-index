# 稿件/平台转换与其他出版实务

> 最后核实：2026-11-17。涉及具体条款先联网核实官网原文。

## 1. 稿件转移 Manuscript Transfer（期刊间转投）

### 三家共同原则：作者同意 + 审稿意见随稿 + 不保证接收

**Elsevier**
> "By agreeing to the transfer, your submission files will be transferred to another journal."（https://service.elsevier.com/app/answers/detail/a_id/6010/supporthub/publishing）
> "Manuscripts are only transferred if the author accepts the transfer offer."（https://www.elsevier.com/connect/how-elseviers-article-transfer-service-transforms-the-author-experience）
> "If you accept the offer to transfer, your article and any available Editorial and referee comments will be sent to the receiving journal."（https://www.elsevier.com/en-in/subject/environmental-science/journals-ecosystem）

**Springer Nature**
> "Please be assured that we will never transfer your manuscript to another journal without your approval."（https://www.springernature.com/fr/authors/transferdesk）
> "In almost all cases, if the paper was peer reviewed, the reviewer comments will be passed along to the receiving journal."（https://go.nature.com/2Mkc1N2）

**Wiley**
> "We will transfer all your submission files, including peer review reports if applicable, to the new journal's submission site and you will be notified when your paper is in the Author Center."（https://authors.wiley.com/author-resources/Journal-Authors/submission-peer-review/Refer_and_Transfer.html）

**DOI 处理**：Elsevier 转稿页面未单独说明。可参考 Crossref 通则 "DOIs ... are persistent identifiers which stay with the work even if it moves location, or publisher."（https://www.crossref.org/pdfs/about-content-registration.pdf）
**COPE 对 manuscript transfer 的立场**：未能核实（COPE 官网未见专门立场文件）。

**实务**：转稿必须经作者明示同意；可随稿转审稿意见加速处理；转稿不构成接收承诺；转稿后 DOI 归属按目标刊/注册机构规则处理，需向编辑部说明清楚。

## 2. 期刊平台迁移 / 出版商变更

### COPE 联合原则 v5（2026-10-29）
**URL**：https://publicationethics.org/guidance/guideline/principles-transparency-and-best-practice-scholarly-publishing
> "Information about the ownership and management of a journal must be clearly indicated on the journal's website, including the individuals and organisations who own and manage the journal."
> "Ownership of a journal should be independent of the editor's decision-making regarding journal content to avoid conflicts of interest."
> "The journal's name must: Be relevant to the aims and scope, and content of the journal. Not be easily confused with another journal. Be accurate regarding the journal's origin, location, and/or association with other journals and organisations."
> "The website must list active ISSNs (print and electronic versions, as applicable)."

**注**：v5 无"所有权/刊名变更须专门公示"的独立条文（该项未能核实）。

### NLM：更名与出版商变更对 MEDLINE 收录的影响
**URL**：https://www.nlm.nih.gov/lstrc/j_sel_faq.html（现存档案版）
> "A straightforward title change or change in sponsor usually is not brought to the attention of the LSTRC."
> "A change in publisher. If the new publisher is not an organization from which NLM is currently acquiring materials for the collection, NLM may deselect the journal from MEDLINE."

**实务**：简单更名/主办方变更通常不影响收录；换出版商且 NLM 不采集其材料者可能被剔除 MEDLINE——平台迁移前须评估收录延续风险。

### DOAJ：刊名/ISSN 一致性与记录维护
**URL**：https://doaj.org/apply/guide/（v2.9）
> "The journal's name in the application and on the website must match what is shown at issn.org."
> "After your journal is accepted, you are responsible for updating the DOAJ record and ensuring the journal continues to comply with DOAJ criteria."

**注**：DOAJ 未见"变更出版商/更名后须重新申请"的专门条文（未能核实）。
**ICMJE 关于更名/出版商变更时 ISSN/DOI/收录延续的专门说明**：未能核实。

**实务建议**：平台迁移时须同步核对 ①官网所有权与管理信息（COPE）②刊名与 ISSN 注册一致性（DOAJ/ISSN）③各数据库收录是否延续（NLM 尤其注意出版商变更）④DOI 前缀与已注册 DOI 的解析维护（Crossref）⑤告知作者与编委。

## 3. 开放获取转换模式

### Subscribe to Open（S2O）
**URL**：https://doaj.org/apply/guide/（v2.9）
> "For journals that have transitioned from closed access to open access under the S2O model, all DOAJ basic criteria, including open license and copyright terms must be clearly stated. Once made available open access, a year's content must stay open in perpetuity."
> "Before applying to DOAJ, an S2O journal must demonstrate that the current year's S2O target has been met and that it has published a new issue or at least five OA research articles under the S2O model."
> "When an S2O offer reaches its subscription target, the journal must make all content from that publication year fully open access within the same calendar year."

### Flipped journals（完整原句，补充 databases.md）
> "Where a journal was previously published as a subscription or hybrid journal and has now flipped to a fully open access model, this information must be clearly displayed: The date of the change to fully open access; The availability of the archive material...; Reuse rights of the archive material..."
> "All content published after the flipped date must be completely open access."
> "DOAJ will consider flipped journals for inclusion if they have a publishing history of more than a year or after they have published at least ten research articles as a fully Open Access journal."

## 4. DOI 与 Crossref

**URL**：https://www.crossref.org/documentation/principles-practices/journals/ ；https://crossref.org/documentation/schema-library/required-recommended-elements ；https://www.crossref.org/pdfs/about-content-registration.pdf
> "We recommend registering DOI records for journal articles, and optionally for journal titles, volumes, and issues."
> "Required metadata must be included or your submission will be rejected. Recommended metadata should be included to create a complete metadata record."
> "Members should always ensure DOIs assigned to their content resolve to a page containing complete bibliographic information (including the identifier), and are responsible for updating and maintaining the accuracy of these pages."
> "DOIs ... are persistent identifiers which stay with the work even if it moves location, or publisher."

**实务**：文章应注册 DOI；必填元数据缺失会被拒收；DOI 须持续可解析、页面元数据须维护；DOI 不因文章或出版方迁移而改变。

## 5. ORCID

**URL**：https://orcid.org/content/mandating-orcid-publication-workflows-open-letter（2015 公开信，现已停止签署）；https://info.orcid.org/?p=3918
> "ORCID iDs are required for corresponding authors of published papers, with the understanding that ORCID iD collection should be enabled as an option for all authors and should ideally take place at submission."
> "The ORCID iD should be displayed in all formats of the article—i.e., HTML, PDF, EPUB—as well as related metadata."

**实务**：建议强制通讯作者 ORCID、所有作者可选，最好投稿时采集，并在 HTML/PDF/EPUB 及元数据中展示。COPE 要求作者提供 ORCID 的专门原句未能核实。

## 6. 预印本

### ICMJE（2026-01 更新）
**URL**：https://icmje.org/recommendations/browse/publishing-and-editorial-issues/overlapping-publications.html
> "This recommendation does not prevent a journal from considering a complete report that follows publication of a preliminary report, such as a letter to the editor, a preprint or an abstract or poster displayed at a scientific meeting."
> "It is the author's responsibility to inform a journal if the work has been previously posted on a preprint server."
> "Posting of work as a preprint may influence a journal's interest in or priority for peer review and publication of that work."

### COPE 立场（2024）
**URL**：https://publicationethics.org/guidance/cope-position/handling-material-previously-published-preprint-server ；DOI 10.24318/9BGzAxia
> "COPE defines prior publication as 'the publication, or attempted publication, of whole or substantial parts of the work/data/analysis that have already been published, or have been submitted elsewhere, without transparency or appropriate declaration/referencing'."

**实务**：预印本不构成先验发表，但作者须主动告知并更新；关键在于透明披露，已披露的预印本不等于不端重复发表。

## 7. 数据可用性声明

### COPE 联合原则 v5
> "Journals should include policies on data sharing, publication and access and encourage the use of the FAIR and CARE principles, reporting guidelines, and registration of clinical trials and other study designs according to standard practice in their discipline."

### ICMJE（临床试验）
**URL**：https://icmje.org/recommendations/browse/publishing-and-editorial-issues/clinical-trial-registration.html（2026-01）
> "As of 1 July 2018 manuscripts submitted to ICMJE journals that report the results of clinical trials must contain a data sharing statement as described below."
> "Data sharing statements must indicate the following: whether individual deidentified participant data (including data dictionaries) will be shared ('undecided' is not an acceptable answer); what data in particular will be shared; whether additional, related documents will be available...; when the data will become available and for how long; by what access criteria data will be shared..."

**实务**：期刊须有数据共享政策并鼓励 FAIR/CARE；ICMJE 期刊的临床试验论文必须含数据共享声明，逐项说明共享内容、时间、期限与获取条件（"undecided" 不可接受）。

## 8. 临床试验注册（ICMJE）

**URL**：https://icmje.org/recommendations/browse/publishing-and-editorial-issues/clinical-trial-registration.html（2026-01）
> "the ICMJE recommends that all medical journal editors require registration of clinical trials in a public trials registry at or before the time of first patient consent for enrollment as a condition of consideration for publication."
> "An acceptable registry must include the minimum 24-item trial registration data set ... at the time of registration and before enrollment of the first participant."

**实务**：临床试验须在首例入组前于合规公共注册库前瞻注册，否则可被拒稿；合规注册库须含 24 项最小注册数据集。

## 9. 版权与许可（COPE 联合原则 v5）

> "The journal's copyright policy for published articles must be clearly stated on the website. The journal website/platform's copyright holder must also be stated separately from the article copyright."
> "The website must clearly and consistently describe licensing information. All full-text versions of the published article (HTML and PDF) must indicate licensing terms. Content labelled as open access must use an open licence."

**实务**：文章版权与平台/网站版权须分别声明；开放获取内容须用开放许可；HTML 与 PDF 全文均须标注许可条款。

## 10. 作者变更（增删署名）

### COPE
> "Journals should have a process for handling authorship issues and disputes identified or raised during the review and publication process, and after publication."（Authorship Discussion Document, 2019-09-02）

**COPE 未见"投稿后增删作者"统一操作原句**（未能核实）。

### 出版商示例（Elsevier GFA，逐字）
> "Any addition, deletion or rearrangement of author names in the authorship list should be made only before the manuscript has been accepted and only if approved by the journal Editor."（https://www.elsevier.com/journals/clinical-nutrition/02615614/guide-for-authors）

**实务**：期刊须建立作者争议处理流程；增删/调整作者一般须在接收前经编辑批准，接收后变更须极严格并留痕。

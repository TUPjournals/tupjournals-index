# 规范版本追踪器（每月核查）

> 维护规则：每月核查下列 URL，发现新版本即更新对应 reference 文件，并在本文件"更新记录"追加一条。回答用户时若官网版本与本表不一致，以官网为准。
> 本表最后核实：2026-11-17

## 当前版本清单

| 规范/机构 | 当前版本 | 发布日期 | 权威 URL |
|---|---|---|---|
| COPE/DOAJ/OASPA/WAME 透明与最佳实践原则 | **v5.0** | 2026-10-29 | https://publicationethics.org/resources/guidelines/principles-transparency-and-best-practice-scholarly-publishing ；DOI 10.24318/cope.2019.1.12 |
| ICMJE Recommendations | Updated January 2026 | 2026-01 | https://www.icmje.org/recommendations/browse/roles-and-responsibilities/defining-the-role-of-authors-and-contributors.html |
| NISO CRediT | ANSI/NISO Z39.104-2022 | 2022-02-08 | https://www.niso.org/publications/z39104-2022-credit ；https://credit.niso.org/ |
| NISO JAV 文章版本 | **RP-8-2026**（取代 RP-8-2008） | 2026-10-05 | https://www.niso.org/publications/rp-8-2026-jav ；DOI 10.3789/niso-rp-8-2026 |
| COPE Authorship Discussion Document | 2019 版 | 2019-09 | https://publicationethics.org/guidance/discussion-document/authorship ；DOI 10.24318/cope.2019.3.3 |
| WAME Chatbots/AI 建议 | 2023-05-31 修订 | 2023-05-31 | https://wame.org/page3.php?id=106 |
| WAME Authorship | 未标日期 | — | https://wame.org/authorship |
| STM 生成式 AI 指南 | Dec 2023 | 2023-12 | https://stm-assoc.org/publishing_decoded/research-integrity-ethics/ |
| DOAJ Guide to applying | v2.9（未标日期） | — | https://doaj.org/apply/guide/ |
| DOAJ Licensing & copyright | v2.1 | 2026-01 | https://doaj.org/apply/copyright-and-licensing/ |
| DOAJ Transparency & best practice | 联合原则 v5.0 镜像 | 2026-10 | https://doaj.org/apply/transparency |
| Scopus CSAB 选择标准 | 页面未标日期 | — | https://www.elsevier.com/products/scopus/content/content-policy-and-selection |
| Clarivate WoS 选择标准 | 页面未标日期（28 项标准） | — | https://clarivate.com/academia-government/scientific-and-academic-research/research-discovery-and-referencing/web-of-science/web-of-science-core-collection/editorial-selection-process/journal-evaluation-process-selection-criteria/ |
| Elsevier CRediT | 页面未标日期 | — | https://www.elsevier.com/researcher/author/policies-and-guidelines/credit-author-statement |
| Wiley CRediT | 页面未标日期 | — | https://authorservices.wiley.com/author-resources/Journal-Authors/open-access/credit.html |
| Springer Nature 编辑政策 | 稿约示例更新 2026-06-10 | 2026-06 | https://www.springernature.com/.../editorial-policies ；https://www.nature.com/npjdigipubhealth/editorial-policies/authorship |
| PLOS 作者资格（McNutt 2018） | 2023-05-10 起 | 2023-05 | https://journals.plos.org/ploscompbiol/s/authorship |
| ACS Just Accepted 免责声明 | 标准模板 | — | https://pubsapp.acs.org/paragonplus/submission/popups/... |
| Springer Online First | — | — | https://www.springer.com/br/statistics/become-an-author |
| COPE Retraction Guidelines | **V3** | 2025-08 | https://publicationethics.org/guidance/guideline/retraction-guidelines ；DOI 10.24318/cope.2019.1.4 |
| COPE Expression of Concern | 2025-08-27 审阅 | 2025-08 | https://publicationethics.org/guidance/guideline/expressions-concern ；DOI 10.24318/mw2J3661 |
| COPE 立场：Authorship and AI tools | 2023-02-13 | 2023-02 | https://publicationethics.org/guidance/cope-position/authorship-and-Ai-tools ；DOI 10.24318/cCVRZBms |
| COPE 立场：预印本重复发表 | 2024 | 2024 | https://publicationethics.org/guidance/cope-position/handling-material-previously-published-preprint-server ；DOI 10.24318/9BGzAxia |
| PubMed / MEDLINE 选刊标准 | **Last Reviewed July 24, 2026** | 2026-07 | https://www.nlm.nih.gov/medline/medline_journal_selection.html |
| PubMed Help（出版类型/链接字段） | Last update 2026-09-30 | 2026-09 | https://pubmed.ncbi.nlm.nih.gov/help/ |
| About PubMed | 2025-03-11 | 2025-03 | https://pubmed.ncbi.nlm.nih.gov/about |
| About PMC | 2026-03-09 | 2026-03 | https://pmc.ncbi.nlm.nih.gov/about/intro/ |
| NIH Public Access Policy | 2025-06-23（2024 政策） | 2025-06 | https://grants.nih.gov/policy-and-compliance/policy-topics/public-access |
| EI/Compendex 选刊标准 | 未标日期（来源表 2026-08） | — | https://www.elsevier.com/products/engineering-village/databases/selection-criteria |
| ICMJE AI 章节（Section V） | 注释版 2025-04 | 2025-04 | https://icmje.org/recommendations/browse/artificial-intelligence |
| STM 生成式 AI 白皮书 | 2023-12-05 | 2023-12 | https://stm-assoc.org/new-white-paper-launch-generative-ai-in-scholarly-communications/ |
| Wiley AI guidelines | 官网未标日期 | — | https://www.wiley.com/en-us/publish/article/ai-guidelines/ |
| Taylor & Francis AI policy | 官网未标日期 | — | https://taylorandfrancis.com/our-policies/ai-policy/ |
| Elsevier Article Correction/Retraction/Removal Policy | 未标日期 | — | https://www.elsevier.com/about/policies-and-standards/article-withdrawal |
| Crossref journals / metadata | 未标日期 | — | https://www.crossref.org/documentation/principles-practices/journals/ |

## 本次核实发现的重要版本变更（2026-11-17）

1. **COPE 联合原则 v4.0（2022-09）→ v5.0（2026-10-29）**。新增/强化 AI 披露、作者资格与贡献透明要求、编辑培训要求。
2. **NISO JAV RP-8-2008 → RP-8-2026（2026-10-05）**。引用文章版本术语应以新版为准；2008 版的核心定义仍可参考，但需注明已被取代。
3. **Clarivate 从"24 项质量 + 4 项影响力"表述为"统一 28 项标准"**（24 质量 + 4 影响力）。
4. **ICMJE 页面标注 Updated January 2026**。
5. **COPE Retraction Guidelines 升级 V3（2025-08）**，替代 2019 V2；COPE 同期更新 Expression of Concern 指南（2025-08-27）。
6. **MEDLINE 选刊标准 Last Reviewed July 24, 2026**；PubMed Help 更新至 2026-09-30（更正/撤稿出版类型与链接字段）。
7. **EI 现行官网已无 "Page One" 区分**——勿再向编辑部讲"核心版/非核心版"口径。

## 未能核实项（不得当作原文引用）

- COPE Discussion Document 中 "acquisition of funding / general supervision / administrative support 不构成作者" 的逐字原句（该措辞属 ICMJE II.A.3，不可归给 COPE）。
- DOAJ Guide 中"编委名单保持更新 / 成员须同意任职"的逐字原句（旧版条款，当前 v2.9 无此表述；但 COPE 联合原则有 "The list should be up to date, and members must agree to serve"）。
- Scopus "编委须列单位"及"对误导性/不活跃/名誉编委的态度"的逐字原句。
- STM 关于通讯作者职责、CRediT 立场、"各刊可自定作者定义"的官网原句。

## 更新记录

- 2026-11-17：首次核实建档。发现 COPE v5.0、NISO JAV 2026、Clarivate 28 项、ICMJE 2026-01 四处版本更新。
- 2026-11-17（第二次，扩充）：新增 EI、PubMed/MEDLINE/PMC、勘误撤稿、AI 三方政策、稿件/平台转移、DOI/ORCID/预印本/数据声明/试验注册等 5 个 reference 文件。发现 COPE 撤稿指南 V3（2025-08）、EoC 指南 2025-08-27、MEDLINE 选刊 2026-07-24、PubMed Help 2026-09-30 等更新；确认 EI 官网已无 Page One 区分。

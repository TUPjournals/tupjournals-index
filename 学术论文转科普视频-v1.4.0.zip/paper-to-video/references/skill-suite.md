# 完整技能套件的范围与交接

当用户要求导出 paper-to-video 套件时使用。打包本技能明确路由的所有分支，而不是只带当前影片执行过的几项；这不等于收集任意主题的全部技能或find-skills未来可能发现的无限来源。

## 应覆盖的技能

- 主入口：paper-to-video。
- 证据：pdf、scientific-critical-thinking。
- 前期叙事与HyperFrames条件支持：hyperframes、hyperframes-cli、hyperframes-registry。
- 绘画与媒体：imagegen、media-use；默认配音脚本随paper-to-video保留，不把它变成HeyGen登录任务。
- 后期装配：remotion-best-practices，连同目录内的创建、markup、字幕、预览、渲染等完整子技能及参考。
- 专门数学/科学镜头：manim-composer、manimce-best-practices、manimgl-best-practices；按工程选择一个Manim引擎，不把两者API混用。
- 科学图表：scientific-visualization。
- 发现、安装与维护：find-skills、skill-installer、skill-creator。
- scientific-schematics：证据检查技能附带的可选科学结构图分支；不是本流程默认生图服务。默认美术仍必须使用imagegen，不自动转去OpenRouter或要求新密钥；仅用户明确选择该分支时按其依赖执行。
- 子技能明确要求的其他技能：逐项核对；若只是在范例或任意生态链接中提及而不属于本流程必要分支，在清单注明而非无边界扩包。需要获取的缺项核实真实来源和版本，不以同名占位文件冒充。

## 打包方式

保留每个技能的整个资料目录（SKILL.md、references、rules、scripts、templates、assets、agents及许可文件中实际存在的内容），排除缓存、凭据、.git及node_modules，不只复制入口。保持相对链接与兄弟目录关系；保留可随包的来源、许可与固定版本/哈希。

清单分为实际采用、参考/服务辅助、条件分支、维护工具，不能把打包或查阅写成已在成片运行。已有本地技能应保留其本地修订，不以联网新版本覆盖它；仅补齐缺项并固定来源。

用户要求固定成功经验时，附已认可版本对应的可编辑工程及成片的版本/校验值；MP4按用户要求另附，不自动增加体积；不要把不完整的代码片段称为可运行模板。套件说明哪些是质量基线、哪些是新片可改参数。

在其他设备恢复：先检查已有技能，内置/插件已提供的同名能力不要重复安装或盲目覆盖；只补缺项，按用户要求更新paper-to-video。新设备仍需Node.js、锁定的Remotion依赖、浏览器、FFmpeg/ffprobe、中文字体和对应Python库；Manim/LaTeX等仅其分支需要。技能文件不等于宿主工具，内置imagegen工具及PDF插件运行服务不能靠复制Markdown安装；Edge TTS需要联网。不得声称完全离线、跨平台全部实测。

导出前核对覆盖清单、关键相对链接、归档可解压与文件哈希。全量上游技能可能含与本片无关的生态链接，不把这些可选链接误报为本片运行依赖。用户指定下载文件夹时，把最终归档实际复制到该目录并核验，不能只在工作区给出同名文件。

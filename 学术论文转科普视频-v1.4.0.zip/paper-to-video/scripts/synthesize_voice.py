#!/usr/bin/env python3
"""Reuse or generate the confirmed Xiaoyi voice. Requires edge-tts for generation only."""
import argparse
import asyncio
import hashlib
import json
import re
from pathlib import Path

DEFAULT = {'name': 'zh-CN-XiaoyiNeural', 'rate': '+7%', 'pitch': '-1Hz'}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare(story_path, output):
    story = json.loads(story_path.read_text(encoding='utf-8-sig'))
    scenes = story if isinstance(story, list) else story['scenes']
    voice = dict(DEFAULT)
    if isinstance(story, dict):
        voice.update(story.get('voice', {}))
    jobs = []
    seen = set()
    for scene in scenes:
        sid, text = scene['id'], scene['text']
        if not re.fullmatch(r'[A-Za-z0-9_-]+', sid) or sid in seen:
            raise ValueError('Scene ids must be unique safe filenames: ' + repr(sid))
        if not isinstance(text, str) or not text.strip():
            raise ValueError('Empty narration: ' + sid)
        seen.add(sid)
        selected = {**voice, **scene.get('voice', {})}
        path = output / (sid + '.mp3')
        meta = path.with_suffix('.json')
        try:
            cached = json.loads(meta.read_text())
        except (OSError, ValueError):
            cached = {}
        reuse = (path.is_file() and path.stat().st_size > 0 and
                 cached.get('text') == text and cached.get('voice') == selected and
                 bool(cached.get('events')))
        if reuse and cached.get('audio_sha256'):
            reuse = digest(path) == cached['audio_sha256']
        jobs.append({'id': sid, 'text': text, 'voice': selected,
                     'path': path, 'meta': meta, 'reuse': reuse})
    return jobs

async def generate(jobs):
    pending = [j for j in jobs if not j['reuse']]
    if not pending:
        return
    try:
        import edge_tts
    except ImportError as exc:
        raise SystemExit('Missing edge-tts. Install it in the project Python environment; keep the confirmed voice.') from exc
    for job in pending:
        path, meta = job['path'], job['meta']
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix('.part.mp3')
        events = []
        v = job['voice']
        client = edge_tts.Communicate(job['text'], v['name'], rate=v['rate'],
                                      pitch=v['pitch'], boundary='WordBoundary')
        with temp.open('wb') as f:
            async for event in client.stream():
                if event['type'] == 'audio':
                    f.write(event['data'])
                elif event['type'] == 'WordBoundary':
                    events.append(event)
        if not events or not temp.stat().st_size:
            raise RuntimeError('Missing audio or WordBoundary: ' + job['id'])
        record = {'text': job['text'], 'voice': v, 'events': events,
                  'audio_sha256': digest(temp)}
        # Keep any prior content addressable before replacement.
        if path.exists():
            suffix = digest(path)[:12]
            old = path.with_name(path.stem + '.previous-' + suffix + '.mp3')
            if not old.exists():
                old.write_bytes(path.read_bytes())
            if meta.exists():
                old.with_suffix('.json').write_bytes(meta.read_bytes())
        temp.replace(path)
        meta_temp = meta.with_suffix('.part.json')
        meta_temp.write_text(json.dumps(record, ensure_ascii=False, indent=2))
        meta_temp.replace(meta)
        print('generated', job['id'], len(events), 'WordBoundary events', flush=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--story', type=Path, required=True,
                        help='JSON {scenes:[{id,text}],voice?:...} or [{id,text}]')
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--plan-only', action='store_true',
                        help='Read caches and report reuse; no synthesis or writes')
    args = parser.parse_args()
    jobs = prepare(args.story, args.output_dir)
    print(json.dumps({'reuse': [j['id'] for j in jobs if j['reuse']],
                      'generate': [j['id'] for j in jobs if not j['reuse']]}, ensure_ascii=False))
    if not args.plan_only:
        asyncio.run(generate(jobs))

if __name__ == '__main__':
    main()

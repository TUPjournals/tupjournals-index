# -*- coding: utf-8 -*-
"""
公号数据整理 - 多公号合并汇总脚本（单一横向汇总表）
用法:
    python merge_wechat_summary.py <输出.xlsx> <文件1.xls> [<文件2.xls> ...]

对多个微信公众平台"平台使用量".xls，逐个提取每周 推文数/曝光量（口径与
process_wechat_data.py 一致：曝光量=渠道"全部"阅读人数按自然周求和，推文数按周合计），
按自然周(周一~周日)对齐，输出**单一**"横向汇总"表，格式与单公号横向汇总表一致：
- 第一列为公众号名称（取输入文件名，不含扩展名）
- 其后每周两列：推文数 | 曝光量
- 数据区第一行为第一个公号，第二行为第二个公号，以此类推
周次不一致时缺失周自动补 0。
"""
import sys
import os
from collections import OrderedDict
from datetime import timedelta

import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from process_wechat_data import validate_input, extract_daily, group_by_week, ERROR_MSG
from wechat_common import load_config, parse_filename


def account_label(f, cfg):
    """公号显示名：文件名能解析出登记过的公号就用『缩写｜全称』，否则退回文件名。"""
    stem = os.path.splitext(os.path.basename(f))[0]
    meta = parse_filename(stem, cfg)
    return f'{meta["abbr"]}｜{meta["account"]}' if meta else stem


def collect_weekly(xls_path):
    """提取单文件每周数据，返回 ({monday: (pub, read)}, week_list)。"""
    sheet = validate_input(xls_path)
    daily_read, daily_pub, all_dates = extract_daily(sheet)
    week_list = group_by_week(all_dates, daily_read, daily_pub)
    acc = {}
    for w in week_list:
        m = w['start'] - timedelta(days=w['start'].weekday())
        acc[m] = (w['pub'], w['read'])
    return acc, week_list


def fmt_range(start, end):
    if start.month == end.month:
        return f'{start.month}月{start.day}-{end.day}日'
    return f'{start.month}月{start.day}日-{end.month}月{end.day}日'


def main():
    args = sys.argv[1:]
    if len(args) < 2:
        print('用法: python merge_wechat_summary.py <输出.xlsx> <文件1.xls> [<文件2.xls> ...]')
        sys.exit(1)

    out_path = args[0]
    files = args[1:]
    for f in files:
        if not os.path.exists(f):
            print(ERROR_MSG)
            sys.exit(1)

    cfg = load_config()

    # 1) 收集各公号周数据（名称优先按配置解析，解析不出退回文件名），建立自然周全局序
    accounts = []              # [(名称, {monday: (pub, read)})]
    week_map = OrderedDict()   # monday -> {'start','end'}（各文件实际数据首尾日并集）
    for f in files:
        name = account_label(f, cfg)
        acc, week_list = collect_weekly(f)
        accounts.append((name, acc))
        for w in week_list:
            m = w['start'] - timedelta(days=w['start'].weekday())
            if m not in week_map:
                week_map[m] = {'start': w['start'], 'end': w['end']}
            else:
                week_map[m]['start'] = min(week_map[m]['start'], w['start'])
                week_map[m]['end'] = max(week_map[m]['end'], w['end'])

    mondays = sorted(week_map.keys())
    labels = [f'第{i+1}周 {fmt_range(week_map[m]["start"], week_map[m]["end"])}' for i, m in enumerate(mondays)]
    period = f'{week_map[mondays[0]]["start"].strftime("%Y.%m.%d")}-{week_map[mondays[-1]]["end"].strftime("%Y.%m.%d")}'

    # 2) 生成单一"横向汇总"表（格式同单公号横向汇总表）
    header_font = Font(name='微软雅黑', size=11, bold=True, color='FFFFFF')
    header_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
    week_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    light_fill = PatternFill(start_color='D6E4F0', end_color='D6E4F0', fill_type='solid')
    data_font = Font(name='微软雅黑', size=11)
    align = Alignment(horizontal='center', vertical='center')
    thin = Side(style='thin')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    n = len(mondays)
    total_cols = n * 2 + 1  # 公众号列 + 每周2列

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = '横向汇总'

    # 标题
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=total_cols)
    t = ws.cell(row=1, column=1, value=f'各公众号每周推文数与曝光量统计（横向，{period}）')
    t.font = Font(name='微软雅黑', size=14, bold=True, color='2F5496')
    t.alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 30

    # 第2行：公众号 | 每周合并2列
    c = ws.cell(row=2, column=1, value='公众号')
    c.font, c.fill, c.alignment, c.border = header_font, week_fill, align, border
    for idx, label in enumerate(labels):
        c1 = idx * 2 + 2
        ws.merge_cells(start_row=2, start_column=c1, end_row=2, end_column=c1 + 1)
        c = ws.cell(row=2, column=c1, value=label)
        c.font, c.fill, c.alignment = header_font, week_fill, align
        for cc in range(c1, c1 + 2):
            ws.cell(row=2, column=cc).border = border
    ws.row_dimensions[2].height = 25

    # 第3行：指标行（推文数|曝光量交替）
    for idx in range(n):
        c1 = idx * 2 + 2
        for j, m in enumerate(['推文数', '曝光量']):
            c = ws.cell(row=3, column=c1 + j, value=m)
            c.font, c.fill, c.alignment, c.border = header_font, header_fill, align, border
    ws.row_dimensions[3].height = 24

    # 数据行：每公号一行，第一列公众号名称
    for i, (name, acc) in enumerate(accounts):
        r = 4 + i
        c = ws.cell(row=r, column=1, value=name)
        c.font, c.alignment, c.border = data_font, align, border
        for idx, m in enumerate(mondays):
            pub, read = acc.get(m, (0, 0))
            c1 = idx * 2 + 2
            for j, v in enumerate([pub, read]):
                cc = ws.cell(row=r, column=c1 + j, value=v)
                cc.font, cc.alignment, cc.border = data_font, align, border
                if j == 0:
                    cc.fill = light_fill
        ws.row_dimensions[r].height = 24

    # 列宽
    ws.column_dimensions['A'].width = 14
    for idx in range(n):
        c1 = idx * 2 + 2
        ws.column_dimensions[get_column_letter(c1)].width = 10
        ws.column_dimensions[get_column_letter(c1 + 1)].width = 12

    # 注释
    nr = 4 + len(accounts) + 1
    ws.merge_cells(start_row=nr, start_column=1, end_row=nr, end_column=total_cols)
    note = ws.cell(row=nr, column=1,
                   value='注：曝光量 = 渠道"全部"的阅读人数合计；推文数 = 该周发表的推文篇数；公众号名称按 config 映射解析，解析不出时取输入文件名。')
    note.font = Font(name='微软雅黑', size=10, color='808080')
    note.alignment = Alignment(horizontal='left', vertical='center')

    wb.save(out_path)
    print('汇总文件已生成:', out_path)
    print('共%d个公号，%d周' % (len(accounts), len(mondays)))


if __name__ == '__main__':
    main()

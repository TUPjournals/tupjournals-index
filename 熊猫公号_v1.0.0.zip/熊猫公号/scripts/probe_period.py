# -*- coding: utf-8 -*-
"""
熊猫公号 · 时间区间探测（只读，不产出任何文件）

在做任何汇总表 / 回填在线表**之前**先跑这一步。设计要点：

1. **先读内容，再谈文件名**——文件名写错不该妨碍"这是哪年哪月"的结论。
   文件名不合规时依然把内容里的时间区间报出来，把文件名问题作为待确认项一并列出。
2. **把所有问题一次性问全**——`issues` 数组汇总全部待确认项（冒烟的、不冒烟的都在里面），
   调用方据此**一个弹窗问完**，不要挤牙膏式一条条问。

之所以必须真读文件：文件名只带「公号名 + 粉丝数」（月份可有可无、且不含年份），
年份与月份只能从数据内容的日期列读出。

用法:
    python probe_period.py <输入目录或文件...> [--fans KEY=N ...]

输出:
    1) 人类可读摘要：数据区间 + 逐文件明细 + 待确认问题清单
    2) 机器可读行：PROBE_RESULT|{json}

退出码:
    0 = 全部干净
    2 = 存在需用户确认/补充的问题（但区间已如实报出，见 PROBE_RESULT.issues）
    2 + NEED_USER_INPUT|{json} = 硬阻断（读不到任何内容 / 输入或配置有问题）
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from process_wechat_data import validate_input, extract_daily, REQUIRED_KEYWORDS  # noqa: E402
from wechat_common import (load_config, parse_filename_lenient, collect_inputs,  # noqa: E402
                           parse_fans_overrides, fill_fans, build_filename_issue,
                           need_user_input, account_mapping_issue, PROBE_PREFIX)


def probe_one(path, cfg, meta):
    """核验并提取单个文件的区间信息；问题收进 issues，不提前退出。

    meta 为 parse_filename_lenient（可能已被 --fans 补值修正）的结果。
    """
    stem = os.path.splitext(os.path.basename(path))[0]
    filename = os.path.basename(path)
    info = {'file': filename, 'path': os.path.abspath(path),
            'abbr': meta['abbr'], 'account': meta['account'], 'fans': meta['fans'],
            'fans_source': meta.get('fans_source'), 'month_in_name': meta['month_in_name'],
            'years': [], 'months': [], 'start': None, 'end': None, 'days': None,
            'read_total': None, 'pub_total': None, 'readable': False}
    issues = []

    # --- 内容优先：无论文件名如何，先把区间读出来 ---
    try:
        sheet = validate_input(path)
        daily_read, daily_pub, dates = extract_daily(sheet)
        info.update({
            'years': sorted({d.year for d in dates}),
            'months': sorted({d.month for d in dates}),
            'start': dates[0].strftime('%Y-%m-%d'), 'end': dates[-1].strftime('%Y-%m-%d'),
            'days': len(dates),
            'read_total': sum(daily_read.values()),
            'pub_total': sum(daily_pub.get(d, 0) for d in dates),
            'readable': True})
    except ValueError:
        issues.append({'severity': 'need_input', 'reason': 'content_validation_failed',
                       'file': filename, 'expected_keywords': REQUIRED_KEYWORDS,
                       'hint': '文件内容不像微信公众平台导出的「平台使用量」文件，读不出时间区间'})

    # --- 文件名问题（含用 --fans 补值后已解决的，不再报） ---
    if meta['issue']:
        issues.append(build_filename_issue(meta, stem, cfg, filename))

    # --- 文件名月份与内容不符：以内容为准，only 告知无需等答复 ---
    if info['readable'] and meta['month_in_name'] and meta['month_in_name'] not in info['months']:
        issues.append({
            'severity': 'info', 'reason': 'name_month_mismatch', 'file': filename,
            'month_in_name': meta['month_in_name'],
            'actual_years': info['years'], 'actual_months': info['months'],
            'hint': f'文件名写 {meta["month_in_name"]} 月，但内容实际是 '
                    f'{"/".join(str(y) for y in info["years"])} 年 '
                    f'{"/".join(str(m) for m in info["months"])} 月的数据，已按内容为准'})
    return info, issues


def main():
    ap = argparse.ArgumentParser(description='熊猫公号 · 时间区间探测（只读）')
    ap.add_argument('inputs', nargs='+', help='输入目录或 .xls/.xlsx 文件')
    ap.add_argument('--fans', action='append', nargs='+', default=[], metavar='KEY=N',
                    help='文件名未带粉丝数时补值。KEY 为文件名或公号缩写。'
                         '可写多个：--fans EMD=3210 HE=1200；也可重复 --fans。'
                         '⚠️ 请放在所有输入路径之后（它会一直取到下一个选项为止）')
    args = ap.parse_args()

    cfg = load_config()
    overrides = parse_fans_overrides(args.fans)
    files, skipped = collect_inputs(args.inputs, cfg.get('ignore_patterns'))
    if not files:
        need_user_input('no_input_file', inputs=args.inputs, skipped=skipped,
                        hint='目录中没有可处理的平台使用量文件'
                             '（被忽略的自家产出/临时文件见 skipped）')

    # 先用 --fans 补齐文件名缺失的粉丝数（歧义问题单独收着）
    parsed = []
    for f in files:
        if not os.path.exists(f):
            need_user_input('file_not_found', file=f)
        stem = os.path.splitext(os.path.basename(f))[0]
        parsed.append((stem, parse_filename_lenient(stem, cfg)))
    fans_issues = fill_fans(parsed, overrides)

    infos, issues = [], []
    for f, (_, patch) in zip(files, parsed):
        info, file_issues = probe_one(f, cfg, patch)
        infos.append(info)
        issues.extend(file_issues)
    issues = fans_issues + issues

    # 映射表整体为空时：逐文件的「公号未登记 / 文件名无法解析」都是"没有映射"的后果，
    # 折叠成一条「请登记映射」，避免刷屏。关键：**不阻断**——内容照读、区间照报。
    if cfg.get('accounts_empty'):
        issues = [i for i in issues
                  if i['reason'] not in ('unregistered_account', 'filename_pattern_mismatch')]
        issues.insert(0, account_mapping_issue())

    readable = [i for i in infos if i['readable']]
    if not readable:
        need_user_input('no_valid_record', files=files,
                        issues=[i for i in issues if i['severity'] == 'need_input'],
                        hint='没有任何一个文件能读出有效数据')

    all_years = sorted({y for i in readable for y in i['years']})
    all_ym = sorted({(y, m) for i in readable for y in i['years'] for m in i['months']})
    start = min(i['start'] for i in readable)
    end = max(i['end'] for i in readable)
    need_input = [i for i in issues if i['severity'] == 'need_input']

    result = {
        'file_count': len(infos),
        'readable_count': len(readable),
        'years': all_years,
        'year_months': [{'year': y, 'month': m} for y, m in all_ym],
        'span': f'{start}~{end}',
        'accounts': sorted({i['abbr'] for i in readable if i['abbr']}),
        'files': infos,
        'issues': issues,
        'need_input_count': len(need_input),
        'skipped': skipped,
    }

    # ---- 人类可读摘要 ----
    print(f'读入 {len(infos)} 个文件，其中 {len(readable)} 个可读出数据；'
          f'数据区间 {start} ~ {end}')
    print('→ 本批数据属于：' + '、'.join(f'{y} 年 {m} 月' for y, m in all_ym))
    for i in infos:
        if i['readable']:
            name = f'{i["abbr"]}｜{i["account"]}' if i['abbr'] else '（公号未定）'
            fans = f'粉丝 {i["fans"]}' + (f'（{i["fans_source"]}补）' if i.get('fans_source') else '') \
                if i['fans'] is not None else '粉丝 未取得'
            print(f'  {name}  {i["file"]} → '
                  f'{"、".join(str(y) for y in i["years"])} 年 '
                  f'{"、".join(str(m) for m in i["months"])} 月'
                  f'（{i["start"]} ~ {i["end"]}，{i["days"]} 天，'
                  f'{i["pub_total"]} 推 / {i["read_total"]} 曝，{fans}）')
        else:
            print(f'  （无法读取）  {i["file"]}')
    for it in issues:
        mark = '⚠ 待确认' if it['severity'] == 'need_input' else 'ℹ 提示'
        print(f'  {mark}：{it["hint"]}')
    if skipped:
        print(f'  ⊘ 已跳过 {len(skipped)} 个自家产出/临时文件（不参与统计）：{"、".join(skipped)}')
    print(PROBE_PREFIX + json.dumps(result, ensure_ascii=False))

    if need_input:
        # 区间已报出；退出码 2 表示"还有事要问用户"，调用方须把 issues 一次问全
        sys.exit(2)


if __name__ == '__main__':
    main()

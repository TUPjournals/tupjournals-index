# -*- coding: utf-8 -*-
"""
公号数据整理 - 核心处理脚本
输入: 微信公众平台导出的平台使用量 .xls 文件
输出: 每周曝光量(阅读人数)与发文数量(推文数)统计 xlsx, 含"横向汇总"工作表

用法:
    python process_wechat_data.py <input.xls> <output.xlsx>

核验规则(任一不满足即退出并提示):
    1. 必须提供 .xls 文件且文件存在
    2. 文件内容必须包含关键字: 数据趋势概况 / 日期 / 渠道 / 阅读人数 / 发表篇数

统计口径:
    曝光量 = "数据趋势概况"表中 渠道=="全部" 的阅读人数, 按自然周(周一~周日)求和
    发文数 = 按自然周合计 "发表篇数"
"""
import sys
import os
import xlrd
from datetime import datetime, timedelta
from collections import OrderedDict

import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

REQUIRED_KEYWORDS = ['数据趋势概况', '日期', '渠道', '阅读人数', '发表篇数']
ERROR_MSG = '提供文件有误，请提供正确文件'


def validate_input(file_path):
    """核验输入文件: 存在性 + 关键字。返回 sheet 或抛出异常。"""
    if not file_path:
        raise ValueError(ERROR_MSG)
    if not os.path.exists(file_path):
        raise ValueError(ERROR_MSG)
    if not file_path.lower().endswith(('.xls', '.xlsx')):
        raise ValueError(ERROR_MSG)
    try:
        wb = xlrd.open_workbook(file_path)
        sheet = wb.sheet_by_index(0)
    except Exception:
        raise ValueError(ERROR_MSG)

    # 扫描整个 sheet 的文本, 检查必需关键字
    full_text = []
    for i in range(min(sheet.nrows, 20)):
        for j in range(sheet.ncols):
            v = sheet.cell_value(i, j)
            if isinstance(v, str) and v.strip():
                full_text.append(v)
    joined = '|'.join(full_text)
    for kw in REQUIRED_KEYWORDS:
        if kw not in joined:
            raise ValueError(ERROR_MSG)
    return sheet


def extract_daily(sheet):
    """提取每日 阅读人数(渠道=全部) 与 发表篇数。返回 (daily_read, daily_pub, all_dates)。"""
    daily_read = {}
    for i in range(3, sheet.nrows):
        date_val = sheet.cell_value(i, 1)
        channel = sheet.cell_value(i, 2)
        read_count = sheet.cell_value(i, 3)
        if date_val and channel == '全部':
            try:
                d = datetime.strptime(str(date_val)[:10], '%Y-%m-%d')
                daily_read[d] = int(read_count)
            except Exception:
                pass

    daily_pub = {}
    for i in range(3, sheet.nrows):
        date_val = sheet.cell_value(i, 5)
        pub = sheet.cell_value(i, 9)
        if date_val:
            try:
                d = datetime.strptime(str(date_val)[:10], '%Y-%m-%d')
                daily_pub[d] = int(pub)
            except Exception:
                pass

    all_dates = sorted(daily_read.keys())
    if not all_dates:
        raise ValueError(ERROR_MSG)
    return daily_read, daily_pub, all_dates


def group_by_week(all_dates, daily_read, daily_pub):
    """按自然周(周一~周日)聚合, 返回有序 week_list: [{'start','end','read','pub'}, ...]"""
    weeks = OrderedDict()
    for d in all_dates:
        monday = d - timedelta(days=d.weekday())
        if monday not in weeks:
            weeks[monday] = {'start': d, 'end': d, 'read': 0, 'pub': 0}
        weeks[monday]['read'] += daily_read[d]
        weeks[monday]['pub'] += daily_pub.get(d, 0)
        if d < weeks[monday]['start']:
            weeks[monday]['start'] = d
        if d > weeks[monday]['end']:
            weeks[monday]['end'] = d
    return list(weeks.values())


def format_date_range(start, end):
    if start.month == end.month:
        return f'{start.month}月{start.day}-{end.day}日'
    return f'{start.month}月{start.day}日-{end.month}月{end.day}日'


def build_output(week_list, output_path):
    """生成 xlsx: 横向汇总(每周2列: 推文数|曝光量) + 每日明细。"""
    n = len(week_list)
    total_cols = n * 2

    wb_out = openpyxl.Workbook()
    ws = wb_out.active
    ws.title = '横向汇总'

    header_font = Font(name='微软雅黑', size=11, bold=True, color='FFFFFF')
    header_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
    week_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    header_align = Alignment(horizontal='center', vertical='center')
    data_font = Font(name='微软雅黑', size=11)
    data_align = Alignment(horizontal='center', vertical='center')
    thin_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                         top=Side(style='thin'), bottom=Side(style='thin'))
    light_fill = PatternFill(start_color='D6E4F0', end_color='D6E4F0', fill_type='solid')

    # 标题
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=total_cols)
    title_cell = ws.cell(row=1, column=1,
                         value=f'公众号每周推文数与曝光量统计（横向，{week_list[0]["start"].strftime("%Y.%m.%d")}-{week_list[-1]["end"].strftime("%Y.%m.%d")}）')
    title_cell.font = Font(name='微软雅黑', size=14, bold=True, color='2F5496')
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 30

    # 周次表头行(第2行): 每周合并2列
    for idx, wdata in enumerate(week_list):
        c1 = idx * 2 + 1
        label = f'第{idx+1}周 {format_date_range(wdata["start"], wdata["end"])}'
        ws.merge_cells(start_row=2, start_column=c1, end_row=2, end_column=c1 + 1)
        cell = ws.cell(row=2, column=c1, value=label)
        cell.font = header_font
        cell.fill = week_fill
        cell.alignment = header_align
        for cc in range(c1, c1 + 2):
            ws.cell(row=2, column=cc).border = thin_border
    ws.row_dimensions[2].height = 25

    # 指标行(第3行): 推文数 | 曝光量
    metrics = ['推文数', '曝光量']
    for idx in range(n):
        c1 = idx * 2 + 1
        for j, m in enumerate(metrics):
            cell = ws.cell(row=3, column=c1 + j, value=m)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_align
            cell.border = thin_border
    ws.row_dimensions[3].height = 24

    # 数据行(第4行)
    for idx, wdata in enumerate(week_list):
        c1 = idx * 2 + 1
        for j, v in enumerate([wdata['pub'], wdata['read']]):
            cell = ws.cell(row=4, column=c1 + j, value=v)
            cell.font = data_font
            cell.alignment = data_align
            cell.border = thin_border
            if j == 0:
                cell.fill = light_fill
    ws.row_dimensions[4].height = 24

    # 列宽
    for idx in range(n):
        c1 = idx * 2 + 1
        ws.column_dimensions[get_column_letter(c1)].width = 10
        ws.column_dimensions[get_column_letter(c1 + 1)].width = 12

    # 注释
    ws.merge_cells(start_row=6, start_column=1, end_row=6, end_column=total_cols)
    note = ws.cell(row=6, column=1, value='注：曝光量 = 渠道"全部"的阅读人数合计；推文数 = 该周发表的推文篇数。')
    note.font = Font(name='微软雅黑', size=10, color='808080')
    note.alignment = Alignment(horizontal='left', vertical='center')

    # 每日明细表
    ws2 = wb_out.create_sheet('每日明细数据')
    ws2.merge_cells('A1:D1')
    t2 = ws2['A1']
    t2.value = '每日"全部"渠道阅读人数与发表篇数明细'
    t2.font = Font(name='微软雅黑', size=14, bold=True, color='2F5496')
    t2.alignment = Alignment(horizontal='center', vertical='center')
    ws2.row_dimensions[1].height = 30
    h2 = ['日期', '星期', '阅读人数', '发表篇数']
    for col, h in enumerate(h2, 1):
        cell = ws2.cell(row=2, column=col, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin_border
    weekday_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    r = 3
    for d in all_dates:
        ws2.cell(row=r, column=1, value=d.strftime('%Y-%m-%d'))
        ws2.cell(row=r, column=2, value=weekday_names[d.weekday()])
        ws2.cell(row=r, column=3, value=daily_read[d])
        ws2.cell(row=r, column=4, value=daily_pub.get(d, 0))
        for col in range(1, 5):
            cell = ws2.cell(row=r, column=col)
            cell.font = data_font
            cell.alignment = data_align
            cell.border = thin_border
        r += 1
    ws2.column_dimensions['A'].width = 15
    ws2.column_dimensions['B'].width = 10
    ws2.column_dimensions['C'].width = 12
    ws2.column_dimensions['D'].width = 12

    wb_out.save(output_path)
    return week_list


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(ERROR_MSG)
        sys.exit(1)
    input_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    try:
        sheet = validate_input(input_path)
    except ValueError as e:
        print(str(e))
        sys.exit(1)

    daily_read, daily_pub, all_dates = extract_daily(sheet)
    week_list = group_by_week(all_dates, daily_read, daily_pub)

    if not output_path:
        base = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(os.path.dirname(input_path), f'{base}_每周统计.xlsx')

    build_output(week_list, output_path)
    print('处理完成，输出文件:', output_path)
    total_read = sum(w['read'] for w in week_list)
    total_pub = sum(w['pub'] for w in week_list)
    print(f'共{len(week_list)}周，曝光量合计{total_read}，推文数合计{total_pub}')

# -*- coding: utf-8 -*-
"""
熊猫公号 · 多公号 × 多月份汇总

把用户提供的公众号平台使用量文件（文件名形如 `{公号名}[{月}月]{当月粉丝数}.xls`）
汇总为一张「月度汇总对比」表 + 每月一张「{月}月每周统计」表。

**月份与年份一律取自文件内容日期列**，文件名里的月份（若有）只作参考：
两者不一致时以内容为准，并在结果中回报 warning。

用法:
    python summarize_accounts.py <输入目录或文件...> [-o 输出.xlsx] [--tail-merge N]

统计口径:
    曝光量 = 渠道"全部"的阅读人数，按自然周（周一~周日）求和
    推文数 = 按自然周合计"发表篇数"
    粉丝数 = 取自文件名的"当月粉丝数"

--tail-merge N:
    若某月最后一个周段天数 <= N，则把它并入前一个周段（用于对齐目标表"8.24-8.31"这类
    把孤立尾日并进前一周的口径；设为 0 表示不合并）。只处理尾段，不动首段。

无法提取所需信息时（文件名不符合规则 / 内容核验失败），脚本不猜、不跳过，
以 NEED_USER_INPUT|{json} 输出并退出码 2，由调用方弹窗询问用户。
"""
import argparse
import os
import sys
from collections import OrderedDict
from datetime import timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from process_wechat_data import validate_input, extract_daily, group_by_week  # noqa: E402
from wechat_common import (load_config, parse_filename_lenient, collect_inputs,  # noqa: E402
                           parse_fans_overrides, fill_fans, build_filename_issue,
                           need_user_input, require_account_mapping)

import openpyxl  # noqa: E402
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side  # noqa: E402
from openpyxl.utils import get_column_letter  # noqa: E402

# ---------------- 样式 ----------------
F_TITLE = Font(name='微软雅黑', size=14, bold=True, color='2F5496')
F_HEAD = Font(name='微软雅黑', size=11, bold=True, color='FFFFFF')
F_DATA = Font(name='微软雅黑', size=11)
F_BOLD = Font(name='微软雅黑', size=11, bold=True)
F_NOTE = Font(name='微软雅黑', size=10, color='808080')
FILL_H1 = PatternFill('solid', start_color='2F5496', end_color='2F5496')
FILL_H2 = PatternFill('solid', start_color='4472C4', end_color='4472C4')
FILL_LIGHT = PatternFill('solid', start_color='D6E4F0', end_color='D6E4F0')
FILL_TOTAL = PatternFill('solid', start_color='FCE4D6', end_color='FCE4D6')
AL_C = Alignment(horizontal='center', vertical='center')
AL_L = Alignment(horizontal='left', vertical='center')
_S = Side(style='thin')
BD = Border(left=_S, right=_S, top=_S, bottom=_S)


def set_cell(ws, r, c, v, font=F_DATA, fill=None, border=True, align=AL_C):
    cell = ws.cell(row=r, column=c, value=v)
    cell.font = font
    cell.alignment = align
    if border:
        cell.border = BD
    if fill is not None:
        cell.fill = fill
    return cell


def fmt_range(s, e):
    if s == e:
        return f'{s.month}月{s.day}日'
    if s.month == e.month:
        return f'{s.month}月{s.day}-{e.day}日'
    return f'{s.month}月{s.day}日-{e.month}月{e.day}日'


def merge_tail_slot(slot, n):
    """把某月内天数 <= n 的末尾周段并入前一段。"""
    weeks, meta = slot['weeks'], slot['meta']
    keys = sorted(weeks)
    if n <= 0 or len(keys) < 2:
        return
    last_k = keys[-1]
    s, e = meta[last_k]
    if (e - s).days + 1 <= n:
        prev_k = keys[-2]
        weeks[prev_k] = (weeks[prev_k][0] + weeks[last_k][0],
                         weeks[prev_k][1] + weeks[last_k][1])
        ps, pe = meta[prev_k]
        meta[prev_k] = (ps, max(pe, e))
        del weeks[last_k]
        del meta[last_k]


# ---------------- 主流程 ----------------
def main():
    ap = argparse.ArgumentParser(description='熊猫公号 · 多公号 × 多月份汇总')
    ap.add_argument('inputs', nargs='+', help='输入目录或 .xls/.xlsx 文件')
    ap.add_argument('-o', '--output', help='输出 xlsx 路径')
    ap.add_argument('--tail-merge', type=int, default=0,
                    help='末尾周段天数 <= N 时并入前一周（对齐目标表口径，默认 0 不合并）')
    ap.add_argument('--fans', action='append', nargs='+', default=[], metavar='KEY=N',
                    help='文件名未带粉丝数时补值。KEY 为文件名或公号缩写。'
                         '可写多个：--fans EMD=3210 HE=1200；也可重复 --fans。'
                         '⚠️ 请放在所有输入路径之后（它会一直取到下一个选项为止）')
    args = ap.parse_args()

    cfg = load_config()
    overrides = parse_fans_overrides(args.fans)
    files, skipped = collect_inputs(args.inputs, cfg.get('ignore_patterns'))
    if not files:
        need_user_input('no_input_file', inputs=args.inputs, skipped=skipped)

    # 1) 解析文件名（公号名可用缩写或全称；月份可有可无；粉丝数可由 --fans 补）
    for f in files:
        if not os.path.exists(f):
            need_user_input('file_not_found', file=f)
    parsed = [(os.path.splitext(os.path.basename(f))[0], parse_filename_lenient(
        os.path.splitext(os.path.basename(f))[0], cfg)) for f in files]
    issues = fill_fans(parsed, overrides)

    # 映射表为空：出表必须有映射才能归属公号 → 直接求助（措辞与探测脚本一致）
    require_account_mapping(cfg)

    records = []
    for f, (stem, meta) in zip(files, parsed):
        if meta['issue']:
            issues.append(build_filename_issue(meta, stem, cfg, os.path.basename(f)))
            continue
        rec = {'file': f, 'abbr': meta['abbr'], 'account': meta['account'],
               'fans': meta['fans'], 'month_in_name': meta['month_in_name']}
        records.append(rec)

    if issues:
        # 把所有问题一次性列全，由调用方一个弹窗问完（不猜、不跳过）
        need_user_input('file_issues', issues=issues,
                        hint='以下文件名/参数问题需你确认或补充后重跑')
    if not records:
        need_user_input('no_valid_record', files=files)

    # 2) 逐个核验 + 提取 + 按「内容年月」聚合
    data = {}          # (abbr, year, month) -> {'fans','weeks','meta','files'}
    abbr_seen, warnings = [], []
    for rec in records:
        try:
            sheet = validate_input(rec['file'])
            daily_read, daily_pub, dates = extract_daily(sheet)
        except ValueError:
            need_user_input('content_validation_failed', file=os.path.basename(rec['file']),
                            expected_keywords=['数据趋势概况', '日期', '渠道', '阅读人数', '发表篇数'],
                            hint='文件内容不像微信公众平台导出的「平台使用量」文件')
        if rec['abbr'] not in abbr_seen:
            abbr_seen.append(rec['abbr'])

        # 按内容日期分桶到 (年, 月)
        buckets = {}
        for d in dates:
            buckets.setdefault((d.year, d.month), []).append(d)

        # 文件名月份与内容不一致 → 以内容为准并回报（年份只能来自内容，不做推断）
        content_months = sorted({m for (_, m) in buckets})
        if rec['month_in_name'] and rec['month_in_name'] not in content_months:
            warnings.append({
                'reason': 'name_month_mismatch', 'file': os.path.basename(rec['file']),
                'month_in_name': rec['month_in_name'],
                'actual_years': sorted({y for (y, _) in buckets}), 'actual_months': content_months,
                'hint': f'文件名写 {rec["month_in_name"]} 月，内容实为 '
                        f'{"/".join(str(y) for y, _ in sorted(buckets))} 年 '
                        f'{"/".join(str(m) for m in content_months)} 月，已按内容为准'})

        for (y, m), dlist in buckets.items():
            dlist.sort()
            sub_read = {d: daily_read[d] for d in dlist}
            sub_pub = {d: daily_pub.get(d, 0) for d in dlist}
            week_list = group_by_week(dlist, sub_read, sub_pub)

            key = (rec['abbr'], y, m)
            slot = data.setdefault(key, {'fans': None, 'weeks': OrderedDict(),
                                         'meta': {}, 'files': []})
            if slot['fans'] is not None and slot['fans'] != rec['fans']:
                warnings.append({
                    'reason': 'fans_conflict', 'abbr': rec['abbr'], 'year': y, 'month': m,
                    'fans_prev': slot['fans'], 'fans_new': rec['fans'],
                    'file': os.path.basename(rec['file']),
                    'hint': f'{rec["abbr"]} {y}年{m}月 出现两个不同的粉丝数'
                            f'（{slot["fans"]} / {rec["fans"]}），已取后者，请确认'})
            slot['fans'] = rec['fans']
            slot['files'].append(os.path.basename(rec['file']))
            for w in week_list:
                monday = w['start'] - timedelta(days=w['start'].weekday())
                p, r = slot['weeks'].get(monday, (0, 0))
                slot['weeks'][monday] = (p + w['pub'], r + w['read'])
                s0, e0 = slot['meta'].get(monday, (w['start'], w['end']))
                slot['meta'][monday] = (min(s0, w['start']), max(e0, w['end']))

    # 尾周合并（每个「公号 × 年月」独立处理）
    for slot in data.values():
        merge_tail_slot(slot, args.tail_merge)

    accounts = [a for a in cfg['order'] if a in abbr_seen] + \
               [a for a in abbr_seen if a not in cfg['order']]
    ym_list = sorted({(y, m) for (_, y, m) in data})
    years = sorted({y for (y, _) in ym_list})
    year = years[0] if len(years) == 1 else None
    multi_year = len(years) > 1

    def ym_label(ym):
        return f'{ym[0]}.{ym[1]:02d}' if multi_year else f'{ym[1]}月'

    def stat(abbr, ym):
        d = data.get((abbr, ym[0], ym[1]), {})
        w = d.get('weeks', {})
        return sum(x[0] for x in w.values()), sum(x[1] for x in w.values()), d.get('fans')

    # 3) 输出
    if not args.output:
        tag = (f'{ym_list[0][0]}{ym_list[0][1]:02d}-{ym_list[-1][0]}{ym_list[-1][1]:02d}'
               if ym_list else 'summary')
        args.output = os.path.join(os.path.dirname(os.path.abspath(files[0])),
                                   f'公众号数据汇总_{tag}.xlsx')
    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)

    wb = openpyxl.Workbook()

    # --- Sheet1 月度汇总对比 ---
    ws = wb.active
    ws.title = '月度汇总对比'
    has_delta = len(ym_list) >= 2
    ncol = 1 + 3 * len(ym_list) + (2 if has_delta else 0)
    span = (f'{ym_list[0][0]}.{ym_list[0][1]:02d}-{ym_list[-1][0]}.{ym_list[-1][1]:02d}'
            if ym_list else '')
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    set_cell(ws, 1, 1, f'各公众号推文数与曝光量月度汇总对比（{span}）', font=F_TITLE, border=False)
    ws.row_dimensions[1].height = 30

    ws.merge_cells(start_row=2, start_column=1, end_row=3, end_column=1)
    set_cell(ws, 2, 1, '公众号', font=F_HEAD, fill=FILL_H1)
    ws.cell(row=3, column=1).border = BD
    c = 2
    for ym in ym_list:
        ws.merge_cells(start_row=2, start_column=c, end_row=2, end_column=c + 2)
        set_cell(ws, 2, c, ym_label(ym), font=F_HEAD, fill=FILL_H2)
        for k in range(1, 3):
            ws.cell(row=2, column=c + k).border = BD
        for k, lab in enumerate(['推文数', '曝光量', '粉丝数']):
            set_cell(ws, 3, c + k, lab, font=F_HEAD, fill=FILL_H1)
        c += 3
    if has_delta:
        ws.merge_cells(start_row=2, start_column=c, end_row=2, end_column=c + 1)
        set_cell(ws, 2, c, '变化', font=F_HEAD, fill=FILL_H2)
        ws.cell(row=2, column=c + 1).border = BD
        for k, lab in enumerate(['粉丝净增', '曝光环比']):
            set_cell(ws, 3, c + k, lab, font=F_HEAD, fill=FILL_H1)
    ws.row_dimensions[2].height = 24
    ws.row_dimensions[3].height = 22

    totals = {ym: [0, 0] for ym in ym_list}
    r = 4
    for abbr in accounts:
        label = f'{abbr}｜{cfg["accounts"][abbr]}'
        row = [label]
        for ym in ym_list:
            p, rd, fan = stat(abbr, ym)
            totals[ym][0] += p
            totals[ym][1] += rd
            row += [p, rd, fan if fan is not None else '—']
        if has_delta:
            fu, fl = stat(abbr, ym_list[-1])[2], stat(abbr, ym_list[-2])[2]
            row.append(f'+{fu-fl}' if (fu is not None and fl is not None and fu - fl > 0)
                       else (str(fu - fl) if (fu is not None and fl is not None) else '—'))
            r_u, r_l = stat(abbr, ym_list[-1])[1], stat(abbr, ym_list[-2])[1]
            row.append(f'{r_u/r_l-1:+.0%}' if r_l else '—')
        for k, v in enumerate(row, 1):
            set_cell(ws, r, k, v, fill=(FILL_LIGHT if k == 1 else None),
                     align=(AL_L if k == 1 else AL_C))
        ws.row_dimensions[r].height = 24
        r += 1

    trow = ['合计']
    for ym in ym_list:
        trow += [totals[ym][0], totals[ym][1], '—']
    if has_delta:
        trow += ['—', f'{totals[ym_list[-1]][1]/totals[ym_list[-2]][1]-1:+.0%}'
                 if totals[ym_list[-2]][1] else '—']
    for k, v in enumerate(trow, 1):
        set_cell(ws, r, k, v, font=F_BOLD, fill=FILL_TOTAL, align=(AL_L if k == 1 else AL_C))
    ws.row_dimensions[r].height = 24

    ws.column_dimensions['A'].width = 30
    for k in range(2, ncol + 1):
        ws.column_dimensions[get_column_letter(k)].width = 11
    nr = r + 2
    ws.merge_cells(start_row=nr, start_column=1, end_row=nr, end_column=ncol)
    set_cell(ws, nr, 1,
             '注：曝光量 = 渠道"全部"的阅读人数合计；推文数 = 当月发表篇数；'
             '粉丝数取自文件名"当月粉丝数"；月份与年份以文件内容日期为准；'
             '不同公号的粉丝与推文不可简单相加。',
             font=F_NOTE, border=False, align=AL_L)

    # --- 分月周表 ---
    used_names = set()
    for ym in ym_list:
        sheet_title = f'{ym[1]}月每周统计'
        if sheet_title in used_names:                      # 跨年同月时消歧
            sheet_title = f'{ym[0]}.{ym[1]:02d}每周统计'
        used_names.add(sheet_title)
        ws2 = wb.create_sheet(sheet_title)

        wm = OrderedDict()
        for abbr in accounts:
            for monday, (s, e) in sorted(data.get((abbr, ym[0], ym[1]), {}).get('meta', {}).items()):
                if monday not in wm:
                    wm[monday] = (s, e)
                else:
                    wm[monday] = (min(wm[monday][0], s), max(wm[monday][1], e))
        mondays = sorted(wm)
        if not mondays:
            continue
        nw = len(mondays)
        total_cols = nw * 2 + 3
        ws2.merge_cells(start_row=1, start_column=1, end_row=1, end_column=total_cols)
        period = f'{wm[mondays[0]][0].strftime("%Y.%m.%d")}-{wm[mondays[-1]][1].strftime("%Y.%m.%d")}'
        set_cell(ws2, 1, 1, f'各公众号每周推文数与曝光量统计（{ym[0]} 年 {ym[1]} 月，{period}）',
                 font=F_TITLE, border=False)
        ws2.row_dimensions[1].height = 30

        ws2.merge_cells(start_row=2, start_column=1, end_row=3, end_column=1)
        set_cell(ws2, 2, 1, '公众号', font=F_HEAD, fill=FILL_H1)
        ws2.cell(row=3, column=1).border = BD
        for cix, lab in ((2, '月推文合计'), (3, '月曝光合计')):
            ws2.merge_cells(start_row=2, start_column=cix, end_row=3, end_column=cix)
            set_cell(ws2, 2, cix, lab, font=F_HEAD, fill=FILL_H1)
            ws2.cell(row=3, column=cix).border = BD
        for i, monday in enumerate(mondays):
            c1 = 4 + i * 2
            ws2.merge_cells(start_row=2, start_column=c1, end_row=2, end_column=c1 + 1)
            s, e = wm[monday]
            set_cell(ws2, 2, c1, f'第{i+1}周 {fmt_range(s, e)}', font=F_HEAD, fill=FILL_H2)
            ws2.cell(row=2, column=c1 + 1).border = BD
            set_cell(ws2, 3, c1, '推文数', font=F_HEAD, fill=FILL_H1)
            set_cell(ws2, 3, c1 + 1, '曝光量', font=F_HEAD, fill=FILL_H1)
        ws2.row_dimensions[2].height = 24
        ws2.row_dimensions[3].height = 22

        rr, tp, tr = 4, 0, 0
        for abbr in accounts:
            d = data.get((abbr, ym[0], ym[1]), {}).get('weeks', {})
            mp, mr = sum(x[0] for x in d.values()), sum(x[1] for x in d.values())
            tp += mp
            tr += mr
            set_cell(ws2, rr, 1, f'{abbr}｜{cfg["accounts"][abbr]}', fill=FILL_LIGHT, align=AL_L)
            set_cell(ws2, rr, 2, mp)
            set_cell(ws2, rr, 3, mr)
            for i, monday in enumerate(mondays):
                p, rd = d.get(monday, (0, 0))
                set_cell(ws2, rr, 4 + i * 2, p, fill=FILL_LIGHT)
                set_cell(ws2, rr, 5 + i * 2, rd)
            ws2.row_dimensions[rr].height = 24
            rr += 1
        set_cell(ws2, rr, 1, '合计', font=F_BOLD, fill=FILL_TOTAL, align=AL_L)
        set_cell(ws2, rr, 2, tp, font=F_BOLD, fill=FILL_TOTAL)
        set_cell(ws2, rr, 3, tr, font=F_BOLD, fill=FILL_TOTAL)
        for i, monday in enumerate(mondays):
            sp = sum(data.get((a, ym[0], ym[1]), {}).get('weeks', {}).get(monday, (0, 0))[0]
                     for a in accounts)
            sr = sum(data.get((a, ym[0], ym[1]), {}).get('weeks', {}).get(monday, (0, 0))[1]
                     for a in accounts)
            set_cell(ws2, rr, 4 + i * 2, sp, font=F_BOLD, fill=FILL_TOTAL)
            set_cell(ws2, rr, 5 + i * 2, sr, font=F_BOLD, fill=FILL_TOTAL)

        ws2.column_dimensions['A'].width = 30
        ws2.column_dimensions['B'].width = 11
        ws2.column_dimensions['C'].width = 12
        for i in range(nw):
            ws2.column_dimensions[get_column_letter(4 + i * 2)].width = 10
            ws2.column_dimensions[get_column_letter(5 + i * 2)].width = 11
        nr2 = rr + 2
        ws2.merge_cells(start_row=nr2, start_column=1, end_row=nr2, end_column=total_cols)
        set_cell(ws2, nr2, 1,
                 '注：曝光量 = 渠道"全部"的阅读人数合计，按自然周（周一至周日）汇总；'
                 '推文数 = 该周发表篇数；首尾不完整周按实际天数统计；月份以文件内容日期为准。',
                 font=F_NOTE, border=False, align=AL_L)

    wb.save(args.output)
    total_read = sum(totals[ym][1] for ym in ym_list)
    print(f'汇总完成: {args.output}')
    print(f'公号 {len(accounts)} 个，年月 {[f"{y}-{m:02d}" for y, m in ym_list]}，'
          f'曝光合计 {total_read}')
    for abbr in accounts:
        detail = ' | '.join(f'{ym_label(ym)}:{stat(abbr, ym)[0]}推/{stat(abbr, ym)[1]}曝/'
                            f'粉{stat(abbr, ym)[2]}' for ym in ym_list)
        print(f'  {abbr}｜{cfg["accounts"][abbr]}: {detail}')
    if skipped:
        print(f'  ⊘ 已跳过 {len(skipped)} 个自家产出/临时文件：{"、".join(skipped)}')
    for w in warnings:
        print(f'  ⚠ {w["hint"]}')


if __name__ == '__main__':
    main()

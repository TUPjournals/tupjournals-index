# -*- coding: utf-8 -*-
"""
熊猫公号 · 公共模块

集中提供三件事，供 probe_period / summarize_accounts / merge_wechat_summary 共用：
1. 配置加载（skill 默认 + 用户级覆盖，两级生效）
2. 文件名解析（公号名可用缩写或全称；月份可有可无）
3. 求助输出（NEED_USER_INPUT|{json} + 退出码 2）

文件名规则（`filename_pattern`）：
    {公号名}[{月}月]{当月粉丝数}.xls

- **公号名**：缩写（如 CS）或全称均可
- **月份**：可有可无。写了仅作参考，**一切以文件内容日期为准**；
  若与内容月份不一致，以内容为准并记录 warning 告知用户
- **粉丝数**：必填，取自文件名
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(HERE)

SKILL_CONFIG = os.path.join(SKILL_ROOT, 'config', 'accounts.json')
USER_CONFIG = os.path.join(os.path.expanduser('~'), '.workbuddy',
                           'panda-wechat-data', 'accounts.json')

NEED_PREFIX = 'NEED_USER_INPUT|'
PROBE_PREFIX = 'PROBE_RESULT|'

# {公号名}[{月}月][-_ ]{粉丝数}
DEFAULT_PATTERN = r'^(?P<name>.+?)(?:(?P<month>\d{1,2})月)?[-_\s]*(?P<fans>\d+)$'

# 从目录中发现时予以忽略的文件（自家产出 / Excel 临时锁文件）。显式传入的文件不受此限。
DEFAULT_IGNORE_PATTERNS = ['~$*', '*.tmp', '公众号数据汇总*']


def need_user_input(reason, **extra):
    """输出结构化求助信息并退出（退出码 2），调用方据此弹窗询问用户。"""
    payload = {'reason': reason}
    payload.update(extra)
    print(NEED_PREFIX + json.dumps(payload, ensure_ascii=False))
    sys.exit(2)


def load_config():
    """读配置：skill 默认在前，用户级覆盖在后（同名键用户级优先）。"""
    cfg = {'accounts': {}, 'order': [], 'filename_pattern': DEFAULT_PATTERN,
           'ignore_patterns': []}
    for path in (SKILL_CONFIG, USER_CONFIG):
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding='utf-8') as f:
                node = json.load(f)
        except Exception as exc:
            need_user_input('config_unreadable', path=path, error=str(exc))
        if node.get('filename_pattern'):
            cfg['filename_pattern'] = node['filename_pattern']
        cfg['accounts'].update(node.get('accounts', {}))
        if node.get('order'):
            cfg['order'] = node['order']
        if node.get('ignore_patterns'):
            cfg['ignore_patterns'] = node['ignore_patterns']
    cfg['accounts_empty'] = not cfg['accounts']
    return cfg


def account_mapping_issue():
    """映射表为空的待确认项。

    探测脚本把它折叠进 `issues`——**不阻断读内容**，仍照报时间区间，
    再把"请登记映射"作为一个待确认项交给用户（与"先读内容、再谈文件名"的原则一致）。
    """
    return {
        'severity': 'need_input',
        'reason': 'no_account_mapping',
        'skill_config': SKILL_CONFIG,
        'user_config': USER_CONFIG,
        'hint': '未找到任何「缩写↔公众号全称」映射（映射表为空），文件名里的公号名无法归属。'
                '登记方式二选一：① 编辑 <skill>/config/accounts.json 的 accounts；'
                '② 新建用户级 ~/.workbuddy/panda-wechat-data/accounts.json'
                '（同名键优先、其余自动继承，模板见 config/accounts.user.example.json）。'
                '登记后即可正常解析。',
    }


def require_account_mapping(cfg):
    """生产类脚本（要出表/填表）用：映射表为空则直接求助，措辞与探测脚本一致。"""
    if cfg.get('accounts_empty'):
        iss = account_mapping_issue()
        reason = iss.pop('reason')
        iss.pop('severity', None)
        need_user_input(reason, **iss)


def _norm(s):
    """归一化：去空格/下划线/连字符，转小写。用于全称与缩写的宽松匹配。"""
    return re.sub(r'[\s_\-]+', '', str(s)).lower()


def resolve_account(name, accounts):
    """把文件名中的公号名（缩写或全称）解析为映射表的键，解析不出返回 None。"""
    if name in accounts:
        return name
    target = _norm(name)
    for key, full in accounts.items():
        if _norm(key) == target or _norm(full) == target:
            return key
    return None


def parse_filename(stem, cfg):
    """解析文件名 → dict；不符合规则或公号未登记时返回 None（严格版，供生产脚本用）。

    返回: {'abbr','account','fans','month_in_name','matched_name'}
    """
    r = parse_filename_lenient(stem, cfg)
    return r if r['ok'] else None


def parse_filename_lenient(stem, cfg):
    """宽容版解析：解析不出来也尽量说清「缺的是什么」，供探测阶段一次性问全。

    返回 dict:
        {'ok': bool, 'issue': None|'missing_fans'|'unregistered_account'|'filename_pattern_mismatch',
         'abbr': str|None, 'account': str|None, 'fans': int|None,
         'month_in_name': int|None, 'matched_name': str|None}
    """
    m = re.match(cfg['filename_pattern'], stem)
    if m:
        matched = m.group('name')
        abbr = resolve_account(matched, cfg['accounts'])
        month = m.group('month')
        month = int(month) if month and 1 <= int(month) <= 12 else None
        if abbr is None:
            return {'ok': False, 'issue': 'unregistered_account', 'abbr': None, 'account': None,
                    'fans': int(m.group('fans')), 'month_in_name': month, 'matched_name': matched}
        return {'ok': True, 'issue': None, 'abbr': abbr, 'account': cfg['accounts'][abbr],
                'fans': int(m.group('fans')), 'month_in_name': month, 'matched_name': matched}

    # 没带粉丝数：剥掉尾部可选的「{月}月」后，看剩下的名字能否对上映射表
    m2 = re.match(r'^(?P<name>.+?)(?:(?P<month>\d{1,2})月)?$', stem)
    if m2 and resolve_account(m2.group('name'), cfg['accounts']):
        matched = m2.group('name')
        abbr = resolve_account(matched, cfg['accounts'])
        month = m2.group('month')
        month = int(month) if month and 1 <= int(month) <= 12 else None
        return {'ok': False, 'issue': 'missing_fans', 'abbr': abbr,
                'account': cfg['accounts'][abbr], 'fans': None,
                'month_in_name': month, 'matched_name': matched}

    return {'ok': False, 'issue': 'filename_pattern_mismatch', 'abbr': None, 'account': None,
            'fans': None, 'month_in_name': None, 'matched_name': None}


def _flatten(items):
    """把可能嵌套的参数列表（argparse 的 append+nargs）摊平。"""
    for it in items or []:
        if isinstance(it, (list, tuple)):
            for sub in _flatten(it):
                yield sub
        else:
            yield it


def parse_fans_overrides(items):
    """把 --fans 参数解析成 {'EMD': 3210}。

    三种写法等价（同一参数内可用逗号/顿号/空格分隔多个）：
        --fans EMD=3210
        --fans EMD=3210 --fans HE=1200
        --fans EMD=3210,HE=1200
    """
    out = {}
    for raw in _flatten(items):
        for token in re.split(r'[,，、\s]+', str(raw).strip()):
            if not token:
                continue
            key, _, val = token.partition('=')
            key, val = key.strip(), val.strip()
            if not key or not val.isdigit():
                need_user_input('bad_fans_override', value=token,
                                hint='格式应为「文件名或公号缩写=数字」，例如 EMD=3210；'
                                     '多个可用逗号或空格分隔或重复 --fans')
            out[key] = int(val)
    return out


def resolve_fans(stem, abbr, overrides):
    """文件名未带粉丝数时，从用户的 --fans 覆盖表取值。返回 (fans, source)。"""
    if not overrides:
        return None, None
    if stem in overrides:
        return overrides[stem], f'--fans {stem}='
    if abbr and abbr in overrides:
        return overrides[abbr], f'--fans {abbr}='
    return None, None


def fill_fans(parsed, overrides):
    """按 overrides 补齐文件名缺失的粉丝数（就地修改 parsed 中每个 meta）。

    parsed: [(stem, meta)]，meta 为 parse_filename_lenient 的返回值。
    返回 issues 列表：仅含「同一缩写键对应多个缺粉丝数的文件」这类歧义告警。
    """
    issues = []
    missing = {}
    for stem, meta in parsed:
        if meta['fans'] is None and meta.get('abbr') and stem not in overrides:
            missing.setdefault(meta['abbr'], []).append(stem)
    ambiguous = {k: v for k, v in missing.items() if len(v) > 1 and k in overrides}
    for k, v in ambiguous.items():
        issues.append({
            'severity': 'need_input', 'reason': 'ambiguous_fans_override', 'abbr': k, 'files': v,
            'hint': f'--fans {k}=N 会同时作用到 {len(v)} 个都没带粉丝数的文件'
                    f'（{"、".join(v)}），请改用文件名逐个指定，例如 --fans {v[0]}=N'})
    for stem, meta in parsed:
        # 只处理「文件名完整但缺粉丝数」这一种；其他问题（公号未登记、完全解析不出）无 abbr 可对，跳过
        if meta['fans'] is not None or meta.get('abbr') in ambiguous:
            continue
        if not (meta['ok'] or meta['issue'] == 'missing_fans'):
            continue
        fans, src = resolve_fans(stem, meta['abbr'], overrides)
        if fans is None:
            continue
        meta['fans'] = fans
        meta['fans_source'] = src
        meta['ok'] = True
        meta['issue'] = None
    return issues


def build_filename_issue(meta, stem, cfg, filename):
    """把文件名解析问题转成结构化 issue（供弹窗逐条问用户）。"""
    reason = meta['issue']
    base = {'severity': 'need_input', 'reason': reason, 'file': filename, 'stem': stem}
    if reason == 'missing_fans':
        base.update({
            'abbr': meta['abbr'], 'account': meta['account'],
            'hint': f'文件名「{stem}」只有公号名、末尾没有"当月粉丝数"，'
                    f'该月粉丝数取不到（可用 --fans {meta["abbr"]}=<数字> 补，或把文件改名）'})
    elif reason == 'unregistered_account':
        base.update({
            'matched_name': meta['matched_name'],
            'known_abbr': sorted(cfg['accounts'].keys()),
            'known_full_names': sorted(cfg['accounts'].values()),
            'hint': f'文件名里的公号名「{meta["matched_name"]}」不在映射表中，'
                    f'无法确定它归属哪个公众号'})
    else:
        base.update({
            'expected': cfg.get('filename_pattern'),
            'known_abbr': sorted(cfg['accounts'].keys()),
            'known_full_names': sorted(cfg['accounts'].values()),
            'hint': '文件名无法解析为「公号名（缩写或全称）+ 粉丝数」'})
    return base


def collect_inputs(inputs, extra_ignore=None):
    """把「目录或文件」的混合输入展开成去重后的文件列表。

    返回 (files, skipped)：
    - 从**目录**中发现、且命中忽略规则的文件（自家产出 `公众号数据汇总*`、Excel 临时锁
      文件 `~$*`、`*.tmp`）不参与处理，收进 skipped —— 调用方必须**如实报出**，不得静默
    - **显式传入**的文件不做忽略（用户点名要的文件一律照处理）
    """
    import fnmatch
    import glob

    patterns = list(DEFAULT_IGNORE_PATTERNS) + list(extra_ignore or [])
    files, skipped, seen = [], [], set()
    for item in inputs:
        if os.path.isdir(item):
            for f in sorted(glob.glob(os.path.join(item, '*.xls')) +
                            glob.glob(os.path.join(item, '*.xlsx'))):
                base = os.path.basename(f)
                if any(fnmatch.fnmatch(base, p) for p in patterns):
                    if base not in skipped:
                        skipped.append(base)
                    continue
                if f not in seen:
                    seen.add(f)
                    files.append(f)
        elif item not in seen:
            seen.add(item)
            files.append(item)
    return files, skipped

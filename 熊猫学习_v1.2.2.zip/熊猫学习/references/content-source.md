# COPE 内容抓取口径

> 站点：`https://publicationethics.org`（公开页面，无需登录）
> ⚠️ 本文所有具体数字都是**某次实测的快照，会漂**。每次运行以当日实测为准，不引用旧数字下结论。

---

## 一、入口

| 用途 | 入口 |
|---|---|
| 案例列表 | `https://publicationethics.org/guidance?f%5B0%5D=type%3A44&page=N` |
| 全部 guidance | `https://publicationethics.org/guidance` |
| 最新发布 | `https://publicationethics.org/news-opinion` |

**分页**：每页 10 条。历史上实测为「旧 → 新」升序（`page=0` 最旧，末页最新），
因此「最新优先」的回溯方向是 **末页 → 0**。站点改版后此方向会变，**首次运行请实测确认**。

```
# 确认末页页码：逐页递增直到返回空列表，记下最后一个有内容的页码
```

⚠️ **列表页码不能当作新旧判据**：列表并非严格按 Case year 排序。
必须逐条进详情页读 `Case number` / `Case year` 后再排序。

---

## 二、按类型分流（关键）

**部分 guidance 类型的全文不在网页上，而在独立 PDF 里。** 抓 HTML 后先判断页面是否含
`/media/{id}/download`：

| 类型 | 网页有全文？ | 处理 |
|---|---|---|
| `case` / `cope-position` / `core-principles` / `code-of-conduct` / `news-opinion` | ✅ 有 | 直接抓网页 |
| `discussion-document` / `endorsed-guidance` | ❌ 只有摘要 | **必须走 PDF 三步** |

判定命令（不下载，只探测）：

```bash
python scripts/cope_pdf.py --slug <slug> --id <内容ID> --type <类型> --dump-links
# page_kind = pdf_needed → 走 PDF；web_fulltext → 直接抓网页
```

---

## 三、PDF 全文三步

```bash
python scripts/cope_pdf.py --slug <slug> --id <内容ID> --type endorsed-guidance \
       --outdir "<archive>/pdf" --textdir "<archive>/pdf/_txt"
```

脚本内部依次做：
1. curl 抓 HTML（**必须带完整 Sec-Fetch-* 头**，见踩坑清单）
2. 提 `/media/{id}/download` → 下载（Referer = 详情页）→ 校验 HTTP 200 / `application/pdf` / `%PDF` 头 / 与页面标注大小偏差 <2%
3. pymupdf 提取全文 → 校验字符数（<200 怀疑图像版）与页脚特征（`COPE DISCUSSION|POSITION|GUIDANCE`）

**归档命名**：`{内容ID} - {内容标题}.pdf`；同名加 `(v2)`，**绝不覆盖**已有文件；文本旁挂 `_txt/`。

`{id}` 与 slug **无映射规律**，只能从页面抓，**绝不可推测或编造**。

---

## 四、详情页必读字段

`https://publicationethics.org/guidance/case/{slug}`：

| 字段 | 位置 |
|---|---|
| 主题标签 | `Case number` 上方的主题链接文字（可多个） |
| Case number / Case year | 标题区 |
| Anonymised case text | 正文主体 |
| Questions | 部分案例有此小节，部分把问题写在正文末尾 |
| Advice | **判定标志：页面是否出现 `Advice from COPE Members`** |

无 Advice → 标「⚠️ COPE 尚未发布建议」并记入待复查清单（+6 个月）。**绝不杜撰。**

---

## 五、COPE 主题受控词表（10 项）

只填官方原文，不自行翻译或发明；一例可挂多主题，多项用 `/` 分隔；无标签留空。

```
Post-publication review
Journal management
Research ethics
Authorship and contributorship
Data
Plagiarism
Peer review
Conflicts of interest
Publication practices
Diversity (DEIA)
```

⚠️ **框架性文件**（Core Principles、Code of Conduct 等）本身不挂 case 主题标签
→ 索引表「分类」列**留空**，不得硬套。

---

## 六、去重与排序

- 去重键：**COPE 链接**（不是标题，标题会改）
- 已学案例索引里出现过的链接 → 跳过
- 排序：先按 `Case year` 降序，同年按 `Case number` 降序
- 「新内容」判定窗口：近 3 个月

---

## 七、抓取工具的可用性（实测，会漂）

| 手段 | 结论 |
|---|---|
| WebFetch 抓 COPE 普通页面 | ✅ 可用，不触发 captcha |
| WebFetch 抓 PDF | ❌ 读不了（bytes dropped） |
| `Read` 直接打开 PDF | ❌ 得到压缩字节流，非文本 |
| 纯脚本 curl（仅 UA） | ❌ 403 |
| 脚本 curl（UA + Referer） | ❌ 403 |
| 脚本 curl（UA + **Sec-Fetch-*** + Referer） | ✅ 200 |

补充：CES 等个别站点会拦爬虫，COPE 不会；若某次返回 403，先查 `Sec-Fetch-*` 是否漏传，补齐后重试**一次**，仍失败如实报告。

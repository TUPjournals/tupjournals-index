# 台账口径（双后端）

> 台账是这套计划的状态机。**它错了，整个系统就错了**——重推会误判、降频会误触、索引会脏。
> 两个后端（腾讯文档 / 本地 md）**列结构完全相同**，`scripts/ledger.py` 里的 `SCHEMA` 是唯一来源。

---

## 一、三个子表

### 进度记录（progress，11 列）

| 列 | 说明 |
|---|---|
| 日期 | `YYYY-MM-DD` |
| 星期 | 周一…周日 |
| 内容ID | 主材料编号，如 `G-005`；无产出日填 `—` |
| 内容类型 | 如 `Case×2 + 文献×1`（每期固定 3 份） |
| 内容标题 | 本期材料英文标题，用 `；` 分隔 |
| 来源 | `COPE主线` / `COPE最新发布` / `用户投喂` / 组合 |
| 状态 | `未完成` / `已完成` |
| 确认时间 | 确认口令到达的日期；未确认留空 |
| 备注 | 仅状态性信息：`第003期；第N次重推`、`（第 k/N 讲 · 续推）` |
| **讲次** | `k/N`（v1.2.0 新增）；单讲留空 |
| **文献锚点** | 下一讲起始处，如 `Section 3 起`（v1.2.0 新增）；**下一期靠它判断要不要续推** |

⚠️ **列顺序不可变**：`讲次`/`文献锚点` 追加在末尾，既有 9 列位置不动。
旧表（9 列）不需要手工改：`ledger.py` 写数据前会先补表头并回读校验，缺列则**拒绝写入并报清单**，
不会把数据写歪。旧表头也不会被误当数据行（否则会把表头复制成第一行数据）。

**记全勤**：每个运行日一行，未学也写。运行日无产出（限流、故障）同样补记。

### 待复查清单（recheck，4 列）
`案例编号 ｜ 案例标题 ｜ 记录日期 ｜ 应复查日期`
仅当案例**无 Advice** 时新建，应复查日期 = 记录日 + `advice_recheck_months`（默认 6 个月）。

### 已学案例索引（index，4 列）
`内容ID ｜ 分类 ｜ COPE 链接 ｜ 学习日期`
**仅已确认材料**，一份材料一行。分类填 COPE 主题原文（多项 `/` 分隔），框架性文件留空。
跨期拆分/续推的材料，**全文推完且最后一讲确认后**才写 1 行，日期取最后一讲确认日。

---

## 二、写入口径（三条硬规矩）

1. **写前必读**：先读回现状，据现状决定「改行」还是「增行」。**不得假设目标为空**，不得按本地镜像拼写入。
2. **写后必回读**：返回值不是成功判据。回读逐字段比对，才算写完。
3. **合并写入**：同一文档 ≥3 次写 → 合并成 1 次调用。

确认到达时的标准动作：
- 进度记录：该材料涉及的**各行**（可能跨很多天）状态改 `已完成`、确认时间填确认日
- 索引：**一次性**写入该材料全部条目
- 重推期间索引**不动**（不建行、不滚动日期）

---

## 三、腾讯文档后端

### 环境与调用

- 插件脚本：`<plugins>/workbuddy-builtin/tencent-docs-plugin/<ver>/skills/tencent-docs/tencentdocs.py`
- **必须设** `TDOC_API_BASE_URL=https://docs.qq.com`
  （不加此变量时 provider 下发的 `api_base` 域名不解析，全部调用失败）
- 子命令：`tdoc_init` / `tdoc_list <service>` / `tdoc_schema <service> <tool>` / `tdoc_call <service> <tool> '<json>'`
- `tdoc_call` 的 JSON 是**位置参数**，没有 `--arguments`
- **调前必跑 `tdoc_schema` 查参数契约**，严禁凭记忆拼参数

### 读写契约（实测）

| 操作 | 工具 | 要点 |
|---|---|---|
| 读 | `get_cell_data` | `start_row/end_row/start_col/end_col`（0-based）+ `return_csv:true`；**没有 `range` 参数**；单次 ≤20000 单元格 |
| 写 | `set_range_value` | `values:[{row,col,value_type:"STRING",string_value}]`；遇 HTTP 501 / WAF 改传 `value_base64` |
| 子表 | `get_sheet_info` / `add_sheet` / `rename_sheet` | `add_sheet` 的 `name` ≤31 字符 |

⚠️ **不给 `end_row` 只会回 1 行**——读全表必须显式给窗口（`ledger.py` 会自动补窗口）。

⚠️ **位置索引 ≠ sheet_id**：`get_sheet_info` 列表里排第 2 位不代表 id 是 `"000002"`，必须读回真实 id。

### 建表流程（腾讯文档没有「新建文档」接口）

1. 用户手动新建一个空白在线表格，把 URL / file_id 交给 agent
2. `python scripts/ledger.py init` → 调 `add_sheet` 建 3 个子表 + 灌表头 → 回填 `config.ledger.sheets`
3. `python scripts/ledger.py read --sheet progress` 回读确认表头逐字一致

### 连接器状态判据

| 要判断 | 看什么 | 不要看 |
|---|---|---|
| 是否可用 | `tdoc_init` 返回 `READY` | `connector-states.json` 的 `enabled` |
| 是否就绪 | 日志 `connection-ready {"tools":N}` | 主观感受 |

失败降级：连续 2 次失败 → 停手如实报告「在线表未写入」，**绝不谎报**；本地镜像照常维护。

---

## 四、本地 md 后端

`config.ledger.backend = "md"` 时启用，路径 `config.ledger.md_path`。结构：

```
# 熊猫学习 · 本地台账

## 进度记录
| 日期 | 星期 | 内容ID | 内容类型 | 内容标题 | 来源 | 状态 | 确认时间 | 备注 | 讲次 | 文献锚点 |
|---|---|---|---|---|---|---|---|---|---|---|

## 待复查清单
## 已学案例索引
```

读写全部由 `ledger.py` 处理，**不要手工编辑表格结构**（列数一变解析就断）。
md 后端同样遵守「写前必读、写后回读」——脚本已内置，人工改动后请跑一次 `read` 复查。

---

## 五、常用命令

```bash
python scripts/ledger.py schema                          # 看列定义
python scripts/ledger.py read --sheet progress           # 读全部
python scripts/ledger.py read --sheet progress --rows 10 # 只读前 10 行
python scripts/ledger.py append --sheet progress --row-json '{"日期":"2026-11-13",...}'
python scripts/ledger.py update --sheet progress --cells-json '[{"row":7,"col":6,"value":"已完成"}]'
python scripts/ledger.py backlog                         # 降频判定（末尾连续未确认行数）
python scripts/ledger.py init                            # 建子表 + 表头
```

`backlog` 输出即降频依据：`consecutive_unconfirmed` ≥ `threshold` → 触发 R21。

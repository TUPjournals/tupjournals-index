#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""budget.py —— 全期字数预算的唯一闸门。

一件事：一期学习材料的篇幅不能失控。本脚本把「中文字符 + 英文单词」变成
可机械判定的数字，并给出**唯一一道硬闸**。文档纯净性请走 purity_check.py，
两者互不代管。

计数口径（唯一口径，不得另立）
  · 汉字：CJK 统一表意文字 U+4E00–9FFF + 扩展A U+3400–4DBF，逐字算 1
  · 英文：按 [A-Za-z][A-Za-z'\\-]* 分词，每词算 1
  · 不计：中英文标点、数字串、空白、Markdown 符号、URL、内容ID（G-005 / C-26-28 / U-20260101-1）

计入与排除
  计入：全部材料节（开篇文献 / Case N / 今日文献），含各节内的三张小表
  排除：头部（标题至首个 --- 行）、今日术语总表、今日表达清单、确认方式

分级（v1.2.0 用户裁定：只设一道闸，不做两级告警）
  ≤ hard_limit（默认 10000）—— 通过。8000 仅为写作目标，**不产生任何提示**
  >  hard_limit         —— 阻断，不得推送，必须删减后重跑

用法：
  python budget.py check  --doc 写好的.md
  python budget.py count  --text 某文件.txt
  python budget.py split  --text 文献全文.txt --chunk-words 1500
  python budget.py lecture --doc 写好的.md
  python budget.py lecture --ledger ledger.md

退出码：0 通过 / 1 输入错误 / 2 超 hard_limit（阻断）
"""

import argparse
import io
import json
import os
import re
import sys

# ── 计数口径 ────────────────────────────────────────────────────────────

CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]")
WORD_RE = re.compile(r"[A-Za-z][A-Za-z'\-]*")
URL_RE = re.compile(r"https?://\S+")
ID_RE = re.compile(r"\b(?:C-\d{2}-\d{2}|G-\d{3}|U-\d{8}-\d)\b")

DEFAULT_HARD = 10000
DEFAULT_CHUNK_WORDS = 1500

# ── 节识别 ──────────────────────────────────────────────────────────────

MATERIAL_HEADS = [
    (re.compile(r"^## 开篇文献"), "opening"),
    (re.compile(r"^## Case \d+"), "case"),
    (re.compile(r"^## 今日文献"), "doc"),
]

EXCLUDED_HEADS = [
    re.compile(r"^## 今日术语总表"),
    re.compile(r"^## 今日表达清单"),
    re.compile(r"^## 确认方式"),
]

LECTURE_RE = re.compile(r"第\s*(\d+)\s*/\s*(\d+)\s*讲")


def read_text(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read().replace("\r\n", "\n").replace("\r", "\n")


def count_units(text):
    """返回 (汉字数, 英文词数, 合计)。

    顺序不可颠倒：必须先删 URL 再删内容ID，最后才分词。
    否则 `https://a.b/c` 会数出 https/a/b/c 四个词，`G-005` 会数出 G 一个词。
    """
    text = URL_RE.sub(" ", text)
    text = ID_RE.sub(" ", text)
    zh = len(CJK_RE.findall(text))
    en = len(WORD_RE.findall(text))
    return zh, en, zh + en


def count_words_only(text):
    """只数英文词（split 子命令判 1500 英文词/讲 用）。"""
    text = URL_RE.sub(" ", text)
    text = ID_RE.sub(" ", text)
    return len(WORD_RE.findall(text))


def split_header(text):
    """切掉头部：标题至首个独立 --- 行。头部不计入预算。

    头部不计入的真正原因：carry_forward.py 的不变量是「第 3 行起内容不变」，
    字数摘要写在第 3 行，若头部计入预算就会与重推机制互相打死。
    """
    lines = text.split("\n")
    for i, l in enumerate(lines):
        if l.strip() == "---":
            return "\n".join(lines[:i + 1]), "\n".join(lines[i + 1:])
    return "", text


def sectionize(body):
    """按 `## ` 级标题切节，返回 [(heading, content), ...]。

    首个 `## ` 之前若有正文，作为 heading="" 的一节返回，不丢弃——
    否则漏在标题外的段落会逃逸预算。
    """
    out, cur_head, buf = [], None, []
    for line in body.split("\n"):
        if re.match(r"^## ", line):
            if cur_head is not None:
                out.append((cur_head, "\n".join(buf)))
            elif "\n".join(buf).strip():
                out.append(("", "\n".join(buf)))
            cur_head, buf = line.strip(), []
        else:
            buf.append(line)
    if cur_head is not None:
        out.append((cur_head, "\n".join(buf)))
    elif "\n".join(buf).strip():
        out.append(("", "\n".join(buf)))
    return out


def classify(head):
    """返回 (kind, excluded)。"""
    for pat in EXCLUDED_HEADS:
        if pat.match(head):
            return "excluded", True
    for pat, kind in MATERIAL_HEADS:
        if pat.match(head):
            return kind, False
    return "other", False


def material_label(head, kind):
    """给材料起一个短标签：优先内容ID，其次标题前段。"""
    if not head.strip():
        return "（无标题段）"
    m = ID_RE.search(head)
    if m:
        return m.group(0)
    head = re.sub(r"^##\s*", "", head)
    if kind == "case":
        m = re.match(r"(Case \d+)", head)
        if m:
            return m.group(1)
    return head[:36]


def analyze(path):
    return analyze_text(read_text(path), os.path.abspath(path))


def analyze_text(text, source=""):
    """对文档文本做预算分析。渲染器可在成文前调用（头部不计入，故无循环依赖）。"""
    header, body = split_header(text)
    items, total, doc_part, case_part = [], 0, 0, 0

    for head, content in sectionize(body):
        kind, excluded = classify(head)
        if excluded:
            continue
        zh, en, units = count_units(head + "\n" + content)
        # 除排除项外一律计入：宁可多算，不可漏算（未知素材类型不得逃逸预算）
        total += units
        if kind in ("opening", "case", "doc"):
            items.append({"id": material_label(head, kind), "kind": kind,
                          "heading": head, "zh": zh, "en": en, "units": units})
            if kind in ("opening", "doc"):
                doc_part += units
            else:
                case_part += units
        else:
            items.append({"id": material_label(head, kind), "kind": "other",
                          "heading": head, "zh": zh, "en": en, "units": units})

    items.sort(key=lambda x: -x["units"])
    return {
        "doc": source,
        "total": total,
        "doc_part": doc_part,
        "case_part": case_part,
        "materials": items,
        "excluded": ["今日术语总表", "今日表达清单", "确认方式", "头部"],
    }


def resolve_hard(arg_hard):
    """hard_limit 取值优先级：命令行 > config.json > 默认 10000。"""
    if arg_hard:
        return int(arg_hard)
    cfg = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "config.json")
    if os.path.exists(cfg):
        try:
            with io.open(cfg, "r", encoding="utf-8") as f:
                hard = json.load(f).get("content", {}).get("budget", {}).get("hard_limit")
            if isinstance(hard, int) and hard > 0:
                return hard
        except Exception:
            pass
    return DEFAULT_HARD


# ── 子命令 ──────────────────────────────────────────────────────────────

def cmd_check(args):
    if not os.path.exists(args.doc):
        sys.stderr.write("找不到文档：{}\n".format(args.doc))
        return 1
    hard = resolve_hard(args.hard)
    r = analyze(args.doc)
    r["hard"] = hard
    r["verdict"] = "block" if r["total"] > hard else "pass"
    r["over"] = max(0, r["total"] - hard)

    if args.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
        return 2 if r["verdict"] == "block" else 0

    if r["verdict"] == "pass":
        # 唯一允许的输出形态：一行，不带任何提示性措辞
        print("篇幅 {:,} 字 · 通过".format(r["total"]))
        return 0

    print("篇幅 {:,} 字 · 超出上限 {:,}（多 {:,}）".format(
        r["total"], hard, r["over"]))
    print("按材料排列（从大到小）：")
    for i, m in enumerate(r["materials"], 1):
        print("  {}. {:<28} {:>6,} 字  [{}]".format(
            i, m["id"], m["units"],
            "文献" if m["kind"] in ("opening", "doc") else "案例"))
    print("  文献合计 {:,} 字 ｜ 案例合计 {:,} 字".format(
        r["doc_part"], r["case_part"]))
    biggest = r["materials"][0]
    print("建议：压缩「{}」（{:,} 字）或将其改为下一讲，把全期压到 {:,} 以内".format(
        biggest["id"], biggest["units"], hard))
    print("不得推送")
    return 2


def cmd_count(args):
    if args.stdin:
        text = sys.stdin.read()
        name = "<stdin>"
    else:
        if not args.text or not os.path.exists(args.text):
            sys.stderr.write("找不到文件：{}\n".format(args.text))
            return 1
        text = read_text(args.text)
        name = args.text
    zh, en, units = count_units(text)
    if args.json:
        print(json.dumps({"source": name, "zh": zh, "en": en, "units": units},
                         ensure_ascii=False, indent=2))
    else:
        print("中文 {:,} · 英文 {:,} · 合计 {:,} 字".format(zh, en, units))
    return 0


def cmd_split(args):
    if not args.text or not os.path.exists(args.text):
        sys.stderr.write("找不到文件：{}\n".format(args.text))
        return 1
    chunk = args.chunk_words
    text = read_text(args.text)

    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    words = [count_words_only(p) for p in paras]
    total = sum(words)

    lead = {}
    for p in paras:
        first = p.split("\n")[0].strip()
        lead[first] = lead.get(first, 0) + 1

    def anchor_of(i):
        """取下讲起始处的可读锚点。

        PDF 取文会把页面眉题（标题行、`COPE DISCUSSION DOCUMENT`）切成独立段落，
        它们在多段开头重复出现，不是正文起点，必须跳过，否则台账锚点全是眉题。
        """
        for line in paras[i].split("\n"):
            line = line.strip()
            if lead.get(line, 0) >= 2:
                continue
            if count_words_only(line) >= 6:
                return line[:70]
        for line in paras[i].split("\n"):
            line = line.strip()
            if lead.get(line, 0) < 2 and line:
                return line[:70]
        return paras[i][:70].replace("\n", " ")

    lectures, acc, start = [], 0, 0
    for i, w in enumerate(words):
        if acc > 0 and acc + w > chunk:
            lectures.append({"lecture": len(lectures) + 1,
                             "words": acc,
                             "paras": [start + 1, i],
                             "anchor": anchor_of(i)})
            acc, start = 0, i
        acc += w
    if acc > 0:
        lectures.append({"lecture": len(lectures) + 1, "words": acc,
                         "paras": [start + 1, len(paras)],
                         "anchor": "(末尾)"})

    out = {"source": os.path.abspath(args.text), "total_words": total,
           "chunk_words": chunk, "lectures": len(lectures), "plan": lectures}
    if args.json:
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        print("英文 {:,} 词 · 每讲 {:,} 词 · 共 {:,} 讲".format(total, chunk, len(lectures)))
        for lec in lectures:
            print("  第 {}/{} 讲：{:,} 词，段 {}-{}，下讲起于：{}".format(
                lec["lecture"], len(lectures), lec["words"],
                lec["paras"][0], lec["paras"][1], lec["anchor"]))
    return 0


def cmd_lecture(args):
    if args.doc:
        if not os.path.exists(args.doc):
            sys.stderr.write("找不到文档：{}\n".format(args.doc))
            return 1
        # 只扫 `## ` 级标题：材料正文里的元数据（如「G-005（第 1/2 讲）」）
        # 与文献本身的讲次是两回事，混扫会取错。
        heads = [l.strip() for l in read_text(args.doc).split("\n")
                 if l.startswith("## ")]
        for pat in (r"^## 今日文献", r"^## 开篇文献"):
            for h in heads:
                if re.match(pat, h):
                    m = LECTURE_RE.search(h)
                    if m:
                        print("第 {}/{} 讲".format(m.group(1), m.group(2)))
                    else:
                        print("第 1/1 讲（单讲）")
                    return 0
        print("本期无文献节")
        return 0

    if args.ledger:
        if not os.path.exists(args.ledger):
            sys.stderr.write("找不到台账：{}\n".format(args.ledger))
            return 1
        text = read_text(args.ledger)
        rows = [l for l in text.split("\n") if l.strip().startswith("|")]
        head_idx, cols = None, []
        for i, l in enumerate(rows):
            cells = [c.strip() for c in l.strip().strip("|").split("|")]
            if "讲次" in cells or "文献锚点" in cells:
                head_idx, cols = i, cells
                break
        if head_idx is None:
            print("台账无「讲次」「文献锚点」列（旧表结构，视为无未推完文献）")
            return 0
        i_l = cols.index("讲次") if "讲次" in cols else -1
        i_a = cols.index("文献锚点") if "文献锚点" in cols else -1
        latest = None
        for l in rows[head_idx + 1:]:
            cells = [c.strip() for c in l.strip().strip("|").split("|")]
            if len(cells) != len(cols):
                continue
            if any(cells):
                latest = cells
        if not latest:
            print("台账无记录")
            return 0
        lec = latest[i_l] if i_l >= 0 else ""
        anc = latest[i_a] if i_a >= 0 else ""
        if lec or anc:
            print("上一讲次 {0} ｜ 锚点 {1}".format(lec or "(空)", anc or "(空)"))
            m = re.match(r"\s*(\d+)\s*/\s*(\d+)", lec)
            if m and int(m.group(1)) < int(m.group(2)):
                print("有未推完文献：下次优先推第 {}/{} 讲".format(
                    int(m.group(1)) + 1, m.group(2)))
        else:
            print("无未推完文献")
        return 0

    sys.stderr.write("请给 --doc 或 --ledger\n")
    return 1


def main():
    ap = argparse.ArgumentParser(description="全期字数预算闸门")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("check", help="对已成文的 .md 做预算裁决")
    p.add_argument("--doc", required=True)
    p.add_argument("--hard", type=int, default=None, help="默认 10000")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("count", help="只数单位，不裁决")
    p.add_argument("--text")
    p.add_argument("--stdin", action="store_true")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_count)

    p = sub.add_parser("split", help="算分讲方案（抓取阶段用）")
    p.add_argument("--text", required=True)
    p.add_argument("--chunk-words", type=int, default=DEFAULT_CHUNK_WORDS)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_split)

    p = sub.add_parser("lecture", help="反查讲次与续推锚点")
    p.add_argument("--doc")
    p.add_argument("--ledger")
    p.set_defaults(func=cmd_lecture)

    args = ap.parse_args()
    if not getattr(args, "func", None):
        ap.print_help()
        return 1
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

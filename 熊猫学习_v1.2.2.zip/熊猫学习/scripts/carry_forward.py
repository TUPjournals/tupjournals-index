#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""carry_forward.py —— 重推时的「单文件滚动」

背景：重推 = 复用上一期文档、只改元信息、正文零改动。
若每次都「复制为新日期文件」，同一材料会堆积 N 个内容相同的文件
（实测曾堆积 28 份）。本脚本改为：**写新文件 → 校验正文未变 → 删除旧文件**，
使同一材料在整个生命周期内只有一份文件，文件名滚动为最近一次推送日。

子命令
------
carry   滚动改名（主机制）
    python carry_forward.py carry --archive <dir> --from 20261111 --to 20261112 \\
        --weekday 周四 --rerun 29 [--dry-run] [--json]

dedupe  重复文档自检（默认只报告，不动文件）
    python carry_forward.py dedupe --archive <dir> [--apply] [--json]

退出码（carry）
---------------
0 成功或幂等     1 源文件不存在（调用方应降级为正常渲染新文档）
2 标题格式无法解析  3 目标已存在且内容不同  4 from 与 to 相同
5 第 3 行起内容发生变化（含头部第 3、4 行）

安全约定
--------
· 删除旧文件是唯一的破坏性动作，放在整条链路最后
· 删除前把「文件名 + 正文 md5 + 时间」写入 <archive>/_rerun_log.txt
· 校验只比对第 3 行起（第 1、2 行为元信息；第 3、4 行及确认行均不再改动）
"""

import argparse
import hashlib
import io
import json
import os
import re
import sys
import time

# 第 1 行：# {前缀} · 2026-11-12（周四）· 第 003 期
RE_TITLE = re.compile(
    r"^(# .+?)\s*·\s*(\d{4}-\d{2}-\d{2})\s*（(.+?)）\s*·\s*第\s*(\d+)\s*期\s*$"
)
# 第 2 行：> 期次类型：第 29 次重推
RE_TYPE = re.compile(r"^>\s*期次类型\s*[：:]\s*(.*)$")
# 讲次标记：第 2/3 讲
RE_LECTURE = re.compile(r"第\s*(\d+)\s*/\s*(\d+)\s*讲")
# 文中内容 ID
RE_IDS = re.compile(r"\b(?:C-\d{2}-\d{2}|G-\d{3}|U-\d{8}-\d)\b")
# 日期文件名
RE_DOCNAME = re.compile(r"^(\d{8})\.md$")

# HTML 阅读版里需要同步的三处元信息（render_html.py 生成的结构）
RE_HTML_TITLE = re.compile(r"(<title>.+? · )\d{4}-\d{2}-\d{2}( · 第 \d+ 期</title>)")
RE_HTML_DATE = re.compile(r'(<p class="date">)\d{4}-\d{2}-\d{2}( · [^<]*)(</p>)')
RE_HTML_TYPE = re.compile(r'(<p class="type">)[^<]*(</p>)')


def die(code, status, msg, extra=None):
    payload = {"status": status, "message": msg}
    if extra:
        payload.update(extra)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    sys.exit(code)


def read_text(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()


def newline_of(text):
    return "\r\n" if "\r\n" in text else "\n"


def body_digest(lines):
    """第 3 行起（索引 2 之后）的内容摘要；统一用 \n 连接，避免换行差异干扰"""
    return hashlib.md5("\n".join(lines[2:]).encode("utf-8")).hexdigest()


def fmt_date(yyyymmdd):
    return "{}-{}-{}".format(yyyymmdd[:4], yyyymmdd[4:6], yyyymmdd[6:8])


def rebuild_type_line(old_type, rerun):
    """拼第 2 行：有讲次标记则保留，再追加「第 N 次重推」"""
    m = RE_LECTURE.search(old_type)
    if m:
        base = re.sub(r"\s*·\s*第\s*\d+\s*次重推\s*$", "", old_type).strip()
        return "{} · 第 {} 次重推".format(base, rerun)
    return "第 {} 次重推".format(rerun)


def cmd_carry(args):
    archive = args.archive
    src = os.path.join(archive, args.frm + ".md")
    dst = os.path.join(archive, args.to + ".md")

    if args.frm == args.to:
        die(4, "same_date", "--from 与 --to 相同：{}".format(args.frm))

    if not os.path.exists(src):
        die(1, "no_source",
            "源文件不存在：{}（调用方应改为正常渲染新文档）".format(src),
            {"archive": archive, "expected_source": src})

    text = read_text(src)
    nl = newline_of(text)
    lines = text.split(nl)

    m1 = RE_TITLE.match(lines[0] if lines else "")
    if not m1:
        die(2, "bad_title",
            "第 1 行格式无法解析，未做任何改动",
            {"line1": lines[0] if lines else ""})

    m2 = RE_TYPE.match(lines[1] if len(lines) > 1 else "")
    if not m2:
        die(2, "bad_type_line",
            "第 2 行不是「> 期次类型：…」，未做任何改动",
            {"line2": lines[1] if len(lines) > 1 else ""})

    prefix, old_date, old_weekday, issue = m1.group(1), m1.group(2), m1.group(3), m1.group(4)
    old_type = m2.group(1).strip()

    new_line1 = "{} · {}（{}）· 第 {:03d} 期".format(
        prefix, fmt_date(args.to), args.weekday, int(issue))
    new_type = rebuild_type_line(old_type, args.rerun)
    new_line2 = "> 期次类型：{}".format(new_type)

    new_lines = list(lines)
    new_lines[0] = new_line1
    new_lines[1] = new_line2

    # 写前校验：第 3 行起必须逐字节一致，行数必须一致
    src_body, dst_body = body_digest(lines), body_digest(new_lines)
    if src_body != dst_body:
        die(5, "body_changed",
            "第 3 行起内容不一致，已中止",
            {"src_body_md5": src_body, "new_body_md5": dst_body})
    if len(lines) != len(new_lines):
        die(5, "line_count_changed", "行数发生变化，已中止",
            {"before": len(lines), "after": len(new_lines)})

    payload = {
        "archive": archive,
        "source": src,
        "target": dst,
        "replaced": [
            {"line": 1, "from": lines[0], "to": new_line1},
            {"line": 2, "from": lines[1], "to": new_line2},
        ],
        "body_md5": src_body,
        "body_md5_equal": True,
        "lines": len(lines),
    }

    new_text = nl.join(new_lines)

    # 目标已存在：内容一致则视为已完成（仍清理残留源文件），否则拒绝覆盖
    if os.path.exists(dst):
        if read_text(dst) == new_text:
            removed = []
            if os.path.exists(src):
                os.remove(src)
                removed.append(src)
                log_rerun(archive, src, src_body, note="幂等清理残留源文件")
            payload.update({"status": "idempotent", "removed": removed})
            print(json.dumps(payload, ensure_ascii=False, indent=2))
            sys.exit(0)
        die(3, "target_conflict",
            "目标文件已存在且内容不同，拒绝覆盖：{}".format(dst),
            {"target": dst})

    if args.dry_run:
        payload["status"] = "dry_run"
        payload["would_remove"] = [src]
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    # 原子写入：同目录 tmp → os.replace
    tmp = dst + ".tmp"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(new_text)
    os.replace(tmp, dst)

    # 复读校验：写出的文件第 3 行起必须仍与源一致
    written_lines = read_text(dst).split(nl)
    if body_digest(written_lines) != src_body or len(written_lines) != len(lines):
        os.remove(dst)
        die(5, "verify_failed", "写入后复读校验失败，已回滚（源文件保留）",
            {"src_body_md5": src_body})

    # 最后才删旧文件
    os.remove(src)
    log_rerun(archive, src, src_body, note="滚动改名为 {}".format(os.path.basename(dst)))

    # 若有同名 HTML 阅读版，一并滚动
    html_info = carry_html(archive, args.frm, args.to, args.weekday, new_type)

    payload.update({"status": "ok", "removed": [src], "html": html_info})
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def carry_html(archive, frm, to, weekday, new_type):
    """把同名 .html 阅读版一起滚动（日期 / 星期 / 期次类型三处）。

    不存在就静默返回 absent——不是每期都有 HTML，没有不算错。
    """
    src = os.path.join(archive, frm + ".html")
    dst = os.path.join(archive, to + ".html")
    if not os.path.exists(src):
        return {"status": "absent"}

    text = read_text(src)
    before = text
    text, n_title = RE_HTML_TITLE.subn(lambda m: m.group(1) + fmt_date(to) + m.group(2), text)
    text, n_date = RE_HTML_DATE.subn(
        lambda m: m.group(1) + fmt_date(to) + " · " + weekday + m.group(3), text)
    text, n_type = RE_HTML_TYPE.subn(lambda m: m.group(1) + new_type + m.group(2), text)

    hits = {"title": n_title, "date": n_date, "type": n_type}
    if not all(hits.values()):
        return {"status": "format_mismatch", "hits": hits, "source": src,
                "message": "HTML 结构不符合 render_html.py 的约定，未改动"}
    if text == before:
        return {"status": "unchanged", "source": src}
    if os.path.exists(dst):
        return {"status": "target_exists", "target": dst, "message": "目标 HTML 已存在，未覆盖"}

    tmp = dst + ".tmp"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    os.replace(tmp, dst)
    os.remove(src)
    log_rerun(archive, src, "-", note="HTML 同步滚动为 {}".format(os.path.basename(dst)))
    return {"status": "ok", "source": src, "target": dst, "replaced": hits}


def log_rerun(archive, removed_path, body_md5, note=""):
    path = os.path.join(archive, "_rerun_log.txt")
    line = "{}\t{}\t{}\t{}\n".format(
        time.strftime("%Y-%m-%d %H:%M:%S"),
        os.path.basename(removed_path),
        body_md5,
        note,
    )
    with io.open(path, "a", encoding="utf-8", newline="\n") as f:
        f.write(line)


def cmd_dedupe(args):
    archive = args.archive
    if not os.path.isdir(archive):
        die(1, "no_archive", "归档目录不存在：{}".format(archive))

    files = []
    for name in sorted(os.listdir(archive)):
        m = RE_DOCNAME.match(name)
        if m and os.path.isfile(os.path.join(archive, name)):
            files.append((m.group(1), os.path.join(archive, name)))

    groups = {}
    for date, path in files:
        text = read_text(path)
        lines = text.split(newline_of(text))
        groups.setdefault(body_digest(lines), []).append((date, path, text))

    report = {"archive": archive, "scanned": len(files), "groups": [], "candidates": []}

    for digest, items in groups.items():
        if len(items) < 2:
            continue
        items.sort(key=lambda x: x[0])
        ids_per = [frozenset(RE_IDS.findall(t)) for _, _, t in items]
        consistent = len(set(ids_per)) == 1
        keep_date, keep_path, _ = items[-1]
        dropped = [{"date": d, "file": p} for d, p, _ in items[:-1]]
        entry = {
            "body_md5": digest,
            "count": len(items),
            "dates": [d for d, _, _ in items],
            "keep": keep_path,
            "drop": [d["file"] for d in dropped],
            "ids_consistent": consistent,
        }
        if not consistent:
            entry["warning"] = "组内正文相同但所含内容 ID 不同，跳过不动（防误删含多份材料的独有文档）"
        else:
            report["candidates"].extend(dropped)
        report["groups"].append(entry)

    if args.apply and report["candidates"]:
        dest = os.path.join(archive, "_dedupe")
        os.makedirs(dest, exist_ok=True)
        moved = []
        for item in report["candidates"]:
            target = os.path.join(dest, os.path.basename(item["file"]))
            if os.path.exists(target):
                base, ext = os.path.splitext(os.path.basename(item["file"]))
                target = os.path.join(dest, "{}_{}{}".format(base, int(time.time()), ext))
            os.rename(item["file"], target)
            moved.append({"from": item["file"], "to": target})
        report["moved"] = moved

    report["status"] = "applied" if args.apply else "report_only"
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main():
    ap = argparse.ArgumentParser(description="重推单文件滚动 / 重复文档自检")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("carry", help="把上一期文档滚动为今日日期（不复制）")
    c.add_argument("--archive", required=True, help="归档目录")
    c.add_argument("--from", dest="frm", required=True, help="源日期 YYYYMMDD（台账末行日期）")
    c.add_argument("--to", required=True, help="目标日期 YYYYMMDD（今日）")
    c.add_argument("--weekday", required=True, help="今日星期，如 周四")
    c.add_argument("--rerun", type=int, required=True, help="第 N 次重推")
    c.add_argument("--dry-run", action="store_true", help="只演算不写盘")
    c.add_argument("--json", action="store_true", help="（输出恒为 JSON，此参数保留兼容）")
    c.set_defaults(func=cmd_carry)

    d = sub.add_parser("dedupe", help="扫描同正文多文件（默认只报告）")
    d.add_argument("--archive", required=True, help="归档目录")
    d.add_argument("--apply", action="store_true", help="把多余副本移到 _dedupe/（移动，不删）")
    d.add_argument("--json", action="store_true")
    d.set_defaults(func=cmd_dedupe)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

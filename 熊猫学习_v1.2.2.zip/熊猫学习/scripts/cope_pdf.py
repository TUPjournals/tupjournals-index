#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""cope_pdf.py —— COPE guidance 类材料的 PDF 全文抓取与归档。

背景（实测）：
  discussion-document / endorsed-guidance 两类材料的网页**只有摘要**，全文以独立 PDF
  挂在页面上。抓 HTML → 提 /media/{id}/download → 下载 → pymupdf 提取。

三条硬边界（勿再试错）：
  ① WebFetch 读不了 PDF（返回 "the bytes are dropped"）
  ② 直接 Read 打开的 PDF 是压缩字节流，不是文本
  ③ COPE 对纯脚本请求 403：仅 UA → 403；UA+Referer → 403；UA + Sec-Fetch-* + Referer → 200

用法：
  python cope_pdf.py --slug <slug> --id G-006 [--outdir DIR] [--textdir DIR]
  python cope_pdf.py --url https://... --id G-006 --dump-links   # 只列候选 PDF 链接

输出：结果 JSON 走 stdout，过程日志走 stderr。
退出码：0 全部成功 / 1 部分成功 / 2 全部失败（或参数错误）
"""

import argparse
import io
import json
import os
import re
import subprocess
import sys
import tempfile

# ── 常量 ────────────────────────────────────────────────────────────────

DEFAULT_SITE = "https://publicationethics.org"

# 最小充分头集合（实测：去掉 Sec-Fetch-* 即 403）
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

SEC_HEADERS = [
    ("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"),
    ("Accept-Language", "en-US,en;q=0.9"),
    ("Sec-Fetch-Dest", "document"),
    ("Sec-Fetch-Mode", "navigate"),
    ("Sec-Fetch-Site", "same-origin"),
    ("Sec-Fetch-User", "?1"),
    ("Upgrade-Insecure-Requests", "1"),
]

WIN_BAD = r'[\\/:*?"<>|]'
TITLE_MAX = 120

MEDIA_RE = re.compile(r'href="([^"]*/media/\d+/download[^"]*)"', re.I)
PDF_DIRECT_RE = re.compile(r'href="([^"]+\.pdf(?:\?[^"]*)?)"', re.I)
SIZE_RE = re.compile(r"Download\s+PDF\s*\(([^)]*)\)", re.I)

SIZE_TOLERANCE = 0.02   # 与页面标注大小的允许偏差
MIN_TEXT_CHARS = 200    # 低于此值怀疑是图像版 PDF


def log(msg=""):
    sys.stderr.write(str(msg) + "\n")


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
    sys.exit(code)


# ── 纯函数：命名与清洗 ──────────────────────────────────────────────────

def sanitize_title(title):
    """把页面标题清洗成安全的文件名片段。

    顺序有意为之：`?` 直接删（COPE 标题多为问句，替换成 `-` 会得到 `xxx-.pdf`）；
    引号删掉；其余 Windows 结构性非法字符替换为 `-`。
    """
    s = title or ""
    s = s.replace("?", "")
    s = s.replace("'", "").replace("\u2019", "")
    s = s.replace('"', "").replace("\u201c", "").replace("\u201d", "")
    s = re.sub(WIN_BAD, "-", s)
    s = re.sub(r"\s+", " ", s).strip()
    s = s.strip(" .-")
    if len(s) > TITLE_MAX:
        s = s[:TITLE_MAX].rstrip(" .-")
    return s


def build_filename(cid, title):
    safe = sanitize_title(title) or "untitled"
    return "{} - {}.pdf".format(cid.strip(), safe) if cid else "{}.pdf".format(safe)


def unique_path(path, force=False):
    """同名冲突：默认不覆盖，加 (v2)(v3)…"""
    if force or not os.path.exists(path):
        return path
    stem, ext = os.path.splitext(path)
    n = 2
    while True:
        cand = "{} (v{}){}".format(stem, n, ext)
        if not os.path.exists(cand):
            return cand
        n += 1


def parse_size_label(label):
    """'587.51 KB' / '1.2 MB' → 近似字节数。"""
    if not label:
        return None
    m = re.search(r"([\d.]+)\s*(KB|MB|B)", label, re.I)
    if not m:
        return None
    mult = {"B": 1, "KB": 1024, "MB": 1024 * 1024}[m.group(2).upper()]
    return int(float(m.group(1)) * mult)


# ── 网络 ────────────────────────────────────────────────────────────────

def curl_get(url, referer=None, timeout=90):
    """带最小充分头的抓取。返回 (ok, code, content_type, bytes)。

    用系统 curl 而非 requests：COPE 的 403 判断对头集合敏感，
    已验证通过的组合就不要再换实现。
    """
    cmd = ["curl", "-sL", "--compressed", "--max-time", str(timeout), "-A", UA]
    for k, v in SEC_HEADERS:
        cmd += ["-H", "{}: {}".format(k, v)]
    if referer:
        cmd += ["-H", "Referer: {}".format(referer)]

    fd, tmp = tempfile.mkstemp(prefix="cope_")
    os.close(fd)
    try:
        cmd += ["-o", tmp, "-w", "%{http_code}\\n%{content_type}\\n", url]
        try:
            p = subprocess.run(cmd, capture_output=True, text=True,
                               encoding="utf-8", errors="replace")
        except FileNotFoundError:
            return False, "0", "", b"", "系统未找到 curl"
        meta = (p.stdout or "").strip().splitlines()
        code = meta[0].strip() if len(meta) > 0 else "0"
        ctype = meta[1].strip() if len(meta) > 1 else ""
        with open(tmp, "rb") as f:
            data = f.read()
        return (code == "200"), code, ctype, data, None
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def fetch_html(url, site, referer=None):
    ok, code, ctype, data, err = curl_get(url, referer=referer or site + "/guidance")
    if err:
        return None, err
    if not ok:
        return None, "HTTP {} ({})".format(code, ctype)
    return data.decode("utf-8", "ignore"), None


# ── 页面解析 ────────────────────────────────────────────────────────────

def extract_title(html):
    m = re.search(r"<title>(.*?)</title>", html, re.S | re.I)
    if not m:
        return ""
    t = re.split(r"\s*\|\s*COPE", m.group(1))[0]
    t = (t.replace("&amp;", "&").replace("&quot;", '"')
          .replace("&nbsp;", " ").replace("&#0?39;", "'").replace("&apos;", "'"))
    return re.sub(r"\s+", " ", t).strip()


def find_media_links(html):
    """收集页面所有 /media/{id}/download 链接（去重、保序）。"""
    seen, out = set(), []
    for u in MEDIA_RE.findall(html):
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def pick_best_pdf(html, site):
    """从候选链接里挑最可能是正文 PDF 的一个。

    只依赖 href 本身，不再要求与「Download PDF (KB)」文本相邻
    —— 旧实现把两者绑在一个正则里，页面结构一变就抓空。
    """
    links = find_media_links(html)
    if links:
        return _abs(links[0], site)
    m = PDF_DIRECT_RE.search(html)
    if m:
        return _abs(m.group(1), site)
    return None


def detect_page_kind(html):
    """判定该页面属于哪类，供内容分流用。

    pdf_needed  —— 页面挂了 /media 下载链接，全文在 PDF 里
    web_fulltext —— 页面本身即全文（case / position / core-principles 等）
    """
    return "pdf_needed" if find_media_links(html) else "web_fulltext"


def _abs(u, site):
    u = u.strip()
    if u.startswith("//"):
        return "https:" + u
    if u.startswith("/"):
        return site + u
    return u


def page_url_for(slug, ptype, site):
    if slug.startswith(("http://", "https://")):
        return slug
    return "{}/guidance/{}/{}".format(site, ptype, slug)


# ── PDF 提取 ────────────────────────────────────────────────────────────

def extract_text(pdf_bytes):
    """pymupdf 提取全文。返回 (text, page_count, err)。"""
    try:
        import pymupdf
    except ImportError:
        try:
            import fitz as pymupdf  # noqa
        except ImportError:
            return None, 0, ("pymupdf 未安装。请执行 pip install -r requirements.txt；"
                             "未安装期间本期只能标注「仅网页摘要」")
    try:
        doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
    except Exception as e:
        return None, 0, "无法打开 PDF：{}".format(e)
    try:
        text = "\n".join(p.get_text() for p in doc)
        n = doc.page_count
    finally:
        doc.close()
    return text, n, None


# ── 目录解析 ────────────────────────────────────────────────────────────

def load_archive_dir():
    """从 config.json 读归档目录（找不到就返回 None）。"""
    here = os.path.dirname(os.path.abspath(__file__))
    cfg_path = os.path.join(os.path.dirname(here), "config.json")
    if not os.path.exists(cfg_path):
        return None
    try:
        with io.open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        d = cfg.get("archive", {}).get("dir") or ""
        return d if d and not d.startswith("<") else None
    except Exception:
        return None


def resolve_outdir(cli_outdir, pdf_subdir="pdf"):
    """四级回落：--outdir → XBS_ARCHIVE_DIR → config.archive.dir → ./archive"""
    if cli_outdir:
        return cli_outdir
    env = os.environ.get("XBS_ARCHIVE_DIR")
    if env:
        return os.path.join(env, pdf_subdir) if pdf_subdir else env
    cfg_dir = load_archive_dir()
    if cfg_dir:
        return os.path.join(cfg_dir, pdf_subdir) if pdf_subdir else cfg_dir
    return os.path.abspath("archive")


# ── 主流程 ──────────────────────────────────────────────────────────────

def download_pdf(pdf_url, page_url):
    """下载并做三重校验。返回 (data, meta_dict, err)。"""
    ok, code, ctype, data, cerr = curl_get(pdf_url, referer=page_url)
    if cerr:
        return None, {}, cerr
    if not ok:
        return None, {"http_code": code}, "PDF 下载失败：HTTP {} ({})".format(code, ctype)
    meta = {"http_code": code, "content_type": ctype, "bytes": len(data)}
    if "pdf" not in (ctype or "").lower():
        return None, meta, "返回的不是 PDF（Content-Type={}）".format(ctype)
    if not data[:5].startswith(b"%PDF"):
        return None, meta, "文件头不是 %PDF（可能是拦截页）"
    return data, meta, None


def extract_and_archive(data, outdir, textdir, cid, title, force):
    """提取正文并落盘。返回 (meta_dict, err)。"""
    text, npages, terr = extract_text(data)
    if terr:
        return {"pages": 0}, terr

    os.makedirs(outdir, exist_ok=True)
    pdf_path = unique_path(os.path.join(outdir, build_filename(cid, title)), force)
    with open(pdf_path, "wb") as f:
        f.write(data)

    meta = {"pages": npages, "text_chars": len(text), "pdf_path": pdf_path}

    if textdir:
        os.makedirs(textdir, exist_ok=True)
        txt_path = os.path.splitext(pdf_path)[0] + ".txt"
        with io.open(txt_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        meta["txt_path"] = txt_path

    if len(text.strip()) < MIN_TEXT_CHARS:
        meta["warning"] = "提取文本过少，可能是图像版 PDF（无文字层），未强行 OCR"

    meta["has_cope_footer"] = bool(re.search(r"COPE\s+(DISCUSSION|POSITION|GUIDANCE)", text, re.I))
    return meta, None


def process_one(slug, cid, ptype, site, outdir, textdir, no_download, force):
    url = page_url_for(slug, ptype, site)
    res = {"id": cid, "slug": slug, "url": url}

    log("[1/4] 抓页面：{}".format(url))
    html, err = fetch_html(url, site)
    if html is None:
        res["error"] = "页面抓取失败：{}".format(err)
        return res

    res["html_bytes"] = len(html.encode("utf-8"))
    res["title"] = extract_title(html)
    res["page_kind"] = detect_page_kind(html)
    log("  HTML {} 字节 | 类型 {} | 标题 {}".format(
        res["html_bytes"], res["page_kind"], res["title"] or "(未取到)"))

    log("[2/4] 提取 PDF 链接")
    pdf_url = pick_best_pdf(html, site)
    res["pdf_url"] = pdf_url
    res["size_label"] = (SIZE_RE.search(html).group(1).strip()
                         if SIZE_RE.search(html) else None)

    if not pdf_url:
        res["note"] = ("页面无 PDF 链接 —— 该类型本身就是网页全文"
                       "（case / cope-position / core-principles / code-of-conduct），无需下载")
        log("  {}".format(res["note"]))
        return res

    res["size_bytes_expected"] = parse_size_label(res["size_label"])
    log("  PDF：{}（页面标注 {}）".format(pdf_url, res["size_label"] or "未标注"))

    if no_download:
        res["note"] = "dry-run：未下载"
        return res

    log("[3/4] 下载（Referer = 详情页）")
    data, meta, derr = download_pdf(pdf_url, url)
    if derr:
        res["error"] = derr
        return res
    res.update(meta)

    exp = res.get("size_bytes_expected")
    if exp:
        delta = abs(len(data) - exp) / exp
        res["size_match"] = delta < SIZE_TOLERANCE
        if not res["size_match"]:
            res["note"] = "下载大小与页面标注偏差 >2%，可能被截断"

    log("[4/4] 提取全文 + 归档")
    ameta, aerr = extract_and_archive(data, outdir, textdir, cid, res["title"], force)
    res.update(ameta)
    if aerr:
        res["error"] = aerr
    else:
        log("  {} 页 / {} 字符 → {}".format(
            ameta.get("pages"), ameta.get("text_chars"), ameta.get("pdf_path")))
    return res


def main():
    ap = argparse.ArgumentParser(description="COPE guidance PDF 全文抓取")
    ap.add_argument("--slug", help="详情页 slug，或直接给 --url")
    ap.add_argument("--url", help="详情页完整 URL（与 --slug 二选一）")
    ap.add_argument("--id", required=True, help="内容ID，如 G-006（用于文件命名）")
    ap.add_argument("--type", default="discussion-document",
                    help="页面类型段：discussion-document / endorsed-guidance / …")
    ap.add_argument("--site", default=DEFAULT_SITE, help="站点根，默认 COPE")
    ap.add_argument("--outdir", default=None, help="PDF 归档目录（缺省按四级回落）")
    ap.add_argument("--textdir", default=None, help="提取文本旁挂目录")
    ap.add_argument("--no-download", action="store_true", help="只解析不下载")
    ap.add_argument("--dump-links", action="store_true", help="只列候选 PDF 链接，不下载")
    ap.add_argument("--force", action="store_true", help="同名覆盖（默认加 (v2)）")
    args = ap.parse_args()

    if not args.slug and not args.url:
        emit({"error": "--slug 与 --url 至少给一个"}, 2)

    slug = args.url or args.slug
    outdir = resolve_outdir(args.outdir)
    textdir = args.textdir

    if args.dump_links:
        url = page_url_for(slug, args.type, args.site)
        html, err = fetch_html(url, args.site)
        if html is None:
            emit({"url": url, "error": err}, 2)
        emit({
            "url": url,
            "page_kind": detect_page_kind(html),
            "media_links": find_media_links(html),
            "picked": pick_best_pdf(html, args.site),
            "size_label": (SIZE_RE.search(html).group(1).strip()
                           if SIZE_RE.search(html) else None),
        }, 0)

    res = process_one(slug, args.id, args.type, args.site,
                      outdir, textdir, args.no_download, args.force)
    ok = not res.get("error")
    emit(res, 0 if ok else 2)


if __name__ == "__main__":
    main()

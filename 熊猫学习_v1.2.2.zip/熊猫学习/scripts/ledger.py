#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""ledger.py —— 熊猫学习台账读写（腾讯文档 / 本地 md 双后端）。

三个 sheet（两后端列结构完全一致，SCHEMA 是唯一来源）：
    progress  进度记录：日期 星期 内容ID 内容类型 内容标题 来源 状态 确认时间 备注
    recheck   待复查清单：案例编号 案例标题 记录日期 应复查日期
    index     已学案例索引：内容ID 分类 COPE链接 学习日期

口径（来自规则书，脚本只执行不解释）：
    · 进度记录记全勤，每个运行日一行；未学也写行，状态=未完成
    · 已学索引只收已确认材料，一份材料一行
    · 写前必读、写后必回读；不假设目标为空

子命令：
    schema                          打印列定义
    read    --sheet progress        读回全部行（JSON）
    append  --sheet progress        追加一行（--row-json）
    update  --sheet progress        改单元格（--cells-json）
    backlog                         末尾连续未确认计数（降频判定用）
    init   [--create]               建 3 个子表并写表头（腾讯文档后端）

退出码：0 成功 / 1 使用错误 / 2 后端故障（未写入或未读到）
"""

import argparse
import base64
import csv
import glob
import io
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
CONFIG = os.path.join(SKILL_DIR, "config.json")

SCHEMA = {
    "progress": ["日期", "星期", "内容ID", "内容类型", "内容标题", "来源", "状态", "确认时间",
                 "备注", "讲次", "文献锚点"],
    "recheck": ["案例编号", "案例标题", "记录日期", "应复查日期"],
    "index": ["内容ID", "分类", "COPE 链接", "学习日期"],
}
SHEET_TITLES = {"progress": "进度记录", "recheck": "待复查清单", "index": "已学案例索引"}
MD_SECTIONS = {"progress": "## 进度记录", "recheck": "## 待复查清单", "index": "## 已学案例索引"}


def log(msg=""):
    sys.stderr.write(str(msg) + "\n")


def is_header_row(cells, key):
    """识别表头行，兼容旧版列数（v1.2.0 起 progress 由 9 列扩到 11 列）。

    旧表头是 SCHEMA 的前缀，补齐后尾部为空；不认出来就会被当数据行重写一遍，
    造成「表头变成第一行数据」的脏账。
    """
    hdr = SCHEMA[key]
    vals = [str(c).strip() for c in cells]
    n = len(hdr)
    if vals[:n] == hdr:
        return True
    for k in range(1, n):
        if vals[:k] == hdr[:k] and not any(vals[k:]):
            return True
    return False


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
    sys.exit(code)


def load_cfg():
    if not os.path.exists(CONFIG):
        emit({"error": "config.json 不存在，请先初始化（xbs_config.py init）"}, 2)
    with io.open(CONFIG, "r", encoding="utf-8") as f:
        return json.load(f)


# ── 腾讯文档后端 ────────────────────────────────────────────────────────

def find_tdoc_script():
    pat = os.path.expanduser(
        "~/.workbuddy/plugins/cache/workbuddy-builtin/tencent-docs-plugin/*/skills/tencent-docs/tencentdocs.py")
    cands = sorted(glob.glob(pat))
    if not cands:
        pat2 = os.path.expanduser("~/.workbuddy/plugins/**/tencentdocs.py")
        cands = sorted(glob.glob(pat2, recursive=True))
    return cands[-1] if cands else None


class TdocBackend(object):
    name = "tdoc"

    def __init__(self, cfg):
        led = cfg.get("ledger", {})
        self.file_id = led.get("file_id") or ""
        self.sheets = led.get("sheets", {}) or {}
        self.script = led.get("tdoc_script") or find_tdoc_script()
        self.python = (cfg.get("runtime", {}) or {}).get("python") or sys.executable
        # 未显式给 end_row 时的读取窗口（get_cell_data 不给 end_row 只会回 1 行）
        self.batch = int(led.get("read_rows") or 60)
        if not self.script:
            raise RuntimeError("找不到 tencentdocs.py（腾讯文档连接器未安装）")
        if not self.file_id:
            raise RuntimeError("config.ledger.file_id 为空")

    def _call(self, tool, args, service="sheet-mcp"):
        env = dict(os.environ)
        # provider 下发的 api_base 域名不解析，必须覆盖为官方域名
        env["TDOC_API_BASE_URL"] = "https://docs.qq.com"
        cmd = [self.python, self.script, "tdoc_call", service, tool,
               json.dumps(args, ensure_ascii=False)]
        p = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", env=env)
        raw = (p.stdout or "").strip()
        if not raw:
            raise RuntimeError("tdoc_call 无输出：{}".format((p.stderr or "")[:400]))
        try:
            d = json.loads(raw)
        except ValueError:
            raise RuntimeError("tdoc_call 输出非 JSON：{}".format(raw[:300]))
        if "error" in d:
            raise RuntimeError("tdoc_call 错误：{}".format(d["error"]))
        res = d.get("result", {}).get("structuredContent")
        if res is None:
            raise RuntimeError("tdoc_call 无 result：{}".format(raw[:300]))
        return res

    def sheet_id(self, key):
        sid = (self.sheets or {}).get(key) or ""
        if not sid:
            raise RuntimeError("config.ledger.sheets.{} 为空".format(key))
        return sid

    def sheet_info(self):
        return self._call("get_sheet_info", {"file_id": self.file_id})

    def read_rows(self, key, start_row=0, end_row=None):
        cols = len(SCHEMA[key])
        if end_row is None:
            end_row = start_row + self.batch - 1
        args = {"file_id": self.file_id, "sheet_id": self.sheet_id(key),
                "start_row": start_row, "end_row": end_row, "start_col": 0,
                "end_col": cols - 1, "return_csv": True}
        res = self._call("get_cell_data", args)
        raw = res.get("csv_data") or ""
        rows = list(csv.reader(io.StringIO(raw))) if raw else []
        rows = [r + [""] * (cols - len(r)) for r in rows]
        # 与 MdBackend 对齐：返回值不含表头，只有数据行
        if rows and is_header_row(rows[0], key):
            rows = rows[1:]
        return rows

    def write_cells(self, key, cells):
        """cells: [{"row":int,"col":int,"value":str}, ...] 一次性写入。"""
        sid = self.sheet_id(key)
        values = [{"row": c["row"], "col": c["col"], "value_type": "STRING",
                   "string_value": c["value"]} for c in cells]
        try:
            return self._call("set_range_value",
                              {"file_id": self.file_id, "sheet_id": sid, "values": values})
        except RuntimeError as e:
            # 501 / WAF：改 value_base64 重试一次
            msg = str(e)
            if "501" not in msg and "WAF" not in msg.upper() and "blocked" not in msg.lower():
                raise
            values = [{"row": c["row"], "col": c["col"], "value_type": "STRING",
                       "value_base64": base64.b64encode(c["value"].encode("utf-8")).decode()} for c in cells]
            return self._call("set_range_value",
                              {"file_id": self.file_id, "sheet_id": sid, "values": values})

    def header_row(self, key):
        """原样读第 0 行（不清洗表头），供列迁移比对。"""
        sid = self.sheet_id(key)
        res = self._call("get_cell_data", {
            "file_id": self.file_id, "sheet_id": sid,
            "start_row": 0, "end_row": 0, "start_col": 0,
            "end_col": len(SCHEMA[key]) - 1, "return_csv": True})
        raw = res.get("csv_data") or ""
        rows = list(csv.reader(io.StringIO(raw))) if raw else []
        return [c.strip() for c in rows[0]] if rows else []

    def ensure_columns(self, key, auto_extend=True):
        """补齐新增列（v1.2.0 给 progress 加了「讲次」「文献锚点」）。

        旧表只有 9 列。做法：把缺的列名写进对应表头格 → 回读校验。
        回读仍缺则返回缺失清单，由调用方如实报错，绝不盲写数据行。
        """
        head = self.header_row(key)
        if not head:
            return []                      # 空表，init 会一次写全
        missing = [c for c in SCHEMA[key] if c not in head]
        if not missing or not auto_extend:
            return missing
        try:
            self.write_cells(key, [{"row": 0, "col": SCHEMA[key].index(c), "value": c}
                                   for c in missing])
        except Exception:
            return missing
        head2 = self.header_row(key)
        return [c for c in SCHEMA[key] if c not in head2]

    def init(self, create=True):
        """确保 3 个子表存在并写表头。返回 {key: sheet_id}。"""
        info = self.sheet_info()
        existing = {s.get("name"): s.get("id") or s.get("sheet_id")
                    for s in (info.get("sheets") or info.get("sheet_list") or [])}
        found = {}
        for key, title in SHEET_TITLES.items():
            if (self.sheets or {}).get(key):
                found[key] = self.sheets[key]
                continue
            sid = existing.get(title)
            if not sid and create:
                r = self._call("add_sheet", {"file_id": self.file_id,
                                             "name": title, "append_index": True})
                sid = r.get("sheet_id") or r.get("id")
            if sid:
                found[key] = sid
        if not found:
            raise RuntimeError("未找到或未建成任何子表；请在腾讯文档手动新建 3 个 sheet")
        # 写表头（写前必读：只有首行为空才写，避免覆盖）
        for key, sid in found.items():
            self.sheets[key] = sid
            rows = self.read_rows(key, 0, 0)
            head = rows[0] if rows else []
            if [h.strip() for h in head[:len(SCHEMA[key])]] != SCHEMA[key]:
                self.write_cells(key, [{"row": 0, "col": i, "value": v}
                                       for i, v in enumerate(SCHEMA[key])])
        return found


# ── 本地 md 后端 ────────────────────────────────────────────────────────

class MdBackend(object):
    name = "md"

    def __init__(self, cfg):
        self.path = (cfg.get("ledger", {}) or {}).get("md_path") or ""
        if not self.path or self.path.startswith("<"):
            raise RuntimeError("config.ledger.md_path 为空")
        self.path = os.path.expanduser(self.path)

    def _ensure(self):
        if os.path.exists(self.path):
            return
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        buf = ["# 熊猫学习 · 本地台账", ""]
        for key in ("progress", "recheck", "index"):
            buf.append(MD_SECTIONS[key])
            buf.append("")
            buf.append("| " + " | ".join(SCHEMA[key]) + " |")
            buf.append("|" + "|".join(["---"] * len(SCHEMA[key])) + "|")
            buf.append("")
        with io.open(self.path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(buf))

    def _split(self, text, key):
        """返回 (section_lines, start_idx, end_idx)。"""
        marker = MD_SECTIONS[key]
        i = text.find(marker)
        if i < 0:
            return None, -1, -1
        j = text.find("\n## ", i + len(marker))
        if j < 0:
            j = len(text)
        return text[i:j], i, j

    def read_rows(self, key, start_row=0, end_row=None):
        self._ensure()
        with io.open(self.path, "r", encoding="utf-8", newline="") as f:
            text = f.read().replace("\r\n", "\n")
        sec, _, _ = self._split(text, key)
        if sec is None:
            return []
        rows = []
        for ln in sec.split("\n"):
            ln = ln.strip()
            if not ln.startswith("|"):
                continue
            if re.match(r"^\|[\s\-:|]+\|$", ln):
                continue
            cells = [c.strip() for c in ln.strip("|").split("|")]
            rows.append(cells + [""] * (len(SCHEMA[key]) - len(cells)))
        if rows and is_header_row(rows[0], key):
            rows = rows[1:]
        return rows[start_row:(end_row + 1 if end_row is not None else None)]

    def ensure_columns(self, key, auto_extend=True):
        """md 后端无需补列：`_rewrite` 每次按 SCHEMA 重写表头，天然迁移。"""
        return []

    def write_cells(self, key, cells):
        """md 后端：按行合并后整段重写该 sheet 的表格。"""
        self._ensure()
        rows = self.read_rows(key)
        ncol = len(SCHEMA[key])
        for c in cells:
            r, col = c["row"], c["col"]
            # row 0 是表头，数据从 row 1 开始 → 表格数据下标 = row-1
            idx = r - 1
            while len(rows) <= idx:
                rows.append([""] * ncol)
            if 0 <= col < ncol:
                rows[idx][col] = c["value"]
        return self._rewrite(key, rows)

    def append_row(self, key, values):
        rows = self.read_rows(key)
        return self.write_cells(key, [
            {"row": len(rows) + 1, "col": i, "value": str(v)}
            for i, v in enumerate(values)
        ])

    def _rewrite(self, key, rows):
        self._ensure()
        with io.open(self.path, "r", encoding="utf-8", newline="") as f:
            text = f.read().replace("\r\n", "\n")
        sec, i, j = self._split(text, key)
        if sec is None:
            raise RuntimeError("md 台账缺少章节：{}".format(MD_SECTIONS[key]))
        ncol = len(SCHEMA[key])
        buf = [MD_SECTIONS[key], "",
               "| " + " | ".join(SCHEMA[key]) + " |",
               "|" + "|".join(["---"] * ncol) + "|"]
        for r in rows:
            safe = [str(x).replace("|", "\\|").replace("\n", " ") for x in (r + [""] * ncol)[:ncol]]
            buf.append("| " + " | ".join(safe) + " |")
        buf.append("")
        new = text[:i] + "\n".join(buf) + ("\n" + text[j:] if j < len(text) else "")
        with io.open(self.path, "w", encoding="utf-8", newline="\n") as f:
            f.write(new)
        return {"path": self.path, "rows": len(rows)}


# ── 门面 ────────────────────────────────────────────────────────────────

def backend(cfg):
    b = (cfg.get("ledger", {}) or {}).get("backend")
    if b == "tdoc":
        return TdocBackend(cfg)
    if b == "md":
        return MdBackend(cfg)
    raise RuntimeError("ledger.backend 非法：{}".format(b))


def cmd_schema(args):
    emit({"schema": SCHEMA, "sheet_titles": SHEET_TITLES}, 0)


def cmd_read(args):
    cfg = load_cfg()
    be = backend(cfg)
    rows = be.read_rows(args.sheet, 0, args.rows)
    emit({"backend": be.name, "sheet": args.sheet, "columns": SCHEMA[args.sheet],
          "rows": rows, "count": len(rows)}, 0)


def cmd_append(args):
    cfg = load_cfg()
    be = backend(cfg)
    row = json.loads(args.row_json)
    missing = be.ensure_columns(args.sheet)
    if missing:
        emit({"backend": be.name, "sheet": args.sheet, "ok": False,
              "error": "台账缺列，未写入任何数据",
              "missing": missing, "required": SCHEMA[args.sheet]}, 3)
    values = [str(row.get(c, "")) for c in SCHEMA[args.sheet]]

    rows = be.read_rows(args.sheet)
    data = [r for r in rows if any(str(x).strip() for x in r)]
    target = len(data) + 1          # 两后端的 row 0 都是表头

    if be.name == "md":
        res = be.append_row(args.sheet, values)
    else:
        res = be.write_cells(args.sheet, [{"row": target, "col": i, "value": v}
                                          for i, v in enumerate(values)])
    emit({"backend": be.name, "sheet": args.sheet, "row": target,
          "written": values, "result": res}, 0)


def cmd_update(args):
    cfg = load_cfg()
    be = backend(cfg)
    cells = json.loads(args.cells_json)
    missing = be.ensure_columns(args.sheet)
    if missing:
        emit({"backend": be.name, "sheet": args.sheet, "ok": False,
              "error": "台账缺列，未写入任何数据",
              "missing": missing, "required": SCHEMA[args.sheet]}, 3)
    res = be.write_cells(args.sheet, cells)
    emit({"backend": be.name, "sheet": args.sheet, "cells": len(cells),
          "result": res}, 0)


def cmd_backlog(args):
    """末尾连续未确认计数 —— 降频判定的唯一依据。"""
    cfg = load_cfg()
    be = backend(cfg)
    rows = be.read_rows("progress")
    data = [r for r in rows if any(str(x).strip() for x in r)]
    hdr = SCHEMA["progress"]
    ci_status = hdr.index("状态")
    ci_cid = hdr.index("内容ID")
    ci_date = hdr.index("日期")

    tail = []
    for r in reversed(data):
        if str(r[ci_status]).strip() == "未完成":
            tail.append(r)
        else:
            break
    tail.reverse()
    last_cid = str(tail[-1][ci_cid]).strip() if tail else ""
    k = sum(1 for r in tail if str(r[ci_cid]).strip() == last_cid) if tail else 0
    thr = int((cfg.get("schedule", {}) or {}).get("no_confirm_threshold") or 5)

    emit({
        "backend": be.name,
        "total_rows": len(data),
        "content_id": last_cid,
        "consecutive_unconfirmed": k,
        "threshold": thr,
        "threshold_reached": k >= thr,
        "first_date": str(tail[0][ci_date]).strip() if tail else "",
        "last_date": str(tail[-1][ci_date]).strip() if tail else "",
        "mode": (cfg.get("schedule", {}) or {}).get("mode"),
    }, 0)


def cmd_init(args):
    cfg = load_cfg()
    be = backend(cfg)
    if be.name != "tdoc":
        be._ensure()
        emit({"backend": "md", "created": be.path, "sheets": list(SCHEMA)}, 0)
    found = be.init(create=not args.no_create)
    # 回填 sheets 到 config.json
    led = cfg.setdefault("ledger", {})
    led.setdefault("sheets", {}).update(found)
    with io.open(CONFIG, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n")
    emit({"backend": "tdoc", "file_id": be.file_id, "sheets": found,
          "config_updated": CONFIG}, 0)


def main():
    ap = argparse.ArgumentParser(description="熊猫学习台账读写")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("schema")
    p.set_defaults(func=cmd_schema)

    p = sub.add_parser("read")
    p.add_argument("--sheet", choices=list(SCHEMA), required=True)
    p.add_argument("--rows", type=int, default=None, help="只读到第 N 行（0-based）")
    p.set_defaults(func=cmd_read)

    p = sub.add_parser("append")
    p.add_argument("--sheet", choices=list(SCHEMA), required=True)
    p.add_argument("--row-json", required=True, help='{"日期":"2026-11-12",...}')
    p.set_defaults(func=cmd_append)

    p = sub.add_parser("update")
    p.add_argument("--sheet", choices=list(SCHEMA), required=True)
    p.add_argument("--cells-json", required=True,
                   help='[{"row":7,"col":6,"value":"已完成"}, ...]')
    p.set_defaults(func=cmd_update)

    p = sub.add_parser("backlog")
    p.set_defaults(func=cmd_backlog)

    p = sub.add_parser("init")
    p.add_argument("--no-create", action="store_true", help="只匹配已有子表，不新建")
    p.set_defaults(func=cmd_init)

    args = ap.parse_args()
    try:
        args.func(args)
    except RuntimeError as e:
        emit({"error": str(e)}, 2)


if __name__ == "__main__":
    main()

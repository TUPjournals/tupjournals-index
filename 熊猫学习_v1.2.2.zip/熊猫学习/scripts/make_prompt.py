#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""make_prompt.py —— 生成可粘贴到「定时任务」的 prompt。

为什么要脚本生成：prompt 里出现的每个数字（阈值、篇幅、台账 ID、周期）
都必须与 config.json 完全一致。手抄一遍就会有一处不一致，而这类不一致
在跑偏之后极难发现（表现为「台账写进别人的表」「降频不触发」）。

用法：
  python make_prompt.py                    # 输出到 stdout
  python make_prompt.py --out prompt.txt
  python make_prompt.py --name "出版物伦理" # 自定义任务名（默认 熊猫学习）
"""

import argparse
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
CONFIG = os.path.join(SKILL_DIR, "config.json")

DAY_CN = {"MO": "一", "TU": "二", "WE": "三", "TH": "四", "FR": "五", "SA": "六", "SU": "日"}


def die(msg):
    sys.stderr.write("[make_prompt] " + msg + "\n")
    sys.exit(2)


def parse_rrule(s):
    """把 RRULE 转成一句中文人话。解析不了就原样回显。"""
    parts = {}
    for seg in (s or "").split(";"):
        if "=" in seg:
            k, v = seg.split("=", 1)
            parts[k.strip().upper()] = v.strip()

    freq = parts.get("FREQ", "").upper()
    hour = parts.get("BYHOUR", "")
    minute = parts.get("BYMINUTE", "0")
    hhmm = "{}:{:02d}".format(hour, int(minute)) if hour.isdigit() else ""

    if freq == "WEEKLY":
        days = [d.strip().upper() for d in parts.get("BYDAY", "").split(",") if d.strip()]
        if sorted(days) == ["FR", "MO", "TH", "TU", "WE"]:
            base = "每个工作日"
        else:
            base = "每周" + "、".join(DAY_CN.get(d, d) for d in days)
        return base + (" " + hhmm if hhmm else "")
    if freq == "DAILY":
        n = int(parts.get("INTERVAL", "1") or 1)
        base = "每天" if n == 1 else "每 {} 天".format(n)
        return base + (" " + hhmm if hhmm else "")
    if freq == "MONTHLY":
        return "每月 {} 日{}".format(parts.get("BYMONTHDAY", "?"),
                                    (" " + hhmm) if hhmm else "")
    if freq == "HOURLY":
        return "每 {} 小时".format(parts.get("INTERVAL", "1"))
    return s or "(未设置)"


def build(cfg, name):
    sch = cfg.get("schedule", {}) or {}
    led = cfg.get("ledger", {}) or {}
    con = cfg.get("content", {}) or {}
    arc = cfg.get("archive", {}) or {}

    rrule = sch.get("original_rrule", "")
    down = sch.get("downshift_rrule", "")
    thr = sch.get("no_confirm_threshold", 5)
    backend = led.get("backend", "")
    cc = con.get("case_count", 2)
    dc = con.get("doc_count", 1)
    tm = con.get("total_materials", cc + dc)
    bud = con.get("budget", {}) or {}
    hard = bud.get("hard_limit", 10000)
    target = bud.get("doc_target", 4000)
    chunk = bud.get("chunk_words", 1500)
    adir = arc.get("dir", "")

    if backend == "tdoc":
        ledger_desc = "腾讯文档（file_id={}；子表 progress={} / recheck={} / index={}）".format(
            led.get("file_id") or "<未填>",
            (led.get("sheets") or {}).get("progress") or "<未填>",
            (led.get("sheets") or {}).get("recheck") or "<未填>",
            (led.get("sheets") or {}).get("index") or "<未填>")
    else:
        ledger_desc = "本地 md（{}）".format(led.get("md_path") or "<未填>")

    return """【{marker}】{when_human} 执行一期出版伦理学习推送。

技能：熊猫学习（{skill_dir}）｜配置：{config}
当前周期：{rrule}

执行顺序（严格按 SKILL.md「工作流」）：
0. 先跑 `python scripts/xbs_config.py check`。ok=false → 只发初始化向导，本期不推送。
1. 判运行日：非工作日/法定节假日 → 静默结束（不推送、不记行、不顺延）。
2. `python scripts/ledger.py backlog` 判积压：
   ├ 有积压 → 复用既有文档、只改元信息（日期与星期、期次类型、重推次数、确认提示），
   │          正文零改动，不重抓不重译；推送该文档 + ≤5 行简报；台账新增一行（未完成）；
   │          已学索引不动；结束。
   └ 无积压 → 继续。
3. 降频检查：末尾连续未确认 ≥ {thr} 期且 mode=normal 时，用 automation_update 把本任务
   rrule 改为 `{down}`，改后回读校验；失败则如实告知「未能自动改期」。
   台账：{ledger_desc}
4. 抓内容：先看 COPE news-opinion / guidance 近 3 个月是否有新发布；取 {cc} 个案例
   （逐条进详情页读 Case number/year/Advice/主题标签，按链接去重）+ 1 份文献
   （discussion-document / endorsed-guidance 必须走 PDF 全文，不得只译摘要）。
   每期固定 {tm} 份：投喂材料占用那 1 个文献位，有投喂就不再另取主线文献。
   翻译与三表写入 content.json。
5. 渲染 + 自查（退出码非 0 禁止推送）：
   `python scripts/render_doc.py --content content.json --out "{adir}/{{YYYYMMDD}}.md"`
   `python scripts/render_html.py --content content.json --out "{adir}/{{YYYYMMDD}}.html"`
   `python scripts/purity_check.py --doc "{adir}/{{YYYYMMDD}}.md" --expect-materials {tm}`
   `python scripts/budget.py check --doc "{adir}/{{YYYYMMDD}}.md"`
   md 是权威源，html 是阅读版；html 渲染失败只如实说明，不阻断推送。
篇幅：全期 case + 文献 + 三表的中文字符与英文单词合计不得超 {hard}；budget.py 退出码
   为 2 即不得推送，必须删减后重渲。末尾术语总表与表达清单不计入。文献部分目标约
   {target} 单位。单篇超 {chunk} 英文词则按节/段截断（保语义完整），文献标题后加
   「（第 k/N 讲 · 承接上期）」，未推完的下次优先续推。
6. 推送文档正文 + ≤5 行简报；`ledger.py append` 记一行（未完成）；Advice 缺失的案例
   进 recheck 表（+6 个月）；运行细节写执行记录文件，不入学习文档。

确认口令：用户回复 `已完成 {{内容ID}}` 时（可能在任意时点），按 SKILL.md「确认到达时」归档：
本地备份 + 回读 md5 →（知识库可用时）入库并回读 media_state → 台账各行改已完成 +
索引一次性写入全部条目。归档对象取**最后一次重推**的文档。

约束：绝不编造内容；抓不到就如实说明；绝不把摘要冒充全文；台账写前必读、写后必回读；
同一参数连续失败 2 次即停手并报告。
""".format(marker=name, when_human=parse_rrule(rrule), skill_dir=SKILL_DIR,
           config=CONFIG, rrule=rrule or "(未设置)", thr=thr, down=down or "(未设置)",
           ledger_desc=ledger_desc, cc=cc, dc=dc, tm=tm, hard=hard, target=target,
           chunk=chunk, adir=adir)


def main():
    ap = argparse.ArgumentParser(description="生成定时任务 prompt")
    ap.add_argument("--name", default="熊猫学习", help="任务名（同时也是 prompt 里的定位标记）")
    ap.add_argument("--config", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    path = args.config or CONFIG
    if not os.path.exists(path):
        die("config.json 不存在：{}（请先初始化）".format(path))
    with io.open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    text = build(cfg, args.name)
    if args.out:
        with io.open(args.out, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        sys.stdout.write(json.dumps({"out": os.path.abspath(args.out),
                                     "chars": len(text)}, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()

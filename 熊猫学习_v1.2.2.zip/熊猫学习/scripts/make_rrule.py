#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""make_rrule.py —— 把「用户说的周期」转成 RRULE，并顺带算出降频用的 rrule。

为什么需要它：给用户看的问法是「每个工作日 11:30」「每周一三五 9:00」这类人话，
而 automation_update 要的是 RRULE 字符串。中间的换算以前靠手写，容易错
（BYDAY 顺序、分钟补零、24 小时制），错了之后表现为「任务到点不跑」或「跑到半夜」。

容错策略（v1.0.6 新增）
------------------------
用户常说得含糊：「早上第一件事就推」「定期推吧」。硬报错会逼人多答一轮，
所以 --human 模式下缺什么补什么，但**必须在输出里标明哪些是猜的**，
方便 agent 回一句「我按 9:00 / 每个工作日设了，要改说一声」。

  · 只说了时段没给点数（早上 / 下午 / 晚上）→ 取该时段的代表时间
  · 完全没说时间 → 09:00
  · 完全没说周期 → 每个工作日
  · 要严格模式：加 --no-default，缺什么就报错并说明缺哪项

用法：
  python make_rrule.py --human "每个工作日 11:30"
  python make_rrule.py --human "早上第一件事就推"
  python make_rrule.py --freq weekly --days MO,TU,WE,TH,FR --time 11:30
  python make_rrule.py --human "定期推吧" --no-default

输出恒为 JSON（含糊时额外带 assumed / note）：
  {"rrule": "...", "human": "每个工作日 09:00",
   "assumed": ["time"], "note": "你没说具体几点，按 09:00 设了。要改说一声。",
   "downshift_rrule": "...", "downshift_human": "每 3 天 09:00"}
"""

import argparse
import json
import re
import sys

DAY_MAP = {"MO": "一", "TU": "二", "WE": "三", "TH": "四", "FR": "五", "SA": "六", "SU": "日"}
CN_DAY = {"一": "MO", "二": "TU", "三": "WE", "四": "TH", "五": "FR", "六": "SA", "日": "SU", "天": "SU"}
WEEKDAY_ORDER = ["MO", "TU", "WE", "TH", "FR"]

DOWN_INTERVAL = 3          # 降频周期：每 3 天
DEFAULT_TIME = (9, 0)      # 完全没说时间时用 9:00
# 只说了时段、没给点数时，按习惯取代表时间
PERIOD_DEFAULTS = {
    "早上": (9, 0), "早晨": (9, 0), "上午": (9, 0), "一早": (9, 0),
    "中午": (12, 0),
    "下午": (15, 0),
    "傍晚": (18, 0),
    "晚上": (20, 0), "夜里": (21, 0),
}


def die(msg):
    sys.stderr.write("[make_rrule] " + msg + "\n")
    sys.exit(2)


def parse_time(s):
    """解析明确的时间，返回 (hour, minute)。支持 11:30 / 11点 / 9点半 / 下午3点。"""
    s = (s or "").strip().replace("：", ":")
    if not s:
        die("内部错误：parse_time 收到空串")

    pm = s.startswith(("下午", "晚上", "傍晚", "夜里"))
    am = s.startswith(("上午", "早上", "早晨", "一早"))
    s = re.sub(r"^(上午|早上|早晨|下午|晚上|傍晚|夜里|中午|一早)", "", s)

    m = re.match(r"^(\d{1,2}):(\d{1,2})$", s)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
    else:
        m = re.match(r"^(\d{1,2})\s*[点時时]\s*(半|(\d{1,2})\s*分?)?$", s)
        if not m:
            die("看不懂时间：{!r}（可用 11:30 / 11点 / 9点半 / 下午3点）".format(s))
        h = int(m.group(1))
        mi = 30 if m.group(2) == "半" else (int(m.group(3)) if m.group(3) else 0)

    if pm and h < 12:
        h += 12
    if am and h == 12:
        h = 0
    if not (0 <= h <= 23 and 0 <= mi <= 59):
        die("时间超出范围：{:02d}:{:02d}".format(h, mi))
    return h, mi


def parse_days(s):
    """解析星期：MO,TU / 一三五 / 周一、周三 / 周一至周五"""
    s = (s or "").strip()
    if not s:
        return []

    codes = [p.strip().upper() for p in s.split(",") if p.strip()]
    if codes and all(c in DAY_MAP for c in codes):
        return [d for d in ["MO", "TU", "WE", "TH", "FR", "SA", "SU"] if d in codes]

    m = re.search(r"([一二三四五六日天])\s*(?:至|到|-|~)\s*([一二三四五六日天])", s)
    if m:
        order = "一二三四五六日"
        a, b = order.index(m.group(1)), order.index(m.group(2))
        if a <= b:
            return [CN_DAY[c] for c in order[a:b + 1]]
        return [CN_DAY[c] for c in order[b:a + 1]][::-1]

    found = [CN_DAY[c] for c in re.findall(r"[一二三四五六日天]", s) if c in CN_DAY]
    if found:
        return [d for d in ["MO", "TU", "WE", "TH", "FR", "SA", "SU"] if d in found]
    return []


def humanize_weekly(days, hour, minute):
    if sorted(days) == sorted(WEEKDAY_ORDER):
        base = "每个工作日"
    else:
        base = "每周" + "、".join(DAY_MAP[d] for d in days)
    return "{} {:02d}:{:02d}".format(base, hour, minute)


def build(freq, days, hour, minute, interval=1):
    hm = "BYHOUR={};BYMINUTE={}".format(hour, minute)
    if freq == "weekly":
        days = days or WEEKDAY_ORDER
        return ("FREQ=WEEKLY;BYDAY={};{}".format(",".join(days), hm),
                humanize_weekly(days, hour, minute))
    if freq == "daily":
        if interval and int(interval) > 1:
            return ("FREQ=DAILY;INTERVAL={};{}".format(int(interval), hm),
                    "每 {} 天 {:02d}:{:02d}".format(int(interval), hour, minute))
        return ("FREQ=DAILY;{}".format(hm), "每天 {:02d}:{:02d}".format(hour, minute))
    die("--freq 只支持 weekly / daily")


def extract_time(text, strict):
    """取时间。返回 (hour, minute, assumed)；assumed=True 表示用了默认值。"""
    # 1) 带数字的时间
    mt = re.search(r"(上午|早上|早晨|下午|晚上|傍晚|夜里|中午|一早)?\s*"
                   r"(\d{1,2}\s*[:：]\s*\d{1,2}|\d{1,2}\s*[点時时]\s*(?:半|\d{1,2}\s*分?)?)", text)
    if mt:
        h, mi = parse_time((mt.group(1) or "") + mt.group(2))
        return h, mi, False

    # 2) 只有时段词（早上 / 下午 / 晚上…）
    for word, (h, mi) in PERIOD_DEFAULTS.items():
        if word in text:
            return h, mi, True

    # 3) 什么都没有
    if strict:
        die("这句话里找不到时间：{!r}（补一句几点，或去掉 --no-default 让我按 9:00 设）".format(text))
    return DEFAULT_TIME[0], DEFAULT_TIME[1], True


def extract_freq(text, hour, minute, strict):
    """取周期。返回 (rrule, human, assumed)"""
    if re.search(r"工作日|上班日|周一至周五|周一到周五|星期一到星期五", text):
        r, h = build("weekly", WEEKDAY_ORDER, hour, minute)
        return r, h, False

    m = re.search(r"每\s*(\d+)\s*天", text)
    if m:
        r, h = build("daily", [], hour, minute, int(m.group(1)))
        return r, h, False

    if re.search(r"每天|每日|天天", text):
        r, h = build("daily", [], hour, minute)
        return r, h, False

    if re.search(r"每周|每星期|每礼拜|周[一二三四五六日天]|星期[一二三四五六日天]", text):
        days = parse_days(text)
        if days:
            r, h = build("weekly", days, hour, minute)
            return r, h, False

    if strict:
        die("这句话里找不到周期：{!r}（说「每个工作日」「每周一三五」「每天」或「每 N 天」；"
            "去掉 --no-default 则默认按每个工作日）".format(text))

    r, h = build("weekly", WEEKDAY_ORDER, hour, minute)
    return r, h, True


def from_human(text, strict=False):
    t = (text or "").strip()
    if not t:
        die("--human 为空")

    hour, minute, t_assumed = extract_time(t, strict)
    rrule, human, f_assumed = extract_freq(t, hour, minute, strict)

    assumed, notes = [], []
    if t_assumed:
        assumed.append("time")
        notes.append("你没说具体几点，按 {:02d}:{:02d} 设了".format(hour, minute))
    if f_assumed:
        assumed.append("freq")
        notes.append("没说周期，按每个工作日算")

    note = ("；".join(notes) + "。要改说一声。") if notes else ""
    return rrule, human, assumed, note


def main():
    ap = argparse.ArgumentParser(description="生成定时任务用的 RRULE")
    ap.add_argument("--human", help="人话周期，如「每个工作日 11:30」「早上推」")
    ap.add_argument("--freq", choices=["weekly", "daily"])
    ap.add_argument("--days", help="星期，如 MO,TU,WE 或 一三五")
    ap.add_argument("--time", help="时间，如 11:30 / 9点 / 下午3点")
    ap.add_argument("--interval", type=int, default=1, help="daily 时的间隔天数")
    ap.add_argument("--down-interval", type=int, default=DOWN_INTERVAL, help="降频间隔，默认 3 天")
    ap.add_argument("--no-downshift", action="store_true", help="不输出降频 rrule")
    ap.add_argument("--no-default", action="store_true",
                    help="严格模式：缺时间或周期就报错，不做默认值兜底")
    args = ap.parse_args()

    if args.human:
        rrule, human, assumed, note = from_human(args.human, strict=args.no_default)
    else:
        if not args.freq:
            die("要么给 --human，要么给 --freq + --time")
        if not args.time:
            die("结构化模式必须给 --time（想让我猜 9:00 就用 --human）")
        hour, minute = parse_time(args.time)
        days = parse_days(args.days) if args.days else []
        rrule, human = build(args.freq, days, hour, minute, args.interval)
        assumed, note = [], ""

    out = {"rrule": rrule, "human": human}
    if assumed:
        out["assumed"] = assumed
        out["note"] = note

    if not args.no_downshift:
        mh = re.search(r"BYHOUR=(\d+)", rrule)
        mm = re.search(r"BYMINUTE=(\d+)", rrule)
        if mh and mm:
            h, mi = int(mh.group(1)), int(mm.group(1))
            out["downshift_rrule"] = "FREQ=DAILY;INTERVAL={};BYHOUR={};BYMINUTE={}".format(
                args.down_interval, h, mi)
            out["downshift_human"] = "每 {} 天 {:02d}:{:02d}".format(args.down_interval, h, mi)

    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

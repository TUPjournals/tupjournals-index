#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""render_doc.py —— 把 content.json 渲染成一期学习文档。

分工：**内容由人/AI 写，骨架由脚本拼**。脚本不生成任何一句译文，
只负责「顺序、表头、编号、汇总」这些机械活，避免每期手抄出错。

input（content.json）：
{
  "date": "2026-11-12", "weekday": "周四", "issue": 3,
  "issue_type": "新内容" | "第 29 次重推" | "第 2/3 讲 承接上期",
  "materials": [
    { "kind": "opening"|"case"|"doc",
      "id": "G-004", "title": "Core Principles", "year": 2026,
      "topics": "—", "url": "https://...",
      "note": "类型说明，可空",
      "blocks": [ {"label": "原文（Intro）", "body": "..."} ],
      "questions": [ {"en": "...", "zh": "..."} ],
      "advice": {"published": true, "en": "...", "zh": "..."},
      "followup": {"en": "...", "zh": "..."},
      "terms": [ {"en": "...", "zh": "...", "note": "..."} ],
      "collocations": [ {"en": "...", "zh": "...", "usage": "..."} ],
      "patterns": [ {"skeleton": "...", "zh": "...", "slots": "..."} ] }
  ],
  "confirm_id": "G-004"
}

用法：
  python render_doc.py --content content.json --out ../20261112.md
  python render_doc.py --content c.json --stdout
"""

import argparse
import io
import json
import os
import sys

import skill_meta

DEFAULT_PREFIX = "出版伦理每日学习"

KIND_HEAD = {"opening": "开篇文献", "case": "Case", "doc": "今日文献"}


def die(msg):
    sys.stderr.write("[render] " + msg + "\n")
    sys.exit(2)


def esc(s):
    return str(s if s is not None else "").replace("\r\n", "\n").strip()


def quote_block(text, indent=""):
    """把多段文本转成 markdown 引用块（空行仍保留 `>`）。"""
    out = []
    for ln in esc(text).split("\n"):
        out.append(("> " + ln).rstrip() if ln.strip() else ">")
    return "\n".join(out)


def table(headers, rows):
    buf = ["| " + " | ".join(headers) + " |",
           "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        buf.append("| " + " | ".join(str(c).replace("|", "\\|") for c in r) + " |")
    return "\n".join(buf)


def render_material(m, idx, case_no):
    kind = m.get("kind")
    if kind not in KIND_HEAD:
        die("材料 kind 非法：{}（应为 opening / case / doc）".format(kind))

    if kind == "case":
        head = "## {} {} · {}".format(KIND_HEAD[kind], case_no, esc(m.get("title")))
    elif kind == "opening":
        head = "## {} · {} · {}".format(KIND_HEAD[kind], esc(m.get("title")), esc(m.get("id")))
    else:
        t = esc(m.get("note")) or "文献"
        head = "## {} · {} · {}".format(KIND_HEAD[kind], t, esc(m.get("title")))

    # 分讲标记由 lecture_index / lecture_total 机械生成，不靠手写字符串
    li, lt = m.get("lecture_index"), m.get("lecture_total")
    if kind in ("doc", "opening") and isinstance(lt, int) and lt > 1:
        k = int(li or 1)
        head += "（第 {}/{} 讲{}）".format(k, lt, " · 承接上期" if k > 1 else "")

    buf = [head, ""]

    if kind == "case":
        buf.append("- **COPE 编号**：{} ｜ **年份**：{}".format(
            esc(m.get("id")), esc(m.get("year"))))
    else:
        meta = []
        if m.get("id"):
            meta.append("**编号**：{}".format(esc(m.get("id"))))
        if m.get("note") and kind == "opening":
            meta.append("**类型**：{}".format(esc(m.get("note"))))
        if m.get("year"):
            meta.append("**年份/版本**：{}".format(esc(m.get("year"))))
        if meta:
            buf.append("- " + " ｜ ".join(meta))
    buf.append("- **主题分类**：{}".format(esc(m.get("topics")) or "—"))
    if m.get("url"):
        buf.append("- **链接**：{}".format(esc(m.get("url"))))
    buf.append("")

    for b in m.get("blocks") or []:
        buf.append("### {}".format(esc(b.get("label"))))
        buf.append("")
        buf.append(quote_block(b.get("body")))
        buf.append("")

    qs = m.get("questions") or []
    if qs:
        buf.append("### 案例提出的问题（Questions）")
        buf.append("")
        for i, q in enumerate(qs, 1):
            buf.append("{}. {}".format(i, esc(q.get("en"))))
            buf.append("   → {}".format(esc(q.get("zh"))))
        buf.append("")

    adv = m.get("advice")
    if adv:
        buf.append("### COPE 官方建议（Advice）")
        buf.append("")
        if adv.get("published"):
            if adv.get("en"):
                buf.append(quote_block(adv.get("en")))
                buf.append("")
            if adv.get("zh"):
                buf.append("**中文翻译**")
                buf.append("")
                buf.append(quote_block(adv.get("zh")))
                buf.append("")
        else:
            buf.append("⚠️ COPE 尚未发布建议（Advice pending）。")
            buf.append("")

    fu = m.get("followup")
    if fu and (fu.get("en") or fu.get("zh")):
        buf.append("**后续进展（What happened next）**")
        buf.append("")
        if fu.get("en"):
            buf.append(quote_block(fu.get("en")))
        if fu.get("zh"):
            buf.append("")
            buf.append("> 中文：" + esc(fu.get("zh")).replace("\n", " "))
        buf.append("")

    terms = m.get("terms") or []
    cols = m.get("collocations") or []
    pats = m.get("patterns") or []

    if terms:
        buf.append("### 术语表")
        buf.append("")
        buf.append(table(["英文术语", "中文", "释义"],
                         [[esc(t.get("en")), esc(t.get("zh")), esc(t.get("note"))] for t in terms]))
        buf.append("")
    if cols:
        buf.append("### 固定搭配")
        buf.append("")
        buf.append(table(["英文搭配", "中文", "用法说明"],
                         [[esc(c.get("en")), esc(c.get("zh")), esc(c.get("usage"))] for c in cols]))
        buf.append("")
    if pats:
        buf.append("### 典型句式")
        buf.append("")
        for p in pats:
            buf.append("- `{}` → {} ｜ 可替换成分：{}".format(
                esc(p.get("skeleton")), esc(p.get("zh")), esc(p.get("slots"))))
        buf.append("")

    buf.append("---")
    buf.append("")
    return buf


UNITS_PLACEHOLDER = "篇幅约 \u2014 字"


def fmt_units(n):
    return "{:,}".format(n)


def measure(text):
    """返回全期字数（口径见 budget.py）。取不到则返回 None，头部不写篇幅。"""
    try:
        import budget as _b
        return _b.analyze_text(text)["total"]
    except Exception:
        return None


def render(content, prefix=DEFAULT_PREFIX):
    mats = content.get("materials") or []
    if not mats:
        die("content.materials 为空")

    d = esc(content.get("date"))
    if not d:
        die("content.date 必填（YYYY-MM-DD）")

    buf = []
    buf.append("# {} · {}（{}）· 第 {:03d} 期".format(
        prefix, d, esc(content.get("weekday")), int(content.get("issue") or 1)))
    buf.append("> 期次类型：{}".format(esc(content.get("issue_type")) or "新内容"))
    n_case = sum(1 for m in mats if m.get("kind") == "case")
    n_doc = sum(1 for m in mats if m.get("kind") in ("doc", "opening"))
    buf.append("> 本期含：Case {} 篇 ｜ 文献 {} 篇 · {} · {}".format(
        n_case, n_doc, UNITS_PLACEHOLDER, skill_meta.generator_line()))
    buf.append("> " + skill_meta.DISCLAIMER)
    buf.append("")
    buf.append("---")
    buf.append("")

    case_no = 0
    for m in mats:
        if m.get("kind") == "case":
            case_no += 1
        buf.extend(render_material(m, None, case_no))

    # 术语总表
    rows = []
    for m in mats:
        tag = esc(m.get("id")) or esc(m.get("title"))
        for t in (m.get("terms") or []):
            rows.append([esc(t.get("en")), esc(t.get("zh")), tag])
    buf.append("## 今日术语总表（{} 条）".format(len(rows)))
    buf.append("")
    if rows:
        buf.append(table(["#", "英文", "中文", "出处"],
                         [[i, r[0], r[1], r[2]] for i, r in enumerate(rows, 1)]))
    buf.append("")

    # 表达清单
    erows = []
    for m in mats:
        for c in (m.get("collocations") or []):
            erows.append([esc(c.get("en")), esc(c.get("zh")), "搭配"])
        for p in (m.get("patterns") or []):
            erows.append([esc(p.get("skeleton")), esc(p.get("zh")), "句式"])
    buf.append("## 今日表达清单（{} 条）".format(len(erows)))
    buf.append("")
    if erows:
        buf.append(table(["#", "英文表达", "中文", "类型"],
                         [[i] + r for i, r in enumerate(erows, 1)]))
    buf.append("")
    buf.append("---")
    buf.append("")
    buf.append("## 确认方式")
    buf.append("")
    buf.append("请回复：`已完成 {}`".format(esc(content.get("confirm_id"))))
    buf.append("")

    text = "\n".join(buf)
    # 头部不计入预算 → 回填篇幅不会改变篇幅本身，无循环依赖
    units = measure(text)
    if units is None:
        text = text.replace(" · " + UNITS_PLACEHOLDER, "")
    else:
        text = text.replace(UNITS_PLACEHOLDER, "篇幅约 {} 字".format(fmt_units(units)))
    return text


def main():
    ap = argparse.ArgumentParser(description="渲染一期学习文档")
    ap.add_argument("--content", required=True)
    ap.add_argument("--out", help="输出路径；不给则配合 --stdout")
    ap.add_argument("--stdout", action="store_true")
    ap.add_argument("--prefix", default=None, help="标题前缀（默认取 config，其次内置值）")
    args = ap.parse_args()

    if not os.path.exists(args.content):
        die("找不到 content 文件：{}".format(args.content))
    with io.open(args.content, "r", encoding="utf-8") as f:
        content = json.load(f)

    prefix = args.prefix or DEFAULT_PREFIX
    if not args.prefix:
        cfg_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "config.json")
        if os.path.exists(cfg_path):
            try:
                with io.open(cfg_path, "r", encoding="utf-8") as f:
                    prefix = json.load(f).get("doc", {}).get("title_prefix") or prefix
            except Exception:
                pass

    text = render(content, prefix)

    if args.stdout or not args.out:
        sys.stdout.write(text)
        return
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    with io.open(args.out, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    sys.stdout.write(json.dumps({"out": os.path.abspath(args.out),
                                 "bytes": len(text.encode("utf-8")),
                                 "units": measure(text),
                                 "materials": len(content.get("materials") or [])},
                                ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()

#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""render_html.py —— 把 content.json 渲染成一期学习文档的 HTML 阅读版。

与 render_doc.py 的分工：
  render_doc.py   →  .md   给 agent 读、给归档与知识库用（权威源）
  render_html.py  →  .html 给人读（排版、原文/译文分区、导航）

两者吃同一份 content.json，**内容不各写一遍**——否则迟早不一致。
脚本只拼骨架：CSS、分区、编号、汇总；不生成任何一句译文。

用法：
  python render_html.py --content content.json --out ../20261112.html

与 md 版同时存在时的约定：
  归档目录里 {YYYYMMDD}.md 与 {YYYYMMDD}.html 同名不同后缀，一份内容两个视图。
  重推时由 carry_forward.py 一并滚动（.html 的日期/期次类型同样会更新）。
"""

import argparse
import html
import io
import json
import os
import re
import sys

import skill_meta

DEFAULT_PREFIX = "出版伦理每日学习"

KIND_LABEL = {"opening": "开篇文献", "case": "Case", "doc": "今日文献"}

# 判断 block 是译文还是原文：标签里带这些词即视为译文
ZH_HINTS = ("中文", "译文", "翻译")

CSS = """
:root{
  --ink:#0f172a; --ink2:#475569; --muted:#94a3b8;
  --line:#e6ebf1; --soft:#f8fafc;
  --teal:#0d9488; --teal-d:#0f766e; --teal-soft:#f0fdfa; --teal-line:#99f6e4;
  --quote-bg:#f7f9fb; --quote-line:#cbd5e1;
  --amber:#b45309; --amber-bg:#fffbeb; --amber-line:#fde68a;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{
  margin:0;background:#fff;color:var(--ink);
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;
  font-size:15px;line-height:1.9;-webkit-font-smoothing:antialiased;
}
.wrap{display:grid;grid-template-columns:250px minmax(0,1fr);max-width:1180px;margin:0 auto}
.side{position:sticky;top:0;height:100vh;padding:40px 20px 24px 28px;
  border-right:1px solid var(--line);display:flex;flex-direction:column}
.issue{margin-bottom:26px}
.badge{display:inline-block;font-size:11.5px;letter-spacing:.06em;
  background:var(--teal-soft);color:var(--teal-d);border:1px solid var(--teal-line);
  padding:2px 9px;border-radius:999px;font-weight:600;margin-bottom:10px}
.issue h1{font-size:17px;line-height:1.5;margin:0 0 6px;letter-spacing:-.01em}
.issue .date{font-size:12.5px;color:var(--ink2);margin:0}
.issue .type{font-size:12px;color:var(--teal-d);margin:3px 0 0;font-weight:500}
.issue .sub{font-size:12px;color:var(--muted);margin:2px 0 0}
nav{flex:1;overflow-y:auto;margin:0 -6px}
nav a{display:block;padding:6px 10px;margin:1px 0;border-radius:7px;
  color:var(--ink2);text-decoration:none;font-size:13px;
  border-left:2px solid transparent;transition:.15s}
nav a:hover{background:var(--soft);color:var(--teal-d)}
nav a.active{background:var(--teal-soft);color:var(--teal-d);border-left-color:var(--teal);font-weight:600}
nav a.grp{margin-top:14px;color:var(--muted);font-size:11.5px;letter-spacing:.05em;pointer-events:none;border:none}
.side-foot{border-top:1px solid var(--line);padding-top:12px;font-size:11.5px;color:var(--muted);line-height:1.7}
main{padding:52px 56px 120px;max-width:790px}
.mat{margin-bottom:64px;scroll-margin-top:16px}
.mat-head{margin-bottom:26px;padding-bottom:18px;border-bottom:1px solid var(--line)}
.kind{display:inline-block;font-size:11.5px;font-weight:600;letter-spacing:.05em;
  color:var(--teal-d);background:var(--teal-soft);border:1px solid var(--teal-line);
  padding:2px 9px;border-radius:5px;margin-bottom:10px}
.mat h2{font-size:24px;line-height:1.45;margin:0 0 12px;letter-spacing:-.02em}
.chips{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:10px}
.chip{font-size:12px;color:var(--ink2);background:var(--soft);
  border:1px solid var(--line);padding:2px 9px;border-radius:6px}
.chip.id{color:var(--teal-d);border-color:var(--teal-line);background:var(--teal-soft);font-weight:600}
.chip.none{color:var(--muted)}
.link{font-size:12.5px;color:var(--ink2);text-decoration:none;word-break:break-all}
.link:hover{color:var(--teal-d);text-decoration:underline}
h3{font-size:14px;font-weight:700;margin:32px 0 12px;color:var(--ink);
  display:flex;align-items:center;gap:8px}
h3::before{content:"";width:3px;height:13px;border-radius:2px;background:var(--teal);display:inline-block}
p{margin:0 0 13px;color:var(--ink2)}
blockquote{margin:0 0 18px;padding:14px 20px;border-radius:0 9px 9px 0;font-size:14px;line-height:1.85}
blockquote.en{background:var(--quote-bg);border-left:3px solid var(--quote-line);color:#334155;
  font-family:Georgia,"Times New Roman","Songti SC",serif}
blockquote.zh{background:#fff;border-left:3px solid var(--teal);color:var(--ink2);padding-left:18px}
blockquote p{margin:0 0 10px;color:inherit;font-size:inherit}
blockquote p:last-child{margin-bottom:0}
blockquote strong{color:var(--ink);font-weight:600}
blockquote.en strong{color:var(--teal-d)}
.disclaimer{font-size:12.5px;color:var(--muted);font-style:italic;
  padding:8px 0 8px 18px;border-left:2px solid var(--line);margin-bottom:14px}
.pending{background:var(--amber-bg);border:1px solid var(--amber-line);border-radius:9px;
  padding:12px 16px;color:var(--amber);font-size:13.5px;margin-bottom:18px}
ol.q{margin:0 0 16px;padding-left:22px;color:var(--ink2);font-size:14px}
ol.q li{margin:6px 0}
ol.q li em{display:block;color:var(--ink2);font-style:normal;font-size:13.5px;margin-top:3px}
table{width:100%;border-collapse:separate;border-spacing:0;margin:0 0 20px;font-size:13px;
  border:1px solid var(--line);border-radius:9px;overflow:hidden}
th{background:var(--soft);text-align:left;font-weight:600;color:var(--ink);
  padding:8px 13px;border-bottom:1px solid var(--line);font-size:12.5px;white-space:nowrap}
td{padding:8px 13px;border-bottom:1px solid var(--line);color:var(--ink2);vertical-align:top;line-height:1.7}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover{background:#fbfdfd}
td:first-child{color:var(--ink);font-weight:500}
code{background:var(--soft);border:1px solid var(--line);border-radius:4px;
  padding:1px 5px;font-size:12.5px;color:var(--teal-d);
  font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
ul.pat{list-style:none;padding:0;margin:0 0 20px}
ul.pat li{padding:12px 15px;margin-bottom:8px;border:1px solid var(--line);
  border-radius:9px;background:#fff;transition:.15s}
ul.pat li:hover{border-color:var(--teal-line);background:#fdfffe}
ul.pat code{display:inline;font-size:12.8px;color:#1e3a4c;background:#f4f7f9;
  border-color:#e2e8f0;padding:3px 7px;line-height:1.7}
ul.pat .use{display:block;font-size:13px;color:var(--ink2);margin-top:7px}
ul.pat .slots{display:block;font-size:12.5px;color:var(--muted);margin-top:4px}
ul.pat .slots b{color:var(--ink2);font-weight:500}
.sum{margin-bottom:56px;scroll-margin-top:16px}
.sum h2{font-size:20px;margin:0 0 6px;letter-spacing:-.01em;display:flex;align-items:baseline;gap:9px}
.sum h2 .cnt{font-size:12px;color:var(--muted);font-weight:400}
.sum .hint{font-size:13px;color:var(--muted);margin:0 0 18px}
.confirm{background:var(--teal-soft);border:1px solid var(--teal-line);border-radius:12px;padding:22px 26px;margin-top:8px}
.confirm h2{font-size:17px;margin:0 0 10px}
.confirm p{margin:0 0 12px;color:var(--teal-d);font-size:14px}
.confirm kbd{display:inline-block;background:#fff;border:1px solid var(--teal-line);
  border-radius:8px;padding:8px 16px;font-size:15px;font-weight:600;color:var(--teal-d);
  font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
@media (max-width:880px){
  .wrap{grid-template-columns:1fr}
  .side{position:static;height:auto;border-right:none;border-bottom:1px solid var(--line);padding:24px 20px 16px}
  .issue{margin-bottom:16px}
  nav{display:flex;flex-wrap:wrap;gap:6px;overflow:visible}
  nav a{border:1px solid var(--line);border-radius:999px;padding:3px 11px;font-size:12px;margin:0}
  nav a.active{border-color:var(--teal)}
  nav a.grp{display:none}
  .side-foot{display:none}
  main{padding:30px 20px 80px;max-width:none}
  .mat h2{font-size:20px}
  table{font-size:12.3px}
  th,td{padding:7px 10px}
}
@media print{
  .side{display:none}
  .wrap{grid-template-columns:1fr;max-width:none}
  main{padding:0;max-width:none}
  .mat{page-break-inside:avoid}
  blockquote{background:#fafafa}
}
"""


def die(msg):
    sys.stderr.write("[render_html] " + msg + "\n")
    sys.exit(2)


def esc(s):
    return html.escape(str(s if s is not None else "").replace("\r\n", "\n").strip(), quote=False)


def inline(text):
    """行内 markdown → HTML：先转义，再处理 **粗体** 与 `代码`。"""
    t = esc(text)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t, flags=re.S)
    t = re.sub(r"`([^`]+?)`", r"<code>\1</code>", t)
    return t


def body_html(text):
    """多段文本 → 段落序列；段内换行转 <br>。"""
    parts = [p for p in esc(text).split("\n\n") if p.strip()]
    out = []
    for p in parts:
        lines = [inline(ln) if "**" in p or "`" in p else ln for ln in p.split("\n")]
        # 上面 inline 已对整段做过一次，这里只需处理换行
        cur = inline(p).split("\n")
        out.append("<p>" + "<br>".join(cur) + "</p>")
    return "\n".join(out)


def is_zh(label):
    return any(h in (label or "") for h in ZH_HINTS)


def chips(m):
    parts = []
    if m.get("id"):
        parts.append('<span class="chip id">{}</span>'.format(esc(m.get("id"))))
    if m.get("year"):
        parts.append('<span class="chip">{}</span>'.format(esc(m.get("year"))))
    topics = [t.strip() for t in str(m.get("topics") or "").split("/") if t.strip()]
    if topics and topics[0] not in ("—", "-"):
        for t in topics:
            parts.append('<span class="chip">{}</span>'.format(esc(t)))
    elif m.get("kind") != "case":
        parts.append('<span class="chip none">无主题标签</span>')
    return "".join(parts)


def _lecture_txt(m):
    """分讲标记（与 .md 同源）。单讲或非文献返回空串。"""
    li, lt = m.get("lecture_index"), m.get("lecture_total")
    if m.get("kind") in ("doc", "opening") and isinstance(lt, int) and lt > 1:
        k = int(li or 1)
        return "（第 {}/{} 讲{}）".format(k, lt, " · 承接上期" if k > 1 else "")
    return ""


def render_material(m, case_no):
    kind = m.get("kind")
    if kind not in KIND_LABEL:
        die("材料 kind 非法：{}".format(kind))

    if kind == "case":
        kind_text = "Case {}".format(case_no)
        title = esc(m.get("title"))
    elif kind == "opening":
        kind_text = KIND_LABEL[kind]
        title = esc(m.get("title"))
    else:
        kind_text = KIND_LABEL[kind]
        if m.get("note"):
            kind_text += " · " + esc(m.get("note"))
        title = esc(m.get("title"))

    # 分讲标记与 .md 同源：由 lecture_index / lecture_total 机械生成
    lecture_txt = _lecture_txt(m)
    if lecture_txt:
        title += lecture_txt

    buf = ['<article class="mat" id="m{}">'.format(case_no if kind == "case" else "x" + str(id(m))[-4:]),
           '  <div class="mat-head">',
           '    <span class="kind">{}</span>'.format(kind_text),
           '    <h2>{}</h2>'.format(title),
           '    <div class="chips">{}</div>'.format(chips(m))]
    if m.get("url"):
        buf.append('    <a class="link" href="{0}">{1}</a>'.format(
            esc(m.get("url")), esc(m.get("url")).replace("https://", "").replace("http://", "")))
    buf.append("  </div>")

    # 原文 / 译文块
    for b in m.get("blocks") or []:
        label = b.get("label") or ""
        cls = "zh" if is_zh(label) else "en"
        buf.append("  <h3>{}</h3>".format(inline(label)))
        buf.append('  <blockquote class="{}">'.format(cls))
        buf.append(body_html(b.get("body")))
        buf.append("  </blockquote>")

    # 问题
    qs = m.get("questions") or []
    if qs:
        buf.append("  <h3>案例提出的问题 · Questions</h3>")
        buf.append('  <ol class="q">')
        for q in qs:
            buf.append("    <li>{}<em>{}</em></li>".format(inline(q.get("en")), inline(q.get("zh"))))
        buf.append("  </ol>")

    # 官方建议
    adv = m.get("advice")
    if adv:
        buf.append("  <h3>COPE 官方建议 · Advice</h3>")
        if adv.get("published"):
            buf.append('  <p class="disclaimer">Advice from COPE Members: Advice on this case is '
                       'from COPE Members and COPE Council Members. Advice on individual cases is '
                       'not formal COPE guidance.</p>')
            if adv.get("en"):
                buf.append('  <blockquote class="en">')
                buf.append(body_html(adv.get("en")))
                buf.append("  </blockquote>")
            if adv.get("zh"):
                buf.append('  <blockquote class="zh">')
                buf.append(body_html(adv.get("zh")))
                buf.append("  </blockquote>")
        else:
            buf.append('  <p class="pending">COPE 尚未发布建议（Advice pending）。'
                       '已计入待复查清单，6 个月后回看是否补发。</p>')

    # 后续进展
    fu = m.get("followup")
    if fu and (fu.get("en") or fu.get("zh")):
        buf.append("  <h3>后续进展 · What happened next</h3>")
        if fu.get("en"):
            buf.append('  <blockquote class="en">')
            buf.append(body_html(fu.get("en")))
            buf.append("  </blockquote>")
        if fu.get("zh"):
            buf.append('  <blockquote class="zh">')
            buf.append(body_html(fu.get("zh")))
            buf.append("  </blockquote>")

    # 三表
    terms = m.get("terms") or []
    cols = m.get("collocations") or []
    pats = m.get("patterns") or []

    if terms:
        buf.append("  <h3>术语表</h3>")
        buf.append("  <table><thead><tr><th>英文术语</th><th>中文</th><th>释义</th></tr></thead><tbody>")
        for t in terms:
            buf.append("    <tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                esc(t.get("en")), esc(t.get("zh")), inline(t.get("note"))))
        buf.append("  </tbody></table>")

    if cols:
        buf.append("  <h3>固定搭配</h3>")
        buf.append("  <table><thead><tr><th>英文搭配</th><th>中文</th><th>用法说明</th></tr></thead><tbody>")
        for c in cols:
            buf.append("    <tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                esc(c.get("en")), esc(c.get("zh")), inline(c.get("usage"))))
        buf.append("  </tbody></table>")

    if pats:
        buf.append("  <h3>典型句式</h3>")
        buf.append('  <ul class="pat">')
        for p in pats:
            buf.append("    <li><code>{}</code><span class=\"use\">{}</span>"
                       "<span class=\"slots\"><b>可替换：</b>{}</span></li>".format(
                           esc(p.get("skeleton")), inline(p.get("zh")), esc(p.get("slots"))))
        buf.append("  </ul>")

    buf.append("</article>")
    return buf


def measure_units(content, prefix):
    """与 .md 完全同源的篇幅数字：直接量渲染后的 Markdown，不另立口径。"""
    try:
        import budget as _b
        import render_doc as _rd
        return _b.analyze_text(_rd.render(content, prefix))["total"]
    except Exception:
        return None


def render(content, prefix=DEFAULT_PREFIX):
    mats = content.get("materials") or []
    if not mats:
        die("content.materials 为空")

    d = esc(content.get("date"))
    if not d:
        die("content.date 必填（YYYY-MM-DD）")
    weekday = esc(content.get("weekday"))
    issue = int(content.get("issue") or 1)
    issue_type = esc(content.get("issue_type")) or "新内容"
    n_case = sum(1 for m in mats if m.get("kind") == "case")
    n_doc = sum(1 for m in mats if m.get("kind") in ("doc", "opening"))
    units = measure_units(content, prefix)
    units_txt = " · 篇幅约 {:,} 字".format(units) if units else ""

    # 汇总表
    term_rows, expr_rows = [], []
    for m in mats:
        tag = esc(m.get("id")) or esc(m.get("title"))
        for t in (m.get("terms") or []):
            term_rows.append((esc(t.get("en")), esc(t.get("zh")), tag))
        for c in (m.get("collocations") or []):
            expr_rows.append((esc(c.get("en")), esc(c.get("zh")), "搭配"))
        for p in (m.get("patterns") or []):
            expr_rows.append((esc(p.get("skeleton")), esc(p.get("zh")), "句式"))

    out = []
    out.append('<!DOCTYPE html>')
    out.append('<html lang="zh-CN">')
    out.append('<head>')
    out.append('<meta charset="utf-8">')
    out.append('<meta name="viewport" content="width=device-width, initial-scale=1">')
    out.append('<title>{} · {} · 第 {:03d} 期</title>'.format(esc(prefix), d, issue))
    out.append('<style>')
    out.append(CSS)
    out.append('</style>')
    out.append('</head>')
    out.append('<body>')
    out.append('<div class="wrap">')
    out.append('  <aside class="side">')
    out.append('    <div class="issue">')
    out.append('      <span class="badge">第 {:03d} 期</span>'.format(issue))
    out.append('      <h1>{}</h1>'.format(esc(prefix)))
    out.append('      <p class="date">{} · {}</p>'.format(d, weekday))
    out.append('      <p class="type">{}</p>'.format(issue_type))
    out.append('      <p class="sub">Case {} 篇 ｜ 文献 {} 篇{} · {}</p>'.format(
        n_case, n_doc, units_txt, skill_meta.generator_line()))
    out.append('    </div>')
    out.append('    <nav id="toc">')
    out.append('      <a class="grp">本期材料</a>')

    # 目录
    case_no = 0
    ids = []
    for m in mats:
        if m.get("kind") == "case":
            case_no += 1
            anchor = "m{}".format(case_no)
            label = "Case {} · {}".format(case_no, esc(m.get("title")))
        else:
            anchor = "d{}".format(len(ids) + 1)
            label = "{} · {}{}".format(KIND_LABEL[m.get("kind")], esc(m.get("title")),
                                       _lecture_txt(m))
        ids.append(anchor)
        out.append('      <a href="#{}">{}</a>'.format(anchor, label))

    out.append('      <a class="grp">汇总</a>')
    out.append('      <a href="#sum1">术语总表 · {} 条</a>'.format(len(term_rows)))
    out.append('      <a href="#sum2">表达清单 · {} 条</a>'.format(len(expr_rows)))
    out.append('      <a href="#confirm">确认方式</a>')
    out.append('    </nav>')
    out.append('    <div class="side-foot">{}</div>'.format(skill_meta.DISCLAIMER))
    out.append('  </aside>')
    out.append('  <main>')

    # 正文
    case_no = 0
    for i, m in enumerate(mats):
        if m.get("kind") == "case":
            case_no += 1
        buf = render_material(m, case_no)
        # 把自动生成的 id 换成与目录一致的锚点
        buf[0] = '<article class="mat" id="{}">'.format(ids[i])
        out.extend(buf)

    # 术语总表
    out.append('    <section class="sum" id="sum1">')
    out.append('      <h2>今日术语总表 <span class="cnt">{} 条</span></h2>'.format(len(term_rows)))
    out.append('      <p class="hint">按材料顺序排列，出处列可对应到上面各份材料。</p>')
    out.append('      <table><thead><tr><th>#</th><th>英文</th><th>中文</th><th>出处</th></tr></thead><tbody>')
    for i, (en, zh, tag) in enumerate(term_rows, 1):
        out.append('        <tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(i, en, zh, tag))
    out.append('      </tbody></table>')
    out.append('    </section>')

    # 表达清单
    out.append('    <section class="sum" id="sum2">')
    out.append('      <h2>今日表达清单 <span class="cnt">{} 条</span></h2>'.format(len(expr_rows)))
    out.append('      <p class="hint">「搭配」可直接套进句子，「句式」是骨架、需替换成分。</p>')
    out.append('      <table><thead><tr><th>#</th><th>英文表达</th><th>中文</th><th>类型</th></tr></thead><tbody>')
    for i, (en, zh, typ) in enumerate(expr_rows, 1):
        out.append('        <tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(i, en, zh, typ))
    out.append('      </tbody></table>')
    out.append('    </section>')

    # 确认
    out.append('    <section class="confirm" id="confirm">')
    out.append('      <h2>确认方式</h2>')
    out.append('      <p>读完之后回复：</p>')
    out.append('      <kbd>已完成 {}</kbd>'.format(esc(content.get("confirm_id"))))
    out.append('    </section>')

    out.append('  </main>')
    out.append('</div>')
    out.append("""<script>
(function () {
  var links = Array.prototype.slice.call(document.querySelectorAll('nav a[href^="#"]'));
  var targets = links.map(function (a) { return document.querySelector(a.getAttribute('href')); });
  function activate(id) {
    links.forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('href') === '#' + id);
    });
  }
  var obs = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) activate(e.target.id); });
  }, { rootMargin: '-10% 0px -70% 0px', threshold: 0 });
  targets.forEach(function (t) { if (t) obs.observe(t); });
  links.forEach(function (a) {
    a.addEventListener('click', function () { activate(a.getAttribute('href').slice(1)); });
  });
})();
</script>""")
    out.append('</body>')
    out.append('</html>')
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="渲染一期学习文档的 HTML 阅读版")
    ap.add_argument("--content", required=True)
    ap.add_argument("--out", help="输出路径；不给则输出到 stdout")
    ap.add_argument("--prefix", default=None, help="标题前缀（默认取 config，其次内置值）")
    args = ap.parse_args()

    if not os.path.exists(args.content):
        die("找不到 content 文件：{}".format(args.content))
    with io.open(args.content, "r", encoding="utf-8") as f:
        content = json.load(f)

    prefix = args.prefix or DEFAULT_PREFIX
    if not args.prefix:
        cfg_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "config.json")
        if os.path.exists(cfg_path):
            try:
                with io.open(cfg_path, "r", encoding="utf-8") as f:
                    prefix = json.load(f).get("doc", {}).get("title_prefix") or prefix
            except Exception:
                pass

    text = render(content, prefix)

    if not args.out:
        sys.stdout.write(text)
        return
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    with io.open(args.out, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    sys.stdout.write(json.dumps({"out": os.path.abspath(args.out),
                                 "bytes": len(text.encode("utf-8")),
                                 "materials": len(content.get("materials") or [])},
                                ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()

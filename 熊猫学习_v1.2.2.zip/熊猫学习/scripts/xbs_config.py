#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Hejia Wei
# SPDX-License-Identifier: LicenseRef-PandaXuexi-Custom
"""xbs_config.py —— 熊猫学习配置的定位、校验与生成。

三个子命令：
    path                打印 config.json 的绝对路径（不存在则给建议路径）
    check [--stage S]   校验配置。S=init（只查致命项）| run（默认，还查待补项）
    init --answers F    用 answers.json 生成 config.json（不覆盖已存在的，除非 --force）

统一输出：结果 JSON 走 stdout，日志走 stderr。
退出码：0 通过 / 1 使用错误 / 2 配置不通过
"""

import argparse
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
EXAMPLE = os.path.join(SKILL_DIR, "config.example.json")
CONFIG = os.path.join(SKILL_DIR, "config.json")

PLACEHOLDER_RE = re.compile(r"^<.*>$")
RRULE_OK = re.compile(r"^FREQ=(HOURLY|DAILY|WEEKLY|MONTHLY|YEARLY)\b")


def log(msg):
    sys.stderr.write(str(msg) + "\n")


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
    sys.exit(code)


def is_placeholder(v):
    return isinstance(v, str) and (PLACEHOLDER_RE.match(v.strip()) is not None)


def dig(d, path, default=None):
    cur = d
    for k in path.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def load(path=None):
    p = path or CONFIG
    if not os.path.exists(p):
        return None, "配置文件不存在：{}".format(p)
    try:
        with io.open(p, "r", encoding="utf-8") as f:
            return json.load(f), None
    except Exception as e:
        return None, "配置文件解析失败：{}".format(e)


# ── 校验 ────────────────────────────────────────────────────────────────

def validate(cfg, stage="run"):
    """返回 (fatal[], incomplete[], notes[])。"""
    fatal, incomplete, notes = [], [], []

    # 1 调度
    rrule = dig(cfg, "schedule.original_rrule", "")
    if not rrule:
        fatal.append("schedule.original_rrule 缺失（推送周期）")
    elif not RRULE_OK.match(rrule.strip()):
        fatal.append("schedule.original_rrule 不是合法 RRULE：{}".format(rrule))

    mode = dig(cfg, "schedule.mode", "normal")
    if mode not in ("normal", "downshifted"):
        fatal.append("schedule.mode 只能是 normal / downshifted，当前：{}".format(mode))
    if mode == "downshifted":
        dr = dig(cfg, "schedule.downshift_rrule", "")
        if not dr or not RRULE_OK.match(dr.strip()):
            fatal.append("schedule.mode=downshifted 但 downshift_rrule 缺失或非法")

    thr = dig(cfg, "schedule.no_confirm_threshold")
    if thr is not None and (not isinstance(thr, int) or not 1 <= thr <= 60):
        fatal.append("schedule.no_confirm_threshold 应为 1–60 的整数")

    # 2 台账
    backend = dig(cfg, "ledger.backend", "")
    if backend not in ("tdoc", "md"):
        fatal.append("ledger.backend 只能是 tdoc / md，当前：{}".format(backend))
    if backend == "tdoc":
        fid = dig(cfg, "ledger.file_id", "")
        if not fid or is_placeholder(fid):
            incomplete.append("ledger.file_id 未填（腾讯文档 file_id）")
        for k in ("progress", "recheck", "index"):
            v = dig(cfg, "ledger.sheets." + k, "")
            if not v or is_placeholder(v):
                incomplete.append("ledger.sheets.{} 未填（子表 sheet_id）".format(k))
    elif backend == "md":
        mp = dig(cfg, "ledger.md_path", "")
        if not mp or is_placeholder(mp):
            incomplete.append("ledger.md_path 未填（本地台账路径）")

    # 3 内容量
    cc = dig(cfg, "content.case_count")
    dc = dig(cfg, "content.doc_count")
    if not isinstance(cc, int) or not 1 <= cc <= 5:
        fatal.append("content.case_count 应为 1–5 的整数")
    if not isinstance(dc, int) or not 0 <= dc <= 3:
        fatal.append("content.doc_count 应为 0–3 的整数")

    tm = dig(cfg, "content.total_materials")
    if tm is not None:
        if not isinstance(tm, int):
            fatal.append("content.total_materials 应为整数")
        elif isinstance(cc, int) and isinstance(dc, int) and tm != cc + dc:
            fatal.append("content.total_materials={} 与 case_count+doc_count={} 不一致"
                         .format(tm, cc + dc))

    # 3.1 篇幅预算（v1.2.0 起取代 max_chars_per_doc）
    #     缺字段 = 用内置默认（旧 config 不因未升级而无法运行）；填了但越界才 fatal
    hard = dig(cfg, "content.budget.hard_limit")
    target = dig(cfg, "content.budget.doc_target")
    chunk = dig(cfg, "content.budget.chunk_words")
    if hard is None:
        notes.append("content.budget.hard_limit 未设置，按默认 10000 运行")
    elif not isinstance(hard, int) or not 5000 <= hard <= 30000:
        fatal.append("content.budget.hard_limit 应为 5000–30000 的整数")
    if target is None:
        notes.append("content.budget.doc_target 未设置，按默认 4000 运行")
    elif not isinstance(target, int) or target < 500:
        fatal.append("content.budget.doc_target 应为 ≥500 的整数")
    elif isinstance(hard, int) and target > hard:
        fatal.append("content.budget.doc_target 不得大于 hard_limit")
    if chunk is None:
        notes.append("content.budget.chunk_words 未设置，按默认 1500 运行")
    elif not isinstance(chunk, int) or not 500 <= chunk <= 3000:
        fatal.append("content.budget.chunk_words 应为 500–3000 的整数")

    if dig(cfg, "content.max_chars_per_doc") is not None:
        notes.append("content.max_chars_per_doc 已弃用（被 content.budget 取代），可删除")

    sp = dig(cfg, "content.start_point", "latest")
    if not (sp in ("latest", "oldest") or str(sp).startswith("case:")):
        fatal.append("content.start_point 只能是 latest / oldest / case:<编号>")

    # 4 归档
    ad = dig(cfg, "archive.dir", "")
    if not ad or is_placeholder(ad):
        incomplete.append("archive.dir 未填（归档目录）")
    elif os.path.isabs(ad) and not os.path.isdir(ad):
        notes.append("archive.dir 当前不存在，首次运行会自动创建：{}".format(ad))

    # 5 期次
    ist = dig(cfg, "doc.issue_start")
    if not isinstance(ist, int) or ist < 1:
        fatal.append("doc.issue_start 应为 ≥1 的整数")

    if dig(cfg, "schedule.pending_schedule_change"):
        notes.append("存在未完成的改期请求：{}".format(dig(cfg, "schedule.pending_schedule_change")))

    return fatal, incomplete, notes


# ── init ────────────────────────────────────────────────────────────────

ANSWERS_MAP = {
    "original_rrule": ("schedule", "original_rrule"),
    "downshift_rrule": ("schedule", "downshift_rrule"),
    "no_confirm_threshold": ("schedule", "no_confirm_threshold"),
    "ledger_backend": ("ledger", "backend"),
    "file_id": ("ledger", "file_id"),
    "file_url": ("ledger", "file_url"),
    "md_path": ("ledger", "md_path"),
    "case_count": ("content", "case_count"),
    "doc_count": ("content", "doc_count"),
    "total_materials": ("content", "total_materials"),
    "hard_limit": ("content.budget", "hard_limit"),
    "doc_target": ("content.budget", "doc_target"),
    "chunk_words": ("content.budget", "chunk_words"),
    "start_point": ("content", "start_point"),
    "archive_dir": ("archive", "dir"),
    "title_prefix": ("doc", "title_prefix"),
    "issue_start": ("doc", "issue_start"),
    "timezone": ("learner", "timezone"),
    "python": ("runtime", "python"),
}


def set_path(cfg, dotted, value):
    keys = dotted.split(".")
    cur = cfg
    for k in keys[:-1]:
        cur = cur.setdefault(k, {})
    cur[keys[-1]] = value


def cmd_init(args):
    with io.open(EXAMPLE, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    if os.path.exists(CONFIG) and not args.force:
        emit({"ok": False, "error": "config.json 已存在，如确需重建请加 --force",
              "path": CONFIG}, 1)

    if not os.path.exists(args.answers):
        emit({"ok": False, "error": "answers 文件不存在：{}".format(args.answers)}, 1)
    with io.open(args.answers, "r", encoding="utf-8") as f:
        ans = json.load(f)

    unknown = [k for k in ans if k not in ANSWERS_MAP]
    if unknown:
        emit({"ok": False, "error": "未知字段：{}".format(unknown),
              "allowed": sorted(ANSWERS_MAP)}, 1)

    applied = {}
    for k, v in ans.items():
        sec, key = ANSWERS_MAP[k]
        set_path(cfg, sec + "." + key, v)
        applied[k] = v

    # md 后端时把 file_id/sheets 清空，避免半截状态
    if dig(cfg, "ledger.backend") == "md":
        cfg["ledger"]["file_id"] = ""
        cfg["ledger"]["file_url"] = ""
        cfg["ledger"]["sheets"] = {"progress": "", "recheck": "", "index": ""}

    fatal, incomplete, notes = validate(cfg, stage="init")
    if fatal:
        emit({"ok": False, "fatal": fatal, "applied": applied}, 2)

    with io.open(CONFIG, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n")

    emit({"ok": True, "path": CONFIG, "applied": applied,
          "incomplete": incomplete, "notes": notes}, 0)


def cmd_check(args):
    cfg, err = load(args.config)
    if cfg is None:
        emit({"ok": False, "error": err, "path": args.config or CONFIG}, 2)

    fatal, incomplete, notes = validate(cfg, stage=args.stage)
    ok = not fatal and (args.stage == "init" or not incomplete)
    emit({
        "ok": ok,
        "stage": args.stage,
        "path": args.config or CONFIG,
        "fatal": fatal,
        "incomplete": incomplete,
        "notes": notes,
        "ledger_backend": dig(cfg, "ledger.backend"),
        "mode": dig(cfg, "schedule.mode"),
    }, 0 if ok else 2)


def cmd_path(args):
    emit({"path": CONFIG, "exists": os.path.exists(CONFIG),
          "skill_dir": SKILL_DIR}, 0)


def main():
    ap = argparse.ArgumentParser(description="熊猫学习配置工具")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("path", help="打印 config.json 路径")
    p.set_defaults(func=cmd_path)

    p = sub.add_parser("check", help="校验配置")
    p.add_argument("--config", default=None)
    p.add_argument("--stage", choices=["init", "run"], default="run")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("init", help="生成 config.json")
    p.add_argument("--answers", required=True, help="answers.json 路径")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_init)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

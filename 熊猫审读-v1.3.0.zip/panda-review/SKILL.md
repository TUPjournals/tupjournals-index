---
name: 熊猫审读
version: 1.3.0
agent_created: true
description: 熊猫审读：期刊文章/PDF/照片的编校质量审读。未表态先问模式；只要意见走②。①教育部格式 Excel 审读表（扣分/差错率/判定）；②全文逐段审读，出自包含 HTML 修改意见；③显式要求时联合「熊猫找茬-已出版」做诚信检查并合并一份 HTML；④提供送排版 Word 时逐字比对排版后 PDF；⑤在原 PDF 上高亮标注并附意见（批注件）。触发词：审读、照片审读、编校质量检查、校对、前 N 页检查、差错、扣分、修改意见、逐段挑错、通读全文、审读+诚信检查、联合审读、对比原稿、校样比对、排版走样、全文检查报告、PDF 标注、高亮批注、原 PDF 上标出来、在文本处附意见。不触发：单独学术诚信检查→走「熊猫找茬-已出版」；翻译润色、纯 PDF 合并/压缩/转换→不触发；通用 PDF 标注/批注（无审读诉求）→不触发。
---

# 熊猫审读（Panda Review）——期刊编校质量审读四模式助手

## 何时不用本技能

- 用户**只要单独学术诚信检查**（不要修改意见/审读）→ 走「熊猫找茬-已出版」，本技能不触发。
- 翻译润色、纯 PDF 合并/压缩/格式转换等无关操作 → 不触发。
- 通用 PDF 标注（如给合同/材料高亮重点、与审读无关的批注）→ 不触发。

## 第零步：判定输出模式（**先问，再动手**）

**默认口径：用户未表态时先问，别默认替用户选**（首次试用尤其要问）；用户拒绝选择、或语境明确只要修改意见时，走模式 B。一次提问把 4 个选项摆出来：

| 选项 | 模式 | 一句话说明 |
|---|---|---|
| A | 审读并出具差错表 | 教育部格式 Excel：差错类型 / 扣分 / 差错率 / 合格判定 |
| B | 审读（**推荐**） | 全文修改意见 HTML，可直接转发作者，不含扣分 |
| C | 审读 + 诚信检查 | 在 B 基础上加跑「熊猫找茬-已出版」六维诚信检查，合并为一份 |
| D | 对比原稿 | 排版后 PDF ↔ 送排版 Word 逐字比对（**需用户提供原稿**，可与 B、C 组合，回填 `BD` / `CD`） |

| | 模式 A：审读表 | 模式 B：修改意见 | 模式 C：审读 + 诚信检查（联合） | 模式 D：对比原稿 |
|---|---|---|---|---|
| 触发话术 | "审读表 / 记录表 / 扣分 / 差错率 / 合格判定 / Excel / 按教育部格式" | "修改意见 / 逐段指出问题 / 通读全文 / 挑错" | "审读 + 诚信检查 / 两个都做 / 一并跑熊猫找茬-已出版"（**必须显式要求**） | "对比原稿 / 校样比对 / 排版是否走样 / 排版有没有改错"（**必须提供原稿**） |
| 输出物 | Excel 审读记录表（双 sheet：审读记录表 + 字数计算） | 自包含单文件 HTML（可离线打开、直接转发） | **一份**自包含单文件 HTML（诚信检查 + 编校修改意见） | 作为 B/C 报告的最后一节「原稿比对」；单独用时 = 只含该节的最小 HTML |
| 差错条目 | 页/栏/行/原文/简析/**差错类型/扣分值**/备注 + 合计 + 差错率 + 合格判定 | 位置/原文摘录/**差错说明/修改建议**（不含类型码与扣分） | 同模式 B 口径（诚信检查部分按找茬报告规范） | 位置/原稿/排版后/说明（不做扣分） |
| 字数 | 必算（附件二口径，作差错率分母） | 不算 | 不算 | 不算 |
| 生成脚本 | `scripts/gen_review_xlsx.py` | `scripts/gen_review_html.py` | `scripts/gen_review_html.py` + 找茬 `gen_report.py` + `scripts/merge_review_report.py` | `scripts/compare_extract.py` + `scripts/compare_diff.py --emit-data` + `gen_review_html.py` |
| 产物命名 | `<刊名>_审读记录表_2026.xlsx` | `<稿件号>_全文修改意见_<年>.html` | `<稿件号>_审读与诚信检查报告_<年>.html` | 融入上列文件；仅 D 时 `<稿件号>_原稿比对_<年>.html` |

- 四种模式的**审读方法论完全一致**（下文通用工作流），差别只在产出物；模式 D 是**额外**的一道比对，不改变原审读口径。
- **附加输出不改变模式选择**：用户说「在原 PDF 上把要改的地方标出来 / 高亮 / 把意见附在文本处」时，任一模式照常出报告，另加一份 PDF 批注件（见「PDF 批注件」专节），不要另开模式、不算进差错条目数。
- **可组合**：`BD` / `CD` → B 或 C **+** D（D 的结果作为报告最后一节）；`AD` 同样成立。
- **选 D 但没给原稿**：**不要自己去找、不要拿别的 docx 顶替**。先提示二选一——① 补充原稿（送排版 Word，修订痕迹按"接受全部修订后的终稿"处理）；② 放弃 D，只做已选的 A/B/C。用户不补充就不做 D，报告里不出现"未检测"式半成品段落。
- **格式蓝本 = 生成器脚本本身**（不要凭记忆另造格式）：模式 A 版式由 `scripts/gen_review_xlsx.py` 内置，模式 B 版式由 `scripts/gen_review_html.py` 内置，数据登记后运行即出标准格式，不需要任何外部蓝本文件。
- **参考文件加载指引**（何时读哪个，全部在 `references/` 下）：
  - 走模式 A 登记差错前 → `references/rules-deduction.md`（扣分上限、类型值、常见场景、字数与差错率口径）；
  - 凡遇"句子突然断裂/缺词/符号怪异"等疑点、准备定性前 → `references/artifacts-falsealarm.md`（先怀疑提取假象 + 取证三件套）；
  - 选定模式 D（或 BD/CD）后、首次运行 compare 脚本前 → `references/mode-d-compare.md`（比对口径 + 14 条雷区 + 报告落位）；
  - 选定模式 C 后、跑找茬前 → `references/mode-c-merge.md`（合并件结构、样式隔离、红线继承）；
  - 用户要求 PDF 批注件时 → `references/pdf-annotation.md`（三层可见性 + 验收清单 + 12 条雷区）。

## 适用范围

- 用户引用一个或多个期刊文章 PDF（通常为英文期刊）要求审读；也可能是**照片/截图**（微信图片、页面拍照），此时按"只审照片上的内容"处理，不做形式审查。
- 本技能只做**编校质量审读**；用户未提供封面、版权页、目次页时，出版形式质量不予检查，需在输出中明确说明。
- 合并输出：多篇结果可汇总到同一文件（模式 A 汇总进同一 Excel；模式 B 每篇一个 HTML 或在 HTML 中加分篇区块）。
- 照片/截图场景不适用模式 C 与模式 D（无法支撑六维检测与字距级比对）。

## 第一步必须先问清：审读范围

用户可能只要求审**部分页**（如"检查前 10 页"）。模式 A 下这直接决定分母，必须先确认再动手；模式 B 下仍需先确认范围（全文/指定页/照片），超范围页的差错一律不记：

- **全文审读**（模式 A）：字数 = 每页字数 × 全部页数（整页插图/表格按半页折算）。
- **指定页审读**（模式 A）：按实际页数算，不要强行凑 30000，并在表中注明范围。实测经验：英文双栏期刊约 10 页 ≈ 29000 字，"查前 10 页"这类划定通常是合理的。
- **指定页内的整页插图页**：逐页行数/词数极少（仅剩页码与页眉）的按附件二折算 0.5 页，有效页数 = 指定页数 − 0.5。
- **先划清页边界再定差错归属**：确认最后一页的文字在哪里结束（逐页打印右栏末尾几行核对），超范围页出现的差错一律不记。
- 用户说"封面、版权页、目次页不检查"→ 即使 PDF 里含这些页也跳过并注明；说"不用识别 CN 号"→ 记录表 CN 号栏填"（未提供，本次未识别）"，不要猜。

## 照片/截图审读（无 PDF 文件）

用户贴出多张文章照片时，走这条分支：

- 用 `Read` 逐张读图（模型不支持图片时，把图复制到工作区后用 OCR 工具或请用户提供文本）。
- **OCR 排假**：照片 OCR 比 PDF 提取更容易误读（公式符号、上下标、希腊字母），排假细则与取证手段见
  `references/artifacts-falsealarm.md` 的「照片场景的 OCR 排假」——能自证为 OCR 假象即不记差错。
- 重要差错判定与扣分上限（模式 A）与 PDF 场景相同；页面缺失（用户未拍到的页）在审读范围中注明。
- 生成记录表时，把"照片审读 + 跳过页范围"写进审读范围列。
- ⚠️ **照片场景不适用模式 C**：找茬需要文件输入做分栏提取与 Crossref 核验。用户一边贴照片一边要诚信检查时，先说明原因、请其提供 PDF/Word 原件；坚持只给照片 → 只做照片审读并如实说明诚信检查未执行。

## 工作流（四模式共用）

1. **判定模式 + 确认文件与范围**：确认输出模式（A/B/C，可选叠加 D）；列出 PDF 路径并确认存在；确认审读页数与是否检查封面/版权页/目次页。
2. **提取文本**：对每个 PDF 用 `scripts/review_extract.py` 按栏裁剪提取并渲染页面图片（双栏 PDF 用 `page.crop` 分栏，输出 `<tag>/<tag>.txt` 与 `pages/pageNN.png`）。
3. **人工审读**：
   - 先读文本了解内容；对可疑处**直接 `Read` 渲染好的页面 PNG 目视核对**（实测 170 dpi 可读，"读图"是首选核对手段）。
   - ⚠️ 图内文字（图例、面板标号、轴标）在 170 dpi 下极易误读，必须 `page.crop(...).to_image(resolution=350~400)` 高倍复核后才能定性。
   - 使用 `WebSearch` 交叉验证存疑的参考文献作者/标题/术语。
   - **取证后再定错**：图注、作者单位等区块常被挤掉空格（`Figure1 a.`），属提取假象非排版差错；排查清单与"取证三件套"见 `references/artifacts-falsealarm.md`。
4. **登记差错（--data 外部数据文件范式）**：
   - **硬规则——核实为假象/误报的问题一律不登记**，产物只呈现已确认真实差错（仅可记工作日志备查）。
   - 把本次审读数据写进**工作区/临时目录**的数据文件（.py 或 .json，格式见各脚本 docstring 与
     `scripts/annotate_data_example.json`），**技能目录内任何文件都保持只读、绝不就地修改**。
   - 模式 A：登记 `JOURNAL/ERRORS/…`；行号用 `python scripts/locate_errors.py <input.pdf> [PAGE_LIMIT] --targets "片段" …` 定位（输出 `p4 左 L37 | 片段 | 整行文本`；页眉/页脚也计一行需说明）。扣分上限、类型值、常见场景先读 `references/rules-deduction.md`。
   - 模式 B：登记 `META/GROUPS/SUGG/QUEST`；每条含位置（P页—栏—L行）、原文摘录（保真）、差错说明（不写类型码/扣分）、修改建议（原句→改句，可直接执行）。同一问题两处矛盾时两处各记一条并互相引用。
   - 同类差错合并计数并注明"同类第 N 处"。
5. **生成产物**：
   - 模式 A：`python scripts/gen_review_xlsx.py --data <数据文件> --out <输出.xlsx>`（多篇时各篇一份再合并汇总）。
   - 模式 B：`python scripts/gen_review_html.py --data <数据文件> --out <输出.html>`（统计卡 + 分组主表 + 润色 + 待确认 + 小结）。
   - 模式 C：先按模式 B 出 `review.html`、按找茬 Step 5 出 `integrity.html`（都落**工作区暂存目录**），再用 `scripts/merge_review_report.py` 合并出**一份**交付件（结构与自检见 `references/mode-c-merge.md`）。
   - 模式 D：见「模式 D」一节的命令链，比对数据用 `compare_diff.py --emit-data` 直接落盘后与审读数据一并传 `gen_review_html.py --data`。
   - **附加输出（用户要求 PDF 标注时，任一模式）**：`python scripts/annotate_pdf.py --pdf <原PDF> --data <同一份数据文件>` 产出 `<原PDF名>_批注.pdf`；**必须在报告之后做**（编号要与报告逐条对齐）；跑完看 stdout 的 `MISS` 清单，任何未命中锚点都要补登记后重跑。
6. **输出说明**：模式 A 汇总关键问题、总扣分、差错率与判定；模式 B 对话内只给简短摘要，细节看 HTML；模式 C 给**两段**摘要（审读 + 诚信），只展示合并件。

## 模式 C：审读 + 诚信检查（联合模式）

在模式 B 全文审读的基础上，**自动调用「熊猫找茬-已出版」**（同级目录 `~/.workbuddy/skills/熊猫找茬-已出版/`）跑完六维学术诚信检查，两份内容合并为**一份**自包含 HTML 交付。

> ⚠️ **依赖前置（本包不含）**：本 skill **不打包**找茬。走模式 C 前确认它在同级目录；未安装则**明确告知此模式不可用、需另行获取**，不顶替、不伪造诚信检查结果。A / B / D 三模式不受影响。

### C1 前置信息盘点（决定六维能跑几条）

| 维度 | 所需信息 | 获取方式 |
|---|---|---|
| ① 内容相关性 | 期刊 scope 文本 | 从 PDF 页眉/版权页取刊名 → 查 `熊猫找茬-已出版/assets/journal_scopes.json`（个人积累库，模板自动初始化）→ 命中以 `--abbrev` 复用；未命中问用户一次；不提供 → 该维度标「未检测」。**禁抓 CES 官网** |
| ② 作者诚信 | 作者列表 + 全文 | 找茬 `preflight.py` 粗检 + **agent 人工确认**（其正则会把声明句误判为"有作者"）；Clean/双盲版按缺作者处理并问用户 |
| ③ 参考文献 | 参考文献列表 | 直接有（全文提取） |
| ④ AIGC | 全文 | 直接有 |
| ⑤ 声明完整性 | 声明段 + 编委会名单 | 声明段直接有；编委名单优先复用本地 `editorial_board`，无则问用户；均无 → 仅「COI 对照编委」子项未检测 |
| ⑥ 参考文献语义相关性 | 全文 + 文献列表 + 联网 | 直接有（需联网） |

缺失项该维度标「未检测」并跳过，**不自行搜索、不猜测、不反复重试**（找茬红线①）。

### C2 文本提取：两份各提一次，**文本严禁混用**

| 用途 | 脚本 | 产出 |
|---|---|---|
| 审读（本 skill） | `scripts/review_extract.py` | 分栏文本 `<tag>/<tag>.txt` + `pages/pageNN.png` |
| 诚信检查（找茬） | `熊猫找茬-已出版/scripts/extract_pdf.py` | `out_text.txt` / `out_paras.json` / `body.txt` |

- 两个 skill 的分栏算法**不同**，谁也不许拿对方的文本喂自己的流程（混用引入"缺空格/单词粘连"假象）。
- ✅ 可复用**渲染图**：审读的 `pages/pageNN.png` 可给诚信检查做人工核对用。
- 找茬侧**禁止手写 pdfplumber 提取代码**，一律用它的 `extract_pdf.py`。

### C3 执行顺序

1. 判定模式 + 确认审读范围（找茬一律全文，见 C4）。
2. 前置盘点（C1）→ 3. 两份提取（C2）。
4. **审读**：走完共用工作流（模式 B 口径），产出暂存工作区（如 `<工作区>/<tag>_merge/review.html`）。
5. **诚信检查**：按找茬 SKILL.md 走完 Step 0 → 0.5（RW 数据准备，**先于任何 RW 查询串行完成**）→ 0.6 → 1~4 → 5（`gen_report.py --out <工作区暂存目录>`）→ `integrity.html`。找茬的执行细则（stdout/stderr 分离、**严禁 `2>&1`**、落盘约定、并行规则、字段坑）**一律以它的 SKILL.md 为准，本 skill 不复制**。
6. **合并**：`python scripts/merge_review_report.py --integrity <integrity.html> --review <review.html> --out <交付目录>/<稿件号>_审读与诚信检查报告_<年>.html`——自检不过即中止且不产出文件，按 stdout 的 FAIL 项修复后重跑（结构与样式隔离详见 `references/mode-c-merge.md`）。
7. **输出说明**：给**两段**简短摘要，**只展示合并件**。

### C4 范围解耦（重要）

审读可以只审指定页；**诚信检查一律全文**（作者与声明在首尾、文献与 AIGC 统计在文末，只喂部分页会让六维失真）。范围不同时必须在摘要与产物中注明（如"审读范围 = 前 10 页；诚信检查范围 = 全文"）。红线继承与数据安全见 `references/mode-c-merge.md`。

## 模式 D：对比原稿（排版后 PDF ↔ 送排版 Word）

**只比字符级内容，不比格式、不比图片。** 目的：**排版方有没有把原稿改错、改漏、改走样。**

### D1 两个输入，缺一不做

| 输入 | 要求 | 缺了怎么办 |
|---|---|---|
| 原稿 | 送排版的 Word（`.docx`）；有修订痕迹时以**接受全部修订后的终稿**为准 | 询问补充或放弃 D，**不许拿别的 docx 顶替** |
| 排版件 | 排版后 PDF | 只有 Word 没 PDF → 无从比，说明后放弃 D |

- 同目录多份相似 docx 时，`scripts/compare_extract.py` 的 preflight 会列出来 → **必须向用户确认用哪一份**，不许默认取第一份。
- 照片/截图场景不适用 D。

### D2 提取与比对（脚本已封装，勿手写）

```bash
python scripts/compare_extract.py --docx "<原稿.docx>" -o <工作目录>/compare --tag <原稿tag>
python scripts/compare_extract.py --pdf  "<排版.pdf>"  -o <工作目录>/compare --tag <排版tag>
python scripts/compare_diff.py --orig <原稿tag>_orig.json --typeset <排版tag>_typeset.json \
       --out <工作目录>/compare/_diff.json --emit-data <工作目录>/compare/比对数据.json
python scripts/gen_review_html.py --data <审读数据文件> --data <工作目录>/compare/比对数据.json \
       --out <输出.html>
```

`--emit-data` 直接落盘 JSON 数据文件（`COMPARE_*` 四组），与审读数据一并喂 `--data`，**无任何手工粘贴环节**；`--emit-py`（打印登记块）已废弃仅为兼容保留。比对数据的字段顺序与报告层严格绑定，**不要手工改**。比对口径、14 条实测雷区、报告落位与验收线（`coverage=1.0` 等）**在走模式 D 前必读 `references/mode-d-compare.md`**。

## 模式 B（修改意见 HTML）产出规范

> **模式 C 的审读部分完全沿用本规范**（先按此出 `review.html`，再与诚信报告合并）。

- **主表四要素**：位置（`P页—栏—L行`）、原文摘录（保真，不改写）、差错说明（不写类型码与扣分）、修改建议（原句→改句，**可直接执行**）。
- **类别徽章**（只分类、不扣分，便于作者扫读）：关键（事实/逻辑矛盾，红）、语法（橙）、表述（青）、格式（蓝）、文献（紫）。
- **页面结构**（缺信息可整块省略）：① 统计卡；② 差错主表（按页/参考文献分组）+ 关键矛盾置顶红框；③ 润色建议（S 系列，非硬错）；④ 待确认（Q 系列）+ 差错构成小结；⑤ **（仅模式 D）原稿比对，列在最后**。提取假象/误报**不设区块、不列入**。
- **样式的硬要求**：白底、蓝绿主色（#0E7C74 系）、`html.escape` 全量转义、单文件自包含（CSS 内联、无外链）、`<meta charset="UTF-8">`。
- 模式 D 数据：同一数据文件里另有 `COMPARE_META / COMPARE_AUTH / COMPARE / COMPARE_QUEST` 四组，由 `compare_diff.py --emit-data` 直接产出。`COMPARE_META = None` 时第五节、导航、统计卡**全部不渲染**——**模式 B 的输出必须与 1.0.0 完全一致**（已实测逐字节等价）。章节号是动态编号：只做 D 时它就是「一、原稿比对」。

## PDF 批注件（附加输出，四模式通用）

**触发**：用户说「审读完了能不能在原 PDF 上标出要改的地方 / 高亮 / 把审读意见也附在文本处」。
**产物**：`<原PDF名>_批注.pdf`，与审读报告同目录；**原件只读、绝不改动**，编号与报告严格一一对应。
**数据**：与报告共用同一份数据文件（`--data` 传入），可另加 `ANCHORS`（候选短语按序回退，必须取自 **PDF 实际文本**；跨行/含特殊码点的短语务必再给一个短回退串）、`PAGE_HINT`（缺省从「位置」的 P<n> 推断）、`EXTRA_ANCHORS`（同类多处/数据矛盾双方一并高亮，页码 1-based 且只在该页找）。未提供 `ANCHORS` 的编号自动生成候选并打印 `AUTO`；**交付前必须核对 stdout 的 `MISS` 清单**（`--strict` 时有 MISS 以退出码 2 结束）。

```bash
python scripts/annotate_pdf.py --pdf "<稿件号>_online.pdf" --data "<本次数据>.py|.json" \
       [--out "<稿件号>_online_批注.pdf"] [--check-render <工作目录>/render] [--strict]
python scripts/annotate_pdf.py --verify-only "<稿件号>_online_批注.pdf" --pdf "<原PDF>"   # 只验已有件
```

`--out` 省略时自动写 `<原PDF名>_批注.pdf`；`--work-dir` 可指定纯 ASCII 临时目录；`--no-badge` 只留高亮。格式示例见 `scripts/annotate_data_example.json`（虚构数据）。三层可见性设计、六项验收清单与 12 条实测雷区**在生成批注件前必读 `references/pdf-annotation.md`**。

## 脚本速查

> 所有脚本的数据一律经 `--data` 从**外部数据文件**（.py/.json）传入，加载与行级校验统一由 `scripts/data_io.py` 完成；技能目录内文件保持只读。依赖见 `requirements.txt`，缺库先 `pip install -r requirements.txt`。

| 脚本 | 用途 | 用法 |
|---|---|---|
| `scripts/data_io.py` | 共享数据加载器（.py/.json、行级校验、类别枚举） | 被下列脚本内部调用，不单独运行 |
| `scripts/review_extract.py` | 提取双栏 PDF 文本 + 渲染页面图 | `python review_extract.py <pdf>… [-o <输出根>]` |
| `scripts/calc_words.py` | 附件二口径测字数（模式 A） | `python calc_words.py <pdf>…`；单篇失败计入 stderr 汇总并以非零码退出 |
| `scripts/locate_errors.py` | 差错定位到页/栏/行 | `python locate_errors.py <pdf> [PAGE_LIMIT] --targets "片段"…`（或 `--data`，键 `TARGETS/SRC/PAGE_LIMIT`） |
| `scripts/gen_review_xlsx.py` | 模式 A：教育部格式审读表（同类上限封顶 + 截断明细，输出逐字节幂等） | `python gen_review_xlsx.py --data <数据文件> [--out <输出.xlsx>]` |
| `scripts/gen_review_html.py` | 模式 B/C：自包含修改意见 HTML | `python gen_review_html.py --data <数据文件>… [--out <输出.html>]`（--data 可多次，后者覆盖前者） |
| `scripts/compare_extract.py` | 模式 D：docx/PDF 双流提取（含 preflight 相近副本提示） | `python compare_extract.py --docx\|--pdf <文件> -o <目录> --tag <tag>` |
| `scripts/compare_diff.py` | 模式 D：三级对齐 + 作者区核对 + `--emit-data` | `python compare_diff.py --orig <..json> --typeset <..json> [--out _diff.json] [--emit-data <比对.json>] [--selftest]` |
| `scripts/merge_review_report.py` | 模式 C：合并诚信 + 审读为一份 HTML（12 项自检，不过即删件） | `python merge_review_report.py --integrity <诚信.html> --review <审读.html> --out <合并.html>` |
| `scripts/annotate_pdf.py` | 附加输出：PDF 批注件（固定 PyMuPDF 1.26.4 + 增量保存，勿改写保存逻辑） | `python annotate_pdf.py --pdf <原PDF> --data <数据文件> [--out …] [--strict]` |
| `scripts/annotate_data_example.json` | 批注数据格式示例（虚构内容） | 只读参考 |

- **模式 C 还要调用「熊猫找茬-已出版」的脚本**（`extract_pdf.py`、`preflight.py`、`download_retraction_watch.py`、`gen_report.py` 等）——**勿手写提取代码、勿修改它的任何脚本**，用法与坑一律以它自己的 SKILL.md 为准。
- 依赖提示：`pdfplumber`（提取/渲染）缺失会直接崩，`openpyxl`（模式 A）缺失无法出 Excel——缺依赖先提示安装，**不要静默降级**；PyMuPDF **固定 1.26.4 勿升级**（脚本内 `import pymupdf`）；Pillow 仅 `--check-render` 需要，缺失时脚本 WARN 跳过。

## 输出文件

**模式 A**：单刊 `<刊名>_审读记录表_2026.xlsx`（审读记录表 + 字数计算双 sheet）；多篇 `<N>篇文章合并审读记录表_2026.xlsx`（汇总页含各篇审读范围）。渲染图 `article/<tag>/pages/pageNN.png` 供核对。
**模式 B**：`<稿件号>_全文修改意见_<年>.html`，自包含单文件，可离线打开、直接转发；不产出 xlsx、不算字数。
**PDF 批注件**：`<原PDF名>_批注.pdf`，与报告两件套、编号一一对应；报告描述里写明「另附同目录批注件」。
**模式 D**：融入 B/C 报告第五节；仅 D 时 `<稿件号>_原稿比对_<年>.html`。中间产物（`_orig.json` / `_diff.json` / 页面图）留工作区，不进交付目录。
**模式 C**：交付目录只落**一份**合并件；`review.html` / `integrity.html` 留工作区暂存目录，从源头不往交付目录放中间件。

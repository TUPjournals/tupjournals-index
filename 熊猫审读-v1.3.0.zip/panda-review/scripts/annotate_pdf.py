# -*- coding: utf-8 -*-
"""熊猫审读 · PDF 批注件生成器（模式 A/B/C/D 通用附加输出）

在**原 PDF 的副本**上：按类别着色高亮问题文本 + 把完整审读意见写进高亮的批注内容
+ 页边标 `#编号` 徽章。编号与同目录的审读报告逐条对应。原件只读、绝不改写。

用法
----
  python annotate_pdf.py --pdf <原PDF> --data <数据.py|数据.json> [--out <批注.pdf>]
                         [--work-dir <纯ASCII临时目录>] [--check-render <目录>]
                         [--no-badge] [--strict] [--quiet]
  # 只校验已有批注件（页数/内容流指纹/注释内容/渲染）：
  python annotate_pdf.py --verify-only <批注.pdf> [--pdf <原PDF>] [--check-render <目录>]

数据文件字段（.py 写成同名变量，.json 写成同名键）
------------------------------------------------
  META (可选)      {"manuscript_id": "9209", "out_path": ".../xxx_全文修改意见_2026.html"}
                   用于批注抬头与「详见 …」；缺失时用源 PDF 文件名兜底
  GROUPS            [(组名, [(编号, 位置, 原文摘录, 差错说明, 修改建议, 类别), ...]), ...]
                   与 gen_review_html.py 的数据区完全同构，可直接复用同一个 .py
  ANCHORS (可选)   {编号: [候选短语, ...]}，按顺序 search_for 回退；命中即用
                   跨行 / 含上下标 / 数学字体的短语务必另给一个短的回退串
  PAGE_HINT(可选)  {编号: 页码(1-based)}；缺省时从「位置」里的 P<n> 自动推断
  EXTRA_ANCHORS    {编号: [(短语, 页码), ...]}，同类多处 / 数据矛盾双方一并高亮
  COLORS (可选)    {类别: (r, g, b)}，0–1 浮点三元组；覆盖默认配色

  未提供 ANCHORS 的编号会按「原文摘录前 8 词」自动生成一个候选，并打印 AUTO 提示；
  生成后务必看 stdout 的 MISS 清单——**任何 MISS 都意味着该条意见没有落到 PDF 上**。

依赖：PyMuPDF==1.26.4（更高版本在本机 67 MB 校样上 import/save 会崩，勿升级）；
      --check-render 另需 Pillow。
"""
import argparse
import hashlib
import json  # noqa: F401  （保留：--data 的 .json 分支由 data_io 处理）
import os
import re
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data_io import merge_data, CATS

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    import pymupdf
except Exception as exc:  # pragma: no cover
    sys.exit("缺少 PyMuPDF：pip install pymupdf==1.26.4  （原始错误：%s）" % exc)

DEFAULT_COLORS = {
    "关键": (0.84, 0.27, 0.27),
    "语法": (0.85, 0.48, 0.16),
    "表述": (0.05, 0.49, 0.45),
    "格式": (0.29, 0.44, 0.65),
    "文献": (0.48, 0.35, 0.97),
}
FIELDS = ("META", "GROUPS", "ANCHORS", "PAGE_HINT", "EXTRA_ANCHORS", "COLORS")


# --------------------------------------------------------------------------- 数据
def load_data(path):
    """加载数据文件（.py/.json），统一走 scripts/data_io.py 的共享加载器。"""
    return merge_data([path], "annot")


def build_items(cfg):
    items = {}
    for _, rows in (cfg.get("GROUPS") or []):
        for row in rows:
            if len(row) != 6:
                sys.exit("GROUPS 每行必须 6 字段（编号,位置,摘录,说明,建议,类别）：%r" % (row,))
            no, loc, quote, issue, fix, cat = row
            if cat not in CATS:
                sys.exit("GROUPS 类别必须是 %s 之一：%r" % ("/".join(CATS), (row,)))
            items[str(no)] = dict(loc=loc, quote=quote, issue=issue, fix=fix, cat=cat)
    if not items:
        sys.exit("数据文件里没有 GROUPS 差错条目，无法生成批注件")
    return items


def guess_page(loc):
    m = re.search(r"\bP\s*(\d+)", str(loc))
    return int(m.group(1)) if m else None


def auto_phrase(quote):
    """从原文摘录里生成候选锚点（去省略号、取前 8 词；再给一个 4 词回退）。"""
    s = str(quote).replace("…", " ").replace("...", " ")
    s = re.sub(r"\s+", " ", s).strip().strip("“”\"' ,;:")
    words = s.split()
    phrases = []
    for n in (8, 4):
        if len(words) >= n:
            p = " ".join(words[:n]).strip(" ,;:.")
            if len(p) >= 8 and p not in phrases:
                phrases.append(p)
    if not phrases and s:
        phrases.append(s[:60])
    return phrases


def resolve_anchors(cfg, items, log):
    """返回 {编号: [候选短语...]}，并补齐缺省项。"""
    given = {str(k): list(v) for k, v in (cfg.get("ANCHORS") or {}).items()}
    result = {}
    for no, it in items.items():
        phrases = [p for p in given.get(no, []) if p]
        if not phrases:
            phrases = auto_phrase(it["quote"])
            log("AUTO #%s -> %r" % (no, phrases[0] if phrases else ""))
        result[no] = phrases
    unknown = sorted(set(given) - set(items))
    if unknown:
        log("WARN ANCHORS 中的编号在 GROUPS 里不存在：%s" % ", ".join(unknown))
    return result


def make_note_text(label, no, it, report_name):
    return (
        "【%s 审读 #%s｜%s｜%s】\n" % (label, no, it["cat"], it["loc"])
        + "原文：%s\n" % it["quote"]
        + "问题：%s\n" % it["issue"]
        + "建议：%s\n" % it["fix"]
        + "（详见同目录 %s）" % report_name
    )


# --------------------------------------------------------------------------- 路径
def ascii_work_dir(explicit):
    """MuPDF 对非 ASCII 保存路径敏感；临时工作文件必须落在纯 ASCII 路径。"""
    cands = [explicit, os.path.join(tempfile.gettempdir(), "panda_annot"),
             "C:/Windows/Temp/panda_annot"]
    for d in cands:
        if not d:
            continue
        d = os.path.abspath(d)
        if all(ord(c) < 128 for c in d):
            os.makedirs(d, exist_ok=True)
            return d
    sys.exit("找不到纯 ASCII 的临时目录，请用 --work-dir 指定一个（如 C:/Temp/panda）")


def default_out(src):
    stem = os.path.splitext(os.path.basename(src))[0]
    return os.path.join(os.path.dirname(os.path.abspath(src)), stem + "_批注.pdf")


# --------------------------------------------------------------------------- 主体
def find_rects(doc, phrases, hint):
    """优先在提示页找，找不到再全文找。返回 (页索引, rect 列表, 命中短语)。"""
    n = len(doc)
    first = hint - 1 if hint and 1 <= hint <= n else None
    order = ([first] if first is not None else []) + [i for i in range(n) if i != first]
    for phrase in phrases:
        for pi in order:
            rects = doc[pi].search_for(phrase, quads=False)
            if rects:
                return pi, rects, phrase
    return None, [], phrases[0] if phrases else ""


def build(args):
    cfg = load_data(args.data)
    items = build_items(cfg)
    colors = dict(DEFAULT_COLORS)
    colors.update(cfg.get("COLORS") or {})
    src, out = os.path.abspath(args.pdf), os.path.abspath(args.out or default_out(args.pdf))

    meta = cfg.get("META") or {}
    raw_label = str(meta.get("manuscript_id") or os.path.splitext(os.path.basename(src))[0])
    # 稿件号常写成「9209（NARE-D-26-…R1）」，批注抬头只取前导短标识
    m = re.match(r"\s*([0-9A-Za-z][0-9A-Za-z\-_.]*)", raw_label)
    label = m.group(1) if m else raw_label
    rp = meta.get("out_path")
    report_name = os.path.basename(str(rp)) if rp else "同目录审读报告 HTML"

    def log(*a):
        if not args.quiet:
            print(*a, flush=True)

    anchors = resolve_anchors(cfg, items, log)
    hints = {str(k): int(v) for k, v in (cfg.get("PAGE_HINT") or {}).items()}
    extra = {str(k): list(v) for k, v in (cfg.get("EXTRA_ANCHORS") or {}).items()}

    work = ascii_work_dir(args.work_dir)
    tmp = os.path.join(work, "panda_annot_%d.pdf" % os.getpid())
    shutil.copyfile(src, tmp)          # 原件始终只读
    doc = pymupdf.open(tmp)
    if doc.is_encrypted:
        sys.exit("PDF 已加密，无法批注：%s" % src)
    log("source pages:", len(doc), "| bytes:", os.path.getsize(src))
    # 原始内容流指纹：注释只作为 /Annots 追加，不应改动任何一页的正文绘制指令
    base_hash = [hashlib.md5(doc[i].read_contents()).hexdigest() for i in range(len(doc))]

    jobs, missing = [], []
    for no, phrases in anchors.items():
        hint = hints.get(no) or guess_page(items[no]["loc"])
        pi, rects, hit = find_rects(doc, phrases, hint)
        if not rects:
            missing.append((no, phrases[0]))
            log("!! MISS #%s : %r" % (no, phrases[0]))
            continue
        if hint and pi + 1 != hint:
            log("WARN #%s 提示页 P%s，实际命中 P%s" % (no, hint, pi + 1))
        jobs.append((no, pi, rects, hit))
        for phrase, page in extra.get(no, []):
            r2 = doc[page - 1].search_for(phrase, quads=False) if 1 <= page <= len(doc) else []
            if r2:
                jobs.append((no, page - 1, r2, phrase))
            else:
                missing.append((no, phrase))
                log("!! MISS extra #%s : %r (P%s)" % (no, phrase, page))
    log("anchor jobs:", len(jobs), "| miss:", len(missing))

    by_page = {}
    for no, pi, rects, hit in jobs:
        by_page.setdefault(pi, []).append((no, rects))

    used_slots = {}
    n_hl = n_badge = 0
    for pi, entries in sorted(by_page.items()):
        page = doc[pi]
        log("  page", pi + 1, "items", len(entries))
        for no, rects in entries:
            it = items[no]
            color = colors.get(it["cat"], (0.5, 0.5, 0.5))
            content = make_note_text(label, no, it, report_name)

            # 1) 高亮：传整条 rects（跨行短语会返回多个矩形，只取第一个会漏标）
            #    完整意见写进高亮的批注内容，鼠标悬停/点击/注释面板可见
            hl = page.add_highlight_annot(rects)
            hl.set_colors(stroke=color)
            hl.set_opacity(0.34)
            hl.set_info(title="%s 审读 #%s（%s）" % (label, no, it["cat"]),
                        content=content, subject=it["cat"])
            hl.update()
            n_hl += 1

            # 2) 页边编号徽章：只写 "#编号"
            #    ⚠️ 绝不把整段意见写进 FreeText 的 /Contents——那会被当成可见文字
            #    印在页边，中文乱码并遮挡正文。set_info 只给 title，不给 content。
            if args.no_badge:
                continue
            r = rects[0]
            tag = "#" + no
            w = 8 + 4.6 * len(tag)
            side = "L" if r.x0 < page.rect.width / 2 else "R"
            x = 3 if side == "L" else page.rect.width - w - 3
            y = r.y0
            key = (side, round(y / 11))
            while key in used_slots:
                y += 11
                key = (side, round(y / 11))
            used_slots[key] = no
            if y + 10 < page.rect.height - 2:
                badge = page.add_freetext_annot(
                    pymupdf.Rect(x, y, x + w, y + 10), tag,
                    fontsize=7, fontname="helv", text_color=color,
                    fill_color=(1, 1, 1), align=1)
                badge.set_info(title="%s 审读 #%s（%s）；意见见该处高亮批注"
                                    % (label, no, it["cat"]))
                badge.update()
                n_badge += 1

    try:
        doc.set_metadata({
            "title": "%s 审读批注（高亮 + 逐条意见）" % label,
            "subject": "原 PDF 副本；编号对应 %s" % report_name,
            "keywords": "proofreading, highlight, annotation, panda-review",
        })
    except Exception as exc:
        log("WARN set_metadata 失败（不影响批注）：", exc)

    # 3) 增量保存：只追加注释对象，不重写整份大文件（全量 save 会触发 MuPDF 崩溃）
    doc.saveIncr()
    doc.close()
    os.makedirs(os.path.dirname(out), exist_ok=True)
    shutil.copyfile(tmp, out)          # 再复制回可能是中文的交付路径
    try:
        os.remove(tmp)
    except OSError:
        pass
    log("saved:", out, os.path.getsize(out), "bytes")
    log("highlight=%d badge=%d" % (n_hl, n_badge))

    verify(out, base_hash, src if not args.verify_only else None, log)
    if args.check_render:
        check_render(out, args.check_render, log)
    if missing:
        log("!! %d 处锚点未命中，请补 ANCHORS 后重跑：" % len(missing))
        for no, phrase in missing:
            log("     #%s  %r" % (no, phrase))
        if args.strict:
            sys.exit(2)
    return out


def verify(out, base_hash=None, src=None, log=print):
    chk = pymupdf.open(out)
    if base_hash is None and src:
        original = pymupdf.open(src)
        base_hash = [hashlib.md5(original[i].read_contents()).hexdigest()
                     for i in range(len(original))]
        original.close()
    log("verify pages:", len(chk))
    if base_hash is not None:
        assert len(chk) == len(base_hash), "页数变化"
        for i, h in enumerate(base_hash):
            got = hashlib.md5(chk[i].read_contents()).hexdigest()
            assert got == h, "第 %d 页原始内容流被改动" % (i + 1)
        log("verify content streams: 逐页与原件一致 ✓")

    total, per_page, bad = 0, {}, []
    for i, p in enumerate(chk):
        ann = list(p.annots() or [])
        total += len(ann)
        if ann:
            per_page[i + 1] = len(ann)
        for a in ann:
            kind = a.type[1]
            info = a.info
            if kind == "Highlight":
                c = info.get("content") or ""
                if "问题：" not in c or "建议：" not in c:
                    bad.append("P%s 高亮缺完整意见 (#%s)" % (i + 1, info.get("title", "?")))
            elif kind == "FreeText":
                visible = info.get("content") or ""
                if not re.fullmatch(r"#\d+", visible.strip()):
                    bad.append("P%s 页边徽章含非编号可见文字：%r" % (i + 1, visible[:30]))
    log("verify annots:", total, "| per page:", per_page)
    if bad:
        log("!! 验收不通过：", "; ".join(bad[:8]))
        chk.close()
        sys.exit(3)
    log("verify annotation contents: 高亮意见完整 / 页边徽章仅编号 ✓")
    chk.close()


def check_render(pdf, out_dir, log=print):
    """渲染含注释页面供目视检查。⚠️ 不能用 pix.save()（含注释时底层会崩），必须走 PIL。"""
    try:
        from PIL import Image
    except Exception:
        log("WARN 跳过渲染自检：缺 Pillow（pip install Pillow）")
        return
    os.makedirs(out_dir, exist_ok=True)
    d = pymupdf.open(pdf)
    targets = [i for i, p in enumerate(d) if list(p.annots() or [])][:2]
    for i in targets:
        p = d[i]
        clip = pymupdf.Rect(0, 0, p.rect.width, min(p.rect.height, 460))
        pix = p.get_pixmap(matrix=pymupdf.Matrix(1.5, 1.5), clip=clip,
                           annots=True, alpha=False)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        path = os.path.join(out_dir, "annot_p%02d.png" % (i + 1))
        img.save(path)
        log("render:", path, img.size)
    d.close()


def main():
    ap = argparse.ArgumentParser(description="在原 PDF 副本上高亮审读问题并附逐条意见")
    ap.add_argument("--pdf", help="原始校样 PDF（只读）")
    ap.add_argument("--data", help="审读数据文件 .py / .json（与 gen_review_html.py 数据区同构）")
    ap.add_argument("--out", help="输出批注 PDF，默认 <原文件名>_批注.pdf（与原 PDF 同目录）")
    ap.add_argument("--work-dir", help="纯 ASCII 临时目录，默认系统临时目录")
    ap.add_argument("--no-badge", action="store_true", help="不生成页边 #编号 徽章")
    ap.add_argument("--strict", action="store_true", help="有锚点未命中时以退出码 2 结束")
    ap.add_argument("--check-render", metavar="DIR", help="额外渲染前两页含注释区域做目视检查")
    ap.add_argument("--verify-only", metavar="PDF", help="只校验已有批注件，不重新生成")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.verify_only:
        verify(args.verify_only, src=args.pdf,
               log=(lambda *a: None) if args.quiet else print)
        if args.check_render:
            check_render(args.verify_only, args.check_render,
                         log=(lambda *a: None) if args.quiet else print)
        return
    if not args.pdf or not args.data:
        ap.error("生成批注件需要 --pdf 与 --data")
    for f in (args.pdf, args.data):
        if not os.path.isfile(f):
            sys.exit("文件不存在：%s" % f)
    build(args)


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""熊猫审读 · 共享数据加载器（--data 外部文件范式统一入口）

所有需要登记审读数据的脚本（gen_review_html.py / gen_review_xlsx.py /
locate_errors.py / annotate_pdf.py）一律通过本模块加载**外部**数据文件，
支持 .py 与 .json 两种格式。技能目录内的脚本本身保持只读——
审任何稿件都不再改动安装目录里的任何文件。

加载后按各脚本的字段契约做行级校验（行长 / 类别枚举 / 必备键），
不合法直接 sys.exit 并指明行内容，绝不静默退化。

本模块无第三方依赖，仅用标准库。
"""
import importlib.util
import json
import os
import sys

# 模式 B 报告层的类别枚举（与 gen_review_html.py 的徽章配色、
# annotate_pdf.py 的默认高亮配色保持同源）
CATS = ("关键", "语法", "表述", "格式", "文献")

HTML_FIELDS = ("META", "GROUPS", "SUGG", "QUEST",
               "COMPARE_META", "COMPARE_AUTH", "COMPARE", "COMPARE_QUEST")
XLSX_FIELDS = ("OUT_PATH", "JOURNAL", "ISSUE", "CN_NOTE", "ARTICLE", "AUTHORS",
               "WORDS", "SCOPE_NOTE", "MAP_NOTE", "FORM_CHECK_ROWS",
               "ERRORS", "WORDS_CALC", "NOTES")
ANNOT_FIELDS = ("META", "GROUPS", "ANCHORS", "PAGE_HINT", "EXTRA_ANCHORS", "COLORS")
LOCATE_FIELDS = ("SRC", "PAGE_LIMIT", "TARGETS")

# 全部脚本共用的字段全集（.py 数据文件按此全集取值）
ALL_FIELDS = tuple(sorted(set(HTML_FIELDS) | set(XLSX_FIELDS) |
                          set(ANNOT_FIELDS) | set(LOCATE_FIELDS)))

# 各脚本未在数据文件中给出字段时的缺省值。
# html：没给的分节一律视为空（避免残留脚本内示例数据混进正式报告）
DEFAULTS = {
    "html": {"META": None, "GROUPS": [], "SUGG": [], "QUEST": [],
             "COMPARE_META": None, "COMPARE_AUTH": [], "COMPARE": [],
             "COMPARE_QUEST": []},
    "xlsx": {k: None for k in XLSX_FIELDS},
    "annot": {k: None for k in ANNOT_FIELDS},
    "locate": {"SRC": None, "PAGE_LIMIT": None, "TARGETS": None},
}


def load_raw(path):
    """读取一个数据文件（.json → dict；.py → 按字段全集取模块属性）。"""
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        sys.exit("数据文件不存在：%s" % path)
    ext = os.path.splitext(path)[1].lower()
    if ext == ".json":
        with open(path, encoding="utf-8") as f:
            try:
                return json.load(f)
            except ValueError as exc:
                sys.exit("数据文件不是合法 JSON：%s（%s）" % (path, exc))
    if ext not in (".py", ".pyw"):
        sys.exit("数据文件须为 .py 或 .json：%s" % path)
    # 数据文件可能 import 同级模块，先把它所在目录挂进 sys.path
    sys.path.insert(0, os.path.dirname(path))
    spec = importlib.util.spec_from_file_location("_panda_review_data", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return {k: getattr(mod, k, None) for k in ALL_FIELDS}


def merge_data(paths, kind):
    """加载一个或多个数据文件并按 kind 的字段契约合并。

    合并规则：以 DEFAULTS[kind] 为底，后面的文件覆盖前面同名字段；
    数据文件里未提供的字段取缺省值（空表 / None），
    **绝不回退到调用脚本内置的示例数据**。
    """
    cfg = dict(DEFAULTS[kind])
    for p in paths:
        raw = load_raw(p)
        for k in DEFAULTS[kind]:
            if raw.get(k) is not None:
                cfg[k] = raw[k]
    return cfg


def _exit_row(msg, row):
    sys.exit("%s\n  出错行内容：%r" % (msg, row))


def validate_html(cfg):
    """模式 B/C 数据契约：META 必备键、GROUPS 为 (组标题, 行列表) 二元组
    且行内 6 字段、SUGG 4 元组、QUEST 3 元组、类别 ∈ 5 类枚举
    （否则徽章会静默落灰）。"""
    meta = cfg.get("META")
    if not isinstance(meta, dict) or not str(meta.get("manuscript_id") or "").strip():
        sys.exit("META 必须是含非空 manuscript_id 的字典（实际：%r）" % (meta,))
    for key, need in (("SUGG", 4), ("QUEST", 3)):
        for row in cfg.get(key) or []:
            if not isinstance(row, (tuple, list)) or len(row) != need:
                _exit_row("%s 每行必须 %d 个字段" % (key, need), row)
    for group in cfg.get("GROUPS") or []:
        if not isinstance(group, (tuple, list)) or len(group) != 2:
            _exit_row("GROUPS 每组必须是 (组标题, 差错行列表) 二元组", group)
        for row in group[1]:
            if not isinstance(row, (tuple, list)) or len(row) != 6:
                _exit_row("GROUPS 每行必须 6 个字段"
                          "（编号,位置,原文摘录,差错说明,修改建议,类别）", row)
            if row[5] not in CATS:
                _exit_row("GROUPS 类别必须是 %s 之一" % "/".join(CATS), row)
    return cfg


def validate_xlsx(cfg):
    """模式 A 数据契约：ERRORS 8 元组（页,栏,行,原文,简析,类型,扣分,备注）、
    类型为数字字符串、扣分为数值。"""
    for row in cfg.get("ERRORS") or []:
        if not isinstance(row, (tuple, list)) or len(row) != 8:
            _exit_row("ERRORS 每行必须 8 个字段（页,栏,行,原文,简析,类型,扣分,备注）", row)
        if not str(row[5]).strip().isdigit():
            _exit_row("ERRORS 差错类型必须为数字字符串（如 \"19\"）", row)
        if not isinstance(row[6], (int, float)) or isinstance(row[6], bool):
            _exit_row("ERRORS 扣分值必须为数字", row)
    return cfg

# 扣分规则速查（模式 A 专用；模式 B/C 只定性不扣分）

> **加载时机**：走模式 A 登记差错前、复核合计/差错率/合格判定前，读本文件。
> 本文件内容与 `scripts/gen_review_xlsx.py` 的 `CAPS` 封顶口径一致，是模式 A 扣分的唯一权威口径。

- **重要差错**（封一/书脊文字、正文中**重要名称、重要时间、重要图片**信息错误）：按同类扣分值×2
  （仅此情形×2，不是"同类≥3处就×2"）。
- **同类扣分上限**（附件四原文，务必遵守）：
  - 类型 2（事实/知识/逻辑/语法）、类型 5（外文拼写）：同类差错有一处扣 1 次（不封顶）；
  - 类型 9（单复数/冠词/语态时态）、类型 11（专有名词/术语）：同类差错**最多扣 3 次**；
  - 类型 14（标点）：同类最多扣 10 次；类型 19/20/21/22（格式/空格）：同类最多扣 10 次；
  - 类型 8/10/17/18：同类最多扣 3 次。
  - 实测案例（AS 第13篇）：类型 9 同类 8 处、类型 11 同类 6 处，均只扣 3 次（各 1.5 分）。
- **事实/知识/逻辑/语法错误**（类型2）：1.0。
- **外文拼写差错**（类型5）：1.0/词。
- **字母大小写/正斜体/黑白体误用**（类型8）：0.5。
- **外文中单复数/冠词/语态/时态差错**（类型9）：0.5。
- **量与单位符号不规范**（类型10）：0.5（如英文文本中用逗号作小数点 ±0,002° → ±0.002°）。
- **专有名词/专业术语/缩写不规范**（类型11）：0.5（缩略语表全称大小写：General motors→General Motors、
  Low earth orbit→Low Earth orbit、Orbital science corporation→Orbital Sciences Corporation 等）。
- **标点符号错用/漏用/多用**（类型14）：0.1（如 Washington. D.C.→Washington, D.C.、
  多余右括号 ±1.22°)、标题误用法式引号 « »）。
- **图序/表序/公式序/参考文献序标注差错**（类型18）：0.5。
- **格式/版式/空格/前后不一致**（类型19/20/21）：0.1（外文单词黏连未空格：DeutschesZentrum→Deutsches Zentrum）。
- **参考文献著录格式不规范**（类型27）：0.1。
- **学术论文编写不符合国标（GB/T 7713.2 等）**（类型28）：0.5。

常见扣分场景：
- 拼写错误（如 Januray、water-scale、Kennwouut、nonnagetative、drugdrug、Itliana→Italiana、
  Nomax→Nomex、Collage Park→College Park、80ies→1980s）。
- 语法错误（如 displayed/illustrated 作谓语用过去式、but albeit 重复、degrade 名词误用、comma splice、
  从句双谓语、悬垂分词 more than tripled→tripling、缺谓语 Sputnik 1 reentry→reentered、
  双主语 Countries exchanging...they began、介词 in June 28→on June 28、序数词漏词尾 135→135th、
  since...till 搭配错误→from...to、a...chips 单复数/漏冠词）。
- **重要名称/时间错误按重要差错×2**（如 Northern Island→Northern Ireland）。
- **同一差错多处出现只扣 1 次**（附件四"同一差错只扣1次"）：如 CAM 807 页邮编 100786 在两位作者单位与基金页共出现 3 次，
  仍只扣 1 次（重要信息×2 = 2.0）。
- **逻辑等价不算错**：`if its boundary is not an analytic curve` 与 `unless` 语义等价、无法确证为错时，
  按附件四说明 3"吃不准的不予扣分"排除（CAM 第14篇实测）。凡"无标准/规范明确为错"的表达一律不记。
- 术语误用：Assumption 误写为动词 Assume（By Assume 2.2 → By Assumption 2.2，类型11，同类多处只扣 3 次）；
  Keywords 以无检索意义的冠词 A 开头（A Jordan curve of positive area，类型11，提请复审）。
- 介词缺失：refer [4] → refer to [4]、method constructing → method of constructing（类型2，各 1.0）；
  easy to be proved → easy to prove（类型9 语态）；a positive real numbers → number（类型9 单复数）。
- 邮编等事实性信息：作者单位地址邮编必须核验真实值（如北京邮电大学=100876，文中 100786 系误写），
  属正文重要信息错误按×2；WebSearch 多方确认后再记。
- 事实核验后再定性：正文时间与史实相符（如 SNAP-10A 1979 年 11 月碎片脱落属实）时只记语法错误，
  不记知识性错误。
- 术语错误（field-effect transistors 缺连字符、PDP 解释错误、insert image → inset image）。
- 单位/符号错误（𝜑 表示直径、Http:// 大写）。
- 作者单位地址缺城市名。
- 参考文献格式不一致。
- 正文与图表/附录信息不一致。
- 化学/材料命名：`poly (ethylene glycol)` 中 poly 与括号间不留空格；取代基定位符写作 `N,N-` 不留空格。
- 减号 U+2212 被误用作连字符（如 `Zr-NMOF−aptamer`），属类型17；用 `hex(ord(c))` 验码点取证。
- 知识性硬伤：数值判据与所举例子自相矛盾（如把 Pd(Z=46) 列入 "Z ≥ 74" 的高原子序数金属）。
  这类差错可用百科常识自证，不必联网，是报告里最硬的一条。
- 专业术语：化合物名要回原始文献核对（如把文献里的 **neridronate** 写成不存在的 "nelumonic acid"），
  缩写（Ner）与原词（neridronate）可互证。
- 缩略语表全称拼写/大小写/空格是高频差错区（ASI Agenzia Spaziale Itliana、UK ... Northern Island），
  用逐词坐标取证确认后照记。

## 高频差错补充案例（实测归纳，四模式通用；括号内为模式 A 的类型/扣分）

- **城市与邮编缺空格**：Beijing100190、Jinan250013、Sendai980-8577（类型19，0.1/处，同类≤10 次；
  同刊 5 处 + 另一稿 2 处再现，确认为投稿稿最高频格式差错）。
- **with + 过去分词结构中多余 was**：`with the solution temperature was maintained at 70°C` →
  `with the solution temperature maintained`（类型2，1.0）。
- **复合形容词缺连字符**：constant temperature oven → constant-temperature oven。
- **单位字符误用**：`V = 5 uL` → `5 μL`（字母 u 冒充 μ，且与 2.3 节 5 μL 不一致；类型10/11）。
- **flow rate 与 flow velocity 混用**：m/s 是流速，"flow rate"（体积流量）单位应为 m³/s（类型11）。
- **数据前后矛盾 = 关键项**：同构型实验值 46.4% 与 CFD 对照段 26.6% 不一致——两处各记一条、互相引用、
  置顶提醒（模式 B 用红色"关键"徽章；模式 A 记类型2 并在备注注明"待作者核实"）。
- **参考文献著录**：4 位作者缺 `&`/`and` 连接；作者自我昵称引号残留（`"Cj" Kim, C. J.` → `Kim, C. J.`）；
  首作者多余中间名（`M. C.` → `M.`）；期刊缩写缺点（`J. Mater Chem A` → `J. Mater. Chem. A`，类型27）；
  冒号前多余空格（`J. Mater. Sci. :` → `J. Mater. Sci.:`）。作者真实名单用 WebSearch 对照原文核实。
- ⚠️ **同刊不同期，页码起始页可以重合，不是差错**：实测 [22] `Acta Oceanol. Sin. 34(1): 38–43`
  与 [50] `Acta Oceanol. Sin. 34(11): 38–45` 起始页同为 38，经出版方页面逐条核实**两条均正确**
  （该刊按期独立编页）。凡疑点必须联网核实到出版方页面，**不可仅凭"页码撞车"就定罪**。
- **专有名词大小写是高频著录差错**：`Loop current warming by hurricane Wilma` 实为
  `Loop Current warming by Hurricane Wilma`（实测，付印前须回官方题名页核对）。
- **符号大小写不一致**：`U = 1.0 m/s` 与 `u = 1.0 m/s` 混用（正文物理量符号全文统一）。
- **波浪号区间**：`W+ = 5 ~ 10` → `5–10`（en-dash，类型19/14）。
- **术语生造**：gas scour resistance duration → steady-state plastron duration（回文献找标准术语，类型11）。
- **厂商/公司英文名**：Dataphysics → DataPhysics Instruments（WebSearch 核对官方拼写）。
- **全称重复定义**：XPS/HDTMOS 等缩写在摘要/正文/3.x 节多次给出全称（模式 B/C 记"重复"，模式 A 可酌情类型28）。
- **Figures 主谓一致**：Figures S8a–S8c ... illustrates → illustrate（类型9）；data is → data are（类型9）。

## 字数与差错率（模式 A 专用；务必按附件二计算，不要用"页数×经验值"估算）

附件二原文要点：
1. 正式检查范围 = 目次页第 1 页 1000 字 + 从第 1 页开始的正文 29000 字，共 3 万字。
2. **每行字数**：`栏宽 ÷ 正文字号`（该行可容纳的汉字数）；**外文期刊再 ×1.3**。
   逗号句号按半字计、栏间空格不计；尽量找无标点的满排文字行测量。
3. **每页字数** = 每行字数 × 每页满排行数（**两栏期刊 = 每栏行数 × 栏数**）。
   页眉、页码、脚注不计行。
4. 文题、作者、单位、摘要、关键词、各级标题、表格、插图、公式、**参考文献**一律按正文填满计字。
5. 整页全是插图/表格的按**半页**计；文末超过半页按满页、不足半页按半页。

- 差错率 = 总扣分 / 字数 × 10000（/万）。
- 合格标准：编校差错率 ≤ 2/万，且出版形式差错数 ≤ 5。
- **字数一律以统一脚本算法为准**（`scripts/calc_words.py` 的 `measure()` + `PAGE_LIMIT`），不要用人工粗算值。
  实测：CAM 前 15 页人工粗算 38850，统一算法 40477（最密页 101 行/页 × 26.7 字/行 × 15 页），
  以 40477 为准。
- **分母影响结论**：用"版面页数×经验值"估算会把字数低估 3–10 倍，导致差错率虚高、误判不合格。
  已实测：改按附件二计算后，JMRA-2（0.95/万）、ISCLS-1（0.37/万）由"不合格"变为"合格"。

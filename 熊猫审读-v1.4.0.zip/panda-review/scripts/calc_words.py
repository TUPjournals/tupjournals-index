# -*- coding: utf-8 -*-
"""
按《附件二：教育部主管科技期刊审读字数计算方法-202603》计算各篇文章的检查字数。
用法: python calc_words.py <pdf> [<pdf> ...]
要点：
  1. 每行字数 = 满排行的汉字字数；外文期刊 = 汉字字数 x 1.3
  2. 每页字数 = 每行字数 x 每页满排行数（两栏期刊按两栏合计行数）
  3. 文题/作者/单位/摘要/关键词/标题/表格/插图/公式/参考文献 均按正文填满计字
  4. 整页全是插图或表格的，按半页计；文末超过半页按满页、不足半页按半页
"""
import os
import statistics
import sys
import pdfplumber


def col_split(page):
    ws = page.extract_words()
    if not ws:
        return [page]
    mid = page.width / 2
    c = [((w["x0"] + w["x1"]) / 2) for w in ws]
    if sum(1 for x in c if x < mid) < 10 or sum(1 for x in c if x >= mid) < 10:
        return [page]
    return [page.crop((0, 0, mid, page.height)), page.crop((mid, 0, page.width, page.height))]


def page_lines(pg):
    """返回该页的 (栏数, 合计行数, 词数)"""
    cols = col_split(pg)
    sz = statistics.median([round(c["size"], 1) for c in pg.chars]) if pg.chars else 9.0
    tot = 0
    for col in cols:
        ws = col.extract_words()
        if len(ws) < 5:
            continue
        tops = sorted({round(w["top"], 0) for w in ws})
        rows = []
        for t in tops:
            if rows and t - rows[-1] < sz * 0.6:
                continue
            rows.append(t)
        tot += len(rows)
    return len(cols), tot, len(pg.extract_words())


def measure(pdf, tag):
    """在文字最密的一页上测量栏宽、字号、行距"""
    best = None
    for i, pg in enumerate(pdf.pages):
        n = len(pg.extract_words())
        if best is None or n > best[0]:
            best = (n, i)
    pg = pdf.pages[best[1]]
    cols = col_split(pg)

    widths, sizes, heights, lines, spacings = [], [], [], [], []
    for col in cols:
        ws = col.extract_words()
        if len(ws) < 20:
            continue
        x0 = min(w["x0"] for w in ws)
        x1 = max(w["x1"] for w in ws)
        widths.append(x1 - x0)
        y0 = min(w["top"] for w in ws)
        y1 = max(w["bottom"] for w in ws)
        # 先取字号，用于设置合理的行合并阈值
        _sizes = [round(c["size"], 1) for c in col.chars] or [9.0]
        _sz = statistics.median(_sizes)
        tops = sorted({round(w["top"], 0) for w in ws})
        # 合并同一行的 top（阈值取 0.6 倍字号，避免上下标被算成独立行）
        rows = []
        for t in tops:
            if rows and t - rows[-1] < _sz * 0.6:
                continue
            rows.append(t)
        lines.append(len(rows))
        spacings.append((y1 - y0) / max(1, len(rows) - 1))
        heights.append(y1 - y0)

    chars = pg.chars
    sizes = [round(c["size"], 1) for c in chars]
    size = statistics.median(sizes) if sizes else 9.0

    col_w = statistics.median(widths) if widths else pg.width * 0.4
    lines_per_col = statistics.median(lines) if lines else 40
    col_h = statistics.median(heights) if heights else pg.height * 0.8

    han_per_line = col_w / size                 # 一个汉字的宽度 = 字号（1 em）
    foreign_per_line = han_per_line * 1.3       # 外文期刊 +30%
    lines_per_page = lines_per_col * len(cols)
    per_page = foreign_per_line * lines_per_page

    # 逐页折算：整页为插图/表格的按半页计（附件二第4条）
    counts = [page_lines(p) for p in pdf.pages]
    max_lines = max(c[1] for c in counts)
    words_med = statistics.median([c[2] for c in counts])
    eff_pages = 0.0
    for nc, ln, wd in counts:
        eff_pages += 0.5 if (wd < words_med * 0.2 and ln < max_lines * 0.25) else 1.0

    n_pages = eff_pages
    return dict(tag=tag, pages=len(pdf.pages), eff=eff_pages, ncols=len(cols), size=size,
                col_w=round(col_w, 1), han=round(han_per_line, 1),
                foreign=round(foreign_per_line, 1),
                lpc=lines_per_col, lpp=lines_per_page,
                lead=round(statistics.median(spacings), 1) if spacings else 0,
                per_page=round(per_page), total=round(per_page * n_pages))


if __name__ == "__main__":
    argv = sys.argv[1:]
    if not argv:
        print("用法: python calc_words.py <pdf> [<pdf> ...]")
        print("示例: python calc_words.py \"D:/稿件/a.pdf\" \"D:/稿件/b.pdf\"")
        sys.exit(1)
    pdfs = [(os.path.splitext(os.path.basename(p))[0], p) for p in argv]
    print(f"{'篇目':<20}{'页数':>5}{'折页':>6}{'栏':>4}{'字号':>6}{'栏宽':>7}{'汉字/行':>8}"
          f"{'外文/行':>8}{'行/栏':>6}{'行/页':>6}{'行距':>6}{'字/页':>7}{'总字数':>8}")
    failed = []
    for tag, path in pdfs:
        try:
            with pdfplumber.open(path) as pdf:
                r = measure(pdf, tag)
        except Exception as e:
            # 单篇失败计入 stderr 汇总，最后以非零码退出——批处理场景必须能感知失败
            print(f"{tag:<20}{'ERROR':>5} {e}", file=sys.stderr)
            failed.append((tag, path, str(e)))
            continue
        print(f"{r['tag']:<20}{r['pages']:>5}{r['eff']:>6.1f}{r['ncols']:>4}{r['size']:>6}"
              f"{r['col_w']:>7}{r['han']:>8.1f}{r['foreign']:>8.1f}"
              f"{r['lpc']:>6.0f}{r['lpp']:>6.0f}{r['lead']:>6}"
              f"{r['per_page']:>7}{r['total']:>8}")
    if failed:
        print("共 %d/%d 篇测量失败：%s" % (
            len(failed), len(pdfs),
            "; ".join("%s(%s)" % (t, m[:60]) for t, _p, m in failed)), file=sys.stderr)
        sys.exit(1)

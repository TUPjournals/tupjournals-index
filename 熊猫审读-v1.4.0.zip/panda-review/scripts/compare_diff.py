#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
熊猫审读（panda-review）· 模式 D 比对器
=====================================
读 compare_extract.py 产出的两份 JSON，比对「送排版 docx」与「排版后 PDF」，
只输出**实质差异**（体例性变化在归一化阶段被吸收，不进结果）。

用法：
    python compare_diff.py --orig <x_orig.json> --typeset <x_typeset.json> \
           --out <x_diff.json> [--emit-data <x_比对数据.json>] [--emit-py] \
           [--selftest] [--th-match 0.60]

    --emit-data <path>  把比对结果落盘为 JSON 数据文件（COMPARE_* 四组键），
                        直接喂给 gen_review_html.py / annotate_pdf.py 的 --data，
                        交付链：compare_diff --emit-data → gen_review_html --data，
                        无任何"手工粘贴"环节（推荐）
    --emit-py           打印可粘进数据文件的 COMPARE_* 登记块（已废弃，仅为兼容保留；
                        含换行的文本请一律用 --emit-data）
    --selftest          内存注入 6 类改动，验证检出能力。不提供 --orig/--typeset 时
                        使用内置合成样本（全虚构 Example 文本）独立运行；
                        全部用例通过 exit 0，有失败 exit 1

口径（由用户确定）：
    * 只做字符级内容比较，不做格式/图片/版式比较
    * 只报实质差异；大小写、连字符、引号变体、引用编号样式、单位符号、
      折行连字符、软连字符等一律视为体例，吸收
    * 参考文献区不比对（排版方会按期刊体例整体重写文献表）
    * 表格按数值集合比对（PDF 表格结构不可靠，不给行列定位）
    * 作者区五项实质核对：通讯邮箱 / 人数 / 顺序 / 姓名拼写 / 作者-机构对应
"""
import argparse
import difflib
import json
import re
import sys
import unicodedata
from collections import Counter

# ====================== 归一化 ======================
SOFT = "\u00ad"
DASHES = "\u2010\u2011\u2012\u2013\u2014\u2015\u2212"
QUOTES = {"\u201c": '"', "\u201d": '"', "\u00ab": '"', "\u00bb": '"',
          "\u2018": "'", "\u2019": "'", "\u201a": "'", "\u2032": "'"}
UNIT_CASE = [(re.compile(r"(?<![A-Za-z])ml(?![A-Za-z])"), "mL"),
             (re.compile(r"(?<![A-Za-z])ul(?![A-Za-z])"), "uL"),
             (re.compile(r"(?<![A-Za-z])l/min(?![A-Za-z])"), "L/min"),
             (re.compile(r"(?<![A-Za-z])um(?![A-Za-z])"), "um")]
ABBR_DOTS = re.compile(r"\b(et\s+al|e\.g|i\.e|Fig|Eq|vs|Ref|No)\.", re.I)
CITE_SP = re.compile(r"\[\s*([\d,\s\u2013\u2014-]+?)\s*\]")
NUM_TOKEN = re.compile(r"\d+(?:[.,]\d+)*")
WORD_TOKEN = re.compile(r"[A-Za-z]+(?:['\u2019-][A-Za-z]+)*|\d+(?:[.,]\d+)*|[^\sA-Za-z0-9]")

STOPWORDS = {"not", "no", "only", "all", "and", "or", "to", "of", "with", "in",
             "on", "for", "by", "as", "at", "from", "but", "than", "that", "this"}


def _n01(s):
    # 零宽字符：docx 里 "(ISO)" 常被 ZWNJ 包起来（‌ISO‌），
    # 不清掉就会在词表里裂出 "" 这种空 token，报成「删字 ‌ ‌」。
    s = re.sub(r"[\u200b\u200c\u200d\u2060\ufeff]", "", s)
    return unicodedata.normalize("NFKC", s)


def _n02(s):
    s = re.sub(r"\s*&\s*", " and ", s)
    for d in DASHES:
        s = s.replace(d, "-")
    for a, b in QUOTES.items():
        s = s.replace(a, b)
    s = s.replace("\u00b5", "\u03bc")
    return s


def _n03(s):
    """软连字符分流：行末折行 → 直接删并；数字之间 → 真连字符。"""
    s = re.sub(r"(?<=[A-Za-z])" + SOFT + r"\s*(?=[A-Za-z])", "", s)
    s = re.sub(r"(?<=\d)" + SOFT + r"(?=\d)", "-", s)
    s = s.replace(SOFT, "")
    # 行末 ASCII 连字符（折行断词）
    s = re.sub(r"(?<=[A-Za-z])-\s+(?=[a-z]{2,})", "", s)
    return s


def _n06(s):
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"\s+([,.;:!?)\]])", r"\1", s)
    return s.strip()


def _n07(s):
    def fix(m):
        inner = re.sub(r"\s+", "", m.group(1))
        return "[" + inner + "]"
    return CITE_SP.sub(fix, s)


NUM_WORDS = {"one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
             "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10",
             "eleven": "11", "twelve": "12"}
NUM_WORD_RX = re.compile(r"(?i)\b(" + "|".join(NUM_WORDS) + r")\b")


def _n11(s):
    s = ABBR_DOTS.sub(lambda m: m.group(1), s)
    s = re.sub(r"(?i)\bfigures?\b", "Fig", s)          # Figure 1 ↔ Fig. 1
    s = re.sub(r"(?i)\bfigs\.?", "Fig", s)              # Figs. 3 和 4 ↔ Fig 3 和 4
    s = re.sub(r"(?i)\btables?\b(?=\s*\d)", "Table", s)
    return s


def _n12(s):
    """英文数词 ↔ 阿拉伯数字：排版体例化（two categories → 2 categories）。"""
    return NUM_WORD_RX.sub(lambda m: NUM_WORDS[m.group(1).lower()], s)


ROMAN = {"i": 1, "ii": 2, "iii": 3, "iv": 4, "v": 5, "vi": 6, "vii": 7, "viii": 8}
ENUM_RX = re.compile(r"(?<![\w)])(?:\((\d{1,2}|[a-h]|[ivx]{1,4})\)"
                     r"|(\d{1,2}|[a-h]|[ivx]{1,4})\))", re.I)
ACR_STOP = {"of", "for", "and", "the", "in", "on", "to", "a", "an", "&"}
ACR_DEF = re.compile(r"((?:[A-Za-z][\w\-]*\s+){1,6})\s*\(([A-Za-z]{2,8})\)")


def _enum_no(tok):
    tok = tok.lower()
    if tok.isdigit():
        return int(tok)
    if tok in ROMAN:
        return ROMAN[tok]
    if len(tok) == 1 and "a" <= tok <= "h":
        return ord(tok) - 96
    return 0


def _n13(s):
    """序号体例化：1) / (1) / i) / (a) → 统一标记。

    排版方常把作者写的「1) 2)」改成「(a) (b)」，或把 (i)(ii) 改成 (a)(b)。
    这是纯体例，保留原文只会报成「改字」噪声。
    """
    def fix(m):
        # 直接删掉，不映射成标记：映射会把「(a)」和「1)」的差异变成
        # 增/删一个 "#e1" token，反而制造噪声；序号本身不承载内容。
        return " " if _enum_no(m.group(1) or m.group(2)) else m.group(0)
    return ENUM_RX.sub(fix, s)


def _n14(s):
    """缩写首现体例化：indoor air quality (IAQ) → IAQ。

    排版方会在首次出现处把缩写补全（或把全称替换成缩写），
    两侧写法必然不同但不是内容差异。只认「全称末 k 词的词首字母 == 缩写」。
    """
    def fix(m):
        phrase, acr = m.group(1).strip(), m.group(2)
        toks = re.findall(r"[A-Za-z][\w\-]*", phrase)
        for k in range(1, len(toks) + 1):
            sub = [t for t in toks[-k:] if t.lower() not in ACR_STOP]
            if not sub:
                continue
            if "".join(t[0] for t in sub).lower() == acr.lower():
                head = " ".join(toks[:len(toks) - k])
                return (head + " " if head else "") + acr + " "
        return m.group(0)
    return ACR_DEF.sub(fix, s)


def _n15(s):
    """缩写括注删除体例化：「全称 (缩写) → 全称」。

    排版方常在正文首现处只留全称、把括注删掉（或反之补上），
    两侧写法必然不同但不是内容差异。缩写字母按「集合」比，
    因为 ISO 之于 International Organization for Standardization 是乱序的。
    """
    def fix(m):
        phrase, acr = m.group(1), m.group(2)
        toks = [t for t in re.findall(r"[A-Za-z][\w\-]*", phrase)
                if t.lower() not in ACR_STOP]
        if not toks:
            return m.group(0)
        core = acr.rstrip("sS").lower()
        for k in range(1, min(len(toks), len(core)) + 1):
            if sorted(t[0].lower() for t in toks[-k:]) == sorted(core):
                return m.group(0).replace("(%s)" % acr, "").replace(
                    "( " + acr + " )", "").rstrip()
        return m.group(0)
    return ACR_DEF.sub(fix, s)


def norm_key(s, region=""):
    """比较用的归一化串。禁吸收项（数字值、词形、否定词）绝不在此处改动。"""
    if not s:
        return ""
    s = _n01(s)
    s = _n02(s)
    s = _n03(s)
    s = _n07(s)
    s = _n11(s)
    s = _n14(s)                                # 全称(缩写) → 缩写
    s = _n15(s)                                # 全称(缩写) → 全称（括注被删）
    for rx, rep in UNIT_CASE:
        s = rx.sub(rep, s)
    s = _n06(s)
    # 标签词（Abstract / Keywords）在排版时常被并入正文或删去
    s = re.sub(r"(?i)^(abstract|summary|keywords?|index terms)\b[:.\s]*", "", s)
    if region == "head":                       # 节标题编号属排版体例
        s = re.sub(r"^\d+(?:\.\d+)*\.?\s*", "", s)
    s = _n13(s)                                # 序号体系
    s = _n12(s)                                # 数词↔数字
    s = re.sub(r"\s+", " ", s).strip()
    # 连字符不敏感（含 U+2010/U+2011 这类真连字符；不含 used-as-range 的 – —）
    s = re.sub(r"[\-\u2010\u2011]", "", s)
    return s


def norm_raw(s):
    return _n06(_n02(_n01(s or "")))


def words_of(key):
    return WORD_TOKEN.findall(key)


def nums_of(key):
    # "ISO 12460 5:2015"（PDF 把连字符变成空格）与 "ISO 12460-5:2015" 归一
    return [t for t in NUM_TOKEN.findall(re.sub(r"(?<=\d) (?=\d)", "", key))]


def sent_starts(raw):
    """返回「句子起始」的字符位置集合，用于判「句首大小写」属体例。"""
    out = {0}
    for m in re.finditer(r"(?<=[.!?])[\"')]?\s+", raw):
        out.add(m.end())
    return out


# ====================== 段落对齐 ======================
def ratio_words(a, b):
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b, autojunk=False).ratio()


def align_paragraphs(A, B, th=0.70):
    """A=docx 段落, B=pdf 块。

    返回 pairs[(ia, ib, score, ka, kb)]（ka/kb>1 表示该侧多段并成一组），
    only_a[i], only_b[j]。
    """
    aw = [words_of(a["_key"]) for a in A]
    bw = [words_of(b["_key"]) for b in B]
    sm = difflib.SequenceMatcher(None, [" ".join(x) for x in aw],
                                 [" ".join(x) for x in bw], autojunk=False)
    pairs, only_a, only_b = [], [], []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                pairs.append((i1 + k, j1 + k, 1.0, 1, 1))
        elif tag == "delete":
            only_a.extend(range(i1, i2))
        elif tag == "insert":
            only_b.extend(range(j1, j2))
        else:
            pairs_local, oa, ob = _dp_block(aw, bw, i1, i2, j1, j2, th)
            pairs.extend(pairs_local)
            only_a.extend(oa)
            only_b.extend(ob)
    return pairs, only_a, only_b


def _merge(paras, i, k):
    """把 k 个相邻段落并成一个虚拟段（保留首段的 page/line/region 用于定位）。"""
    if k <= 1:
        return paras[i]
    ps = paras[i:i + k]
    out = dict(ps[0])
    out["text"] = " ".join(p.get("text", "") for p in ps)
    if any("runs" in p for p in ps):
        out["runs"] = [r for p in ps for r in (p.get("runs") or [])]
    out["_merged"] = k
    return out


def _dp_block(aw, bw, i1, i2, j1, j2, th):
    """局部 DP：吸收「一段被拆成多段 / 多段被并成一段」。

    PDF 段落边界是启发式推的：一个 docx 段常被拆成 2~5 块（栏断、图绕排、
    句中标点换字体都会断）。所以 merge 必须支持 k 对 1 / 1 对 k（k≤3），
    否则这些块会全落进 only_*，在报告里冒充「漏排/多排」。
    """
    n, m = i2 - i1, j2 - j1
    if n * m > 40000:                    # 块太大，退回一对一
        pairs = [(i1 + k, j1 + k, ratio_words(aw[i1 + k], bw[j1 + k]))
                 for k in range(min(n, m))]
        return pairs, list(range(i1 + len(pairs), i2)), list(range(j1 + len(pairs), j2))

    INF = float("inf")                    # 必须是真无穷：大块累计代价会超过任何常数，
                                          # 曾用 9.0 当哨兵，26 次 del(23.4) 就被判「不可达」，
                                          # 回溯退化成乱配，配对数凭空掉一半
    DEL, INS = 0.90, 0.90
    MRG = 0.30                            # 每多并一段收的惩罚
    MERGE_TH = 0.85                       # 合并组的相似度门槛要比单段配对更严：
                                          # 同一段文字被拆开后再拼回来，字符比必然很高，
                                          # 拼不到 0.75 的「合并」基本都是错误组合
    K = 6                                 # 最多 6 段并 1 段（一页正文可被切 4~6 块）

    def join(seq, a, b):
        return [t for x in seq[a:b] for t in x]

    dp = [[INF] * (m + 1) for _ in range(n + 1)]
    bk = [[None] * (m + 1) for _ in range(n + 1)]
    dp[0][0] = 0.0
    for i in range(n + 1):
        for j in range(m + 1):
            if dp[i][j] == INF:
                continue
            for ka in range(1, K + 1):
                if i + ka > n:
                    break
                for kb in range(1, K + 1):
                    if j + kb > m:
                        break
                    # 多对多是必要的：PDF 的段界与 docx 段界并不对齐，
                    # 一对多/多对一都覆盖不了 3:2 这类真实切段。
                    # 但合并组必须是「近乎同一段文字」，故门槛抬到 0.85。
                    r = ratio_words(join(aw, i1 + i, i1 + i + ka),
                                    join(bw, j1 + j, j1 + j + kb))
                    if ka == 1 and kb == 1:
                        need = th
                    else:
                        need = max(th, MERGE_TH)
                    if r < need:
                        continue
                    c = dp[i][j] + (1.0 - r) + MRG * (ka + kb - 2)
                    if c < dp[i + ka][j + kb]:
                        dp[i + ka][j + kb] = c
                        bk[i + ka][j + kb] = ("pair", i, j, r, ka, kb)
            if i < n:
                c = dp[i][j] + DEL
                if c < dp[i + 1][j]:
                    dp[i + 1][j], bk[i + 1][j] = c, ("del", i, j, 0.0, 1, 0)
            if j < m:
                c = dp[i][j] + INS
                if c < dp[i][j + 1]:
                    dp[i][j + 1], bk[i][j + 1] = c, ("ins", i, j, 0.0, 0, 1)

    pairs, oa, ob = [], [], []
    i, j = n, m
    while i > 0 or j > 0:
        op = bk[i][j]
        if op is None:
            if i > 0:
                oa.append(i1 + i - 1)
                i -= 1
            elif j > 0:
                ob.append(j1 + j - 1)
                j -= 1
            continue
        kind, pi, pj, r, ka, kb = op
        if kind == "pair":
            pairs.append((i1 + pi, j1 + pj, r, ka, kb))
            i, j = pi, pj
        elif kind == "del":
            oa.append(i1 + pi)
            i, j = pi, pj
        else:
            ob.append(j1 + pj)
            i, j = pi, pj
    pairs.reverse()
    return pairs, sorted(set(oa)), sorted(set(ob))


# ====================== 差异判定 ======================
def _acronym_equiv(sa, sb):
    """缩写 ↔ 全称互换（排版体例化）：BFRs ↔ brominated flame retardants。"""
    da = re.sub(r"[^A-Za-z]", "", sa)
    db = re.sub(r"[^A-Za-z]", "", sb)
    if not da or not db:
        return False

    def initials(txt, plural_ok=True):
        toks = re.findall(r"[A-Za-z]+", txt)
        return "".join(t[0] for t in toks).lower()

    for short, long_ in ((da, sb), (db, sa)):
        if len(short) <= 9 and short.isupper() is False and short.upper() != short:
            continue
        if len(short) <= 9 and re.fullmatch(r"[A-Z][A-Za-z]{1,8}s?", short):
            ini = initials(long_)
            if ini and (ini == short.lower() or ini + "s" == short.lower()
                        or ini == short.lower().rstrip("s")):
                return True
    return False


def _expand_equiv(short_toks, long_toks):
    """单侧一个纯缩写、另一侧是 2+ 词的展开（IoT ↔ Internet of Things）。

    词首字母按「含/不含虚词」两种口径各试一次，命中即算体例化——
    专业缩写的取字母规则不统一（ISO 取乱序、IoT 跳过 of），无法唯一判定。
    """
    if not short_toks or len(short_toks) > 2 or len(long_toks) < 2:
        return False
    core = re.sub(r"[^A-Za-z]", "", "".join(short_toks))
    if not (2 <= len(core) <= 9) or core[:1].islower():
        return False
    toks = [t for t in long_toks if re.search(r"[A-Za-z]", t)]
    if len(toks) < 2:
        return False
    for pool in (toks, [t for t in toks if t.lower() not in ACR_STOP]):
        if len(pool) < 2:
            continue
        ini = "".join(t[0] for t in pool).lower()
        if ini == core.lower() or ini == core.lower().rstrip("s"):
            return True
    return False


ACR_DEF_RX = re.compile(r"([A-Za-z][\w\-]*(?:\s+[A-Za-z][\w\-]*){0,6})\s*\(\s*([A-Z]{2,8}[a-z]?)\s*\)")
ACR_MAP = {}


def build_acr_map(*datas):
    """全篇缩写字典：{缩写: 全称}，取原文首次定义。

    排版方常把「全称 (缩写)」拆成「全称」或只留「缩写」，同一条内容在两侧
    必然对不上。有了全篇字典就能两侧同时展开，把这类纯体例差异吃掉。

    两条闸门（踩过坑）：
    ① 括注必须**全大写**。否则 "China (GB/T …)"、"Europe (Ventilation of
       buildings)" 这种表格里的普通词也会被当成缩写，把 "Europe" 展开成
       「Ventilation of buildings」，反而制造假差异。
    ② 全称取「括注前最后 k 个词」（k = 缩写字母数），不能整段照抄——
       否则会带上前缀，"such as International Organization for
       Standardization" 这种。
    """
    def score(core, content):
        cand = content[-max(2, len(core)):]
        return len(set(t[0].lower() for t in cand) ^ set(core.lower()))

    mp = {}
    for d in datas:
        for p in d.get("paras", []):
            for m in ACR_DEF_RX.finditer(p.get("text") or ""):
                phrase, acr = m.group(1), m.group(2)
                raw = re.findall(r"[A-Za-z][\w\-]*", phrase)
                content = [t for t in raw if t.lower() not in ACR_STOP]
                if len(content) < 2:
                    continue
                best = None
                for core in {acr, acr.rstrip("sS")}:
                    sc = score(core, content)
                    if sc > 2:
                        continue
                    cand = (sc, max(2, len(core)))
                    if best is None or cand < best:
                        best = cand
                if not best or acr in mp:
                    continue
                # 用 raw 的后缀重建全称，保留 for / and 这类虚词
                # （"International Organization for Standardization" 丢 for 就对不上了）
                k, cnt, idx = best[1], 0, 0
                for j in range(len(raw) - 1, -1, -1):
                    if raw[j].lower() not in ACR_STOP:
                        cnt += 1
                    idx = j
                    if cnt == k:
                        break
                # 归一化层最后会剥掉连字符，展开项也必须同口径，
                # 否则 "Semi-volatile" 展开进来又把连字符带回去，rule 1 就失效了
                mp[acr] = re.sub(r"[\-\u2010\u2011]", "", " ".join(raw[idx:]))
    return mp


def _apply_acr(s):
    """把缩写统一展开成全称，并消掉「全称 全称」重复。"""
    if not ACR_MAP or not s:
        return s
    for acr, full in ACR_MAP.items():
        s = re.sub(r"\(\s*%s\s*\)" % re.escape(acr), "", s)
        s = re.sub(r"\b%s\b" % re.escape(acr), full.replace("\\", "\\\\"), s)
    for full in set(ACR_MAP.values()):
        s = re.sub(r"(?:%s)(?:\s+%s)+" % (re.escape(full), re.escape(full)),
                   full, s)
    return re.sub(r"\s+", " ", s).strip()


def _glue(toks):
    """把若干 token 压成「只剩字母数字」的小写串。"""
    return re.sub(r"[^a-z0-9]", "", "".join(toks).lower())


def _sig_tok(w):
    """是不是「有分量」的词：带数字，或 ≥5 个字母。

    公式上下标在 PDF 文本层会被拆成独立词（`Parc` → `P arc`）、甚至被重排到
    行尾堆成一串 `arc arc arc`，这些 token 全是 2–4 字母的变量名碎片，没有
    判别力；真正的漏字/改字几乎都落在 ≥5 字母的实词或数字上。
    """
    if re.search(r"\d", w):
        return True
    return len(re.sub(r"[^A-Za-z]", "", w)) >= 5


def _junk_frag(toks):
    """一整段「不像句子」的碎片：图内轴标（`B r ea k D o w n`）、公式残渣。"""
    if len(toks) < 4:
        return False
    longs = sum(1 for w in toks if len(re.sub(r"[^A-Za-z]", "", w)) >= 3)
    return longs / float(len(toks)) < 0.35


def _eq_no_only(toks):
    return bool(toks) and all(re.fullmatch(r"\(\d{1,2}[a-z]?\)", w) for w in toks)


def _frac_change(sa, sb, a_raw="", b_raw=""):
    """判断这处差异是否只是公式/上下标排版噪声（是→返回说明串，否→None）。"""
    # 上下标拆分：两侧压掉空白与标点后完全相等（Parc ↔ P arc、P(t) ↔ P ( t )）
    if _glue(sa) == _glue(sb):
        return "上下标拆分（公式变量被拆成独立词）"
    # 单侧为空：只有碎片、没有实词/数字
    if not sa or not sb:
        one = sa or sb
        if _eq_no_only(one):
            return "公式编号单独成行"
        if _junk_frag(one) and not any(re.search(r"\d{2,}", w) for w in one):
            return "图内轴标/公式残渣"
        if not any(_sig_tok(t) for t in one):
            return "仅上下标/公式变量碎片"
        return None
    # 引用编号（`[26]`）在 PDF 文本层常被上标重排挤到别处，正文里只剩个孤零零的
    # 数字差异。这类不计实质差异——文献引用完整性由「熊猫找茬」的维度③负责。
    cites = set(re.findall(r"\[\s*(\d{1,3})\s*[,–\-]", a_raw + " " + b_raw))
    cites |= set(re.findall(r"\[\s*(\d{1,3})\s*\]", a_raw + " " + b_raw))
    rest = [t for t in sa + sb
            if _sig_tok(t) and not (t.strip("[]") in cites and len(t.strip("[]")) <= 3)]
    if not rest:
        return "仅上下标/公式变量碎片"
    return None


def judge(a_raw, b_raw, a_key, b_key, region):
    """返回 (等级, kind, note) 或 None(=无差异)。顺序敏感。

    等级：'体例'（吸收，不进报告）/ '实质' / '待确认'
    """
    if a_key == b_key:
        return None
    a_key, b_key = _apply_acr(a_key), _apply_acr(b_key)
    if a_key == b_key:
        return ("体例", "", "缩写/全称写法差异（全篇已定义）", "")
    ta, tb = words_of(a_key), words_of(b_key)
    na, nb = nums_of(a_key), nums_of(b_key)

    # 1 仅大小写/连字符/引号/空白差异
    if a_key.lower().replace(" ", "") == b_key.lower().replace(" ", ""):
        return ("体例", "", "大小写/连字符/空白体例差异", "")
    # 2b 引用编号被挤出文本流（PDF 把上标引用 `[26]` 挪到别处，正文里就没这个数）
    CITE_RX = r"\[\s*\d+(?:\s*[,–\-]\s*\d+)*\s*\]"
    if re.sub(CITE_RX, "", a_key).replace(" ", "") == \
            re.sub(CITE_RX, "", b_key).replace(" ", ""):
        return ("体例", "", "仅引用编号被拆出文本流", "")
    # 2 仅标点差异
    if re.sub(r"[^A-Za-z0-9]", "", a_key) == re.sub(r"[^A-Za-z0-9]", "", b_key):
        return ("体例", "", "仅标点/符号差异", "")
    # 3 仅引用编号
    if re.sub(r"\[\d+(?:[,–-]\d+)*\]", "", a_key) == \
            re.sub(r"\[\d+(?:[,–-]\d+)*\]", "", b_key):
        return ("体例", "", "仅引用编号差异", "")
    # 3b 仅节号差异（正文块也可能带节号，不只看 region=head）
    if re.sub(r"^\d+(?:\.\d+)*\.?\s*", "", a_key) == b_key or \
            re.sub(r"^\d+(?:\.\d+)*\.?\s*", "", b_key) == a_key:
        return ("体例", "", "节号有无属排版体例", "")
    # 3c 逗号 ↔ and（标准号并列，排版常把 ", " 改成 " and "）
    if re.sub(r"\s*,\s*", " and ", a_key) == re.sub(r"\s*,\s*", " and ", b_key):
        return ("体例", "", "逗号与 and 互换", "")
    # 4 句首大小写
    if a_key and b_key and a_key[0].lower() == b_key[0].lower() and \
            a_key[1:] == b_key[1:]:
        return ("体例", "", "句首大小写", "")

    sm = difflib.SequenceMatcher(None, ta, tb, autojunk=False)
    ops = [o for o in sm.get_opcodes() if o[0] != "equal"]
    sa = [t for o in ops for t in ta[o[1]:o[2]]]
    sb = [t for o in ops for t in tb[o[3]:o[4]]]

    # 4b 公式/上下标排版噪声（否则数学稿会被拆词噪声淹没）
    why = _frac_change(sa, sb, a_raw, b_raw)
    if why:
        return ("体例", "", why, "")

    # 5 增删（必须先于数值判定：一侧为空时「数值不同」只是删/增的结果）
    if not sa and sb:
        return ("实质", "增字", "排版后多出：%s" % " ".join(sb[:12]), " ".join(sb))
    if sa and not sb:
        return ("实质", "删字", "排版后缺失：%s" % " ".join(sa[:12]), " ".join(sa))
    # 6 缩写 ↔ 全称（体例化，只对单侧不超过 6 词的短片段生效）
    if len(sa) <= 6 and len(sb) <= 6 and _acronym_equiv(" ".join(sa), " ".join(sb)):
        return ("体例", "", "缩写与全称互换：%s ↔ %s" % (" ".join(sa), " ".join(sb)), "")
    # 6b 单侧纯缩写、另一侧为其展开（含无括注形式：IoT ↔ Internet of Things）
    for x, y in ((sa, sb), (sb, sa)):
        if _expand_equiv(x, y):
            return ("体例", "", "缩写与全称互换：%s ↔ %s" % (" ".join(x)[:40],
                                                          " ".join(y)[:40]), "")
    # 7 数值变化（先排除 m2/m3/PM2.5 这类上标或小数被拆开的情形）
    if na != nb:
        if "".join(na) == "".join(nb):
            return ("体例", "", "数字断字/写法差异", "")
        big_a = [n for n in na if len(n) > 1]
        big_b = [n for n in nb if len(n) > 1]
        small = set(na) ^ set(nb)
        if big_a == big_b and all(len(x) == 1 for x in small):
            return ("体例", "", "仅上标/小角标数值差异", "")
        return ("实质", "数字", "数值不一致：%s → %s" % ("/".join(na[:6]) or "无",
                                                    "/".join(nb[:6]) or "无"), "")
    # 8 单个专名大小写
    if len(ta) == len(tb) == 1 and ta[0].lower() == tb[0].lower():
        return ("实质", "改字", "专名大小写不一致：%s → %s" % (ta[0], tb[0]), "")
    # 9 词替换
    if len(sa) <= 3 and len(sb) <= 3:
        return ("实质", "改字", "%s → %s" % (" ".join(sa), " ".join(sb)), "")
    return ("实质", "改字", "改写：%s → %s" % (" ".join(sa[:10]), " ".join(sb[:10])), "")


SENT_SPLIT = re.compile(r"(?<=[.!?])[\"')\]]?\s+(?=[A-Z0-9(\[])")
SENT_ABBR = re.compile(r"(?i)\b(fig|figs|tab|tabs|eq|eqs|no|nos|vs|al|ref|refs"
                       r"|approx|ca|cf|resp|sec|sect|vol|pp|p|ch|dr|prof)\.$")


SENT_ENUM_ONLY = re.compile(r"^(?:\(\d{1,2}\)|\d{1,2}[.)]|[a-h][.)]|"
                            r"\([ivx]{1,4}\)|[ivx]{1,4}[.)])$", re.I)
SENT_FLOAT_NO = re.compile(r"(?i)^(table|tab|figure|fig)\.?\s*\d+\.$")


def split_sents(raw):
    """切句；被缩写点号误切（"Fig. 1" / "et al. 2020"）的并回去。"""
    parts = [p.strip() for p in SENT_SPLIT.split(raw or "") if p.strip()]
    out = []
    for p in parts:
        if out and (SENT_ABBR.search(out[-1]) or out[-1].endswith(("e.g.", "i.e."))
                    or SENT_FLOAT_NO.match(out[-1])):
            out[-1] = out[-1] + " " + p
        else:
            out.append(p)
    # PDF 里悬挂的条号（"2." / "(a)"）常单独成行，并入下一句，否则会被当成
    # 删/增一句而把真差异掩盖掉
    merged = []
    pend = ""
    for p in out:
        if SENT_ENUM_ONLY.match(p):
            pend = (pend + " " + p).strip()
            continue
        merged.append((pend + " " + p).strip() if pend else p)
        pend = ""
    if pend:
        merged.append(pend)
    return merged


def _sent_sim(ka, kb):
    wa, wb = words_of(ka), words_of(kb)
    if not wa or not wb:
        return 0.0
    return difflib.SequenceMatcher(None, wa, wb, autojunk=False).ratio()


def _align_sents(ka, kb, gap=0.35):
    """块内句级 DP（Needleman-Wunsch）。

    replace 块内 pa≠pb 时若按位置硬配，会配出「改写：The reconstruction of the
    modern indoor environment… → humidity, and carbon dioxide」这种荒谬对——
    真实原因是排版后多/少了一句（或段落被页界截断），句序整体滑动一格。
    gap=0.35 意味着相似度低于 0.30 的句子宁可不配，落成单侧的漏排/多排。
    """
    n, m = len(ka), len(kb)
    if n == 0 or m == 0:
        return [(i, None) for i in range(n)] + [(None, j) for j in range(m)]
    INF = float("inf")
    dp = [[INF] * (m + 1) for _ in range(n + 1)]
    bk = [[None] * (m + 1) for _ in range(n + 1)]
    dp[0][0] = 0.0
    sim = [[_sent_sim(ka[i], kb[j]) for j in range(m)] for i in range(n)]
    for i in range(n + 1):
        for j in range(m + 1):
            c = dp[i][j]
            if c == INF:
                continue
            if i < n and j < m:
                v = c + (1.0 - sim[i][j])
                if v < dp[i + 1][j + 1]:
                    dp[i + 1][j + 1] = v
                    bk[i + 1][j + 1] = ("pair", i, j)
            if i < n and c + gap < dp[i + 1][j]:
                dp[i + 1][j] = c + gap
                bk[i + 1][j] = ("del", i, None)
            if j < m and c + gap < dp[i][j + 1]:
                dp[i][j + 1] = c + gap
                bk[i][j + 1] = ("ins", None, j)
    out = []
    i, j = n, m
    while i > 0 or j > 0:
        op, a_, b_ = bk[i][j]
        out.append((a_, b_))
        if op == "pair":
            i, j = i - 1, j - 1
        elif op == "del":
            i -= 1
        else:
            j -= 1
    return out[::-1]


def diff_pair(a, b, idx, th=0.70):
    """对一对已对齐段落做**句级**差异。

    token 级 hunk 会在一段里炸出十几条（同一处改动被邻接规则拆碎），
    编辑根本读不下去；按句对齐后一处改动通常只出一条，且能整句复核。
    """
    out = []
    region = a.get("region") or b.get("region") or "body"
    a_raw, b_raw = a.get("text", ""), b.get("text", "")
    if not (a_raw or b_raw):
        return out

    sa_s, sb_s = split_sents(a_raw), split_sents(b_raw)
    ka = [norm_key(s, region) for s in sa_s]
    kb = [norm_key(s, region) for s in sb_s]
    sm = difflib.SequenceMatcher(None, ka, kb, autojunk=False)

    def emit(i, j, forced=None):
        ga = sa_s[i] if i is not None and i < len(sa_s) else ""
        gb = sb_s[j] if j is not None and j < len(sb_s) else ""
        res = forced or judge(ga, gb, norm_key(ga, region), norm_key(gb, region),
                              region)
        if not res or res[0] == "体例":
            return
        res = tuple(res) + ("",) * (4 - len(res))
        lvl, sub, note, frag = res
        if not frag and sub in ("增字", "删字"):
            frag = gb if sub == "增字" else ga
        out.append({
            "id": "C%d" % (idx + len(out) + 1),
            "page": b.get("page") or a.get("page") or 1,
            "loc": ("P%s L%s" % (b.get("page"), b.get("line")) if b.get("page")
                    else "原稿段 %s" % (a.get("i", 0) + 1)),
            "region": region,
            "orig": _clip(ga),
            "typeset": _clip(gb),
            "kind": ("待确认" if lvl == "待确认" else sub),
            "note": note,
            "_chk": (sub, frag),
            "conf": "高" if len(words_of(norm_key(ga, region))) + \
                len(words_of(norm_key(gb, region))) > 2 else "中",
        })

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "delete":
            for i in range(i1, i2):
                if len(words_of(ka[i])) >= 3:
                    emit(i, None, ("实质", "删字", "整句在排版后缺失"))
            continue
        if tag == "insert":
            for j in range(j1, j2):
                if len(words_of(kb[j])) >= 3:
                    emit(None, j, ("实质", "增字", "排版后多出整句"))
            continue
        pa, pb = i2 - i1, j2 - j1
        if pa == pb:
            for k in range(pa):
                emit(i1 + k, j1 + k)
            continue
        for k_a, k_b in _align_sents(ka[i1:i2], kb[j1:j2]):
            gi = i1 + k_a if k_a is not None else None
            gj = j1 + k_b if k_b is not None else None
            if gi is None:
                if len(words_of(kb[gj])) >= 3:
                    emit(None, gj, ("实质", "增字", "排版后多出整句"))
            elif gj is None:
                if len(words_of(ka[gi])) >= 3:
                    emit(gi, None, ("实质", "删字", "整句在排版后缺失"))
            else:
                emit(gi, gj)
    return out


def _clip(s, n=220):
    s = norm_raw(s)
    return s if len(s) <= n else s[:n] + "…"


def _grab(raw, frag):
    """在原文里找到归一化片段大致对应的原始写法（保真展示）。"""
    if not frag:
        return ""
    core = re.sub(r"[^A-Za-z0-9]", "", frag)[:24]
    if not core:
        return frag
    flat = re.sub(r"[^A-Za-z0-9]", "", raw)
    pos = flat.lower().find(core.lower())
    if pos < 0:
        return frag
    # 用原串顺序扫一遍，定位到对应字符区间
    cnt, start, end = 0, None, None
    for k, ch in enumerate(raw):
        if re.match(r"[A-Za-z0-9]", ch):
            if cnt == pos:
                start = k
            if cnt == pos + len(core) - 1:
                end = k + 1
                break
            cnt += 1
    if start is None or end is None:
        return frag
    return raw[max(0, start - 12):min(len(raw), end + 12)]


# ====================== 作者区五项 ======================
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")


def parse_authors_docx(paras):
    """docx 作者区 → 姓名 / 上标编号 / 邮箱 / 机构。

    邮箱与机构常单独成段（region=email / affil），且位于作者段之后，
    所以必须先扫全篇再定型，不能命中作者段就 return。
    """
    auth, emails, affils = None, [], []
    for p in paras:
        r = p.get("region")
        if r == "email":
            t = p.get("text", "")
            got = EMAIL_RE.findall(t)
            if not got:                        # 折行把邮箱拆开时再试去空格
                got = EMAIL_RE.findall(re.sub(r"\s+", "", t))
            emails.extend(got)
        elif r == "affil":
            affils.append(p.get("text", ""))
        elif r == "authors" and auth is None:
            auth = p
    if auth is None:
        return None

    runs = auth.get("runs") or []
    seq, cur_name, cur_marks = [], [], []
    for text, va in runs:
        if va == "superscript":
            cur_marks.append(text.strip())
        else:
            cur_name.append(text)
    # 按逗号/and 切
    joined = "".join(cur_name)
    names = [x.strip() for x in re.split(r",|\band\b", joined) if x.strip()]
    # 机构编号按顺序回填：每个姓名后的上标
    marks = [[] for _ in names]
    mi = 0
    buf = ""
    for text, va in runs:
        if va == "superscript":
            if mi < len(marks):
                marks[mi].extend(re.findall(r"\d+", text))
        else:
            buf += text
            if re.search(r",|\band\b", text) and mi < len(marks) - 1:
                mi += 1
    sup_all = [m for text, va in runs if va == "superscript"
               for m in re.findall(r"\d+", text)]
    star = any("*" in (text or "") and va == "superscript" for text, va in runs)
    return {"names": names, "marks": marks, "sup_all": sup_all,
            "star": star, "raw": auth.get("text", ""),
            "emails": emails, "affils": affils}


def parse_authors_pdf(blocks, page1_blocks):
    auth = [b for b in blocks if b.get("region") == "authors"]
    if not auth:
        return None
    t = auth[0]["text"]
    t2 = re.sub(r"\s+([\d,*\u2020\u2021]+)", r"\1", t)
    parts = [x.strip(" .") for x in re.split(r",|\band\b", t2) if x.strip(" .")]
    names, marks = [], []
    for p in parts:
        m = re.match(r"^(.*?)([\d,*\u2020\u2021]+)$", p)
        if m:
            names.append(m.group(1).strip())
            marks.append(re.findall(r"\d+", m.group(2)))
        else:
            names.append(re.sub(r"[\d,*\u2020\u2021]+$", "", p).strip())
            marks.append([])
    star = "*" in t2
    emails = []
    for b in page1_blocks:
        tx = b.get("text", "")
        if "@" not in tx:
            continue
        got = EMAIL_RE.findall(tx)
        if not got:                            # 折行拆开邮箱时再去空格重试
            got = EMAIL_RE.findall(re.sub(r"\s+", "", tx))
        emails.extend(got)
    affils = [b["text"] for b in page1_blocks if b.get("region") == "affil"]
    return {"names": names, "marks": marks, "star": star, "raw": t,
            "emails": emails, "affils": affils,
            "sup_all": [m for mk in marks for m in mk]}


def surname(name):
    toks = re.findall(r"[A-Za-z][A-Za-z'\-]+", name)
    return toks[0].lower() if toks else name.lower()


def affil_keys(text):
    """机构串 → 可比的集合：去地址尾、去标记、统一大小写。"""
    t = norm_key(text)
    t = re.sub(r"^(?:and\s+)?", "", t)
    t = re.sub(r"\b(ltd|limited|co|inc|gmbh)\b", "", t)
    t = re.sub(r"[^a-z0-9 ]", " ", t.lower())
    return {w for w in t.split() if len(w) > 2}


def norm_email(s):
    return re.sub(r"\s+", "", (s or "")).lower()


def compare_authors(o, p):
    checks = []

    def add(item, ov, pv, status, note):
        checks.append({"item": item, "orig": ov, "typeset": pv,
                       "status": status, "note": note})

    if not o or not p:
        for item in ("通讯作者邮箱", "作者人数", "作者顺序", "姓名拼写", "作者-机构对应"):
            add(item, "—", "—", "未检测", "任一侧未能定位作者区")
        return checks, []

    # 1 通讯邮箱
    eo = sorted({norm_email(e) for e in o["emails"] if e})
    ep = sorted({norm_email(e) for e in p["emails"] if e})
    if not eo or not ep:
        add("通讯作者邮箱", "；".join(eo) or "未取到", "；".join(ep) or "未取到",
            "未检测", "邮箱未能从原稿或校样中取出")
    elif eo == ep:
        add("通讯作者邮箱", "；".join(eo), "；".join(ep), "ok", "")
    else:
        add("通讯作者邮箱", "；".join(eo), "；".join(ep), "不一致",
            "邮箱不同：%s vs %s" % ("；".join(sorted(set(eo) - set(ep))) or "—",
                                   "；".join(sorted(set(ep) - set(eo))) or "—"))

    # 2 人数
    no, np_ = len(o["names"]), len(p["names"])
    if no == np_:
        add("作者人数", str(no), str(np_), "ok", "")
    else:
        add("作者人数", str(no), str(np_), "不一致",
            "原稿 %d 人，校样 %d 人" % (no, np_))

    # 3 顺序（姓氏序列）
    so, sp = [surname(n) for n in o["names"]], [surname(n) for n in p["names"]]
    if so == sp:
        add("作者顺序", " → ".join(so), " → ".join(sp), "ok", "")
    elif sorted(so) == sorted(sp):
        add("作者顺序", " → ".join(so), " → ".join(sp), "不一致", "姓氏集合相同但次序不同")
    else:
        add("作者顺序", " → ".join(so), " → ".join(sp), "未检测",
            "姓氏集合本身不同，顺序无法单列比较（见「姓名拼写」）")

    # 4 姓名拼写（按位比）
    bad = []
    for k, (a, b) in enumerate(zip(o["names"], p["names"])):
        na = re.sub(r"[\s\-.']", "", a).lower()
        nb = re.sub(r"[\s\-.']", "", b).lower()
        if na != nb:
            r = difflib.SequenceMatcher(None, na, nb).ratio()
            if r < 0.85:
                bad.append("%s → %s" % (a, b))
    if not bad:
        add("姓名拼写", "%d 人" % no, "%d 人" % np_, "ok", "")
    else:
        add("姓名拼写", "；".join(o["names"]), "；".join(p["names"]), "不一致",
            "；".join(bad))

    # 5 作者-机构对应
    def marks_ok(auth, affils):
        if not affils:
            return None
        mk = auth.get("marks") or []
        if not any(mk):
            return None
        return {tuple(sorted(set(m))) for m in mk if m}

    mo, mp = marks_ok(o, o["affils"]), marks_ok(p, p["affils"])
    if mo is None or mp is None:
        add("作者-机构对应", "—", "—", "未检测",
            "缺少上标编号或机构行，无法建立对应关系")
    elif mo == mp:
        add("作者-机构对应", "/".join("+".join(t) for t in sorted(mo)),
            "/".join("+".join(t) for t in sorted(mp)), "ok", "")
    else:
        add("作者-机构对应", "/".join("+".join(t) for t in sorted(mo)),
            "/".join("+".join(t) for t in sorted(mp)), "不一致",
            "机构编号组合不同：%s vs %s" % (sorted(mo), sorted(mp)))

    # 机构文本层面（辅助，仅列不一致）
    ao = set().union(*[affil_keys(x) for x in o["affils"]]) if o["affils"] else set()
    ap = set().union(*[affil_keys(x) for x in p["affils"]]) if p["affils"] else set()
    if ao and ap:
        only_o, only_p = ao - ap, ap - ao
        # 只保留像地名/机构名的长词差异，避免介词噪声
        only_o = {w for w in only_o if len(w) >= 5}
        only_p = {w for w in only_p if len(w) >= 5}
        if only_o or only_p:
            checks.append({"item": "机构名称用语", "orig": "、".join(sorted(only_o)) or "—",
                           "typeset": "、".join(sorted(only_p)) or "—",
                           "status": "不一致",
                           "note": "仅原稿有：%s；仅校样有：%s"
                                   % ("、".join(sorted(only_o)) or "—",
                                      "、".join(sorted(only_p)) or "—")})
    return checks, bad


# ====================== 表格（数字流 + 数值集合） ======================
def table_nums(cells):
    s = "".join(cells).replace(SOFT, "")
    s = re.sub(r"https?://\S*|10\.\d{4,}/\S*", " ", s)
    s = re.sub(r"\s+", "", s)
    s = s.replace("-", "")      # 连字符会断号："62.1-2022" 与 "62.12022" 须归一
    return Counter(re.findall(r"\d+\.\d+", s))


def table_digits(cells):
    """整表数字流（只留数字）。PDF 会把单元格折行切碎，逐格比对必然误报；
    按全表数字流比，切碎不影响结果（"1888"+"3-2" 与 "18883-2" 数字流相同）。"""
    s = "".join(cells).replace(SOFT, "")
    s = re.sub(r"https?://\S*|10\.\d{4,}/\S*", " ", s)
    return re.sub(r"\D", "", s)


def diff_tables(otabs, ptabs):
    items = []
    pmap = {}
    for t in ptabs:
        m = re.match(r"(?i)^\s*table\s*(\d+)", t.get("caption") or "")
        if m:
            pmap.setdefault(int(m.group(1)), t)
    for t in otabs:
        no = t["no"]
        pt = pmap.get(no)
        if not pt:
            items.append({"id": "T%d" % no, "page": 0,
                          "loc": "表 %d" % no,
                          "kind": "表格", "region": "table",
                          "orig": "（原稿有表 %d）" % no, "typeset": "未定位到该表",
                          "note": "PDF 中未定位到表 %d，表格数值未逐项核对，建议人工核对"
                                  % no, "conf": "低"})
            continue
        da, db = table_digits(t["cells"]), table_digits(pt["cells"])
        if da == db:
            continue                      # 数字流完全一致：不报，也不进统计
        a, b = table_nums(t["cells"]), table_nums(pt["cells"])
        sa, sb = set(a), set(b)
        def _prefix_variant(x, ys):
            return any(y != x and (y.startswith(x) or x.startswith(y)) for y in ys)

        # 化学式下标粘连：'20.1' 脱掉前导数字后等于 '0.1'
        res_b = set()
        for v in sb - sa:
            if _prefix_variant(v, sa):
                continue
            cand = {v[i:] for i in (1, 2) if len(v) - i >= 3}
            if cand & (sa - sb) or any(re.fullmatch(r"\d+\.\d+", c) and c in sa
                                       for c in cand):
                continue
            res_b.add(v)
        res_a = {v for v in (sa - sb) if not _prefix_variant(v, sb)}

        # PDF 表格被折行切碎、合并单元格被重复展开，逐值核对不可靠 →
        # 一律只作为「需人工核对」提示，不判为实质差异（本 skill 硬规则：
        # 核实为提取假象的不写入产物）。
        gap = abs(len(da) - len(db)) / max(len(da), len(db), 1)
        if res_a or res_b:
            o_col = "、".join(sorted(res_a)[:8]) or "—"
            t_col = "、".join(sorted(res_b)[:8]) or "—"
            note = ("表体数值不完全对应（原稿有/排版后无：%s；排版后有/原稿无：%s）。"
                    "PDF 表格存在折行切分与合并单元格重复展开，此条仅作提示，"
                    "请人工对照原表核对" % (o_col, t_col))
        else:
            o_col, t_col = "%d 位数字" % len(da), "%d 位数字" % len(db)
            if len(da) == len(db):
                note = ("表体数字序列内容不一致（两侧位数相同但数字不同），"
                        "多为 PDF 合并单元格重复展开或表注数字被并入，"
                        "请人工对照原表核对")
            else:
                note = ("表体数字序列长度相差 %.0f%%，多为 PDF 合并单元格重复展开或"
                        "表注数字被并入，请人工对照原表核对" % (gap * 100))
        items.append({"id": "T%d" % no, "page": pt.get("page") or 0,
                      "loc": "表 %d" % no, "kind": "待确认", "region": "table",
                      "orig": o_col, "typeset": t_col, "note": note, "conf": "低"})
    return items


# ====================== 主流程 ======================
SKIP_REGIONS_A = {"ref", "kicker", "affil", "authors", "email"}
SKIP_REGIONS_B = {"ref", "kicker", "affil", "authors", "email"}
FLOAT_REGIONS = {"figcap", "tabcap", "tabnote"}
LABEL_ONLY = re.compile(r"(?i)^(abstract|summary|keywords?|index terms|references?)$")
FLOAT_NO = re.compile(r"(?i)^\s*(table|tab|figure|fig)\.?\s*(\d+)")


def float_key(p):
    m = FLOAT_NO.match(p.get("text", ""))
    if not m:
        return None
    kind = "T" if m.group(1).lower().startswith("tab") else "F"
    return (kind, int(m.group(2)))


def align_floats(Af, Bf):
    """表题/图题按编号配对（体例改写不影响编号）；表注按出现次序配对。"""
    bmap, used = {}, set()
    for j, p in enumerate(Bf):
        k = float_key(p)
        if k and k not in bmap:
            bmap[k] = j
    pairs, left_a = [], []
    for i, p in enumerate(Af):
        k = float_key(p)
        if k and k in bmap and bmap[k] not in used:
            pairs.append((i, bmap[k]))
            used.add(bmap[k])
        else:
            left_a.append(i)
    left_b = [j for j in range(len(Bf)) if j not in used]
    na = [i for i in left_a if Af[i].get("region") == "tabnote"]
    nb = [j for j in left_b if Bf[j].get("region") == "tabnote"]
    for i, j in zip(na, nb):
        pairs.append((i, j))
        used.add(j)
    pair_a = {p[0] for p in pairs}
    pairs.sort()
    return (pairs,
            [i for i in range(len(Af)) if i not in pair_a],
            [j for j in range(len(Bf)) if j not in used])

# 声明区：排版方会按刊物体例重排次序（本案例 PDF 把 Funding 提到 Author
# contributions 之前），按顺序对齐必然两边都落空。声明块以「标签:」开头，
# 标签本身就是稳定主键，改按标签配对。
DECL_LABEL = re.compile(
    r"(?i)^\s*(acknowledg\w*|funding|author contributions?"
    r"|competing interests?|conflicts? of interest|declaration of \w+"
    r"|data availability(?: statement)?|ethics statement"
    r"|use of ai statement|ai tool usage declaration|supplementary material)\b")


def decl_label(text):
    m = DECL_LABEL.match(text or "")
    if not m:
        return None
    s = m.group(1).lower()
    s = re.sub(r"[^a-z ]", "", s)
    return re.sub(r"\s+", " ", s).strip()


def group_decls(lst):
    """把「标签段 + 其后无标签续段」并成一条声明（docx 常把声明拆成多段）。"""
    out, cur = [], None
    for p in lst:
        lab = decl_label(p.get("text"))
        if lab or cur is None:
            cur = {"label": lab, "text": p.get("text", ""),
                   "page": p.get("page"), "line": p.get("line"),
                   "i": p.get("i"), "region": "decl"}
            out.append(cur)
        else:
            cur["text"] = cur["text"] + " " + p.get("text", "")
    return out


def align_decls(Ad, Bd):
    """声明区按标签配对（次序无关）；标签被改写时按内容相似度回配。"""
    A, B = group_decls(Ad), group_decls(Bd)
    la, lb = {}, {}
    for i, p in enumerate(A):
        if p["label"]:
            la.setdefault(p["label"], i)
    for j, p in enumerate(B):
        if p["label"]:
            lb.setdefault(p["label"], j)
    pairs, used_b = [], set()
    for k in sorted(set(la) & set(lb)):
        pairs.append((la[k], lb[k]))
        used_b.add(lb[k])
    left_a = [i for i in range(len(A)) if i not in {p[0] for p in pairs}]
    for i in list(left_a):
        best, bj = 0.0, None
        ka = words_of(norm_key(A[i]["text"]))
        for j in range(len(B)):
            if j in used_b:
                continue
            r = ratio_words(ka, words_of(norm_key(B[j]["text"])))
            if r > best:
                best, bj = r, j
        if bj is not None and best >= 0.45:
            pairs.append((i, bj))
            used_b.add(bj)
            left_a.remove(i)
    pairs.sort()
    return (A, B, pairs, left_a, [j for j in range(len(B)) if j not in used_b])


DECL_NAME_INI = re.compile(r"\b(?:[A-Z]\.\s*){2,}")


def diff_decl_pair(a, b, idx):
    """声明区只核数值（基金号、编号、年份）。

    排版方会把声明里的作者姓名统一改成缩写（Li Jingguang → L.J.）、
    调整大小写与冒号，逐字比对必然全是噪声；声明区的实质在于
    「声明是否齐全 + 基金号/编号是否一致」，因此只比数值。
    """
    out = []
    ka = norm_key(DECL_NAME_INI.sub(" ", a.get("text", "")), "decl")
    kb = norm_key(DECL_NAME_INI.sub(" ", b.get("text", "")), "decl")
    a_key = re.sub(r"(?i)\b(l\.?j|w\.?y|l\.?m|w\.?j)\.", " ", ka)
    b_key = re.sub(r"(?i)\b(l\.?j|w\.?y|m\.?w|w\.?j)\.", " ", kb)
    na, nb = nums_of(a_key), nums_of(b_key)
    if na == nb:
        return out
    out.append({
        "id": "C%d" % (idx + 1),
        "page": b.get("page") or 1,
        "loc": "P%s L%s" % (b.get("page"), b.get("line")),
        "region": "decl",
        "orig": _clip(a.get("text", "")),
        "typeset": _clip(b.get("text", "")),
        "kind": "数字",
        "note": "声明数值不一致：%s → %s" % ("/".join(na[:8]) or "无",
                                            "/".join(nb[:8]) or "无"),
        "conf": "高",
    })
    return out


def _only_junk(t):
    """单侧块是不是「公式编号/残渣」——不是内容，别报成漏排/多排。

    PDF 里公式编号常独立成行（` (14)` / ` (20)`），docx 侧没有对应块，
    会被 align 判成「排版后多排了一段」。这类只看「有没有 ≥4 字母的实词」。
    """
    # Symbol 字体的大括号在文本层是 PUA 字符（\uf0ec 等），先剥掉再判
    t = re.sub(r"[\ue000-\uf8ff]", " ", t or "")
    toks = [w for w in re.split(r"\s+", t.strip()) if w]
    if not toks:
        return True
    if any(len(re.sub(r"[^A-Za-z]", "", w)) >= 4 for w in toks):
        return False
    return len(toks) <= 2 or bool(re.fullmatch(r"[\d\s.,()\[\]\-–—]+", t.strip()))


def run(orig, typeset, th=0.70):
    global ACR_MAP
    ACR_MAP = build_acr_map(orig, typeset)
    # 空块必须按 strip 判：PDF 侧丢掉公式行后常剩「只有空格」的块，
    # 它 truthy 但不是内容，会以「排版后多排了一段空白」的形式混进报告。
    A = [p for p in orig["paras"] if (p.get("text") or "").strip()
         and p.get("region") not in SKIP_REGIONS_A]
    B = [p for p in typeset["paras"] if (p.get("text") or "").strip()
         and p.get("region") not in SKIP_REGIONS_B]
    for p in A:
        p["_key"] = norm_key(p["text"], p.get("region", ""))
    for p in B:
        p["_key"] = norm_key(p["text"], p.get("region", ""))
    A = [p for p in A if p["_key"]]
    B = [p for p in B if p["_key"]]

    # ── 三流拆分 ────────────────────────────────────────────────────
    # 1 浮动对象（表题/图题/表注）排版时脱离正文流、按版面就近安置，
    #   会把一个 docx 长段在 PDF 里切成十几块（本案例 A[23] 640 词被
    #   Table 1/2/3 的表题与表注切成 13 块），远超 DP 的合并能力。
    # 2 声明区排版时会被重排次序（本案例 Funding 被提到 Author
    #   contributions 之前），顺序对齐必然两边落空 → 按标签配。
    # 因此：正文流只放真正文，其余两流各自单独配对。
    def is_decl(p):
        return p.get("region") == "decl" or decl_label(p.get("text")) is not None

    def is_float(p):
        return p.get("region") in FLOAT_REGIONS

    Ad = [p for p in A if is_decl(p)]
    Bd = [p for p in B if is_decl(p)]
    Af = [p for p in A if is_float(p)]
    Bf = [p for p in B if is_float(p)]
    Ab = [p for p in A if not is_decl(p) and not is_float(p)]
    Bb = [p for p in B if not is_decl(p) and not is_float(p)]

    pairs, only_a, only_b = align_paragraphs(Ab, Bb, th)
    fpairs, fonly_a, fonly_b = align_floats(Af, Bf)
    Adg, Bdg, dpairs, donly_a, donly_b = align_decls(Ad, Bd)

    items, unverified = [], []
    for (ia, ib, score, ka, kb) in pairs:
        a, b = _merge(Ab, ia, ka), _merge(Bb, ib, kb)
        low = score < 0.85          # 段界推错时容易出现「低相似度硬配」
        for it in diff_pair(a, b, len(items)):
            if it["kind"] == "待确认" or low:
                it["kind"] = "待确认"
                it["note"] = (it["note"] + "｜" if it["note"] else "") + \
                    "段界对齐置信度低（%.2f），需人工复核" % score
                unverified.append(it)
            else:
                items.append(it)
    for (ia, ib) in fpairs:
        for it in diff_pair(Af[ia], Bf[ib], len(items)):
            if it["kind"] == "待确认":
                unverified.append(it)
            else:
                items.append(it)
    for (ia, ib) in dpairs:
        items.extend(diff_decl_pair(Adg[ia], Bdg[ib], len(items)))
    for i in donly_a:
        a = Adg[i]
        items.append({
            "id": "C%d" % (len(items) + 1), "page": 0,
            "loc": "原稿段 %d" % (a.get("i", 0) + 1), "region": "decl",
            "orig": _clip(a["text"]), "typeset": "（排版后未找到该声明）",
            "kind": "漏排", "note": "原稿该声明在排版后 PDF 中未找到",
            "conf": "中"})
    for j in donly_b:
        b = Bdg[j]
        items.append({
            "id": "C%d" % (len(items) + 1), "page": b.get("page"),
            "loc": "P%s L%s" % (b.get("page"), b.get("line")), "region": "decl",
            "orig": "（原稿无该声明）", "typeset": _clip(b["text"]),
            "kind": "多排", "note": "排版后出现原稿中没有的声明",
            "conf": "中"})

    # 整段缺失/多余：先做全篇回查，确认不是「被拆段/移位」或「落在表格里」
    tab_a = "".join("".join(c for c in t["cells"]) for t in orig.get("tables", []))
    tab_b = "".join("".join(c for c in t["cells"]) for t in typeset.get("tables", []))

    def recover(key, pool, cells):
        core = "".join(words_of(key))[:60]
        if not core:
            return True
        for p in pool:
            if core in "".join(words_of(p["_key"])):
                return True
        flat = "".join(words_of(norm_key(cells)))
        return core in flat

    for i in only_a:
        a = Ab[i]
        if len(words_of(a["_key"])) < 3 or _only_junk(a["text"]):
            continue
        if recover(a["_key"], Bb, tab_b):
            continue
        items.append({
            "id": "C%d" % (len(items) + 1), "page": 0,
            "loc": "原稿段 %d" % (a.get("i", 0) + 1), "region": a.get("region"),
            "orig": _clip(a["text"]), "typeset": "（排版后未找到对应段落）",
            "kind": "漏排",
            "note": "原稿该段在排版后 PDF 中未找到（已核对非拆段/移位、非表内文字）",
            "conf": "中"})
    for j in only_b:
        b = Bb[j]
        if len(words_of(b["_key"])) < 3 or _only_junk(b["text"]):
            continue
        if recover(b["_key"], Ab, tab_a):
            continue
        items.append({
            "id": "C%d" % (len(items) + 1), "page": b.get("page"),
            "loc": "P%s L%s" % (b.get("page"), b.get("line")),
            "region": b.get("region"),
            "orig": "（原稿无对应段落）", "typeset": _clip(b["text"]),
            "kind": "多排",
            "note": "排版后出现原稿中没有的段落（已核对非拆段/移位、非表内文字）",
            "conf": "中"})

    # 浮动对象的落单项：表注（缩写说明类）多为排版方后加的表附属文字，
    # 不逐字比对（表体已按数值集合核过），只报编号化的表题/图题。
    for i in fonly_a:
        a = Af[i]
        items.append({
            "id": "C%d" % (len(items) + 1), "page": 0,
            "loc": "原稿段 %d" % (a.get("i", 0) + 1), "region": a.get("region"),
            "orig": _clip(a["text"]), "typeset": "（排版后未找到对应题注）",
            "kind": "漏排", "note": "原稿该题注在排版后 PDF 中未找到",
            "conf": "中"})
    for j in fonly_b:
        b = Bf[j]
        if b.get("region") == "tabnote":
            continue
        items.append({
            "id": "C%d" % (len(items) + 1), "page": b.get("page"),
            "loc": "P%s L%s" % (b.get("page"), b.get("line")),
            "region": b.get("region"),
            "orig": "（原稿无对应题注）", "typeset": _clip(b["text"]),
            "kind": "多排", "note": "排版后出现原稿中没有的题注",
            "conf": "中"})

    for t in diff_tables(orig.get("tables", []), typeset.get("tables", [])):
        (unverified if t.get("kind") == "待确认" else items).append(t)

    oa = parse_authors_docx(orig["paras"])
    pa = parse_authors_pdf(typeset["paras"],
                           [p for p in typeset["paras"] if p.get("page") == 1])
    checks, _ = compare_authors(oa, pa)

    # ── 假象剔除 ────────────────────────────────────────────────────
    # 增字/删字若在**对侧全文**里能找到，说明只是段落边界推错（同一段被切在
    # 别处），不是真的增删。按本 skill 既有原则，核实为提取假象的不写入产物。
    def flat_of(d):
        return "".join("".join(words_of(norm_key(p.get("text", ""))))
                       for p in d["paras"] if p.get("region") != "kicker")

    fa, fb = flat_of(orig), flat_of(typeset)
    def flat_words(d):
        out = {}
        for p in d["paras"]:
            if p.get("region") == "kicker":
                continue
            for t in words_of(norm_key(p.get("text", ""))):
                out[t] = out.get(t, 0) + 1
        return out

    fa_w, fb_w = flat_words(orig), flat_words(typeset)

    def mostly_present(frag, bag, need=0.85):
        toks = words_of(norm_key(frag))
        if not toks:
            return True
        left = dict(bag)
        hit = 0
        for t in toks:
            if left.get(t, 0) > 0:
                left[t] -= 1
                hit += 1
        return hit / len(toks) >= need

    kept, suppressed = [], 0
    for it in items:
        sub, frag = it.pop("_chk", (None, ""))
        if sub in ("增字", "删字") and frag:
            # 顺序变动的同一句也算：按词袋判断，不按子串
            bag = fa_w if sub == "增字" else fb_w
            if mostly_present(frag, bag):
                suppressed += 1
                continue
        kept.append(it)
    items = kept

    items.sort(key=lambda d: (d.get("page") or 0, d.get("id", "")))
    for k, it in enumerate(items):
        it["id"] = "C%d" % (k + 1)

    # 覆盖率：被配对吃掉的 docx 正文字符 / docx 正文字符总数（只算正文流）。
    # 这是段落级对齐唯一有意义的验收指标——PDF 段落边界是启发式推的，
    # 「配对数」会随版面拆合大幅波动，不能当门槛。
    tot_chars = sum(len(re.sub(r"\s", "", p["text"])) for p in Ab)
    cov_chars = sum(len(re.sub(r"\s", "", _merge(Ab, ia, ka)["text"]))
                    for (ia, ib, _s, ka, _kb) in pairs)
    tot_f = sum(len(re.sub(r"\s", "", p["text"])) for p in Af)
    cov_f = sum(len(re.sub(r"\s", "", Af[i]["text"])) for i, _j in fpairs)

    return {
        "summary": {
            "pairs": len(pairs) + len(fpairs),
            "pairs_body": len(pairs),
            "pairs_float": len(fpairs),
            "pairs_decl": len(dpairs),
            "decl_only_orig": len(donly_a),
            "decl_only_typeset": len(donly_b),
            "only_orig": len(only_a),
            "only_typeset": len(only_b),
            "float_only_orig": len(fonly_a),
            "float_only_typeset": len(fonly_b),
            "diff": len(items),
            "unverified": len(unverified),
            "suppressed": suppressed,
            "auth_bad": sum(1 for c in checks if c["status"] == "不一致"),
            "auth_miss": sum(1 for c in checks if c["status"] == "未检测"),
            "tables_orig": len(orig.get("tables", [])),
            "tables_typeset": len(typeset.get("tables", [])),
            "th_match": th,
            "coverage": round(cov_chars / tot_chars, 4) if tot_chars else 0.0,
            "coverage_float": round(cov_f / tot_f, 4) if tot_f else 0.0,
        },
        "docx": orig.get("path"),
        "pdf": typeset.get("path"),
        "items": items,
        "unverified": unverified,
        "author_check": checks,
        "author_raw": {"orig": oa, "typeset": pa},
    }


def emit_py(res, docx_rev="接受全部修订后的终稿"):
    """把比对结果渲染成可粘进 .py 数据文件的 COMPARE_* 登记块（已废弃，
    仅为兼容保留；正式链路请用 --emit-data 直接落盘 JSON）。

    三块数据的字段顺序必须与报告层严格一致（踩过：emit_py 写 6 元组、
    报告层解 5 元组，结果整表错列）。
    """
    def q(s):
        # 用 json.dumps 转义：除 \ 与 " 外，换行/控制字符/非 ASCII 一并安全处理
        #（旧实现只转义 \ 与 "，含换行的登记块粘进 .py 即语法错误）
        return json.dumps(s or "", ensure_ascii=False)

    s = res["summary"]
    lines = ["COMPARE_META = {"]
    lines.append('    "docx": %s,' % q(res.get("docx", "")))
    lines.append('    "pdf": %s,' % q(res.get("pdf", "")))
    lines.append('    "docx_rev": %s,' % q(docx_rev))
    lines.append('    "coverage": %s,' % s.get("coverage", 0))
    lines.append('    "pairs": %d,' % s.get("pairs_body", 0))
    lines.append('    "suppressed": %d,' % s.get("suppressed", 0))
    lines.append('    "tables": %d,' % s.get("tables_orig", 0))
    lines.append("}")
    lines.append("")
    lines.append("COMPARE_AUTH = [")
    for c in res["author_check"]:
        st = "一致" if c["status"] == "ok" else c["status"]
        lines.append("    (%s, %s, %s, %s, %s)," % (
            q(c["item"]), q(c["orig"]), q(c["typeset"]),
            q(st), q(c.get("note", ""))))
    lines.append("]")
    lines.append("")
    lines.append("COMPARE = [")
    for it in res["items"]:
        note = it.get("note", "")
        kind = it.get("kind", "")
        if kind and not note.startswith(kind):
            note = "%s：%s" % (kind, note)
        lines.append("    (%s, %s, %s, %s, %s)," % (
            q(it["id"]), q(it["loc"]), q(it["orig"]), q(it["typeset"]), q(note)))
    lines.append("]")
    lines.append("")
    lines.append("COMPARE_QUEST = [")
    for k, it in enumerate(res.get("unverified", []), 1):
        lines.append("    (%s, %s, %s)," % (
            q("Q%d" % k), q(it.get("loc", "")), q(it.get("note", ""))))
    lines.append("]")
    return "\n".join(lines)


def emit_data(res, docx_rev="接受全部修订后的终稿"):
    """把比对结果转成 --data 范式的数据结构（dict，落盘交给调用方 json.dump）。

    四组键与 gen_review_html.py 的数据文件字段同名，行结构与 .py 数据文件
    完全同构（JSON 里用数组代替元组，报告层按下标解包）：
      COMPARE_META    {docx, pdf, docx_rev, coverage, pairs, suppressed, tables}
      COMPARE_AUTH    [[核对项, 原稿, 排版后, 状态, 说明], ...]
      COMPARE         [[编号, 位置, 原稿, 排版后, 说明], ...]
      COMPARE_QUEST   [[编号, 位置, 说明], ...]
    字段顺序与报告层严格绑定（同 emit_py 的教训，勿手工调整结构）。
    """
    s = res["summary"]
    meta = {"docx": res.get("docx") or "", "pdf": res.get("pdf") or "",
            "docx_rev": docx_rev, "coverage": s.get("coverage", 0),
            "pairs": s.get("pairs_body", 0), "suppressed": s.get("suppressed", 0),
            "tables": s.get("tables_orig", 0)}
    auth = [[c["item"], c["orig"], c["typeset"],
             ("一致" if c["status"] == "ok" else c["status"]),
             c.get("note", "")] for c in res["author_check"]]
    items = []
    for it in res["items"]:
        note = it.get("note", "")
        kind = it.get("kind", "")
        if kind and not note.startswith(kind):
            note = "%s：%s" % (kind, note)
        items.append([it["id"], it["loc"], it["orig"], it["typeset"], note])
    quest = [["Q%d" % k, it.get("loc", ""), it.get("note", "")]
             for k, it in enumerate(res.get("unverified", []), 1)]
    return {"COMPARE_META": meta, "COMPARE_AUTH": auth,
            "COMPARE": items, "COMPARE_QUEST": quest}


def synthetic_docs():
    """构造一份最小的内存合成样本（全部为虚构 Example 文本），供
    --selftest 在没有真实提取 JSON 时独立运行。

    设计要点：正文段足够长（~150 词）而变异句只占 ~9%，保证段落对齐
    相似度 ≥0.85、差异按"实质"落进 items 而不是被降级成"待确认"。
    """
    body = (
        "The example suspension was stirred continuously and the temperature of "
        "the mixture was kept at 25.0 degrees during the whole measurement "
        "procedure as described below. "
        "Each value is the mean of three independent readings. "
        "The example operator recorded every reading in the laboratory notebook, "
        "checked the calibration status of the example instrument before each run, "
        "and repeated the complete sequence after cleaning the cuvette holder; all "
        "recorded values were then transferred to the example spreadsheet and "
        "compared with the reference curve that had been prepared on the previous "
        "day by the same operator using the same batch of example reagents and the "
        "same analytical procedure."
    )
    # 作者串不用「1,*」这类带逗号的上标——PDF 侧按 ,/and 切分会把 * 单独拆成一段
    authors_text = "Author One 1, Author Two 1 and Author Three 2"
    email_text = "Corresponding author: author.one@example.edu"
    affil_text = "1 Department of Example Science, Beijing 100000, China"
    orig = {
        "path": "<selftest 合成 docx>",
        "paras": [
            {"region": "authors", "page": 1, "text": authors_text,
             "runs": [("Author One", None), ("1", "superscript"), (", ", None),
                      ("Author Two", None), ("1", "superscript"), (" and ", None),
                      ("Author Three", None), ("2", "superscript")]},
            {"region": "email", "page": 1, "text": email_text},
            {"region": "affil", "page": 1, "text": affil_text},
            {"region": "body", "page": 2, "i": 0, "text": body},
        ],
        "tables": [{"no": 1, "cells": ["10.5", "2.5", "3.0"]}],
    }
    typeset = {
        "path": "<selftest 合成 pdf>",
        "paras": [
            {"region": "authors", "page": 1, "text": authors_text},
            {"region": "email", "page": 1, "text": email_text},
            {"region": "affil", "page": 1, "text": affil_text},
            {"region": "body", "page": 2, "text": body},
        ],
        "tables": [{"no": 1, "caption": "Table 1. Example measurements.",
                    "cells": ["10.5", "2.5", "3.0"]}],
    }
    return orig, typeset


def selftest(orig, typeset, th=0.70):
    """内存注入 6 类改动，检查检出能力（正断言：改了一定要看得出来）。

    ⚠️ 变异点必须"真的改到了东西"：早先按 `body_paras(d)[0]` 取第一段、
    再找数字正则，该段恰好没有小数 → 变异空转，用例永远 False，
    看起来像检出能力退化，实际是测试自己没生效。所以这里先 find 再 mutate，
    找不到匹配句就明确标「跳过」，不许静默算失败。
    ⚠️ 变异方向要与 kind 语义一致：judge 以「排版后相对原稿少了/多了」定
    删字/增字，所以 B2 整句删除变异打在**排版侧**（模拟排版漏句），
    打在原稿侧会报成「增字」，断言落空。
    """
    import copy
    base = run(orig, typeset, th)
    cases = []

    def body_paras(d):
        return [p for p in d["paras"]
                if p.get("region") == "body" and len(p.get("text", "")) > 120]

    def inject(label, want, fn, pool="items", side="orig"):
        base_doc = orig if side == "orig" else typeset
        other_doc = typeset if side == "orig" else orig
        o2 = copy.deepcopy(base_doc)
        hit = False
        for p in body_paras(o2):
            if fn(p):
                hit = True
                break
        if not hit:
            cases.append({"case": label, "want": want, "got_some": None,
                          "kinds": ["跳过：样本无匹配句"]})
            return
        pair = (o2, other_doc) if side == "orig" else (other_doc, o2)
        r = run(pair[0], pair[1], th)
        got = [i["kind"] for i in r[pool]]
        cases.append({"case": label, "want": want, "got_some": want in got,
                      "kinds": sorted(set(got))})

    def bump_decimal(p):
        m = re.search(r"(?<![\d.])(\d+)\.(\d+)(?![\d.])", p["text"])
        if not m:
            return False
        new = "%s.%d" % (m.group(1), (int(m.group(2)) + 1) % 10)
        p["text"] = p["text"][:m.start()] + new + p["text"][m.end():]
        return True

    def drop_sentence(p):
        parts = split_sents(p["text"])
        if len(parts) < 3:
            return False
        victim = parts[1]
        if len(victim) < 40 or victim not in p["text"]:
            return False
        p["text"] = re.sub(r"\s+", " ", p["text"].replace(victim, "", 1)).strip()
        return True

    def swap_and(p):
        if " and " not in p["text"]:
            return False
        p["text"] = p["text"].replace(" and ", " or ", 1)
        return True

    def swap_word(p):
        # 注：原变异 and→or 会被 _frac_change 的短词噪声闸门吸收（_sig_tok 只认
        # 带数字或 ≥5 字母的实词，属判定逻辑既有设计），改用等价的实词替换检验"改字"检出
        if " temperature " not in p["text"]:
            return False
        p["text"] = p["text"].replace(" temperature ", " tempreture ", 1)
        return True

    inject("B1 正文数值 0.10→0.11", "数字", bump_decimal)
    inject("B2 整句删除（排版侧漏句）", "删字", drop_sentence, side="typeset")
    inject("B3 实词替换 temperature→tempreture", "改字", swap_word)

    # B4 表格数值改动：PDF 表格只能给「需人工复核」提示，故断言落在 unverified
    o2 = copy.deepcopy(orig)
    hit = False
    if o2.get("tables"):
        cells = o2["tables"][0]["cells"]
        for k, c in enumerate(cells):
            m = re.search(r"\d+\.\d+", c)
            if m:
                cells[k] = c.replace(m.group(0), "9.99", 1)
                hit = True
                break
    if hit:
        r = run(o2, typeset, th)
        got = [i["kind"] for i in r["unverified"]]
        cases.append({"case": "B4 表格数值改动", "want": "待确认",
                      "got_some": "待确认" in got, "kinds": sorted(set(got))})
    else:
        cases.append({"case": "B4 表格数值改动", "want": "待确认",
                      "got_some": None, "kinds": ["跳过：原稿无表"]})

    # B5/B6 作者区专项
    def mut_authors(fn):
        o2 = copy.deepcopy(orig)
        done = fn(o2)
        if not done:
            return None
        r = run(o2, typeset, th)
        return r

    def m_email(d):
        for p in d["paras"]:
            if p.get("region") == "email" and EMAIL_RE.search(p.get("text", "")):
                p["text"] = EMAIL_RE.sub(
                    lambda m: m.group(0).replace("@", "_x@"), p["text"], count=1)
                return True
        return False

    def m_affil(d):
        for p in d["paras"]:
            if p.get("region") == "affil":
                m = re.search(r"(?i)\b(Beijing|Shanghai|Tianjin|Hangzhou|Nanjing|Guangzhou)\b",
                              p.get("text", ""))
                if m:
                    other = "Shanghai" if m.group(1).lower() != "shanghai" else "Beijing"
                    p["text"] = p["text"][:m.start()] + other + p["text"][m.end():]
                    return True
        return False

    for label, mut, want_item, alt in (
            ("B5 通讯作者邮箱改动", m_email, "通讯作者邮箱", None),
            ("B6 机构地名改动", m_affil, "作者-机构对应", "机构名称用语")):
        r = mut_authors(mut)
        if r is None:
            cases.append({"case": label, "want": want_item, "got_some": None,
                          "kinds": ["跳过：样本无匹配字段"]})
            continue
        hit = [c for c in r["author_check"]
               if c["status"] == "不一致" and (c["item"] == want_item
                                               or (alt and c["item"] == alt))]
        cases.append({"case": label, "want": want_item, "got_some": bool(hit),
                      "kinds": [c["item"] + ":" + c["status"] for c in r["author_check"]]})

    ran = [c for c in cases if c["got_some"] is not None]
    return {"baseline": base["summary"], "cases": cases,
            "pass": sum(1 for c in ran if c["got_some"]),
            "total": len(ran), "skipped": len(cases) - len(ran)}


def main():
    ap = argparse.ArgumentParser(description="模式 D 比对器")
    ap.add_argument("--orig")
    ap.add_argument("--typeset")
    ap.add_argument("--out")
    ap.add_argument("--th-match", type=float, default=0.70)
    ap.add_argument("--emit-data", metavar="FILE",
                    help="把 COMPARE_* 四组数据落盘为 JSON，喂给 gen_review_html 的 --data")
    ap.add_argument("--emit-py", action="store_true",
                    help="（已废弃）打印 COMPARE_* 登记块，仅为向后兼容保留")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()

    if a.selftest:
        if a.orig and a.typeset:
            with open(a.orig, encoding="utf-8") as f:
                orig = json.load(f)
            with open(a.typeset, encoding="utf-8") as f:
                typeset = json.load(f)
        else:
            # 独立自检：不依赖任何外部文件，直接用内置合成样本（全虚构 Example 文本）
            print("--selftest：未提供 --orig/--typeset，使用内置合成样本", file=sys.stderr)
            orig, typeset = synthetic_docs()
        st = selftest(orig, typeset, a.th_match)
        print(json.dumps(st, ensure_ascii=False, indent=1))
        sys.exit(0 if st["total"] > 0 and st["pass"] == st["total"] else 1)

    if not (a.orig and a.typeset):
        ap.error("--orig 与 --typeset 必填（--selftest 可省略二者，用内置合成样本）")
    with open(a.orig, encoding="utf-8") as f:
        orig = json.load(f)
    with open(a.typeset, encoding="utf-8") as f:
        typeset = json.load(f)

    res = run(orig, typeset, a.th_match)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
    if a.emit_data:
        with open(a.emit_data, "w", encoding="utf-8") as f:
            json.dump(emit_data(res), f, ensure_ascii=False, indent=1)
        print("emit-data written:", a.emit_data)
    if a.emit_py:
        print("--emit-py 已废弃，请改用 --emit-data（直接落盘 JSON 数据文件）",
              file=sys.stderr)
        print(emit_py(res))
    print(json.dumps({"summary": res["summary"],
                      "items_sample": res["items"][:3],
                      "author_check": res["author_check"]},
                     ensure_ascii=False, indent=1), file=sys.stderr)


if __name__ == "__main__":
    main()

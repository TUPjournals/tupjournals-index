#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
熊猫审读（panda-review）· 模式 D 提取器
======================================
把「排版后 PDF」与「送排版 Word 原稿」分别提取成结构化文本，供 compare_diff.py 比对。

用法：
    python compare_extract.py --docx <原稿.docx> [--pdf <排版后.pdf>] -o <工作目录>
    python compare_extract.py --pdf  <排版后.pdf> [--docx <原稿.docx>] -o <工作目录>

产出（写到 <工作目录>）：
    <tag>_orig.json        docx 侧段落 + 表格 + 警告
    <tag>_typeset.json     PDF 侧段落（带页/区/行号）+ 表格 + 丢弃统计
    <tag>_preflight.json   原稿候选预检（同目录同名副本告警）
    pages/pageNN.png       PDF 页面渲染图（170 dpi）

约定：
    * stdout 只出 JSON 摘要，日志一律走 stderr（禁 2>&1，否则污染 JSON）
    * docx 侧只用标准库（zipfile + xml.etree），不依赖 python-docx
    * 修订痕迹口径：接受全部修订——跳过 w:del / w:moveFrom，保留 w:ins / w:moveTo
"""
import argparse
import json
import os
import re
import sys
import zipfile

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

# 修订口径：这些子树里的文字视为「已删除/非正文」，整棵跳过
SKIP_SUBTREE = {
    W + "del", W + "moveFrom", W + "instrText", W + "commentReference",
    W + "commentRangeStart", W + "commentRangeEnd", W + "proofErr",
    W + "lastRenderedPageBreak", W + "rPr", W + "pPr",
}

INSTITUTION = re.compile(
    r"(?i)\b(university|universiteit|college|school|institute|institution|"
    r"laborator|academy|research cent|research institut|department|faculty|"
    r"centre|center|hospital|corporation|company|limited|ltd|inc\b|gmbh|"
    r"universit[a-z]*|cnrs|academia)"
)
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
AFFIL_MARK = re.compile(r"^\s*(?P<m>\d{1,2}|[a-z])[.)]?\s*(?P<t>\S.*)$")
HEAD_NUM = re.compile(r"^\s*\d+(?:\.\d+)*\.?\s*")
REF_HEAD = re.compile(r"(?i)^\s*(references|reference|bibliography)\s*$")
ABS_HEAD = re.compile(r"(?i)^\s*(abstract|summary)\b")
KW_HEAD = re.compile(r"(?i)^\s*(key\s*words?|index terms)\b")
ACK_HEAD = re.compile(r"(?i)^\s*(acknowledg|funding|author contribution|"
                      r"conflicts? of interest|declaration|data availability|"
                      r"ethics statement|competing interest)")
# 栏头（article type）：iEnergy 用「Original Research Article」，旧式只认
# 「Original Article」，导致栏头被当题名、真题名被当摘要——整篇区域全错位。
KICKER = re.compile(r"(?i)^\s*(?:(?:original|review|research|short|full|brief|"
                    r"technical|regular)\s+){0,2}"
                    r"(?:article|paper|letter|communication|report|perspective|"
                    r"editorial|review)\s*$")
AQ_MARK = re.compile(r"^AQ\d+$")
# 书眉/页脚：iEnergy 版式是「页码 iEnergy | VOL 1| September 2021| 1–5」，
# 横在两栏中间，会被并进正文块，比对时变成「排版后多出 iEnergy | VOL 1…」。
RUNHEAD = re.compile(r"(?i)(\|\s*vol\.?\s*\d+)|(\bvol\.?\s*\d+\b[^|]*\|)")
TABLE_CAP = re.compile(r"(?i)^\s*(table|tab)\.?\s*\d+")
FIG_CAP = re.compile(r"(?i)^\s*(figure|fig)\.?\s*\d+")
TAB_NOTE = re.compile(r"(?i)^\s*(notes?|source|data source|reprinted|adapted)\s*[:.]")
DOI_LIKE = re.compile(r"(?i)^(https?://|doi\b|www\.)")
FOOTER_CELL = re.compile(r"(?i)^(\d{1,4}|https?://\S+|10\.\d{4,}/\S+|doi:?\s*\S*)$")


def log(*a):
    print(*a, file=sys.stderr)


def clean_ws(s):
    s = s.replace("\u00a0", " ").replace("\t", " ")
    s = re.sub(r"[ \u2002\u2003\u2009\u200b]+", " ", s)
    return s.strip()


def _font_base(name):
    """去子集前缀：HRENEE+BentonSansCond-Bold → BentonSansCond-Bold"""
    if not name:
        return ""
    return re.sub(r"^[A-Z]{6}\+", "", name.split(",")[0].strip())


def _style_of(words):
    """一组词的字号/字体（取中位数与出现最多的字体），用于断段判定。"""
    if not words:
        return 10.0, ""
    sizes = sorted(w.get("size", 10.0) for w in words)
    cnt = {}
    for w in words:
        f = _font_base(w.get("fontname"))
        if f:
            cnt[f] = cnt.get(f, 0) + 1
    font = max(cnt.items(), key=lambda kv: kv[1])[0] if cnt else ""
    return sizes[len(sizes) // 2], font


# ======================================================================
# docx 侧
# ======================================================================
def _runs_of(p):
    """产出一个段落内所有 (text, va)；va ∈ {None,'superscript','subscript'}。

    接受全部修订：w:del / w:moveFrom 整棵跳过（其内是 w:delText）。
    """
    out = []

    def walk(el):
        if el.tag in SKIP_SUBTREE:
            return
        if el.tag == W + "r":
            buf = []
            for ch in el:
                if ch.tag == W + "t":
                    buf.append(ch.text or "")
                elif ch.tag == W + "tab":
                    buf.append(" ")
                elif ch.tag == W + "br":
                    buf.append(" ")
            txt = "".join(buf)
            if txt:
                # vertAlign 在 w:rPr 内部，必须递归查（直接子节点只有 w:rPr）
                va = el.find(".//" + W + "vertAlign")
                out.append((txt, va.get(W + "val") if va is not None else None))
            return
        for ch in el:
            walk(ch)

    walk(p)
    return out


def _para(p):
    runs = _runs_of(p)
    text = clean_ws("".join(t for t, _ in runs))
    return {
        "text": text,
        "runs": [[t, va] for t, va in runs if t.strip()],
        "n_sup": sum(1 for _, va in runs if va == "superscript"),
    }


def _cell_texts(tc, warns):
    out = []

    def walk(el):
        for ch in el:
            if ch.tag in SKIP_SUBTREE:
                continue
            if ch.tag == W + "p":
                d = _para(ch)
                if d["text"]:
                    out.append(d["text"])
            elif ch.tag == W + "tbl":
                warns["nested_table"] += 1
                walk(ch)
            else:
                walk(ch)

    walk(tc)
    return clean_ws(" ".join(out))


def parse_docx(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        xml = z.read("word/document.xml")
    warns = {"textbox": 0, "field": 0, "nested_table": 0,
             "grid_span": 0, "v_merge": 0, "comments": 0,
             "n_ins": 0, "n_del": 0, "header_footer": 0}
    raw = xml.decode("utf-8", "replace")
    warns["n_ins"] = raw.count("<w:ins ")
    warns["n_del"] = raw.count("<w:del ")
    warns["textbox"] = raw.count("<w:txbxContent")
    warns["field"] = raw.count("<w:fldSimple") + raw.count("<w:instrText")
    warns["grid_span"] = raw.count("<w:gridSpan")
    warns["v_merge"] = raw.count("<w:vMerge")
    warns["comments"] = raw.count("<w:commentReference")
    warns["header_footer"] = len([n for n in names
                                  if re.search(r"word/(header|footer)\d*\.xml$", n)])

    from xml.etree import ElementTree as ET
    root = ET.fromstring(xml)
    body = root.find(W + "body")

    paras, tables = [], []

    def walk(el):
        for ch in el:
            if ch.tag == W + "p":
                paras.append(_para(ch))
            elif ch.tag == W + "tbl":
                cells, no = [], len(tables) + 1
                for tr in ch.findall(W + "tr"):
                    for tc in tr.findall(W + "tc"):
                        t = _cell_texts(tc, warns)
                        if t:
                            cells.append(t)
                cap = ""
                for pv in reversed(paras):          # 表题 = 紧邻其上的 Table N. 段
                    if TABLE_CAP.match(pv["text"]):
                        cap = pv["text"][:120]
                        break
                tables.append({"no": no, "cells": cells, "caption": cap, "page": 0})
            elif ch.tag == W + "sdt":
                content = ch.find(W + "sdtContent")
                if content is not None:
                    walk(content)
            else:
                walk(ch)

    walk(body)

    return {
        "source": "docx",
        "path": os.path.abspath(path),
        "paras": [dict(d, i=i) for i, d in enumerate(paras)],
        "tables": tables,
        "warnings": warns,
    }


def preflight_docx(docx_path):
    """同目录（含一级子目录）里名字相近的 docx 候选，防「选错原稿」。"""
    d = os.path.dirname(os.path.abspath(docx_path))
    stem = os.path.splitext(os.path.basename(docx_path))[0]

    def name_key(s):
        s = re.sub(r"(?i)(finalfile[-_]?|final[-_]?|waste[-_]?|polish|善峰|"
                   r"clean|highlight|revised)", "", s)
        return re.sub(r"[^A-Za-z0-9]", "", s).lower()

    key = name_key(stem)
    cands = []
    roots = [d] + [os.path.join(d, s) for s in sorted(os.listdir(d))
                   if os.path.isdir(os.path.join(d, s))]
    for root in roots:
        for fn in sorted(os.listdir(root)):
            if not fn.lower().endswith(".docx") or fn.startswith("~$"):
                continue
            if re.match(r"(?i)cover|feedback|response|authorship|license", fn):
                continue
            full = os.path.join(root, fn)
            nk = name_key(os.path.splitext(fn)[0])
            cands.append({
                "path": full,
                "rel": os.path.relpath(full, d),
                "size": os.path.getsize(full),
                "mtime": os.path.getmtime(full),
                "selected": os.path.abspath(full) == os.path.abspath(docx_path),
                "name_key_similar": bool(nk and key and (nk == key or nk in key or key in nk)),
            })
    cands.sort(key=lambda c: -c["mtime"])
    similar = [c for c in cands if c["name_key_similar"]]
    others = [c["rel"] for c in similar if not c["selected"]]
    return {
        "selected": os.path.abspath(docx_path),
        "candidates": cands,
        "similar_others": others,
        "need_confirm": bool(others),
        "note": ("同目录存在名字相近的其他 docx，请确认用的是「送排版」那一版；"
                 "选错会把整条题名/文献差异误报成排版改动" if others else "无相近副本"),
    }


# ======================================================================
# PDF 侧
# ======================================================================
def _in_box(x, y, box, pad=0.0):
    x0, top, x1, bottom = box
    return (x0 - pad) <= x <= (x1 + pad) and (top - pad) <= y <= (bottom + pad)


def _union_boxes(boxes, dilate=0.0):
    """合并相交/相邻的框。dilate 用于把图内零散的线段并成一整块图区。"""
    out = []
    for b in boxes:
        b = (b[0] - dilate, b[1] - dilate, b[2] + dilate, b[3] + dilate)
        placed = False
        for i, o in enumerate(out):
            if not (b[2] < o[0] or b[0] > o[2] or b[3] < o[1] or b[1] > o[3]):
                out[i] = (min(o[0], b[0]), min(o[1], b[1]),
                          max(o[2], b[2]), max(o[3], b[3]))
                placed = True
                break
        if not placed:
            out.append(tuple(b))
    return out


def rail_bbox(page):
    """首页右 rail（Citation / Submitted / Copyright 块）。

    按「线段」而不是「整行」判定：rail 线段起点固定在 x≈437，而正文右栏线段
    起点是 312——两者常共用同一条基线（作者行右侧就是 rail 的 Citation），
    按整行判定会漏掉一半 rail，让 rail 文字混进题名/作者/单位里。
    """
    Wd = page.width
    trig = re.compile(r"(?i)^(citation:|submitted|revised|accepted|copyright|"
                      r"exclusive licensee|creative commons|doi\b)")
    rows = build_rows(page.extract_words())
    segs = []
    for r in rows:
        for s in r["segs"]:
            x0 = min(w["x0"] for w in s)
            if x0 < 0.70 * Wd:
                continue
            segs.append({"top": r["top"], "bottom": r["bottom"],
                         "x0": x0, "x1": max(w["x1"] for w in s),
                         "text": clean_ws(" ".join(w["text"] for w in s))})
    segs.sort(key=lambda d: d["top"])
    trig_idx = [i for i, d in enumerate(segs) if trig.match(d["text"])]
    if not trig_idx:
        return None
    i0 = trig_idx[0]
    lo = hi = i0
    while lo > 0 and segs[lo]["top"] - segs[lo - 1]["top"] < 60:
        lo -= 1
    while hi + 1 < len(segs) and segs[hi + 1]["top"] - segs[hi]["top"] < 60 \
            and segs[hi + 1]["top"] - segs[i0]["top"] < 260:
        hi += 1
    sel = segs[lo:hi + 1]
    return (min(d["x0"] for d in sel) - 4, sel[0]["top"] - 4, Wd,
            max(d["bottom"] for d in sel) + 4)


def graphic_boxes(page, min_area=3000):
    """矢量图/表框：rects+curves+lines+位图 合并后面积够大的盒子，用于屏蔽图内文字。

    ⚠️ 位图（page.images）必须计入：某刊校样实测正文图多为**栅格图**、
    无矢量外框，图内轴标/图例/面板标号因此逃过屏蔽，混进正文块，炸出
    「多排 / 数字不一致」假差异十余条（`Z-average = 85.95 nm`、`Wavenumber (cm-1)`
    之类）。整页背景图（面积 > 60% 页面积）不入表——否则会连正文一起罩住。
    """
    boxes = []
    page_area = page.width * page.height
    img_boxes = []
    for objs in (page.rects, page.curves, page.lines):
        for o in objs:
            try:
                b = (o["x0"], o["top"], o["x1"], o["bottom"])
            except KeyError:
                continue
            if (b[2] - b[0]) * (b[3] - b[1]) < 200:
                continue
            boxes.append(b)
    # 位图单独成框、**不参与矢量框的合并**：一旦合进来，首页图形摘要那张大图会和
    # 周边矢量元素串成一整块（实测 [65,225,558,590]），把图下方的图形摘要说明
    # 一并罩住，比对时误报「原稿摘要段漏排」。
    for o in page.images:
        try:
            b = (o["x0"], o["top"], o["x1"], o["bottom"])
        except KeyError:
            continue
        a = (b[2] - b[0]) * (b[3] - b[1])
        if a < 200 or a > 0.6 * page_area:
            continue
        img_boxes.append(b)
    merged = _union_boxes(boxes, dilate=6.0)
    merged = [b for b in merged if (b[2] - b[0]) * (b[3] - b[1]) >= min_area]
    return merged + img_boxes


def _junk_text(t):
    """这一串文字是不是「不像话」的碎片：书眉页脚、公式残渣、图内轴标。

    ⚠️ 判据必须**保守**：早期用「长词占比 < 0.5」把 `selected as 0.3.`
    （段末短行，3 个 token 里只有 1 个长词）当垃圾丢了，反过来制造出
    「排版漏排 selected as 0.3.」的假差错。现在只用一条硬信号：
    **整串里没有一个 ≥4 字母的正常单词**（`B r ea k D o w n`、`= heat (3)`、
    `(20)`、`500 80 20` 都满足；任何真句子都不满足）。
    """
    t = (t or "").strip()
    if not t:
        return True
    if RUNHEAD.search(t):
        return True
    toks = [w for w in re.split(r"\s+", t) if w]
    # 单/双 token 的行不判垃圾：经费号折行后的 `2-1-ZX)).` 只有一个 token，
    # 按「没有 ≥4 字母词」一刀切会把它删掉，导致声明区凭空报「数值缺失」。
    # 这类残留交给 compare_diff 的非实词过滤去吸收。
    if len(toks) < 3:
        return False
    words = [re.sub(r"[^A-Za-z]", "", w) for w in toks]
    return not any(len(w) >= 4 for w in words)


def _is_junk_row(row):
    """拆栏后的单栏行：碎片文字，或整行都是上下标字号。"""
    if _junk_text(row_text(row)):
        return True
    sizes = [w.get("size") or 10.0
             for seg in row.get("segs", []) for w in seg] or [10.0]
    med = sorted(sizes)[len(sizes) // 2]
    return med < 7.5                    # 整行都是上下标（正文 10.5pt）


def page_words(page, rail, gboxes, keep_tops=(), tbands=()):
    """返回 (words, dropped_counter)。

    过滤：旋转文字 / rail / 表格区 / 图内文字（表题行除外）/ 校样边注 / URL。
    keep_tops 是「表题·图题所在行」的 top，落在这些行上的词即使位于图框内也保留。
    tbands 是表格真实矩形（由横线定界）：只屏蔽矩形内的单元格文字；
    横线以下（表注 Note: / Source: 等）不在矩形内，自然交回正文流——外框常一直
    罩到表注，按外框屏蔽会把表注整段吞掉，进而在比对里报成假「漏排」。
    """
    dropped = {}
    keep = []
    upright = {}
    for c in page.chars:
        upright[(round(c["x0"], 1), round(c["top"], 1), c["text"])] = c.get("upright", True)

    for w in page.extract_words(keep_blank_chars=False,
                                extra_attrs=["size", "fontname"]):
        cx = (w["x0"] + w["x1"]) / 2
        cy = (w["top"] + w["bottom"]) / 2
        # 页脚带（运行刊头/作者行 + DOI + 页码）：正文最末行也止于 0.94Ht 以内，
        # 留着会让「Mgiba and Kolawole 2026 |」混进段首/段尾，制造一串假
        # 「增字 / 改字 / 数字」差异（实测一次 30 页稿炸出 15 条以上）。
        if w["top"] >= 0.94 * page.height:
            dropped["furniture"] = dropped.get("furniture", 0) + 1
            continue
        if not upright.get((round(w["x0"], 1), round(w["top"], 1), w["text"]), True):
            dropped["rotated"] = dropped.get("rotated", 0) + 1
            continue
        if rail and _in_box(cx, cy, rail):
            dropped["rail"] = dropped.get("rail", 0) + 1
            continue
        is_cap = any(abs(w["top"] - t) <= 4 for t in keep_tops)
        hit_tab = None
        if not is_cap:
            for band in tbands:
                if _in_box(cx, cy, band):
                    hit_tab = band
                    break
        if hit_tab is not None:
            dropped["table"] = dropped.get("table", 0) + 1
            continue
        if not is_cap and any(_in_box(cx, cy, b) for b in gboxes):
            dropped["graphic"] = dropped.get("graphic", 0) + 1
            continue
        if AQ_MARK.match(w["text"]) or re.fullmatch(r"AQ\d+", w["text"]):
            dropped["aq"] = dropped.get("aq", 0) + 1
            continue
        if DOI_LIKE.match(w["text"]):
            dropped["url"] = dropped.get("url", 0) + 1
            continue
        keep.append(w)
    return keep, dropped


def find_gutter(words, Wd, Ht):
    """正文纵向区间内找栏缝：覆盖率 <20% 的最长连续 x 带。"""
    if not words:
        return None
    rows = {}
    for w in words:
        if 0.42 * Ht <= w["top"] <= 0.93 * Ht:
            rows.setdefault(round(w["top"] / 2), []).append(w)
    if len(rows) < 5:
        rows = {}
        for w in words:
            rows.setdefault(round(w["top"] / 2), []).append(w)
    if not rows:
        return None
    nrows = len(rows)
    cov = {}
    for ws in rows.values():
        bins = set()
        for w in ws:
            for x in range(int(w["x0"]), int(w["x1"]) + 1):
                bins.add(x)
        for x in bins:
            cov[x] = cov.get(x, 0) + 1
    lo, hi = int(0.34 * Wd), int(0.66 * Wd)
    best, start = None, None
    for x in range(lo, hi):
        ok = cov.get(x, 0) / nrows < 0.20
        if ok and start is None:
            start = x
        if (not ok or x == hi - 1) and start is not None:
            end = x if not ok else x + 1
            if best is None or (end - start) > (best[1] - best[0]):
                best = (start, end)
            start = None
    if not best or (best[1] - best[0]) < 5:
        return None
    return (best[0] + best[1]) / 2.0, best[1] - best[0]


def build_rows(words):
    if not words:
        return []
    hs = sorted(w["bottom"] - w["top"] for w in words)
    med_h = hs[len(hs) // 2]
    tol = max(3.0, 0.40 * med_h)
    ws = sorted(words, key=lambda w: (w["top"], w["x0"]))
    rows, cur, cur_top = [], [], None
    for w in ws:
        if cur_top is None or abs(w["top"] - cur_top) <= tol:
            cur.append(w)
            cur_top = w["top"] if cur_top is None else min(cur_top, w["top"])
        else:
            rows.append(cur)
            cur, cur_top = [w], w["top"]
    if cur:
        rows.append(cur)
    out = []
    for r in rows:
        r = sorted(r, key=lambda w: w["x0"])
        segs, seg = [], [r[0]]
        for a, b in zip(r, r[1:]):
            if b["x0"] - a["x1"] > 14:
                segs.append(seg)
                seg = [b]
            else:
                seg.append(b)
        segs.append(seg)
        size, font = _style_of(r)
        out.append({
            "top": r[0]["top"],
            "bottom": max(w["bottom"] for w in r),
            "x0": min(w["x0"] for w in r),
            "x1": max(w["x1"] for w in r),
            "size": size,
            "font": font,
            "segs": segs,
        })
    return out


def row_text(row):
    return clean_ws(" ".join(w["text"] for w in
                             sorted([w for s in row["segs"] for w in s],
                                    key=lambda w: w["x0"])))


def split_row(row, gutter_x):
    """返回 (span_text|None, left_row|None, right_row|None)。

    * 有线段跨越栏缝 → 通栏（SPAN）
    * 左右各有线段 → 同一基线两栏并排，拆成左、右两条虚拟行
    """
    if gutter_x is None:
        return row_text(row), None, None
    crossing, left, right = [], [], []
    for s in row["segs"]:
        x0 = min(w["x0"] for w in s)
        x1 = max(w["x1"] for w in s)
        if x0 < gutter_x - 2 and x1 > gutter_x + 2:
            crossing.append(s)
        elif x1 <= gutter_x + 2:
            left.append(s)
        else:
            right.append(s)
    if crossing or (not left and not right):
        return row_text(row), None, None
    def mk(segs):
        if not segs:
            return None
        ws = [w for s in segs for w in s]
        size, font = _style_of(ws)      # 必须按本栏自己的词算：
        return {                        # 用整行中位数会把通栏标题的字号冲掉
            "top": row["top"], "bottom": row["bottom"],
            "size": size, "font": font,
            "x0": min(w["x0"] for w in ws), "x1": max(w["x1"] for w in ws),
            "segs": segs,
        }
    return None, mk(left), mk(right)


def assemble(rows_in, col_right):
    """同栏连续行拼段：ragged-right / 大行距 / 字号跳变 / 字体族切换即断段。

    字号与字体族是标题与正文分家的**唯一可靠信号**：本节标题（11pt
    BentonSansCond-Bold）紧贴上一段末行（10pt MinionPro）时，行距和 ragged-right
    都判不出来——末行往往是齐栏的，反而被当成同段续排。
    """
    blocks, buf, prev = [], [], None
    for row in rows_in:
        brk = False
        if prev is not None:
            gap = row["top"] - prev["bottom"]
            med = max(1.0, prev["bottom"] - prev["top"])
            if gap > 1.7 * med:
                brk = True
            fa, fb = prev.get("font") or "", row.get("font") or ""
            if fa and fb and fa != fb:
                brk = True                       # 字体族切换（标题 vs 正文）
            elif abs(row.get("size", 0) - prev.get("size", 0)) >= 0.8:
                brk = True                       # 字号跳变且字体同名
            bold_pair = "bold" in fa.lower() and "bold" in fb.lower()
            ragged = prev["x1"] < (col_right - max(18.0, 2.0 * med))
            indented = row["x0"] > (prev["x0"] + 0.6 * med)
            # 粗体标题折行时首行常是 ragged、次行齐左，会被误判成「上一段结束」，
            # 于是把 "Whether environmental standards meet / human needs" 拆成两块。
            if ragged and not indented and prev["x1"] < col_right - 12 and not bold_pair:
                brk = True
        if brk and buf:
            blocks.append(buf)
            buf = []
        buf.append(row)
        prev = row
    if buf:
        blocks.append(buf)
    return blocks


def _all_names(t):
    """每个逗号段都像人名——比 looks_authors 更严。

    用途：把「作者行」和「单位行」分开。单位行
    `Department of Electrical Engineering, Tsinghua University, Beijing 100084, China`
    的 4 段里有 3 段"像人名"，looks_authors 会判真；但第 1 段开头是小写 of，
    过不了"每段都是人名"这一关，于是能可靠区分。
    """
    if not t or "@" in t:
        return False
    parts = [p.strip() for p in t.split(",") if p.strip()]
    if len(parts) < 2:
        return False
    for p in parts:
        p = re.sub(r"^(and|&)\s+", "", p)
        if not re.fullmatch(r"[A-Z][\w.'\-]*(?:\s+[A-Z][\w.'\-]*){0,3}[\d,*†‡]*", p):
            return False
    return True


def _is_affil(t):
    """单位行判据：含机构词、不是纯人名列表。带不带 `1.` / `a)` 标号都认。"""
    if not t or "@" in t or not INSTITUTION.search(t):
        return False
    return AFFIL_MARK.match(t) is not None or not _all_names(t)


def _header_kind(row):
    t = row_text(row)
    if "@" in t:
        return "email"
    if _is_affil(t):
        return "affil"
    if looks_authors(t):
        return "authors"
    if TABLE_CAP.match(t):
        return "tabcap"
    if FIG_CAP.match(t):
        return "figcap"
    return "text"


def assemble_header(rows):
    """首页顶部（题名/作者/单位/邮箱/摘要）：按语义分行，不按栏切。

    换类型 / 大行距 / 字号跳变 即断块——否则题名会跟作者行粘成一块。
    """
    blocks, buf, prev, prev_k = [], [], None, None
    for row in rows:
        k = _header_kind(row)
        if prev is not None:
            gap = row["top"] - prev["bottom"]
            med = max(1.0, prev["bottom"] - prev["top"])
            if k != prev_k or gap > 1.7 * med or abs(row["size"] - prev["size"]) > 1.5:
                if buf:
                    blocks.append(buf)
                buf = []
        buf.append(row)
        prev, prev_k = row, k
    if buf:
        blocks.append(buf)
    return blocks


def _hrules(page, box=None):
    """页面横线 [(top, x0, x1)]（可限定在 box 内）。

    表格的**真实上下界与左右界只信横线**，不信 table.bbox：text 策略给出的
    列宽常常只覆盖到检测到的列，右侧列（或通栏表头）会落在 bbox 外，
    那些单元格的文字就会漏进正文流，变成 `semi semi` / `of` 这种碎片。
    """
    out = []
    for l in page.lines:
        if abs(l["top"] - l["bottom"]) >= 1.5:
            continue
        if box is not None and not (box[1] - 3 <= l["top"] <= box[3] + 3):
            continue
        out.append((round(l["top"], 1), l["x0"], l["x1"]))
    out.sort()
    return out


def _area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def _ov(b, c):
    """两个矩形的重叠面积。"""
    w = min(b[2], c[2]) - max(b[0], c[0])
    h = min(b[3], c[3]) - max(b[1], c[1])
    return max(0.0, w) * max(0.0, h)


def _clamp_band_to_gboxes(band, gboxes):
    """把「由横线推出的表带」切回图框（真实表/图矩形）。

    本刊表格无竖线 → lines 策略失效 → 降级 text 策略会造出**整页假网格**，
    t.bbox 直接横跨大半页；再拿它去找横线，方程里的分数线/负号（宽 4–20pt）
    也被当成表线，表带一路罩到页脚，把两栏正文大片吞掉（实测因此报出
    21 条假「漏排」）。图框集合在这里是精确的（InDesign 导出的表/图矩形），
    因此只要图框被表带覆盖超过一半，就以图框为准。
    """
    if not gboxes:
        return [band]
    hits = [b for b in gboxes
            if _area(b) > 0 and _ov(band, b) / _area(b) > 0.5]
    if not hits:
        return [band]
    hits.sort(key=lambda b: (b[1], b[0]))
    return [tuple(h) for h in hits]


def extract_tables(page):
    """返回 (tables, boxes, bands)。

    * tables 每个含 cells / box
    * boxes  表格真实矩形（= bands，用于从「图框」集合里剔掉，
             避免外框把表下注当图内文字丢掉）
    * bands  [rect] 表格真实矩形（由横线定界，并用图框校正，不是 table.bbox）

    可信度闸门（本刊表格无竖线，lines 策略基本失效，text 策略会在图上乱造网格）：
      * lines 策略命中且单表 ≥2 行 ≥2 列 → 采信
      * 否则仅当本页出现 `Table N` 表题时才降级到 text 策略
    表题行从单元格中剔除；表注（横线以下）不属表格，交回正文流。
    """
    Wd, Ht = page.width, page.height
    txt = page.extract_text() or ""
    has_cap = bool(re.search(r"(?im)^\s*Table\s*\d+", txt))
    gb = graphic_boxes(page, min_area=2000)
    big = any((b[2] - b[0]) * (b[3] - b[1]) > 0.06 * Wd * Ht for b in gb)
    if not (big or has_cap):
        return [], [], []

    strat = [{"vertical_strategy": "lines", "horizontal_strategy": "lines"}]
    if has_cap:
        strat.append({"vertical_strategy": "text", "horizontal_strategy": "text"})

    best = (0, [], [])
    for st in strat:
        try:
            ts = page.find_tables(st)
        except Exception:  # noqa: BLE001
            ts = []
        payload, bands, n = [], [], 0
        for t in ts:
            rows = t.extract()
            if not rows or len(rows) < 2:
                continue
            if max(len(r) for r in rows) < 2:      # 单列 / 图上假网格
                continue
            top = t.bbox[1]
            first = clean_ws(" ".join(c for c in rows[0] if c))
            if TABLE_CAP.match(first):
                try:
                    top = t.rows[0].bbox[3] + 1
                except Exception:  # noqa: BLE001
                    top = t.bbox[1] + 14
                rows = rows[1:]
            cells = [clean_ws(c) for r in rows for c in r if c and c.strip()]
            if len(cells) < 4:
                continue
            bot = min(t.bbox[3], 0.94 * Ht)      # 截掉页脚带（DOI/页码）
            box = (t.bbox[0], top, t.bbox[2], bot)
            rules = _hrules(page, box)
            if len(rules) >= 2:
                band = (min(r[1] for r in rules) - 2, rules[0][0] - 2,
                        max(r[2] for r in rules) + 2, rules[-1][0] + 2)
            else:
                band = box
            # 假网格校正：表带若罩住了图框，就切回图框（见 _clamp_band_to_gboxes）
            for bd in _clamp_band_to_gboxes(band, gb):
                bands.append(bd)
            # 整页假网格的「单元格」是正文碎片，不能进表格数字流比对；
            # 但矩形仍要保留——屏蔽表格区靠的是 bands，不是 cells
            fake = sum(len(c) for c in cells) > 0.5 * max(1, len(txt))
            payload.append({
                "cells": [] if fake else [c for c in cells if not FOOTER_CELL.match(c)],
                "box": (band[0], band[1], band[2], band[3]),
                "grid_ok": not fake,
            })
            n += 0 if fake else len(cells)
        if n > best[0] or (n == 0 and bands and not best[2]):
            best = (n, payload, bands)
        if n >= 20:
            break
    return best[1], best[2], best[2]


def _overlap_ratio(b, others):
    """b 被 others 覆盖的最大比例。"""
    a = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    if a <= 0:
        return 0.0
    best = 0.0
    for o in others:
        w = min(b[2], o[2]) - max(b[0], o[0])
        h = min(b[3], o[3]) - max(b[1], o[1])
        if w > 0 and h > 0:
            best = max(best, (w * h) / a)
    return best


def parse_pdf(path, outdir):
    import pdfplumber

    pages_out = []
    tables_all = []
    dropped_total = {}
    gutters = []
    os.makedirs(outdir, exist_ok=True)
    pdir = os.path.join(outdir, "pages")
    os.makedirs(pdir, exist_ok=True)

    with pdfplumber.open(path) as pdf:
        for pg in pdf.pages:                      # 统一探栏缝（多页中位数）
            rail = rail_bbox(pg)
            gb = graphic_boxes(pg)
            ws, _ = page_words(pg, rail, gb)
            g = find_gutter(ws, pg.width, pg.height)
            if g:
                gutters.append(g)
        gutter_x = None
        if gutters:
            gx = sorted(g[0] for g in gutters)
            gutter_x = gx[len(gx) // 2]
            log("[gutter] per-page=%d median=%.1f" % (len(gutters), gutter_x))

        for pi, pg in enumerate(pdf.pages, 1):
            rail = rail_bbox(pg)
            gb = graphic_boxes(pg)

            # 表格先探：拿到外框与「真实上下界」，才能把图框/表框/表注分开
            tabs, tboxes, tbands = extract_tables(pg)
            if tboxes:
                # 表格外框从图框里剔除，改由 tbands 按横线屏蔽；
                # 否则外框一直罩到表下 Note:，整段表注会被当图内文字丢掉
                gb = [b for b in gb
                      if _overlap_ratio(b, tboxes) < 0.5 and
                      not any(_overlap_ratio(t, [b]) > 0.9 for t in tboxes)]

            # 表题/图题所在行：即使被图框覆盖也要保留（否则表题会消失）
            keep_tops = []
            for r in build_rows(pg.extract_words(extra_attrs=["size", "fontname"])):
                t = row_text(r)
                if TABLE_CAP.match(t) or FIG_CAP.match(t):
                    keep_tops.append(r["top"])

            ws, dropped = page_words(pg, rail, gb, keep_tops, tbands)
            for k, v in dropped.items():
                dropped_total[k] = dropped_total.get(k, 0) + v

            for t in tabs:
                t["no"] = len(tables_all) + 1
                t["page"] = pi
                # 配表题：表格上方 45pt 内最近的 Table 行
                t["caption"] = ""
                for r in build_rows(pg.extract_words(extra_attrs=["size", "fontname"])):
                    if TABLE_CAP.match(row_text(r)) and \
                            t["box"][1] - 45 <= r["top"] <= t["box"][1] + 3:
                        t["caption"] = row_text(r)[:120]
                tables_all.append(t)

            rows = build_rows(ws)
            units = [split_row(r, gutter_x) for r in rows]

            # 首页顶部「页头区」：出现第一个「左右并排」行之前的全部行。
            # 只有第 1 页有页头（题名/作者/单位/摘要）；其余页按正文处理——
            # 否则图占左栏时右栏正文会被误当页头、按 assemble_header 拆碎。
            head_end = 0
            if pi == 1:
                for i, (span, l, rr) in enumerate(units):
                    if l is not None and rr is not None:
                        head_end = i
                        break
                else:
                    head_end = 0 if gutter_x is None else len(units)

            page_blocks = []

            def emit(txt, zone, top):
                if not txt:
                    return
                if TEXT_NOISE(txt):
                    dropped_total["noise"] = dropped_total.get("noise", 0) + 1
                    return
                page_blocks.append({"page": pi, "zone": zone,
                                    "line": int(top), "text": txt})

            if head_end > 0:
                head_rows = [rows[i] for i in range(head_end)]
                for b in assemble_header(head_rows):
                    emit(clean_ws(" ".join(row_text(r) for r in b)), "HEAD",
                         min(r["top"] for r in b))

            # 正文：SPAN 行切断分带；带内先左栏后右栏
            pend_l, pend_r = [], []

            def flush():
                for zone, pend in (("LEFT", pend_l), ("RIGHT", pend_r)):
                    if not pend:
                        continue
                    col_right = max(r["x1"] for r in pend)
                    for b in assemble(pend, col_right):
                        emit(clean_ws(" ".join(row_text(r) for r in b)), zone,
                             min(r["top"] for r in b))
                    pend.clear()

            for i in range(head_end, len(units)):
                span, l, rr = units[i]
                if span is not None:
                    flush()
                    if _junk_text(span):
                        dropped_total["junk"] = dropped_total.get("junk", 0) + 1
                        continue
                    emit(span, "SPAN", rows[i]["top"])
                else:
                    # 必须在**拆栏之后**判垃圾：整行含右栏图内轴标时，
                    # 整行中位字号会被拉到 6.6pt，把左栏正常正文一起误杀
                    # （实测把「direction, belonging to longitudinal waves.
                    #  Therefore,」整行吃掉，凭空报出一条「排版漏字」）。
                    if l is not None:
                        if _is_junk_row(l):
                            dropped_total["junk"] = dropped_total.get("junk", 0) + 1
                        else:
                            pend_l.append(l)
                    if rr is not None:
                        if _is_junk_row(rr):
                            dropped_total["junk"] = dropped_total.get("junk", 0) + 1
                        else:
                            pend_r.append(rr)
            flush()

            pages_out.extend(page_blocks)
            # 表注定位：紧贴表格下沿 45pt 内、**且篇幅像注不像段**的块
            # （本刊表注常无 Note: 前缀，只写「TC, technical committee; IAQ, ...」
            #   这类缩写说明，通常 1–2 行）
            # 长度闸门不可省：表格下沿紧接正文时，首个正文段落距表底也常在
            # 45pt 内，实测把「The allowable axial load-carrying capacity …」
            # 整段 600 余字标成表注，正文配对随即落空、报出假「漏排」。
            if tbands:
                for b in page_blocks:
                    if len(b["text"]) > 260:
                        continue
                    for band in tbands:
                        if band[3] <= b["line"] <= band[3] + 45:
                            b["zone"] = "TABNOTE"
                            break
            pg.to_image(resolution=170).save(
                os.path.join(pdir, "page%02d.png" % pi), format="PNG")
            log("[page %d] blocks=%d tables=%d dropped=%s"
                % (pi, len(page_blocks), len(tabs), dropped))

    for i, b in enumerate(pages_out):
        b["i"] = i
    return {
        "source": "pdf",
        "path": os.path.abspath(path),
        "pages": len([f for f in os.listdir(pdir) if f.endswith(".png")]),
        "gutter_x": gutter_x,
        "paras": pages_out,
        "tables": tables_all,
        "dropped": dropped_total,
    }


def TEXT_NOISE(t):
    if len(t) <= 3 and not re.search(r"[A-Za-z]{2}", t):
        return True
    if re.fullmatch(r"[\d\s|·.\-–—]+", t):
        return True
    if AQ_MARK.match(t):
        return True
    # 页眉/页脚的作者行：Jingya et al. 2026 | / Wei et al. 12
    t2 = re.sub(r"[\s|·]+$", "", t)
    if re.fullmatch(r"(?i)[A-Z][\w.\-]*(\s+et\s+al\.?)?\s*\|?\s*\d{1,4}", t2):
        return True
    return False


# ======================================================================
# 区域分类（docx / pdf 通用）
# ======================================================================
def looks_authors(t):
    """作者行判据：宁可判不出来（后面会渲染图人工核），也不要误判。

    摘要里逗号很多，只用「≥2 个逗号」会把摘要行判成作者行，导致摘要被逐行拆块。
    """
    if "@" in t or len(t) > 220:
        return False
    if t.count(",") < 2 or re.search(r"[.;:]\s*$", t):
        return False
    # PDF 会把上标拆成独立词，产生 "Jingya 1 ," 这种空格；先并回去再判
    t = re.sub(r"\s+([\d,*†‡]+)", r"\1", t)
    t = re.sub(r"\s+([,;])", r"\1", t)
    parts = [p.strip() for p in t.split(",") if p.strip()]
    if len(parts) < 2:
        return False
    nameish = 0
    for p in parts:
        p = re.sub(r"^(and|&)\s+", "", p)
        if re.fullmatch(r"[A-Z][\w.'\-]*(?:\s+[A-Z][\w.'\-]*){0,3}[\d,*†‡]*", p):
            nameish += 1
    return nameish >= max(2, int(0.7 * len(parts)))


def classify(items, source):
    """items: [{'text':...}]，按阅读顺序给每个块打 region。"""
    n = len(items)
    regions = ["body"] * n
    i = 0
    while i < n and (not items[i]["text"] or KICKER.match(items[i]["text"])):
        regions[i] = "kicker"
        i += 1
    if i < n:
        regions[i] = "title"
        i += 1
    if i < n and looks_authors(items[i]["text"]):
        regions[i] = "authors"
        i += 1
    while i < n and _is_affil(items[i]["text"] or ""):
        regions[i] = "affil"
        i += 1
    for j in range(i, min(n, i + 3)):
        if "@" in (items[j]["text"] or ""):
            regions[j] = "email"

    state = "pre_abs"
    for j in range(i, n):
        t = items[j]["text"] or ""
        if not t or regions[j] == "email":
            continue
        if REF_HEAD.match(t):
            for k in range(j, n):
                regions[k] = "ref"
            break
        if ABS_HEAD.match(t):
            regions[j] = "abstract"
            state = "abs"
            continue
        if KW_HEAD.match(t):
            regions[j] = "kw"
            state = "body"
            continue
        if ACK_HEAD.match(t):
            regions[j] = "decl"
            state = "decl"
            continue
        if state == "decl":
            # 声明区一旦开始就整段归 decl：docx 里「Author Contributions」
            # 常拆成「标题 + 3 个无标签续段」，不整段归入就会拿续段去和
            # 正文配对，凭空生出「改写/删字」。
            regions[j] = "decl"
            continue
        if regions[j] != "body":
            continue
        if TABLE_CAP.match(t):
            regions[j] = "tabcap"
            continue
        if FIG_CAP.match(t):
            regions[j] = "figcap"
            continue
        if TAB_NOTE.match(t):
            regions[j] = "tabnote"
            continue
        # 节号开头的行一律按标题处理：章标题常超 8 词
        # （"2.1 Propagation characteristics of pulse discharge pressure waves in oil"），
        # 走下面的 is_head（≤8 词）会被判成正文，于是 docx 的标题段落和 PDF 的
        # 标题块配不上，标题文字被算进正文，凭空报「排版后多出 2.2」。
        if re.match(r"^\d+(?:\.\d+)*\.?\s+[A-Z]", t) and \
                len(t.split()) <= 18 and not re.search(r"[.;:]\s*$", t):
            regions[j] = "head"
            state = "body"
            continue
        # 标题行判定必须在摘要状态之前，否则摘要会一路吞到文末
        is_head = (len(t.split()) <= 8 and re.match(r"^[A-Z0-9]", t)
                   and not re.search(r"[.;:]\s*$", t) and t.count(",") < 2)
        if is_head:
            regions[j] = "head"
            state = "body"
            continue
        if state == "abs":
            regions[j] = "abstract"
            continue
        if state == "pre_abs":
            # PDF 摘要常无 ABSTRACT 标签：紧接邮箱区之后的第一段即摘要
            regions[j] = "abstract"
            state = "abs"
            continue
        regions[j] = "body"
    return regions


def attach_regions(data):
    items = data["paras"]
    regs = classify([{"text": p.get("text", "")} for p in items], data["source"])
    for p, r in zip(items, regs):
        # 位置判定的表注优先于文本分类，但表题/图题仍按编号走
        if p.get("zone") == "TABNOTE" and r not in ("tabcap", "figcap", "ref"):
            r = "tabnote"
        p["region"] = r
    return stitch_continuations(data)


# ======================================================================
# PDF 段落续接：同一逻辑段落在 PDF 里常被栏缝/页界/浮动对象截成两三块
# ======================================================================
SENT_END = re.compile(r'[.!?:;\"\'”’）)\]]\s*$|\u2014\s*$')
CONT_START = re.compile(r'^[a-z0-9(\[\u201c\u2018]')
# 前块以数字/逗号收尾时，续块以大写开头也属正常续接：
# 「…such as ISO 16000-28:2020」+「Indoor air — Part 28: …」（标准名整体另起一行）
CONT_PREV = re.compile(r"[\d,]\s*$")


def stitch_continuations(data, max_skip=8):
    """把「未以句末标点收尾」的正文块与后续块并回去。

    PDF 里一个 docx 长段会被切成多块（跨栏、跨页、或中间插进表题/图题/表注），
    不并回去会造成两连击：① 段落级对齐硬配 → 相似度骤降；② 句级对齐按位置
    错配 → 报出一批「改写：A → 完全无关的 B」假差异。

    只在 PDF 侧做（docx 段落本就是完整的）；表题/图题/表注允许被跨越，
    因此「续块」不要求紧邻。收尾判据用标点，续块首字符必须是
    小写字母/数字/左括号——句首大写的正常新段不会被误并。
    """
    if data.get("source") != "pdf":
        return data
    ps = data["paras"]
    BODY = ("body", "abstract")
    i, merged = 0, 0
    while i < len(ps):
        cur = ps[i]
        if cur.get("region") not in BODY:
            i += 1
            continue
        t = (cur.get("text") or "").rstrip()
        if not t or SENT_END.search(t):
            i += 1
            continue
        j = i + 1
        while j < len(ps) and j - i <= max_skip and \
                ps[j].get("region") not in BODY:
            j += 1
        if j >= len(ps) or j - i > max_skip:
            i += 1
            continue
        nt = (ps[j].get("text") or "").lstrip()
        if not nt:
            i += 1
            continue
        if not CONT_START.match(nt) and not CONT_PREV.search(t):
            i += 1
            continue
        # 链条闸门：① 单段合并后不得超 3600 字符（正常正文段远小于此，
        # 超限必是跨段误并，实测出现 10635 字符的巨块，把整页正文吞进去，
        # 导致对侧段落全部失配、报成「漏排」）；② 续块与当前块跨页不得超 1 页。
        if len(t) + len(nt) > 3600:
            i += 1
            continue
        if (ps[j].get("page") or 0) - (cur.get("page") or 0) > 1:
            i += 1
            continue
        # 行末连字符：保留连字符直接相连（"cross-" + "system"→"cross-system"），
        # 归一化层会把连字符全部剥掉，因此这里不需要猜是不是断字
        sep = "" if t.endswith("-") else " "
        cur["text"] = t + sep + nt
        cur["_stitched"] = cur.get("_stitched", 0) + 1
        del ps[j]
        merged += 1
        # 合并后可能仍是半句（三块以上），不回退 i，继续拼
    if merged:
        log("[stitch] PDF 段落续接合并 %d 处" % merged)
    for k, b in enumerate(ps):
        b["i"] = k
    data["stitched"] = merged
    return data


# ======================================================================
def main():
    ap = argparse.ArgumentParser(description="模式 D 提取器（docx / pdf）")
    ap.add_argument("--docx")
    ap.add_argument("--pdf")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--tag")
    a = ap.parse_args()
    if not a.docx and not a.pdf:
        print(__doc__.strip())
        sys.exit(2)

    os.makedirs(a.out, exist_ok=True)
    tag = a.tag or os.path.splitext(os.path.basename(a.docx or a.pdf))[0]
    summary = {"out": os.path.abspath(a.out), "tag": tag}

    if a.docx:
        data = attach_regions(parse_docx(a.docx))
        fp = os.path.join(a.out, tag + "_orig.json")
        with open(fp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        pf = preflight_docx(a.docx)
        with open(os.path.join(a.out, tag + "_preflight.json"), "w", encoding="utf-8") as f:
            json.dump(pf, f, ensure_ascii=False, indent=1)
        summary["orig"] = {
            "json": fp,
            "paras": len(data["paras"]),
            "nonempty": sum(1 for p in data["paras"] if p["text"]),
            "tables": len(data["tables"]),
            "warnings": data["warnings"],
            "regions": {r: sum(1 for p in data["paras"] if p["region"] == r)
                        for r in sorted(set(p["region"] for p in data["paras"]))},
            "preflight_need_confirm": pf["need_confirm"],
            "preflight_similar_others": pf["similar_others"],
        }
        if pf["need_confirm"]:
            log("[!!] 同目录存在相近副本，需向用户确认原稿：%s" % pf["similar_others"])

    if a.pdf:
        data = attach_regions(parse_pdf(a.pdf, a.out))
        fp = os.path.join(a.out, tag + "_typeset.json")
        with open(fp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        summary["typeset"] = {
            "json": fp,
            "pages": data["pages"],
            "blocks": len(data["paras"]),
            "tables": len(data["tables"]),
            "gutter_x": data["gutter_x"],
            "dropped": data["dropped"],
            "regions": {r: sum(1 for p in data["paras"] if p["region"] == r)
                        for r in sorted(set(p["region"] for p in data["paras"]))},
        }

    print(json.dumps(summary, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()

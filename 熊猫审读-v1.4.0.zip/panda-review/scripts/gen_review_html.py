# -*- coding: utf-8 -*-
"""
熊猫审读 · 模式 B（修改意见 HTML）生成器 —— --data 外部数据文件范式
==================================================================
用法：把审读结果登记进一个**外部**数据文件（.py 或 .json），然后运行：
    python gen_review_html.py --data <数据.py|数据.json> [--data <比对数据.json>] [--out <输出.html>]

⚠️ 技能目录内的脚本保持只读：数据一律放工作区/临时目录的数据文件，
   不要再编辑本文件顶部的示例数据区（示例仅演示字段格式）。
   --data 可多次传入（如审读登记 + compare_diff --emit-data 产出的比对数据），
   后面的文件覆盖前面的同名字段；未在数据文件中给出的分节一律按空处理，
   不会混入本文件内置示例。

产出：与模板内置版式同款的自包含单文件 HTML：
    统计卡 + 锚点导航 + ①按页分组差错主表（编号/位置/原文/差错说明/修改建议 + 类别色徽章）
    ②润色建议 ③待确认 ④差错构成小结。
不含差错类型码与扣分；经取证核实为 PDF 提取假象/误报的问题一律不登记、不出现（无假象区块）。
全量 html.escape，特殊字符安全。

数据文件字段（.py 写成同名变量，.json 写成同名键；校验见 scripts/data_io.py）：
  META:   {manuscript_id, title, kicker, description, warn_note, out_path}
  GROUPS: [(组标题, [(编号, 位置, 原文摘录, 差错说明, 修改建议, 类别), ...]), ...]
          类别 ∈ {"关键","语法","表述","格式","文献"}
  SUGG:   [(编号, 位置, 问题, 建议), ...]                      （润色建议，非硬错）
  QUEST:  [(编号, 位置, 待确认内容), ...]
  模式 D 四组（不做 D 时缺省即可，整节自动不渲染）：
  COMPARE_META / COMPARE_AUTH / COMPARE / COMPARE_QUEST
"""
import argparse
import html
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data_io import merge_data, validate_html, HTML_FIELDS  # noqa: E402

def esc(t):
    return html.escape(t, quote=True)

# ======================= 示例数据区（只读，勿改） =======================
# ⚠️ 下面全部是【只读示例】，用虚构稿件/引文演示字段格式与徽章分类。
#    实际使用时把数据登记进外部数据文件，用 --data 传入，不要改这里。
META = {
    "manuscript_id": "EXAMPLE-2026-0001",     # 稿件号 / 刊名标签
    "title": "全文通读修改意见",              # 页面主标题
    "kicker": "期刊投稿 · 编辑加工意见",       # 页眉小标签
    "description": ("稿件《An example article title for demonstration》逐段修改意见"
                    "（示例数据，10 页双栏全文通读）。每项均给出所在位置、原文摘录、"
                    "差错说明与可直接执行的修改建议。"),
    "warn_note": ("重点提醒：#2 与 #3 指向同一处数据矛盾（第 4 页正文数值与第 6 页表格不一致），"
                  "修改时必须两处一起核对，建议优先处理。"),
    "out_path": "review.html",
}

# ---- 差错主表（按页分组）----
GROUPS = [
    ("第 1 页", [
        ("1", "P1 右栏 L82", "...increased from 9.6% to 19.9% . Their study...",
         "\"%\" 与 \".\" 之间多空格（高倍渲染确认真实排版差错，非提取假象）",
         "...to 19.9%. Their study...", "格式"),
    ]),
    ("第 4 页", [
        ("2", "P4 左栏 L382",
         "The maximum efficiency is achieved at 13.7 m/s, corresponding to a rate of 46.4%.",
         "关键事实/逻辑矛盾：同一工况在第 6 页表中效率写作 26.6%，两处必有一处错",
         "请作者核实：① 若表中数值正确，正文改为 26.6%；② 若正文正确，表中数值与结论需同步修订",
         "关键"),
    ]),
    ("参考文献", [
        ("3", "[35] P9 右栏 L1250",
         "Smith, J. C., Doe, A., Roe, B., \"J\" Lee, C. J. (2021). Example paper title. "
         "J. Example Stud. 908, A6.",
         "著录严重错误：① 4 位作者缺 & 连接；② \"J\" 昵称引号残留；③ 首作者多余中间名 C（示例条目）",
         "Smith, J., Doe, A., Roe, B. & Lee, C. J. (2021). ... J. Example Stud. 908, A6.", "文献"),
    ]),
]

# ---- 润色建议（非硬错）----
SUGG = [
    ("S1", "P1 摘要",
     "\"the duration reaching 7.3 h\" 与 \"the rates ranging from 17.2% to 46.4%\" 并列于同一 "
     "\"corresponding\" 短语下，但两组数据分属不同工况（示例）",
     "分两句表述，分别注明各自的工况条件"),
]

# ---- 待作者确认 ----
QUEST = [
    ("Q3", "P4 L382 / P6 表 1", "正文 46.4% 与表中 26.6% 的矛盾（见差错 #2）"),
]

# ---- 模式 D：原稿比对（不做模式 D 时 COMPARE_META 保持 None，全段自动不渲染）----
# COMPARE_META = {"docx": "…edi.docx", "pdf": "…typeset.pdf", "coverage": 1.0,
#                 "pairs": 20, "suppressed": 18, "tables": 3}
COMPARE_META = None

# 作者区核对：(核对项, 原稿, 排版后, 状态, 说明)；状态 ∈ {"一致","不一致","未检测"}
# 报告只列「不一致」项；全一致时用一句话带过。
COMPARE_AUTH = [
    # ("通讯作者邮箱", "corresponding@example.edu", "corresponding@example.edu", "一致", ""),
]

# 差异明细：(编号, 位置, 原稿, 排版后, 说明)
COMPARE = [
    # ("D1", "P2 左栏", "…China, USA, European, and WHO…", "…China, USA, Europe, and WHO…",
    #  "改字：European → Europe（排版后改了用词，需编辑确认）"),
]

# 原稿比对里需人工复核的项（表体数字流不一致等）：(编号, 位置, 说明)
COMPARE_QUEST = [
    # ("Q4", "表 2 P4", "表体数字序列长度不一致，请人工对照原表"),
]

# ======================= 以下为模板（一般无需改动） =======================
CAT_COLOR = {"关键": "#D64545", "语法": "#D97B29", "表述": "#0E7C74",
             "格式": "#4A6FA5", "文献": "#7A5AF8", "": "#888888"}


def cat_badge(c):
    col = CAT_COLOR.get(c, "#888888")
    return f'<span class="badge" style="color:{col};border-color:{col}">{esc(c)}</span>'


LEGEND_TEXT = {"关键": "事实/逻辑矛盾", "语法": "主谓/语态/句构", "表述": "措辞/术语/用词",
               "格式": "空格/标点/单位", "文献": "参考文献著录"}


def legend_html():
    """类别图例：一行徽章 + 短语。"""
    out = []
    for c, d in LEGEND_TEXT.items():
        col = CAT_COLOR[c]
        out.append(f'<span class="badge" style="color:{col};border:1px solid {col};'
                   f'display:inline-block;font-size:11px;padding:1px 8px;'
                   f'border-radius:999px;font-weight:600">{esc(c)}</span>&nbsp;{esc(d)}')
    return "　".join(out)


def err_table(rows):
    out = []
    for (no, loc, quote, issue, fix, cat) in rows:
        out.append(f"""
<tr>
  <td class="c-no">{esc(no)}</td>
  <td class="c-loc">{esc(loc)}</td>
  <td class="c-q">{esc(quote)}</td>
  <td class="c-issue">{cat_badge(cat)}<div class="celltext">{esc(issue)}</div></td>
  <td class="c-fix">{esc(fix)}</td>
</tr>""")
    return "\n".join(out)


def sugg_table(rows):
    out = []
    for (no, loc, issue, fix) in rows:
        out.append(f"""
<tr>
  <td class="c-no">{esc(no)}</td>
  <td class="c-loc">{esc(loc)}</td>
  <td class="c-issue"><div class="celltext">{esc(issue)}</div></td>
  <td class="c-fix">{esc(fix)}</td>
</tr>""")
    return "\n".join(out)


def quest_table(rows):
    out = []
    for (no, loc, q) in rows:
        out.append(f"""
<tr>
  <td class="c-no">{esc(no)}</td>
  <td class="c-loc">{esc(loc)}</td>
  <td class="c-issue"><div class="celltext">{esc(q)}</div></td>
</tr>""")
    return "\n".join(out)


def cmp_table(rows):
    """原稿 / 排版后 左右对照。"""
    out = []
    for (no, loc, o, t, note) in rows:
        out.append(f"""
<tr>
  <td class="c-no">{esc(no)}</td>
  <td class="c-loc">{esc(loc)}</td>
  <td class="c-o"><div class="celltext">{esc(o)}</div></td>
  <td class="c-t"><div class="celltext">{esc(t)}</div></td>
  <td class="c-issue"><div class="celltext">{esc(note)}</div></td>
</tr>""")
    return "\n".join(out)


def cmp_auth_table(rows):
    out = []
    for (item, o, t, status, note) in rows:
        col = "#D64545" if status == "不一致" else "#0E7C74"
        out.append(f"""
<tr>
  <td class="c-no">{esc(item)}</td>
  <td class="c-o"><div class="celltext">{esc(o)}</div></td>
  <td class="c-t"><div class="celltext">{esc(t)}</div></td>
  <td class="c-issue"><span class="badge" style="color:{col};border-color:{col}">{esc(status)}</span>
    <div class="celltext">{esc(note)}</div></td>
</tr>""")
    return "\n".join(out)


def build_page():
    err_total = 0
    sec_err = []
    for title, rows in GROUPS:
        err_total += len(rows)
        sec_err.append(f"""
<section class="gsec">
  <h3 class="gtitle">{esc(title)} <span class="gcnt">{len(rows)} 项</span></h3>
  <table class="tbl">
    <thead><tr><th style="width:3%">#</th><th style="width:9%">位置</th><th style="width:30%">原文</th><th style="width:27%">差错说明</th><th style="width:31%">修改建议</th></tr></thead>
    <tbody>{err_table(rows)}</tbody>
  </table>
</section>""")

    n_key = sum(1 for _, rows in GROUPS for r in rows if r[5] == "关键")
    n_gram = sum(1 for _, rows in GROUPS for r in rows if r[5] == "语法")
    n_expr = sum(1 for _, rows in GROUPS for r in rows if r[5] == "表述")
    n_fmt = sum(1 for _, rows in GROUPS for r in rows if r[5] == "格式")
    n_ref = sum(1 for _, rows in GROUPS for r in rows if r[5] == "文献")

    # ── 模式 D：原稿比对（未启用时整段不渲染）──
    cmp_on = COMPARE_META is not None
    warn = (f'\n  <div class="warn-note"><b>⚠ {esc(META["warn_note"])}</b></div>'
            if META.get("warn_note") else "")
    auth_bad = [r for r in COMPARE_AUTH if r[3] == "不一致"]
    auth_ok = len(COMPARE_AUTH) - len(auth_bad)
    cmp_n = len(COMPARE)

    # 章节号动态编号：只做模式 D 时它就是「一、原稿比对」，
    # 不能硬编码「五」——否则单独出 D 报告会出现「五、」打头、前面全是空号。
    CN = "一二三四五六"
    sec_no, sec_ar, _k = {}, {}, 0
    for _key, _present in (("err", bool(GROUPS)), ("sugg", bool(SUGG)),
                           ("quest", bool(QUEST)),
                           ("sum", bool(GROUPS or SUGG or QUEST)), ("cmp", cmp_on)):
        if _present:
            _k += 1
            sec_no[_key] = CN[_k - 1]
            sec_ar[_key] = str(_k)
    n_cmp = sec_no.get("cmp", "")
    n_cmp_ar = sec_ar.get("cmp", "")

    if cmp_on:
        m = COMPARE_META
        if auth_bad:
            auth_html = f"""
  <table class="tbl narrow">
    <thead><tr><th style="width:16%">核对项</th><th style="width:26%">原稿</th><th style="width:26%">排版后</th><th style="width:32%">说明</th></tr></thead>
    <tbody>{cmp_auth_table(auth_bad)}</tbody>
  </table>"""
        else:
            auth_html = (f'\n  <p class="lead">作者区 {len(COMPARE_AUTH)} 项核对'
                         f'（通讯作者邮箱、作者人数、作者顺序、姓名拼写、作者-机构对应）'
                         f'<b>全部一致</b>，无差异项。</p>')
        cmp_html = f"""
  <h2 class="sec" id="s-cmp">{n_cmp}、原稿比对（{cmp_n} 项差异）</h2>
  <p class="lead">比对对象：送排版原稿 <span class="cmp-path">{esc(m.get("docx", ""))}</span> ↔ 排版文件
    <span class="cmp-path">{esc(m.get("pdf", ""))}</span>。仅做<b>字符级</b>比较，不做格式级与图片级比较；
    大小写、标点、连字符、引用编号、节号、英文数词与阿拉伯数字、序号体系、缩写与全称互换等
    <b>体例性变化已全部吸收</b>，下表只列实质差异。正文覆盖率 {m.get("coverage", 1):.0%}。</p>

  <h3 class="gtitle">{n_cmp_ar}.1 作者区核对（实质性比较，非字面比较）</h3>{auth_html}

  <h3 class="gtitle">{n_cmp_ar}.2 逐字比对差异（{cmp_n} 项）</h3>
  <table class="tbl">
    <thead><tr><th style="width:3%">#</th><th style="width:9%">位置</th><th style="width:30%">原稿</th><th style="width:30%">排版后</th><th style="width:28%">说明</th></tr></thead>
    <tbody>{cmp_table(COMPARE)}</tbody>
  </table>

  <h3 class="gtitle">{n_cmp_ar}.3 原稿比对中需人工复核的事项（{len(COMPARE_QUEST)} 项）</h3>
  <table class="tbl narrow">
    <thead><tr><th style="width:5%">#</th><th style="width:12%">位置</th><th style="width:83%">待复核内容</th></tr></thead>
    <tbody>{quest_table(COMPARE_QUEST)}</tbody>
  </table>
"""
        cmp_nav = '<a href="#s-cmp">原稿比对</a>'
        cmp_row = (f'\n      <tr><td class="c-loc">原稿比对差异（模式 D）</td>'
                   f'<td>{cmp_n} 项（详见「原稿比对」一节；另需人工复核 '
                   f'{len(COMPARE_QUEST)} 项）</td></tr>')
        cmp_foot = ("另经模式 D 与原稿（送排版 Word）逐字比对，"
                    "仅比字符级内容，作者区 5 项实质核对已通过。")
    else:
        cmp_html = ""
        cmp_nav = ""
        cmp_row = ""
        cmp_foot = ""

    # 空区块不渲染（只做模式 D 时不该出现「一、已确认真实差错（0 项）」这种空表）
    head_err = (f'<h2 class="sec" id="s-err">{sec_no.get("err", "")}、'
                f'已确认真实差错（{err_total} 项，建议作者逐项修改）</h2>\n'
                f'  <p class="lead">类别图例：{legend_html()}</p>{warn}\n'
                f'  {"".join(sec_err)}') if GROUPS else ""
    head_sugg = (f'<h2 class="sec" id="s-sugg">{sec_no.get("sugg", "")}、'
                 f'表述 / 格式润色建议（{len(SUGG)} 项，不算硬错）</h2>\n'
                 f'  <p class="lead">以下为行文质量优化项，供编辑或作者自行斟酌，非必须修改。</p>\n'
                 f'  <table class="tbl narrow">\n'
                 f'    <thead><tr><th style="width:3%">#</th><th style="width:9%">位置</th>'
                 f'<th style="width:45%">问题</th><th style="width:43%">建议</th></tr></thead>\n'
                 f'    <tbody>{sugg_table(SUGG)}</tbody>\n  </table>') if SUGG else ""
    head_quest = (f'<h2 class="sec" id="s-quest">{sec_no.get("quest", "")}、'
                  f'需作者进一步确认的事项（{len(QUEST)} 项）</h2>\n'
                  f'  <p class="lead">以下涉及实验数据、图表参数与文献核验，编辑无法单方判断，'
                  f'需作者提供原始数据或复核说明。</p>\n'
                  f'  <table class="tbl narrow">\n'
                  f'    <thead><tr><th style="width:3%">#</th><th style="width:9%">位置</th>'
                  f'<th style="width:88%">待确认内容</th></tr></thead>\n'
                  f'    <tbody>{quest_table(QUEST)}</tbody>\n  </table>') if QUEST else ""
    head_sum = (f'<h2 class="sec">{sec_no.get("sum", "")}、差错构成小结</h2>\n'
                f'  <table class="tbl narrow" style="max-width:560px">\n    <tbody>\n'
                f'      <tr><td class="c-loc" style="width:150px">关键（事实/逻辑矛盾）</td><td>{n_key} 项</td></tr>\n'
                f'      <tr><td class="c-loc">语法（主谓/语态/句构）</td><td>{n_gram} 项</td></tr>\n'
                f'      <tr><td class="c-loc">表述（措辞/术语/用词）</td><td>{n_expr} 项</td></tr>\n'
                f'      <tr><td class="c-loc">格式（空格/标点/单位）</td><td>{n_fmt} 项</td></tr>\n'
                f'      <tr><td class="c-loc">参考文献著录</td><td>{n_ref} 项</td></tr>\n'
                f'      <tr><td class="c-loc"><b>真实差错合计</b></td><td><b>{err_total} 项</b>'
                f' + 润色建议 {len(SUGG)} 项 + 待确认 {len(QUEST)} 项</td></tr>{cmp_row}\n'
                f'    </tbody>\n  </table>') if (GROUPS or SUGG or QUEST) else ""
    nav_err = '<a href="#s-err">真实差错</a>' if GROUPS else ""
    nav_sugg = '<a href="#s-sugg">润色建议</a>' if SUGG else ""
    nav_quest = '<a href="#s-quest">待确认</a>' if QUEST else ""

    # 统计卡只摆实际有内容的项：只做模式 D 时不该出现一排「0 已确认差错」
    stats = []
    if GROUPS:
        stats.append('<div class="stat"><b>%d</b><span>已确认真实差错（共 %d 组）</span></div>'
                     % (err_total, len(GROUPS)))
        stats.append('<div class="stat alert"><b>%d</b><span>关键事实/逻辑矛盾</span></div>'
                     % n_key)
    if SUGG:
        stats.append('<div class="stat"><b>%d</b><span>表述 / 格式润色建议</span></div>'
                     % len(SUGG))
    if QUEST:
        stats.append('<div class="stat"><b>%d</b><span>待作者确认事项</span></div>'
                     % len(QUEST))
    if cmp_on:
        stats.append('<div class="stat%s"><b>%d</b><span>原稿↔排版实质差异</span></div>'
                     % (" alert" if cmp_n else "", cmp_n))
    stats_html = "\n      ".join(stats)
    # 主表为空时（只做模式 D），提醒语没有落点 → 提到 wrap 最前面
    warn_top = warn if not GROUPS else ""

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(META["manuscript_id"])} {esc(META["title"])}</title>
<style>
:root {{
  --ink:#22303f; --mut:#5f6f7e; --teal:#0E7C74; --teal-d:#0B5D5A; --teal-l:#E7F4F2;
  --line:#DDE7E5; --bg:#F4F8F7;
}}
* {{ box-sizing:border-box; }}
body {{ margin:0; font-family:-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei","Helvetica Neue",Arial,sans-serif;
       color:var(--ink); background:#fff; line-height:1.55; }}
.wrap {{ max-width:1180px; margin:0 auto; padding:0 22px 90px; }}
.hero {{ background:linear-gradient(135deg,#0B5D5A 0%,#0E7C74 60%,#15998F 100%); color:#fff;
        padding:34px 22px 28px; border-radius:0 0 16px 16px; }}
.hero .tag {{ display:inline-block; font-size:12px; letter-spacing:2px; background:rgba(255,255,255,.16);
             padding:4px 12px; border-radius:999px; margin-bottom:14px; }}
.hero h1 {{ margin:0 0 8px; font-size:26px; font-weight:700; }}
.hero .sub {{ font-size:13.5px; opacity:.92; max-width:900px; }}
.stats {{ display:flex; flex-wrap:wrap; gap:12px; margin-top:20px; }}
.stat {{ background:#fff; color:var(--ink); border-radius:12px; padding:12px 18px; min-width:150px;
        border-left:4px solid #2BB3A8; box-shadow:0 1px 3px rgba(11,93,90,.08); }}
.stat b {{ display:block; font-size:24px; color:var(--teal-d); line-height:1.1; }}
.stat span {{ font-size:12.5px; color:var(--mut); }}
.stat.alert {{ border-left-color:#D64545; }} .stat.alert b {{ color:#B33636; }}
.nav {{ position:sticky; top:0; z-index:20; background:rgba(255,255,255,.94); backdrop-filter:blur(6px);
       border-bottom:1px solid var(--line); padding:8px 0; }}
.nav .inner {{ max-width:1180px; margin:0 auto; padding:0 22px; display:flex; flex-wrap:wrap; gap:6px; }}
.nav a {{ text-decoration:none; font-size:13px; color:var(--teal-d); border:1px solid #BFDDD9;
         padding:3px 12px; border-radius:999px; background:#fff; }}
.nav a:hover {{ background:var(--teal-l); }}
h2.sec {{ margin:38px 0 6px; font-size:20px; color:var(--teal-d); display:flex; align-items:center; gap:10px; }}
h2.sec::before {{ content:""; width:5px; height:22px; background:var(--teal); border-radius:3px; display:inline-block; }}
p.lead {{ color:var(--mut); font-size:13.5px; margin:0 0 16px; }}
.gsec {{ margin:26px 0 6px; }}
.gtitle {{ font-size:15.5px; margin:18px 0 8px; color:#31424F; display:flex; align-items:center; gap:8px; }}
.gtitle::before {{ content:""; width:12px; height:12px; border-radius:3px; background:var(--teal); opacity:.85; }}
.gcnt {{ font-size:12px; color:var(--mut); background:var(--bg); padding:2px 10px; border-radius:999px; font-weight:400; }}
table.tbl {{ width:100%; border-collapse:collapse; background:#fff; font-size:13px;
            border:1px solid var(--line); border-radius:10px; overflow:hidden; box-shadow:0 1px 4px rgba(16,42,67,.05);
            table-layout:fixed; }}
.tbl th {{ background:#F0F7F6; color:var(--teal-d); text-align:left; font-weight:600; padding:9px 10px;
          border-bottom:2px solid var(--teal); white-space:nowrap; }}
.tbl td {{ border-bottom:1px solid #EDF2F1; padding:9px 10px; vertical-align:top;
          word-break:break-word; overflow-wrap:anywhere; }}
.tbl tbody tr:nth-child(even) {{ background:#FBFDFC; }}
.tbl tbody tr:hover {{ background:#F1FAF8; }}
.c-no {{ font-weight:700; color:var(--teal-d); white-space:nowrap; }}
.c-loc {{ color:#40505E; font-size:12.5px; }}
.c-q {{ background:#F6F8F7; border-left:3px solid #CFE0DD; border-radius:0 6px 6px 0; color:#35424E; }}
.c-issue .badge {{ display:inline-block; font-size:11px; padding:1px 8px; border-radius:999px; border:1px solid;
                  margin-bottom:5px; font-weight:600; }}
.celltext {{ color:#3A4753; }}
.c-fix {{ color:#0C6B63; background:#F2FAF9; border-radius:6px; }}
.c-o {{ background:#FBF7F5; border-left:3px solid #EBD7CB; border-radius:0 6px 6px 0; color:#4A3A34; }}
.c-t {{ background:#F5F9FB; border-left:3px solid #CFE0E8; border-radius:0 6px 6px 0; color:#334450; }}
.cmp-path {{ font-family:ui-monospace,Consolas,monospace; font-size:12px; background:var(--bg);
             padding:1px 5px; border-radius:4px; word-break:break-all; }}
.tbl.narrow td {{ padding:8px 10px; }}
.warn-note {{ background:#FFF8F0; border:1px solid #F0DCC2; color:#7A5426; padding:12px 16px; border-radius:10px;
             font-size:13px; margin:10px 0 22px; }}
footer {{ margin-top:46px; color:var(--mut); font-size:12.5px; border-top:1px solid var(--line); padding-top:16px; }}
@media print {{ .nav{{display:none}} .hero{{border-radius:0}} body{{background:#fff}} }}
</style>
</head>
<body>
<div class="hero">
  <div class="wrap" style="padding-bottom:6px">
    <span class="tag">{esc(META["kicker"])}</span>
    <h1>{esc(META["manuscript_id"])} {esc(META["title"])}</h1>
    <div class="sub">{esc(META["description"])}</div>
    <div class="stats">
{stats_html}
    </div>
  </div>
</div>

<div class="nav"><div class="inner">
  {nav_err}{nav_sugg}{nav_quest}{cmp_nav}
</div></div>

<div class="wrap">
  {warn_top}
  {head_err}

  {head_sugg}

  {head_quest}

  {head_sum}
{cmp_html}
  <footer>
    审读方式：全文通读 + 疑点 PDF 定点取证（码点/字体名检查 + 局部渲染图核验），
    经核实为 PDF 提取假象/误报的疑点已剔除、不列入本报告。位置栏中 Pn 为 PDF 页码，Ln 为全文提取文本行号。
    由熊猫审读（panda-review）模式 B 生成。{cmp_foot}
  </footer>
</div>
</body>
</html>"""


if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="模式 B/C：从外部数据文件生成自包含修改意见 HTML")
    ap.add_argument("--data", action="append", required=True, metavar="FILE",
                    help="数据文件 .py / .json，可多次传入（后面的覆盖前面的同名字段；"
                         "模式 D 比对数据由 compare_diff.py --emit-data 直接产出）")
    ap.add_argument("--out", metavar="FILE",
                    help="输出路径，默认取数据文件 META.out_path")
    args = ap.parse_args()

    cfg = merge_data(args.data, "html")
    if cfg.get("META") is None:
        ap.error("数据文件必须提供 META（含 manuscript_id）")
    validate_html(cfg)

    # 用外部数据覆盖模块级变量，模板函数零改动（保证输出与 1.2.0 逐字节一致）
    _g = globals()
    for _k in HTML_FIELDS:
        _g[_k] = cfg.get(_k)

    out = args.out or META["out_path"]
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    # 不加 newline 参数：与 1.2.0 的写文件行为逐字节一致（回归红线）
    with open(out, "w", encoding="utf-8") as f:
        f.write(build_page())
    err_total = sum(len(rows) for _, rows in GROUPS)
    print("written:", out)
    print("真实差错:", err_total, "| 润色:", len(SUGG), "| 待确认:", len(QUEST),
          "| 原稿比对:", (len(COMPARE) if COMPARE_META else "未启用"))

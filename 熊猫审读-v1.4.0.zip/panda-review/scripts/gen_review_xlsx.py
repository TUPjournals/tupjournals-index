# -*- coding: utf-8 -*-
"""
熊猫审读 · 模式 A（审读记录表 xlsx）生成器 —— --data 外部数据文件范式
====================================================================
用法：把审读结果登记进一个**外部**数据文件（.py 或 .json），然后运行：
    python gen_review_xlsx.py --data <数据.py|数据.json> [--out <输出.xlsx>]

⚠️ 技能目录内的脚本保持只读：数据一律放工作区/临时目录的数据文件，
   不要再编辑本文件顶部的示例数据区（示例仅演示字段格式）。

产出：与教育部审读记录表同格式的双 sheet Excel：
    [审读记录表] 刊名/期次/CN号/检查字数/检查范围/文章/作者/地图检查/出版形式检查区/
                 差错明细（页/栏/行/原文/简析/类型/扣分）/合计/差错率/合格判定/说明区
    [字数计算]   附件二口径测算过程
内置 calc_total() 同类扣分上限封顶（附件四口径，与 SKILL.md 扣分速查一致）：
    类型 8/9/10/11/17/18 同类最多扣 3 次；
    类型 14/19/20/21/22 同类最多扣 10 次；
    其余类型不封顶。被上限截断的条目会在 stdout 打印明细。
重要差错 ×2 不在此处理——登记时直接把扣分值写为 ×2 后的值，并在备注注明"重要差错×2"。

数据文件字段（.py 写成同名变量，.json 写成同名键；校验见 scripts/data_io.py）：
  OUT_PATH (可选)   默认输出路径（--out 可覆盖）
  JOURNAL/ISSUE/CN_NOTE/ARTICLE/AUTHORS/WORDS/SCOPE_NOTE/MAP_NOTE
  FORM_CHECK_ROWS: [(序号, 出版形式质量问题, 计错数, 备注), ...]
  ERRORS: [(页, 栏, 行, 差错原文, 差错简析, 类型, 扣分值, 备注), ...]  类型为字符串如 "19"
  WORDS_CALC: [(项目, 数值, 说明), ...]  字数计算 sheet 数据行
  NOTES: [说明文字, ...]  审读记录表底部说明区（自动加"说明"标签与序号）

输出逐字节幂等：workbook 元数据（creator/created/modified）固定为常量，
同一数据文件两次运行产出完全一致。
"""
import argparse
import os
import re
import sys
import zipfile
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data_io import merge_data, validate_xlsx, XLSX_FIELDS  # noqa: E402

from openpyxl import Workbook  # noqa: E402
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side  # noqa: E402

# ======================= 示例数据区（只读，勿改） =======================
# ⚠️ 下面全部是【只读示例】，用虚构刊名/文章/作者演示字段格式。
#    实际使用时把数据登记进外部数据文件，用 --data 传入，不要改这里。
OUT_PATH = "审读记录表.xlsx"

JOURNAL = "Example Journal"
ISSUE = "Vol 1 (2026) 100001"
CN_NOTE = "（未提供，本次未识别）"
ARTICLE = "An example article title used to demonstrate the registration format"
AUTHORS = "Given1 Family1, Given2 Family2, Given3 Family3"
WORDS = 3200
SCOPE_NOTE = ("仅审读第 1 页（标题/作者/单位/Abstract/Keywords/Introduction 首段）。"
              "封面、版权页、目次页本次不检查，不做形式审查。")
MAP_NOTE = "□有   ☑无"
FORM_CHECK_ROWS = [(1, "（本次未提供封面、版权页，未作形式检查）", "—", "用户指定不检查")]

# (页, 栏, 行, 差错原文, 差错简析, 类型, 扣分值, 备注)
ERRORS = [
    (1, "左", "L7",
     "a Department of Example Engineering, Example University,Exampleville100000,China",
     "标点/字符错误：城市名 Exampleville 与邮编 100000 之间缺空格，应为 'Exampleville 100000, China'。",
     "19", 0.1, "a 单位"),
    (1, "左", "L9",
     "b Example Institute of Technology,Exampleville100001,China",
     "标点/字符错误：城市名与邮编之间缺空格。", "19", 0.1, "b 单位"),
    (1, "右", "L20",
     "the example type of samples exhibit promising characteristics ...",
     "语态/主谓差错：单数主语 the example type 应配 exhibits（当前 exhibit 为复数动词形式）。",
     "9", 0.5, ""),
    (1, "右", "L57",
     "Number 6 shows the cross-section of the example cable wrapped with tape; "
     "structure of the reference cable is showed in right",
     "语法性错误：被动语态时态错误，is showed → is shown；并缺介词/冠词，in right → on the right。",
     "2", 1.0, "图注 (a) 两处合 1 条"),
    (1, "右", "L60", "The insert image shows the appearance of a single example coil.",
     "用词不当：学术插图标准术语为 inset image（放大图/插入图），insert 多用于产品说明书；建议改为 inset。",
     "9", 0.5, "图注 (e)，可酌情"),
]

WORDS_CALC = [
    ("审读页数", 1, "仅 PDF 第 1 页（标题/摘要/Keywords/Introduction 首段）"),
    ("正文字号", "9.0 pt", "实测页中位数"),
    ("单栏栏宽", "265.0 pt", "实测中位数"),
    ("每行汉字数", 29.4, "栏宽 ÷ 字号"),
    ("每行外文字数", 38.2, "汉字数 × 1.3（外文期刊）"),
    ("栏数", 2, "双栏"),
    ("每栏行数", 42, "实测中位数"),
    ("每页行数", 84, "两栏合计"),
    ("行距", "11.0 pt", "实测中位数"),
    ("每页字数", 3200, "38.2 × 84 ≈ 3209，按 3200 计"),
    ("折算页数", 1, "1 页"),
]

NOTES = [
    "审读范围为第 1 页（标题页含 Abstract/Keywords/Introduction 首段）。",
    "字数按《附件二》计算：字号 9.0 pt、双栏栏宽 265.0 pt、外文每行 38.2 字、每栏 42 行、"
    "每页 84 行、每页 3200 字 × 1 页 = 3200 字。",
    "扣分依据《附件四：教育部主管科技期刊编校差错扣分细则-202603》。",
    "同类上限：类型 19 同类计足、类型 9 同类计足、类型 2 单条（is showed → is shown），"
    "上限由脚本 calc_total() 自动封顶。",
    "图注中 'insert image'（→ inset image）属学术插图用词规范问题，可酌情扣分。",
    "已排除项（示例）：PDF 文本提取出现的下标错位、单词黏连（如 andtechnology）"
    "系提取假象而非作者错误，一律不登记、不出现在产物中，仅记工作日志备查。",
]

# ======================= 以下为模板（一般无需改动） =======================

# 附件四口径（与 SKILL.md「扣分规则速查」一致）：
# 类型 8/9/10/11/17/18 同类最多扣 3 次；类型 14/19/20/21/22 同类最多扣 10 次；其余不封顶
CAPS = {"8": 3, "9": 3, "10": 3, "11": 3, "17": 3, "18": 3,
        "14": 10, "19": 10, "20": 10, "21": 10, "22": 10}


def calc_total(errors, log=None):
    """合计扣分（附件四同类上限封顶）。

    被上限截断的条目逐类打印明细（哪一类截到第几条止、截掉多少分），
    避免封顶变成黑箱；log=None 时不打印。
    """
    total = 0.0
    caps_used = {k: 0 for k in CAPS}
    cut_pts = {}
    cut_cnt = {}
    for e in errors:
        typ = str(e[5])
        if typ in CAPS:
            if caps_used[typ] < CAPS[typ]:
                total += e[6]
                caps_used[typ] += 1
            else:
                cut_pts[typ] = cut_pts.get(typ, 0.0) + e[6]
                cut_cnt[typ] = cut_cnt.get(typ, 0) + 1
        else:
            total += e[6]
    if log is not None:
        for typ in sorted(cut_pts, key=lambda t: (len(t), t)):
            log("封顶：类型 %s 同类超过前 %d 次不计，本次截掉 %d 条共 %.1f 分"
                % (typ, CAPS[typ], cut_cnt[typ], cut_pts[typ]))
    return total


thin = Side(style="thin", color="000000")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
HDR_FILL = PatternFill("solid", fgColor="D9E1F2")

# 固定的 workbook 元数据时间戳：保证同一数据文件两次运行输出逐字节一致
FIXED_TS = datetime(2026, 1, 1, 0, 0, 0)
FIXED_ZIP_TS = (2026, 1, 1, 0, 0, 0)


def _normalize_xlsx(path):
    """openpyxl 保存时会两个地方写当前时刻：
    ① docProps/core.xml 的 <dcterms:modified>（保存时强制改写，wb.properties 管不住）；
    ② 每个 zip 条目的 date_time。
    这里统一重写为固定值，保证同一数据文件两次运行逐字节一致。"""
    with zipfile.ZipFile(path) as zin:
        entries = [(zi.filename, zin.read(zi.filename)) for zi in zin.infolist()]
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, data in entries:
            if name == "docProps/core.xml":
                s = data.decode("utf-8")
                s = re.sub(r"(<dcterms:modified[^>]*>)[^<]*(</dcterms:modified>)",
                           r"\g<1>2026-01-01T00:00:00Z\g<2>", s)
                data = s.encode("utf-8")
            zi = zipfile.ZipInfo(name, date_time=FIXED_ZIP_TS)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o600 << 16
            zout.writestr(zi, data)


def build_single(out_path, cfg):
    wb = Workbook()
    # 幂等关键：creator/created/modified 全部固定，不用运行时刻
    wb.properties.creator = "panda-review"
    wb.properties.lastModifiedBy = "panda-review"
    wb.properties.created = FIXED_TS
    wb.properties.modified = FIXED_TS
    ws = wb.active
    ws.title = "审读记录表"

    journal = cfg["JOURNAL"]
    ws.append(["2026年教育部主管科技期刊编校质量检查结果记录表"])
    ws.append(["刊    名", journal, "", "期    次", cfg["ISSUE"]])
    ws.append(["CN    号", cfg["CN_NOTE"], "", "检查字数", cfg["WORDS"]])
    ws.append(["检查范围", cfg["SCOPE_NOTE"], "", "", ""])
    ws.append(["文章", cfg["ARTICLE"], "", "", ""])
    ws.append(["作者", cfg["AUTHORS"], "", "", ""])
    ws.append(["被检查文字中有无地图", cfg["MAP_NOTE"], "", "", ""])
    ws.append([])
    ws.append(["序号", "封面、版权页的出版形式质量问题", "计错数", "备注", ""])
    for (no, item, cnt, note) in cfg["FORM_CHECK_ROWS"]:
        ws.append([no, item, cnt, note, ""])
    ws.append(["", "合计", "", "", ""])
    ws.append(["", "检查结果", "出版形式质量：□合格  □不合格（如未检查请注明）", "", ""])
    ws.append([])
    ws.append(["页", "栏", "行", "差错原文", "差错简析（改正建议）", "差错类型", "扣分值"])
    hr = ws.max_row
    errors = cfg["ERRORS"]
    for e in errors:
        page, col, line, txt, parse, typ, score, note = \
            e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7]
        if note:
            parse = f"{parse}［{note}］"
        ws.append([page, col, line, txt, parse, typ, score])
    ws.append([])

    total_pts = calc_total(errors, log=print)
    base_pts = sum(e[6] for e in errors)
    words = cfg["WORDS"]
    rate = total_pts / words * 10000

    ws.append(["", "", "", "差错总数", len(errors), "合计扣分值", total_pts])
    ws.append(["", "", "", "差错率 = 合计扣分值 / 检查字数", "", "", "{:.2f}/10000".format(rate)])
    ws.append(["", "", "", "合格标准", "", "", "编校差错率 ≤ 2.00/10000"])
    ws.append(["", "", "", "本次判定", "", "", "不合格" if rate > 2 else "合格"])
    ws.append([])
    for i, note_text in enumerate(cfg["NOTES"] or [], 1):
        ws.append(["说明" if i == 1 else "", "{}. {}".format(i, note_text), "", "", "", "", ""])

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    ws["A1"].font = Font(bold=True, size=14)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.merge_cells("D4:G4")
    ws.merge_cells("B5:G5")
    ws.merge_cells("B6:G6")

    for row in ws.iter_rows(min_row=hr, max_row=hr + len(errors)):
        for c in row:
            c.border = BORDER
            c.alignment = Alignment(vertical="top", wrap_text=True)
    for c in ws[hr]:
        c.fill = HDR_FILL
        c.font = Font(bold=True)

    for col, w in zip("ABCDEFG", [6, 6, 8, 46, 62, 10, 10]):
        ws.column_dimensions[col].width = w

    # 字数计算 sheet
    ws2 = wb.create_sheet("字数计算")
    ws2.append(["审读字数计算（依据《附件二：教育部主管科技期刊审读字数计算方法-202603》）"])
    ws2.append(["每行字数 = 栏宽 ÷ 正文字号（该行可容纳的汉字数）× 1.3（外文期刊）"])
    ws2.append(["每页字数 = 每行字数 × 每页满排行数（两栏期刊按两栏合计行数）"])
    ws2.append(["检查字数 = 每页字数 × 审读页数"])
    ws2.append([])
    ws2.append(["项目", "数值", "说明"])
    r0 = ws2.max_row
    for row in cfg["WORDS_CALC"]:
        ws2.append(list(row))
    ws2.append(["★ 检查字数", words, "见上"])
    ws2.merge_cells("A1:C1")
    ws2["A1"].font = Font(bold=True, size=13)
    ws2["A1"].alignment = Alignment(horizontal="center")
    for c in range(2, 5):
        ws2.merge_cells(start_row=c, start_column=1, end_row=c, end_column=3)
    for row in ws2.iter_rows(min_row=r0, max_row=ws2.max_row):
        for c in row:
            c.border = BORDER
            c.alignment = Alignment(vertical="top", wrap_text=True)
    for c in ws2[r0]:
        c.fill = HDR_FILL
        c.font = Font(bold=True)
    for c in ws2[ws2.max_row]:
        c.font = Font(bold=True)
    for col, w in zip("ABC", [16, 14, 56]):
        ws2.column_dimensions[col].width = w

    wb.save(out_path)
    _normalize_xlsx(out_path)
    verdict = "不合格" if rate > 2 else "合格"
    print("saved", out_path)
    print("差错 {} 处, 原值 {} 分, 附件四口径 {} 分, 字数 {}, 率 {:.2f}/万, 判定 {}".format(
        len(errors), base_pts, total_pts, words, rate, verdict))


def main():
    ap = argparse.ArgumentParser(
        description="模式 A：从外部数据文件生成教育部格式审读记录表 Excel")
    ap.add_argument("--data", action="append", required=True, metavar="FILE",
                    help="数据文件 .py / .json，可多次传入（后面的覆盖前面的同名字段）")
    ap.add_argument("--out", metavar="FILE", help="输出路径，默认取数据文件 OUT_PATH")
    args = ap.parse_args()

    cfg = merge_data(args.data, "xlsx")
    missing = [k for k in XLSX_FIELDS
               if k not in ("OUT_PATH",) and cfg.get(k) is None]
    if missing:
        ap.error("数据文件缺少必备字段：%s" % ", ".join(missing))
    validate_xlsx(cfg)
    out = args.out or cfg.get("OUT_PATH") or "审读记录表.xlsx"
    build_single(out, cfg)


if __name__ == "__main__":
    main()

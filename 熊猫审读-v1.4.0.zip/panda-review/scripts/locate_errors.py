# -*- coding: utf-8 -*-
"""
把审读差错定位到"页 / 栏 / 行"，供填写附件三记录表使用。

用法（--data 外部数据文件范式，脚本本身只读）：
  python locate_errors.py <input.pdf> [PAGE_LIMIT] [--targets "frag1" "frag2" ...]
                          [--data <数据.py|数据.json>]
    例：python locate_errors.py "D:/稿件/xxx.pdf" 10 --targets "example-technique"
  --data 数据文件可提供 TARGETS（必）/ SRC、PAGE_LIMIT（可选）三个键；
  命令行参数优先于 --data，--data 优先于内置虚构示例。

原理：
  分栏 crop -> 按 round(top/(size*0.6)) 把词分桶 -> 桶内按 x0 排序拼接 -> 桶序号即行号
  注意：页眉、页脚(URL)也各占一行，描述时需说明。
"""
import argparse
import os
import statistics
import sys

import pdfplumber

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data_io import merge_data, LOCATE_FIELDS  # noqa: E402

# 内置【虚构示例】待定位片段（小写匹配，填能唯一锁定该句的一小段即可）。
# ⚠️ 仅演示格式；实际片段用 --targets 或 --data 的 TARGETS 传入，不要改这里。
TARGETS = [
    "example-technique",
    "illustrative algorithm",
    "exampleville",
]


def col_split(page):
    """返回该页的栏（左/右）；单栏时返回整页"""
    ws = page.extract_words()
    if not ws:
        return [page]
    mid = page.width / 2
    c = [((w["x0"] + w["x1"]) / 2) for w in ws]
    if sum(1 for x in c if x < mid) < 10 or sum(1 for x in c if x >= mid) < 10:
        return [page]
    return [page.crop((0, 0, mid, page.height)), page.crop((mid, 0, page.width, page.height))]


def col_rows(col):
    """返回该栏按行归并后的文本行（升序），元素为 str"""
    ws = col.extract_words()
    if not ws:
        return []
    sz = statistics.median([round(c["size"], 1) for c in col.chars] or [9.0])
    buckets = {}
    for w in ws:
        buckets.setdefault(round(w["top"] / (sz * 0.6)), []).append(w)
    return [" ".join(w["text"] for w in sorted(buckets[k], key=lambda w: w["x0"]))
            for k in sorted(buckets)]


def locate(path, targets, page_limit=None, context=110):
    with pdfplumber.open(path) as pdf:
        pages = pdf.pages[:page_limit] if page_limit else pdf.pages
        for i, pg in enumerate(pages):
            for j, col in enumerate(col_split(pg)):
                side = "左" if j == 0 else "右"
                for k, txt in enumerate(col_rows(col), 1):
                    for tg in targets:
                        if tg.lower() in txt.lower():
                            print("p{:<2} {} L{:<2} | {:<24} | {}".format(
                                i + 1, side, k, tg, txt[:context]))
                            break


if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="把审读差错定位到页/栏/行（数据走 --data 或 --targets，脚本只读）")
    ap.add_argument("src", nargs="?", help="输入 PDF 路径")
    ap.add_argument("page_limit", nargs="?",
                    help="审读页数；none/full/all 表示全文")
    ap.add_argument("--targets", nargs="+", metavar="FRAG",
                    help="待定位片段（小写匹配），可多个")
    ap.add_argument("--data", metavar="FILE",
                    help="数据文件 .py / .json，可含 TARGETS / SRC / PAGE_LIMIT 键")
    args = ap.parse_args()

    cfg = merge_data([args.data], "locate") if args.data else \
        {k: None for k in LOCATE_FIELDS}
    src = args.src or cfg.get("SRC")
    if not src:
        ap.error("必须提供输入 PDF（位置参数或 --data 的 SRC 键）")
    if not os.path.isfile(src):
        sys.exit("文件不存在：%s" % src)
    targets = args.targets or cfg.get("TARGETS") or TARGETS
    if not targets:
        sys.exit("没有待定位片段：请用 --targets 或 --data 的 TARGETS 提供")
    pl = args.page_limit
    if pl is None:
        page_limit = cfg.get("PAGE_LIMIT")
    elif pl.lower() in ("none", "full", "all"):
        page_limit = None
    else:
        page_limit = int(pl)
    print("SRC =", src, "| PAGE_LIMIT =", page_limit)
    locate(path=src, targets=targets, page_limit=page_limit)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""熊猫审读 · 模式 C 合并器
=================================================
把「熊猫找茬-已出版」的诚信检查报告（integrity）与「熊猫审读」的修改意见 HTML（review）
合并成**一份**自包含 HTML：诚信检查在前、编校审读在后。

为什么需要"作用域前缀化"
-------------------------------------------------
两份报告各带一套 CSS，且找茬那份用的是**裸元素选择器**（body / h1 / h2 / table / th,td）。
若原样首尾拼接，后出现的那套会覆盖前一套的同名规则，实测后果：
  · 审读报告的 body 被压到 max-width:980px + padding:32px、行高被改
  · 审读的刊头 h1 多出一条蓝色下划线（#2c6fbb）
  · 每个审读章节标题 h2 多出蓝色左边框并右移
  · 审读表格从"仅横线"变成满格线
处理办法：把诚信那份的 CSS 选择器全部加上 `.pk-embed` 前缀，其正文包进一个
真实存在的 `<div class="pk-embed">` 容器 —— 作用域隔离，两侧样式互不侵犯。
（不能把 class 加在内层 <body> 上：内层 <html>/<head>/<body> 标签会被浏览器忽略，
  属性会与外层 body 合并丢失，隔离随即失效。）

用法
-------------------------------------------------
python merge_review_report.py --integrity <诚信.html> --review <审读.html> --out <合并件.html> [--title "..."]

输出：合并件写入 --out；stdout 打印摘要（含自检结果）；自检不过则中止且不产出文件。
交付件会把源报告中的裸 & 统一规范化为 &amp;（两侧源报告不动），使合并件成为严格合法 HTML。
"""

import argparse
import hashlib
import os
import re
import sys

PREFIX = ".pk-embed"

# 合并层样式：只负责分界与容器兜底，不覆盖两侧任何原有规则
MERGE_CSS = """
/* ── 模式 C 合并层（熊猫审读新增；不改动两侧原有样式） ── */
.pk-band{background:#eef4fb;border-left:5px solid #2c6fbb;color:#1a4f8a;
         font-size:14px;font-weight:700;padding:9px 14px;margin:0}
body > .pk-band:first-child{margin-top:0}
.pk-sep{border:0;border-top:4px double #c9d6e3;margin:0}
"""

# 自检用：前缀化后不应残留的裸元素选择器
BARE_SELECTORS = ["body", "html", "h1", "h2", "h3", "h4", "table", "th", "td", "tr", "p"]

# 裸 & 匹配（排除各类合法实体）
BARE_AMP = re.compile(r"&(?!#x?[0-9a-fA-F]+;|#\d+;|amp;|lt;|gt;|quot;|apos;|nbsp;)")

# 结束标签「必需」的标签：不配对即致命
PAIR_TAGS = ["div", "table", "tr", "td", "th", "span", "section", "h1", "h2", "h3"]
# 结束标签「可省略」的标签（HTML 规范：<p> 遇下一块级元素自动闭合）：不配对仅提示、不阻断
PAIR_TAGS_OPTIONAL = ["p", "li"]


# ────────────────────────── CSS 作用域前缀化 ──────────────────────────

def _scope_selector_list(prelude):
    """把逗号分隔的选择器列表逐项加作用域前缀。返回 (新选择器列表, 被丢弃的选择器列表)。"""
    kept, dropped = [], []
    for sel in prelude.split(","):
        sel = sel.strip()
        if not sel:
            continue
        low = sel.lower()
        # 全局规则：丢弃（审读侧已有 body / box-sizing 等等效声明）
        if low in ("html", ":root", "*", "html,body"):
            dropped.append(sel)
            continue
        # body 规则整体转移给容器本身
        if low == "body":
            kept.append(PREFIX)
            continue
        kept.append(PREFIX + " " + sel)
    return kept, dropped


def scope_css(css, prefix=PREFIX):
    """给 CSS 加作用域前缀。支持嵌套条件 at-rule（@media/@supports/@layer/@container）。
    返回 (前缀化后的 CSS, 被丢弃的选择器列表, 被改写的规则数)。"""
    if not css.strip():
        return "", [], 0

    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)  # 去注释，避免污染 prelude

    out, dropped = [], []
    rewritten = 0
    i, n = 0, len(css)

    while i < n:
        j = css.find("{", i)
        if j == -1:
            tail = css[i:].strip()
            if tail:
                out.append(tail)      # 理论不达；保留以免静默丢内容
            break

        prelude = css[i:j].strip()

        # 括号平衡找块尾
        depth, k = 1, j + 1
        while k < n and depth > 0:
            c = css[k]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
            k += 1

        body = css[j + 1:k - 1]

        if prelude.startswith("@"):
            at = prelude.split()[0].lower()
            if at in ("@media", "@supports", "@layer", "@container"):
                inner, d2, r2 = scope_css(body, prefix)
                dropped.extend(d2)
                rewritten += r2
                out.append("%s{%s}" % (prelude, inner))
            else:
                out.append("%s{%s}" % (prelude, body))   # @font-face / @keyframes 等原样
        else:
            kept, d = _scope_selector_list(prelude)
            dropped.extend(d)
            if kept:
                out.append("%s{%s}" % (", ".join(kept), body.strip()))
                rewritten += 1

        i = k

    return "\n".join(x for x in out if x.strip()), dropped, rewritten


# ────────────────────────── HTML 片段提取 ──────────────────────────

def extract_styles(html):
    return re.findall(r"<style[^>]*>(.*?)</style>", html, re.S | re.I)


def extract_body(html, path="<html>"):
    m = re.search(r"<body[^>]*>(.*)</body>", html, re.S | re.I)
    if not m:
        raise SystemExit("[FATAL] %s 中找不到 <body>...</body>" % path)
    return m.group(1)


def extract_title(html):
    m = re.search(r"<title>(.*?)</title>", html, re.S | re.I)
    return m.group(1).strip() if m else ""


# ────────────────────────── 自检 ──────────────────────────

def check(merged, review_css_src, scoped_css, dropped, out_path, amp_fixed=0, integ_body=""):
    ok = True
    lines = []

    def rep(name, passed, detail=""):
        nonlocal ok
        if not passed:
            ok = False
        lines.append("  [%s] %s%s" % ("PASS" if passed else "FAIL", name,
                                      ("  " + detail) if detail else ""))

    # 1) 文档骨架唯一
    for tag, pat in (("<!DOCTYPE", r"<!DOCTYPE"), ("<html", r"<html\b"), ("<body", r"<body\b")):
        c = len(re.findall(pat, merged, re.I))
        rep("骨架唯一 %s 计数=1" % tag, c == 1, "实际 %d" % c)

    # 2) 审读 CSS 字节级一致（合并件里必须原样含源 style 块）
    norm = lambda s: re.sub(r"\s+", " ", s).strip()
    rep("审读 CSS 原样保留（未作用域化）", norm(review_css_src) in norm(merged))

    # 3) 前缀化后无裸元素选择器残留
    leaks = []
    for sel in BARE_SELECTORS:
        for m in re.finditer(r"(?m)^\s*([^{}\n]+?)\s*\{", scoped_css):
            pl = m.group(1).strip()
            for one in pl.split(","):
                one = one.strip()
                if one.lower() == sel or one.lower().startswith(sel + " "):
                    leaks.append(one)
    rep("诚信 CSS 无裸元素选择器残留", not leaks, ("泄漏: %s" % leaks[:6]) if leaks else "")

    # 4) 作用域容器真实存在
    rep("作用域容器 .pk-embed 存在于 body", 'class="pk-embed"' in merged)

    # 5) 标签配对（必需闭合的标签）+ 可省略闭合标签的提示
    bad, soft = [], []
    for tag in PAIR_TAGS:
        o = len(re.findall(r"<%s(?=[\s>/])" % tag, merged, re.I))
        c = len(re.findall(r"</%s\s*>" % tag, merged, re.I))
        if o != c:
            bad.append("%s(%d/%d)" % (tag, o, c))
    rep("标签配对（必需闭合）", not bad, ("不配对: %s" % ", ".join(bad)) if bad else "")
    for tag in PAIR_TAGS_OPTIONAL:
        o = len(re.findall(r"<%s(?=[\s>/])" % tag, merged, re.I))
        c = len(re.findall(r"</%s\s*>" % tag, merged, re.I))
        if o != c:
            soft.append("%s(%d/%d)" % (tag, o, c))
    if soft:
        lines.append("  [NOTE] 可省略闭合的标签计数不一（HTML 允许，不阻断）: %s" % ", ".join(soft))

    # 6) 无裸 &（实体形式不计）—— 合并前已统一规范化
    bare = re.findall(BARE_AMP, merged)
    rep("无裸 &（已转义；合并时规范化 %d 处）" % amp_fixed, not bare,
        "仍残留 %d" % len(bare))

    # 7) 无残留占位符
    left = re.findall(r"\{\{[^}]*\}\}", merged)
    rep("无残留占位符 {{...}}", not left, ("残留: %s" % left[:5]) if left else "")

    # 8) 离线自包含：无外部**资源**引用（<a href> 外链无害，不计）
    res = re.findall(r"<link[^>]+href=[\"']https?://|<script[^>]+src=|<img[^>]+src=[\"']https?://"
                     r"|@import\s+url|url\(\s*[\"']?https?://", merged, re.I)
    rep("离线自包含（无外链资源）", not res, ("命中 %d" % len(res)) if res else "")

    # 9) 内容都在：诚信正文片段非空
    rep("诚信内容非空", len(integ_body.strip()) > 0, "%d 字符" % len(integ_body))

    # 10) 反向渗透自检：审读 CSS 里的**裸元素选择器**不得命中诚信内容中真实出现的标签。
    #     （审读 CSS 排在文档前面、且不能改动，故必须确认它不会误伤诚信那部分；
    #       实测 58/58 份诚信报告均不含 <footer>，当前交集为空；此检查防未来模板改版。）
    review_css_flat = re.sub(r"/\*.*?\*/", "", review_css_src, flags=re.S)
    bare_in_review = set()
    for m in re.finditer(r"(?m)(?:^|[};])\s*([^{}@;\n]+?)\s*\{", review_css_flat):
        for one in m.group(1).split(","):
            one = one.strip()
            if one and re.fullmatch(r"[a-zA-Z][a-zA-Z0-9]*", one):
                bare_in_review.add(one.lower())
    present = set(t.lower() for t in re.findall(r"<([a-zA-Z][a-zA-Z0-9]*)(?=[\s>/])", integ_body))
    clash = sorted(bare_in_review & present)
    rep("无反向渗透（审读裸元素选择器 vs 诚信标签）", not clash,
        ("命中: %s" % clash) if clash else "审读裸选择器=%s" % sorted(bare_in_review))

    size = os.path.getsize(out_path)
    sha = hashlib.sha256(open(out_path, "rb").read()).hexdigest()

    lines.append("  丢弃的全局选择器: %s" % (", ".join(dropped) if dropped else "（无）"))
    lines.append("  合并件: %s  (%.1f KB)" % (out_path, size / 1024.0))
    lines.append("  SHA256: %s" % sha)

    return ok, lines


# ────────────────────────── 主流程 ──────────────────────────

def main():
    ap = argparse.ArgumentParser(description="熊猫审读模式 C：合并诚信检查报告与编校审读报告")
    ap.add_argument("--integrity", required=True, help="诚信检查报告 HTML（熊猫找茬-已出版 产出）")
    ap.add_argument("--review", required=True, help="编校审读修改意见 HTML（熊猫审读 模式 B 产出）")
    ap.add_argument("--out", required=True, help="合并件输出路径")
    ap.add_argument("--title", default="", help="合并件 <title>；缺省用审读报告的标题加后缀")
    args = ap.parse_args()

    for p in (args.integrity, args.review):
        if not os.path.isfile(p):
            raise SystemExit("[FATAL] 输入文件不存在: %s" % p)

    integ_html = open(args.integrity, encoding="utf-8").read()
    review_html = open(args.review, encoding="utf-8").read()

    integ_css = "\n".join(extract_styles(integ_html))
    review_css = "\n".join(extract_styles(review_html))
    if not integ_css:
        raise SystemExit("[FATAL] 诚信报告中未找到 <style> 块: %s" % args.integrity)
    if not review_css:
        raise SystemExit("[FATAL] 审读报告中未找到 <style> 块: %s" % args.review)

    integ_body = extract_body(integ_html, args.integrity)
    review_body = extract_body(review_html, args.review)

    scoped_css, dropped, n_rules = scope_css(integ_css)

    title = args.title or (extract_title(review_html) + " · 诚信检查 + 编校审读")

    # 插入两块：① 合并层样式（在 </head> 前）② 诚信内容（在 <body> 后、审读内容前）
    style_block = ("<style>\n%s\n%s\n</style>\n" % (scoped_css, MERGE_CSS))
    content_block = (
        '<div class="pk-band">第一部分 · 学术诚信检查（熊猫找茬-已出版）</div>\n'
        '<div class="pk-embed">%s</div>\n'
        '<hr class="pk-sep">\n'
        '<div class="pk-band">第二部分 · 编校质量审读（熊猫审读）</div>\n'
        % integ_body
    )

    merged = review_html
    merged, n_title = re.subn(r"<title>.*?</title>", "<title>%s</title>" % title,
                              merged, count=1, flags=re.S | re.I)
    if n_title != 1:
        print("[WARN] 审读报告中未找到 <title>，已跳过标题替换", file=sys.stderr)

    if "</head>" not in merged.lower():
        raise SystemExit("[FATAL] 审读报告中未找到 </head>")
    idx = merged.lower().find("</head>")
    merged = merged[:idx] + style_block + merged[idx:]

    m_body = re.search(r"<body[^>]*>", merged, re.I)
    if not m_body:
        raise SystemExit("[FATAL] 审读报告中未找到 <body>")
    merged = merged[:m_body.end()] + "\n" + content_block + merged[m_body.end():]

    # 交付件做成严格合法 HTML：把源报告里的裸 & 统一规范化为 &amp;
    # （两侧源报告不动；浏览器本就容错，但合并件按规范收口，便于校验与第三方工具解析）
    merged, amp_fixed = BARE_AMP.subn("&amp;", merged)

    out_dir = os.path.dirname(os.path.abspath(args.out))
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    with open(args.out, "w", encoding="utf-8", newline="\n") as f:
        f.write(merged)

    ok, lines = check(merged, review_css, scoped_css, dropped, args.out, amp_fixed, integ_body)

    print("熊猫审读 · 模式 C 合并结果")
    print("  诚信报告: %s  (body %d 字符, CSS %d 字符)" % (args.integrity, len(integ_body), len(integ_css)))
    print("  审读报告: %s  (body %d 字符, CSS %d 字符)" % (args.review, len(review_body), len(review_css)))
    print("  作用域化: %d 条规则加 %s 前缀，丢弃全局选择器 %d 条"
          % (n_rules, PREFIX, len(dropped)))
    print("自检:")
    for ln in lines:
        print(ln)

    if not ok:
        os.remove(args.out)
        print("[FATAL] 自检未通过，已删除产出文件，请修复后重跑", file=sys.stderr)
        return 1

    print("  状态: OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())

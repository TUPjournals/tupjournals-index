# -*- coding: utf-8 -*-
"""
期刊编校审读 —— 通用 PDF 提取脚本（参数化，跨机可移植）
用法:
    python review_extract.py <input.pdf> [<input2.pdf> ...] [-o <输出根目录>]
输出:
    <输出根>/<tag>/<tag>.txt          (按栏提取的文本)
    <输出根>/<tag>/pages/pageNN.png   (页面渲染图)
说明:
    输入 PDF 用其绝对/相对路径直接给出；<输出根> 默认为当前工作目录下的 article/。
    例：python review_extract.py "D:/稿件/xxx.pdf" -o "D:/审读工作区"
"""
import os
import sys
import pdfplumber

DEFAULT_OUTROOT = os.path.join(os.getcwd(), "article")


def detect_columns(page):
    """判断是否双栏，返回 (is_two_col, split_x)"""
    words = page.extract_words()
    if not words:
        return False, None
    mid = page.width / 2
    centers = [((w["x0"] + w["x1"]) / 2) for w in words]
    left_cnt = sum(1 for c in centers if c < mid)
    right_cnt = len(centers) - left_cnt
    if left_cnt < 10 or right_cnt < 10:
        return False, None
    return True, mid


def process(src, outroot):
    tag = os.path.splitext(os.path.basename(src))[0]
    outdir = os.path.join(outroot, tag)
    os.makedirs(outdir, exist_ok=True)

    with pdfplumber.open(src) as pdf:
        n = len(pdf.pages)
        probe = pdf.pages[1] if n > 1 else pdf.pages[0]
        two_col, split_x = detect_columns(probe)
        print("=== %s : %d pages, two_col=%s ===" % (src, n, two_col))

        parts = []
        for i, page in enumerate(pdf.pages):
            parts.append("\n" + "#" * 60)
            parts.append("########## PAGE %d ##########" % (i + 1))
            if two_col:
                sx = split_x or (page.width / 2)
                left = page.crop((0, 0, sx, page.height), strict=False)
                right = page.crop((sx, 0, page.width, page.height), strict=False)
                parts.append("---------- LEFT COLUMN ----------")
                parts.append(left.extract_text() or "")
                parts.append("---------- RIGHT COLUMN ----------")
                parts.append(right.extract_text() or "")
            else:
                parts.append("---------- SINGLE COLUMN ----------")
                parts.append(page.extract_text() or "")

        text = "\n".join(parts)
        tpath = os.path.join(outdir, tag + ".txt")
        with open(tpath, "w", encoding="utf-8") as f:
            f.write(text)

        pdir = os.path.join(outdir, "pages")
        os.makedirs(pdir, exist_ok=True)
        for i, page in enumerate(pdf.pages):
            page.to_image(resolution=170).save(
                os.path.join(pdir, "page%02d.png" % (i + 1)), format="PNG"
            )
        print("  chars=%d -> %s" % (len(text), tpath))


if __name__ == "__main__":
    argv = sys.argv[1:]
    outroot = DEFAULT_OUTROOT
    targets = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-o", "--out"):
            i += 1
            if i >= len(argv):
                print("错误：-o 后缺少输出目录", file=sys.stderr)
                sys.exit(2)
            outroot = argv[i]
        else:
            targets.append(a)
        i += 1
    if not targets:
        print(__doc__.strip())
        print("\n示例: python review_extract.py \"D:/稿件/xxx.pdf\" -o \"D:/审读工作区\"")
        sys.exit(1)
    for t in targets:
        if not os.path.isfile(t):
            print("跳过（文件不存在）：%s" % t, file=sys.stderr)
            continue
        process(t, outroot)

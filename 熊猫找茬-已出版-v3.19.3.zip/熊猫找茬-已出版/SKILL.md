---
name: 熊猫找茬-已出版
version: 3.19.3
agent_created: true
description: 熊猫找茬-已出版 — 对投稿或已出版论文进行学术诚信辅助筛查。输入：论文文件（Word/PDF，须含作者与参考文献）+ 期刊全名、缩写或 aims & scope 链接。六个检测维度同等对待（无模式区分），某维度所需信息缺失时该维度标「未检测」并跳过：① 内容相关性——比对论文主题与期刊收稿领域；② 作者诚信——含撤稿检索（Retraction Watch 逐一比对，同名二次核验）与作者机构-领域适配性（机构名称语义比对，缺机构信息则子项未检测）；③ 参考文献真实性——Crossref 逐条核对标题/作者/年份/期刊，检索是否被撤稿，统计引用年份分布；④ 参考文献语义相关性——逐篇比对引用上下文与文献实际内容；⑤ 声明完整性——COI/作者贡献/研究伦理声明核对（编委会名单可选，提供后可对照编委核 COI，缺名单仅该子项未检测）；⑥ AI 痕迹——句长均匀度、高频 AI 用词、人称使用等文本特征。另含前置政治敏感词扫描（Taiwan/Tibet/Xizang，命中时报告「0 政治风险」红字提示）。输出：HTML 报告一份，含各检查项结论；所有发现均为筛查信号，建议人工核实。Use when user mentions 诚信检查、新收稿件检查、投稿审查、熊猫找茬、新稿筛查、稿件初筛、已出版论文核查、编委会名单，或提交论文要求做入审前筛查/诚信核查。
---

# 熊猫找茬-已出版 — 稿件诚信检查（六维检测，缺信息维度标未检测）

## When to use

触发场景：
- 用户说"检查这篇新投稿"、"帮我做诚信检查"、"看看这篇稿件能不能送审"
- 用户提交了论文文件（Word/PDF）+ 期刊 scope 信息（或期刊名）
- 用户提交已出版论文（链接 / DOI / 文件）要求做诚信核查
- 编辑要在送外审前对稿件做一次全维度初筛
- 用户提供编委会名单（可选）→ 声明完整性维度可对照编委核对 COI；缺名单仅「COI 对照编委」子项标未检测

**缺信息跳过说明**：
- 六个检测维度（①-⑥）同等对待，**无模式区分**。
- 某维度所需信息缺失时，该维度标「未检测」并跳过，**不阻止整体流程**，也不自行搜索、不猜测、不反复重试。
- 缺信息只影响对应维度（或子项），其余维度正常执行。

**用户指定跳过维度（v3.12.0）**：用户可显式要求跳过某维度（如「跳过参考文献的相关检查」），此时 ③④ 相关维度标 `.info`「未检测」，**报告中不得出现该维度的任何核验结论**。落盘/渲染步骤：
1. `summary.refs` = `{badge:"info", verdict:"未检测", text:"本维度按用户要求跳过：…"}`；`summary.ext` 中 ④ 行（参考文献语义相关性）同法处理。
2. `refs_verify.summary`（必填）与 `refs_citation_issues`、`year_stats_note`、`refs_rw.note` 均写跳过说明。
3. `ext_sections.semantic_refs` 写 `<p><span class="badge info">未检测</span> …</p>`（不含 h2）。
4. ⚠️ **模板第 4 节的表格覆盖不到**：4.1 年份分布表、4.2/4.3 由 content 字段驱动可覆盖，但 **4.4 的 `build_refs_rw_check` 在 `matches` 为空的分支只返回一句话、不追加 note**，会留下「…0 篇存在真实撤稿记录」这一**未执行却看似已核验**的结论。因此生成 HTML 后须用 Edit 将第 4 节整体（`<h2>4 参考文献可靠性检测</h2>` 至 `<h2>5` 之前）替换为「未检测」块（子项状态表 + 说明），并 grep 确认全文无 `0 篇存在真实撤稿记录` 等残留。
5. 与作者维度解耦：作者撤稿检索（3.1）属 ②，**不随参考文献跳过**，照常执行。

## When NOT to use

- 用户只需要 AI 率检测 → 用 `AI率检测助手` skill
- 用户只需要某单一检查项（如只看参考文献）→ 分别调用对应脚本即可，无需走完整流程

## Prerequisites

```bash
pip install -r requirements.txt
```

- `rapidfuzz` — 用于作者名/标题的模糊匹配（缺失时脚本自动回退 difflib，功能正确但较慢）
- `requests` — Crossref API 查询、scope URL 可达性校验
- `pdfplumber` — PDF 输入稿件的文本提取（docx/txt 不需要）
- `python-docx` — docx 正文/表格提取（agent 工作流常用）
- `defusedxml` — **v4.0.0 起（同步新稿 v2.15.0）**：docx XML 安全解析（防 billion-laughs 实体膨胀；缺失时回退 xml.etree 并打警告，功能可用但不防实体攻击）
- Retraction Watch CSV 下载使用标准库 `urllib` 实现（见 `scripts/download_retraction_watch.py`）
- 首次运行需要联网下载 `retraction_watch.csv`（约 60MB），缓存在 `<skill>/data/` 下
- 运行环境：任何装有上述依赖的 Python 3.10+ 即可（示例 venv：`<你的Python环境>/Scripts/python.exe`；本机路径因机器而异，分享后按实际环境替换即可）

## 分享包打包规范（生成给同事的 zip 时逐条核对）

打包脚本：`<skills>/dist/_build_pack.py`（构建 + 内置自检）、`<skills>/dist/_verify_pack.py`（独立复验，只读 zip 本体，不信任 staging）——⚠️ **`dist/` 是技能目录的同级兄弟目录，不在技能目录内**，故它天然不会被打进包。二者 v3.18.0 起随 dist 存放，**均不属技能运行文件、不进分享包**。产出 `dist/熊猫找茬-已出版_v<版本>.zip` + 同名 `.sha256`（内容格式 `hash␣␣文件名`，沿用 v3.8.0/3.9.0 约定）+ `熊猫找茬-已出版_v<版本>.清单.txt`（记录源提交、哈希、包含/不含清单与校验命令），zip 内顶层目录固定为 `熊猫找茬-已出版/`。

**版本号三处必须同步**（打包脚本会校验，不一致即中止）：① `SKILL.md` frontmatter 的 `version`；② `README.md` 的「当前版本 **vX.Y.Z**」；③ 两个打包脚本顶部的 `VER` 常量。**发版顺序固定**：改版本 → `git commit` → 重建包（清单的「源仓库提交」取自 HEAD，且脚本断言工作区干净）→ 打 tag。

**新增脚本无需改打包脚本**：`scripts/*.py` 按白名单通配**全量**纳入，仅 `gen_report_emd*.py` 两枚一次性脚本（硬编码本机路径 + 具体稿件元数据）被排除——因此新增参考文献解析/统计类脚本会自动进包，无需逐一登记。

**打包后必须跑独立复验**：`python _verify_pack.py`（读 zip 本体，不信任 staging），六组检查全 PASS 才算可交付；任一 FAIL 即不得发出。

**必须排除**（缺一项即算打包事故）：

| 排除项 | 原因 |
|---|---|
| `data/`（retraction_watch.csv ≈60MB） | 运行数据；同事首次运行自动下载 |
| `cache/`（crossref_cache.json ≈84MB、rw_index.pkl ≈55MB） | 运行缓存，可重建 |
| `work/`、`work_*/` | **含未发表稿件的正文与作者信息，最高敏感级** |
| `assets/journal_scopes.json` + `*.bak-*` | 个人积累期刊记录，设计上「禁止进分享包、升级永不覆盖」 |
| `_user_meta.json`、`*.log` | 本机技能元数据与日志 |
| `scripts/gen_report_emd*.py` | **一次性报告脚本**：硬编码具体稿件标题、作者单位与本机个人工作目录，且在接收方环境中不可运行（依赖已排除的 `work_*/`）。通用能力由 `gen_report.py` 覆盖；两文件仅在本机留存作历史参考 |

**必须脱敏**（逐项 grep 复验，不得只靠肉眼）：

- 本机绝对路径与系统用户名：凡出现「系统盘符 + 用户目录 + 用户名」形式（如 `…:…/Users/<用户名>/…`）或「个人工作盘 + 中文个人目录名」形式的字符串，一律换成通用占位。已处理 Prerequisites 条目；打包脚本内置正则扫描，命中即中止打包。

**打包后自检**（全部通过才算完成）：

1. `zipfile.namelist()` 复查：顶层唯一、无 `data/`/`cache/`/`work`/`journal_scopes.json`/`*.bak-*`；
2. 对解包内容跑 `py_compile` 全脚本语法校验；
3. 跑打包脚本内置的泄漏扫描（三组关键词：本机系统用户名、系统盘用户目录路径、个人工作盘中文目录路径）——命中即中止，不产出 zip；关键词表与正则写在 `dist/_build_pack.py` 中，**不要写进本文档**（否则文档自身会被扫描命中）；
4. 读 `SKILL.md` 与 `README.md` 的版本号，须与文件名版本一致（**曾出现 README 写 v3.7.0 而实际 v3.9.1 的漂移**）；
5. 写 `.sha256` 并回读确认哈希与文件名同列。

## 脚本运行注意（CRITICAL：stdout/stderr 分离）

所有脚本的 JSON 结果输出到 **stdout**，日志输出到 **stderr**（`download_retraction_watch.py` / `retraction_watch.py` 的 `log()` 均为 `print(..., file=sys.stderr)`）。因此：
- 后台/重定向运行时，**必须分离两个流**：`python xxx.py ... > result.json 2> result.log`，**严禁 `2>&1`**。
- 若误用 `2>&1`，stderr 日志会污染 JSON 文件开头，导致后续 `json.load` 失败、报告误显示"数据未就绪"。
- 报告生成脚本读取结果时，应做容错：跳过 JSON 前导的非 JSON 行（定位第一个 `{` 再 `json.loads`），双重保险。
- **`gen_report.py`（报告渲染）**：stdout 只输出**一行机器可读 JSON**（`{"status":"ok"|"warn"|"error","out_file","size","leftover"}`），日志/警告走 stderr；agent 读取 stdout 判断生成结果，`status=error` 时按 stderr 提示修复，`status=warn` 时按 `leftover` 补全 report_content 字段后重跑。

## 运行环境陷阱（Windows/Git Bash 实战经验）

- **Git Bash heredoc 会破坏反斜杠转义**：`python - <<'EOF' ... EOF` 方式传递 Python 源码时，MSYS 会把 `\s` `\.` `\S` 等静默改写为 `/s` `/./` `/S`，导致正则**静默失效**（不报错、匹配为空，如 `doi:\s*(10\.\S+)` 永远匹配不到）。排查特征：正则匹配结果异常为空、repr 显示 `\` 变成 `/`。**规避：所有含转义序列的脚本一律写成 .py 文件再运行，禁止用 heredoc 传递 Python 源码。**
- **docx 参考文献可能在 Mendeley SDT 字段中**：Word 引用管理器（Mendeley/Zotero）会把参考文献列表放进 `MENDELEY_BIBLIOGRAPHY` 的 `<w:sdt>` 结构化标签内，**python-docx 的 `document.paragraphs` 不会遍历 sdtContent 内段落**，导致提取出的文本只有 "References" 空标题、参考文献"缺失"（误判稿件不完整）。**规避：docx 提取必须用 XML 深度遍历**（`ElementTree.fromstring(document.xml)` + `tree.iter('{...}w:p')`，sdt 内的 `w:p` 也会被迭代），并保留文档顺序（body 子元素混合 `w:p`/`w:tbl`/`w:sdt` 时写递归 walker）。遇 docx 缺参考文献时先查 `word/endnotes.xml`/SDT 再判定不完整。**已提供 `scripts/extract_docx.py` 深度提取工具**（XML 递归遍历 body，覆盖 sdt/表格，输出全文 `out_text.txt` + 段落 `out_paras.json`），docx 文本提取一律用它，勿手工写提取代码。
- **rapidfuzz 累积处理原生崩溃（Windows，CRITICAL）**：`retraction_watch.py check-refs` 在同进程内对大批量参考文献（实测约 60+ 篇）连续调用 `process.extractOne` 时，rapidfuzz C 扩展发生原生段错误，**进程静默退出（无 traceback、无 JSON 输出、退出码 1）**，临界点取决于累积处理量而非单条标题（单条单独跑正常）。表现：日志只有 `ensure_csv` 行、stdout 为空。**规避：参考文献 > 50 篇时用 `scripts/batch_check_refs.py <refs.json> <out.json> [batch_size=40]` 分批运行**（每批独立子进程调用 check-refs，再合并 matches，等效全量结果）；诊断方法：二分切片 `refs[:N]` 定位崩溃批次。
- **APA 风格参考文献（`作者 (年). 标题. 期刊 卷, 页码.`）解析**：与 EMD 惯用「作者, 标题, 期刊, 卷 (年) 页码」格式不同，须用 `scripts/parse_refs_apa.py`（年份 `(YYYY)` 为锚 → 首个句点分标题 → 卷号前取期刊名）；注意标题内缩写（如 "vs."）会使标题提前截断、年份括号后的前导句点会污染解析，均需人工抽查修正（实测修正过 [57]「Mechanical properties vs.…」与 [115] 期刊字段）。
- **APA 解析后须二次清理卷/页/DOI（EMD20260105 实测）**：`parse_refs_apa.py` 解析结果中行尾 DOI（`doi: 10.xxx`）未剥离、卷/页码混入 journal 字段（如 `"Adv. Mater. 30, 1800561. doi: 10.1002/adma.201800561"`），导致 Crossref 无法走 DOI 优先验证。**规避：解析后用清理脚本拆分**——先用 `doi:\s*(10\.\S+)` 提取 DOI 并删除该段，再用 `^(.*?)\s+(\d+),\s*([\d\u2013-]+)$` 拆分「期刊名 卷, 页码」；卷号为连字符区间（如 152–153）或页码为 e 文章号（如 e202413927）时拆分失败属正常（DOI 优先验证不受影响），无需强修。
- **batch_check_refs.py 合并 total_references 缺陷（EMD20260105 实测）**：分批运行（batch_size=40）后输出 JSON 的 `total_references` 只反映**第一批**（40/52），matches 合并正常。**规避：生成后核对 `total_references` 与 refs.json 总数是否一致，不符则手动合并各批 `_batch_N_out.json`**（matches 相加、total_references 累加），再覆写 refs_rw.json。
- **EMD 惯用格式解析字段错位 → Crossref DOI 反查补全（EMD20260111 实测）**：EMD 参考文献惯用「作者, 标题, 期刊. 卷 (年) 页码」格式，`parse_refs.py` 解析时**整行吞入 authors、title/journal 为空或 title 被页码污染**（如 `e202502116`），但 **DOI 提取正确**（29/32 篇）。**规避：不修解析器，写二次清洗脚本**——有 DOI 条目直接 `GET https://api.crossref.org/works/{doi}`（UA+mailto 礼貌池）反查规范元数据覆盖（title/journal/volume/page/year/authors，仅保留原 index+doi）；无 DOI 条目（如 CNKI 中文文献）才启发式拆分。**反查返回的 title/journal 含 HTML 标记（`<sub>5</sub>`、`<mml:math>`、`&amp;`）须先 `re.sub(r'<[^>]+>', '', s)` + 实体替换清理再入库**，否则污染标题比对与报告展示。可复用模板：`work/EMD20260111_m20260044_李清/refs_clean.py`。
- **引用统计正则须支持带空格编号组 + 四种破折号（hyphen / en-dash / em-dash / minus sign）**：正文 `[49, 50]`、`[25, 29, 31, 38, 39]`（如 ESM 表 S2 对比标注）等带空格逗号形式，以及 `[5–7]`、`[12–15]`、`[24–26]` 等**范围**写法（CESCI20260019 实测论文常用 en-dash 而非 hyphen），若用 `\[(\d+(?:[-,]\d+)*)\]` 会**漏匹配**导致误报「文献未引用」。⚠️ **【CRITICAL，ECM20260040 实测】范围连接符还可能是 U+2212 MINUS SIGN（`−`，数学减号，PDF 排版高频）**——该字符既不等于 hyphen(U+002D) 也不等于 en-dash(U+2013)，只写 `[-–]` 时 `[1,16−18]` 整组被当作单 token **静默丢弃**，[16][18] 被误报「未引用文献」（`citation_stats.py`）且引用上下文抓不到（`semantic_check.py`），两脚本同一 Bug、同组编号同时中招。**规避：统一用四字符类 `_DASH = r'\-\u2013\u2014\u2212'`，`PAT_REF`/`PAT_RANGE`/`CITE_GROUP_RE` 全部共享；normalize 阶段须把 `\u2013`/`\u2014`/`\u2212` 三者都替换为 `-`**，再按逗号 split + strip 展开区间；统计范围覆盖正文段落 + 全部表格单元格（out_text.txt 已含表格文本）。**排查口诀：凡是「按引用标记切分/展开」的正则结果异常（漏编号、上下文为空），先打印该处字符码（`ord()`）确认破折号类型——缺一种就静默漏、且不报错。**
- **refs.json 必须为纯列表格式（CESCI20260019 实测）**：`crossref_check.py verify/year-stats` 与 `retraction_watch.py check-refs` 均期望 `--refs` 参数指向 **list of dict**（各条目含 index/authors/title/journal/volume/page/year/doi 字段）。若传入 parse_refs.py 的 dict 输出（`{"refs": [...], "parse_failed": [...], "raw_refs": [...]}` 结构）会直接 TypeError（`'str' object does not support item assignment` / `'str' object has no attribute 'get'`），crossref.json/refs_rw.json 落盘为空。**规避：解析脚本输出后，单独将 refs 数组写为纯 list JSON 再传给验证脚本**；自定义解析器（如 Vancouver/APA 二次清理）输出时直接落盘 list 格式。
- **引用统计必须用脚本，禁止 agent 手写（v4.0.0 同步新稿 v2.12.0）**：`scripts/citation_stats.py <全文文本> <refs总数整数>` 自动处理逗号列表/带空格/en-dash 范围并区间展开，输出 cited/uncited/over_range。实测手写代码只 split 不区间展开时 `[2-5]` 仅计 {2,5}，致 57 篇「未引用」全部误报（EMD20260103）；en-dash 范围（`[5–7]`）若不专门处理同样误报（CESCI20260019）。**凡报告 4.4 引用分布一律跑此脚本**。
- **统一配置收敛（v4.0.0 同步新稿 v2.15.0）**：路径/UA/mailto 统一收口到 `scripts/config.py`（PANDA_MAILTO 环境变量可覆盖礼貌池邮箱）；`scripts/journal_scopes.py` 提供期刊记录双层数据源（`load_all()` = 模板 ∪ 用户合并、用户优先；`save_scope()` 只写用户文件 `assets/journal_scopes.json`——该文件为个人积累记录，**禁止进分享包、升级永不覆盖**，内置模板为 `assets/journal_scopes_template.json`）。任何路径/标识改动先改 config.py。
- **同一文件多处编辑禁止并行发出（v3.13.0 实测 + v3.15.0 二次确认，CRITICAL）**：对**同一文件**连续发出多个编辑请求时，每个编辑各自基于**编辑前的快照**写回整个文件，故**最后一次写回会吞掉同批次的其余全部编辑**——实测对 `report_content.json` 连发 3 处修改仅 1 处生效（v3.13.0）；对 `gen_report.py` 连发 3 处修改**仅最后 1 处生效、前 2 处被整体回退**（v3.15.0），两次**每次工具都返回成功**。规避：同一文件的多处修改要么**串行逐次执行并在每次后回读复核**，要么（推荐）写成**单脚本一次读出、一次写回**（`json.load` → 改内存对象 → `json.dump`），脚本内对每条替换加「已应用/已存在/未匹配」状态输出，写后立即回读断言。**判断特征：编辑报成功但 grep 文件仍是旧文案；修复方式：逐条重发 + 逐条 grep 复验。** **v3.18.0 三次复现（新增，纠正上文「串行即安全」的隐含假设）**：同一轮内 **3 次串行**编辑本文件（frontmatter 版本号 3.17.0→3.18.0 → 插入 v3.18.0 变更行 → 追加上文变更行末尾）后，**插入与追加两条都在、唯独首次的 frontmatter 改动被吞掉**，同样每次工具均返回成功。可见危险不只来自并行：**同一文件内相距越远的改动越易互相覆盖**（frontmatter 与文末变更表相隔 110KB，中间的任意一次整体写回都会基于自身旧快照）。规避升级为：① 版本号这类**单点小改单独一次编辑并立即回读**，不与大批量编辑同轮；② 必须同轮多改时，用**单脚本一次读出/一次写回**，且把「版本号」放在同一次写回内；③ 以打包脚本的**版本一致性闸门**兜底（`SKILL.md` frontmatter / `README` / 包名三者不符即中止，本次即由此拦截）。
- **重新生成报告会冲掉第 4 节「跳过」补丁（v3.13.0 实测）**：`gen_report.py` 每次运行都从模板重渲染全文，因此「用户指定跳过维度」所做的**第 4 节 HTML 后处理补丁会被覆盖**（4.4 节重新出现「0 篇存在真实撤稿记录」这类未执行却看似已核验的结论）。规避：**任何重新生成之后都必须重跑第 4 节替换，并 grep 复验**——`0 篇存在真实撤稿记录` 应无命中、全文不应出现 `<p><p>`、`{{…}}` 占位符应为空。另：`build_aigc_note` 曾对已是 HTML 片段的 `aigc_note`（内含 `<p>`）**再包一层 `<p>`** 产生 `<p><p>` 双包裹，v3.13.0 已修（检测到块级标签则直接拼接，仅纯文本才补 `<p>`）。**v3.14.0 已修根因**：`build_refs_rw_check` 的「零命中」分支原先丢弃 `note` 参数，导致跳过说明无法落进 4.4 节——现已在零命中分支拼接 `note`。**v3.15.0 彻底闭环**：新增「未执行」判定（`refs_rw.json` 缺 `total_references` 键 → 输出 `.info`「撤稿检索未执行」，而非 `0 篇存在撤稿记录`），因此**该维度按用户要求跳过时不再需要任何 HTML 后处理补丁**；其余需后处理的场景仍按上述流程 grep 复验。
- **docx 超链接必须用 `w:hyperlink` 命名空间查找（v3.14.0 实测，CRITICAL）**：`<w:hyperlink>` 元素在 **wordprocessingml** 命名空间（`{http://schemas.openxmlformats.org/wordprocessingml/2006/main}hyperlink`），只有 **`r:id` 属性**在 relationships 命名空间。若用 `{...relationships}hyperlink` 查找会得到 **0 个结果且不报错**，从而误判「文档里没有链接」（实测首次探测即因此漏掉 31 个 DOI 锚点）。规避：一律用 `scripts/extract_doi_anchors.py`，勿手写探测代码。
- **DOI 锚点提取的三个隐藏坑（v3.14.0）**：① DOI 可含**圆括号**（ASCE 系：`10.1061/(asce)hy.1943-7900.0001476`），正则排除 `)` 会截断 DOI；② 少数链接畸形（前导 `%20`、指向 arXiv 页面而非 DOI），需回退到**文献文本行内**搜 `10.xxxx/...`；③ PubMed 链接只有 PMID，须经 NCBI **eutils esummary** 换 DOI（`idconv` 接口常返回 HTML 错误页 → `JSONDecodeError`）。另：arXiv DOI（`10.48550/...`）由 **DataCite** 注册，**Crossref 查不到（404）**，核验时须回退标题检索并注明「引用版本为预印本」。
- **PDF 提取必须分栏感知，且上/下标合并有跨栏吞字风险（v3.15.0 固化，CRITICAL）**：pdfplumber 的 `extract_words` 按 x 排序，**双栏排版会把左右栏文字并进同一行**——直接拼接会让引用标记的宿主句被错栏内容污染（引用统计、语义上下文、句长统计全部失真）。规避：一律用 `scripts/extract_pdf.py`（先按行统计「中部大空档」取中位中心作为 gutter → 逐行切 L/R → 按 F→L→R 顺序拼接），勿手写提取代码。**其中「把小字号上/下标并回前一个词」这一步是隐藏雷区**：若仅按「字号小」判断，会把低栏字号（参考文献 8.5pt vs 正文 10pt）在**同基线附近**的词跨栏并入正文，产生 `andtechnology`、`intreatmentprocesses(inChinese)`、`will bereduction` 之类粘连，并直接破坏 gutter 切分（本稿实测事故）。正确判据必须**三条同时满足**：小字号（< 正文中位字号 × 0.86）**且**垂直偏移 ≥ 0.8pt **且**与前词水平间隙 ≤ 3pt（跨栏间隙通常十几 pt）。
- **AIGC 统计会被分栏 PDF 的「折行引用标记」截断（v3.16.0 实测，CRITICAL）**：`aigc_stats.py` 在找不到 References 标题时回退「首个 `[N]` 开头行」作为正文截断点；正文**换行**把引用标记载到行首时（`...Schnepf et al.` 换行 `[15] proposed using...`）会误触发，正文被截到该行之前——OCE20260029 实测 7196 词 → **640 词**，句长/变异系数/TTR/首人称/提示语密度**全部失真且不报错**（历史 OCE20260026 报告同样受影响：5497 → 8288 词，其 AIGC 指标须以新脚本重测）。**规避：v3.16.0 已加严回退条件**——仅当 `[N]` 开头行 ≥5 行、首行编号 ≤2 且编号序列下降次数 ≤20% 时才认定参考文献节。**判断特征：正文字数与稿件体量明显不符（数千词论文只有几百词）即命中本坑**，须核对 aigc.json 的 word_count 与正文规模。
- **泛用词高重叠会把「完全不同的文献」判为同一篇（v3.16.0 实测，CRITICAL）**：`titles_match` 原仅按 token 重叠率 ≥0.65 判定，`global / report / 年份` 这类泛用词足以让主题完全不同的文献拿高分——OCE20260029 [1] GWEC《Global wind report 2025》被 OECD《Global Debt Report 2025》以 0.75 重叠、8/13 分**接受为「通过」**，并连带在 `semantic_check.py fetch` 的「无 DOI 标题反查」中挂上错误摘要（DOI 10.3987 系 OECD 报告），不复核就会产出「真实性通过 + 语义一致」的双重假结论。**规避：v3.16.0 起新增特征词守卫**——稿内特征词（长度 ≥4、非泛用词、非纯数字）一个都无法在候选标题中找到即判非同篇。**判断特征：报告/标准/网页类文献被判 verified 时，人工核对 crossref_title 是否与稿内标题同指一物**；同类误配还须清理 semantic_abs.json（重跑 fetch 即不再反查该 DOI）。
- **APA + 分栏 PDF 折行的文献表须先去折行再解析（v3.16.0 新增 `scripts/parse_refs_apa_wrapped.py`）**：`parse_refs.py`（EMD 惯用格式）与 `parse_refs_apa.py`（假定「单行 = 单条」）都无法处理**双栏 PDF 提取产生的折行文献表**（每条折成 2–4 行、条间夹页眉/版权/页码/页脚 DOI 噪声行）——OCE20260029 实测：前者把 25 条拆成 26 条且 21 条标题为空，后者因丢弃续行只剩骨架。**规避：APA 式分栏 PDF 稿件一律用 `parse_refs_apa_wrapped.py <全文文本> <out.json>`**（定位 References → 剔 URL/页码/页眉版权噪声 → 以 `[n]` 为条目起点合并续行 → 年份锚定解析；标题切分跳过 `U. S.` 式单字母缩写，先摘 DOI 再取期刊/卷/页），输出纯 list 可直接喂下游脚本。诊断特征：正文出现「正常英文单词被无空格粘连」即回头查此规则。
- **文献条目会吞入文末页码/版权噪声，且「条目内搜 DOI」会捞到本稿自身 DOI（v3.16.1 实测，CRITICAL）**：`parse_refs_apa_wrapped.py` 以 `[n]` 为条目起点合并续行，当页脚（`Ocean, 2026, 2, 9470027`）、版权行（`© The author(s) 2026. Published by TUP.`）恰好夹在两条文献之间时，会被并入相邻条目的 `journal` 字段（OCE20260027 实测 [40] 吞入页眉文案、[43] 变为 `Ocean, 2026, 2, 9470027 Joule`）；更隐蔽的是**在条目文本内正则搜 `doi:`/`doi.org/` 会命中本稿自身的页脚 DOI**，使无关文献被挂上本稿 DOI（[40][43] 同时被误挂 `10.26599/OCEAN.2026.9470027`），DOI 优先通道随即走偏。**规避**：二次清理（`work/OCE20260027/cleanup_refs.py` 可复用）必须同时做两件事——① 按噪声正则剔除 `journal` 字段中的页脚/版权/运行标题，再按 `^(.*?)\s+(\d{1,4}),\s*([^\s]+)` 拆分「期刊 卷, 页」；② 设 **本稿 DOI 黑名单常量**（`MANUSCRIPT_DOI`），凡提取结果等于本稿 DOI 一律丢弃。**判断特征：清除后带 DOI 篇数骤降（本稿 6→3）且剩余 DOI 均能在 Crossref 命中，即为清理正确。**
- **区分「原稿笔误」与「PDF 提取丢字」的字形探测法（v3.16.1 实测）**：作者名/题名出现可疑缺字（如 `Prtner`、`Plike`）时，不要凭「其他变音符号正常」就下结论，也不要直接判为提取失真——用 pdfplumber 打印目标词邻域的逐字符属性（`page.chars` 的 `text` / `fontname` / `size`，取 `joined.find(token)` 后前后各若干字符）。**判据**：① 字符序列在目标位置**连续无空档**（`P r t n e r ,`）、② 字体与上下文一致且**该字体标准字符集包含缺字**（Times New Roman 含 ö/ä）→ 判定**原稿用字缺失**，可作为著录问题报告；③ 若邻域出现字体切换、空字符或位置跳变 → 按提取局限处理，不得报告为稿内问题。OCE20260027 实测 [3] `Prtner`/[39] `Plike` 满足 ①②（同页 Müller、Niño、Skákala 变音符号均正常），故判为原稿缺字。可复用脚本模式：`work/OCE20260027/glyph_probe.py`。
- **Crossref「同题异著」须单独甄别（v3.16.1 实测）**：报告类/网页类文献（政府报告、联合国网页、机构白皮书）常与同名书章/评注**题名完全相同**，Crossref 会给出高分命中并通过 `titles_match`，`semantic_check fetch` 更会把该错误 DOI 对应的摘要挂到条目上（本稿 [1] 2022 年 UNESCO 报告 → 被挂 1981 年书章 `10.1007/978-94-009-8261-1_32`；[6] 联合国 SDG 14 网页 → 被挂德文 SDG 评注）。**判据：年份/出版者/文献类型与稿内著录明显不符时，一律归「无法定位（Crossref 未收录）」，不得标真实性风险，也不得据其摘要做语义一致性结论。** 另：DataCite 注册的 DOI（Zenodo、arXiv 等，`10.5281/…`、`10.48550/…`）Crossref 必然 404，应改走 `https://api.datacite.org/dois/{doi}` 核验后再判（本稿 [34] NEMO 手册据此确认著录完全一致）。

- **PDF 折行会把「完整句子」拆成碎片（v3.18.1 实测，报告第 0 条政治风险块失真）**：`geo_check.py` 原先逐行切句，分栏 PDF 提取后一个自然句常被拆成 3–4 个物理行，报告中「完整句子」列只显示断句碎片（ECM20260041 实测：地理区域列举句显示为 `(Xizang Autonomous Region, Hong Kong Special Administrative` + `Region, Macau Special Administrative Region, and Taiwan` 两段残句），人工核查看不到完整语境。**已修复**：命中行先经 `expand_wrapped()` 向前/向后补齐到句子边界再切句，同一句被多行触发时由 `_dedupe_hits()` 按后缀包含合并（保留最完整者并合并关键词）。**判断特征：政治风险/引用上下文等按「行」取句的字段出现无标点结尾的残句即命中本坑。**

- **双栏 PDF + APA 折行文献表的 DOI 提取必须在「去空白」文本上做，且先摘本稿 DOI 黑名单（v3.18.2 实测，CRITICAL）**：URL/DOI 会跨行折断（`https://doi.org/10.1016/j.ese.` + 换行 + `2021.100134`），逐行 DOI 正则会把 DOI **静默截断**（截成 `10.1016/j.ese`）；更隐蔽的是**本稿页脚 DOI 会并入相邻条目**（ECM20260043 实测 [3][59][78] 三条被吞入 `10.26599/ECM.2026.9400043` 并向后吞字），修剪前若未做黑名单，DOI 优先通道会直接走偏。正确四步：① 整行剔除 `^https?://doi\.org/10\.26599…`，并在拼接后按 `MANUSCRIPT_DOI` 做 substring 删除；② 在 `re.sub(r'\s+','',条目全文)` 上匹配 `10\.\d{4,9}/[A-Za-z0-9._;()/:\-]+`；③ 尾部修剪**只在「句点后接大写开头词」时截断**——按「最后一段以大写开头」判会把 `10.1039/D0EE02681F` 砍成 `10.1039`（本稿踩坑 1 次）；④ 取**最短合法候选**（跨行粘连只会让候选变长），长度 >70 视为吞并正文丢弃。**另：不可加「必须含字母」守卫**——ISBN 型纯数字 DOI（`10.1017/9781009157926.013`）会被误杀（本稿踩坑 1 次）。本稿逐行提取得 7 篇但其中 2 篇截断，改用去空白法 + 上述四条后 7 篇全部正确。

- **URL slug 截断与「运行页眉词」内联清洗的边界（v3.18.2 实测）**：① 双栏页眉词 `Article` 与页码标记 `9400043 (14 of 15)` 会被折行解析**内联进题名中段**（本稿实测 `Monthly generation Article reports`、`Sustainable Article aviation fuel technologies…`、`The 9400043 (14 of 15) environment and directed technical change`），须在 `clean_text()` 内联剔除；② 为清除域名被截断后残留的 URL slug（`040325-playing-catchup-with-china-…`）而设的「首个 slug 处截断」规则**只能作用于 journal 字段**——题名里 `Re-examining`、`grid-enhancing` 等合法连字符词会被误截（本稿实测把 `Re-examining rates of lithium-ion battery technology improvement and cost decline` 砍成 `Re-examining rates of`）；且 slug 正则必须带 `(?<=\s)` / `(?=\s|/|$)` 边界，否则会在词内部做子串匹配（`Re-examining` 里的 `e-examining` 也会命中）；③ 题名在 `U.S` / `vs` / `et al` 等**无空格缩写**处被「首个句点」规则提前截断（本稿 `…(CPI-U), U.S`、`Pay-as-Produced PPA vs`），续接修复须在**折叠换行后的条目原文**里定位（在含 `\n` 的原文里 `find()` 会失败）。

- **`crossref_check.py` 的 verified 计数不可直接采信——ECM20260043 已核 3 例误判（v3.18.2）**：本稿 status=verified 的 14 条中，[24] 稿内 `Geração de Energia Elétrica no Brasil` 被命中 `GERAÇÃO DISTRIBUÍDA NO SETOR DE ENERGIA ELÉTRICA NO BRASIL`（**不同文献**）、[31] IEA `Electricity 2026—Prices` 被命中 `Electricity prices`、[45] 欧盟 `Critical raw materials act` 被命中 `Unpacking the Critical Raw Materials Act`，三条均为「短题名/泛用词」型误配且**通过了 4 分接受阈**。**规避：报告 4.3 的「通过」篇数必须逐条比对 `crossref_title` 与稿内题名是否同指一物，不得直接采信脚本计数**（与 v3.16.0 泛用词误配同源——特征词守卫只能挡住「一个特征词都对不上」的情形，短题名仍会漏过）。

- **「DOI 未注册 + 刊名卷页不符」类著录错误的判定路径（v3.18.2，ECM20260043 [15] 实测）**：Crossref `/works/{doi}` 返回 404 后脚本回退标题检索，给出的候选**刊名与稿内明显不符**（稿内 Nature Climate Change，返回 Nature Communications）。此时**不得按「同题异著」归入无法定位**——须用 **OpenAlex 题名反查真实 DOI**，再取 Crossref 记录核对字段：本稿据此确认该文实为 *Nature Communications* 11(1): 2096、DOI `10.1038/s41467-020-15414-6`，而稿内 DOI（`10.1038/s41558-020-0880-1`）未注册、刊名与卷页均错，作者序列一致 → 判为**同一文献的三项著录错误**（真实问题，写入 4.3 问题表）。判据要点：**作者序列一致 + 题名一致 + 载体/卷页全不一致 = 著录错误，而非不同文献**。

- **可复用检出项：合引编号升序检查（v3.18.2 新增，建议纳入 4.2）**：用 `_DASH` 四字符类正则抽出全部 `[n,m,…]` 组并做区间展开，`nums != sorted(nums)` 即为非升序组；ECM20260043 实测 2 处（`[64,54]`、`[83, 19, 84]`），属体例问题，写入 4.2 著录问题表。

- **ACS 编号式参考文献 + 裸上标数字引用（Carbon Future，CF2024-9200019 实测，v3.19.2，CRITICAL）**：ACS/Nature 系刊物常见两处与既有解析器不兼容：① **参考文献为 ACS 式**（`[n] Surname, A. B.; Surname, C. D. Title. Journal Year, Volume, Pages.`）——作者段以 `;` 分隔、标题后紧跟期刊缩写，`parse_refs.py`（EMD 式）与 `parse_refs_apa*.py`（年份括号锚定）均不适用；② **正文引用为无括号上标数字**（`… catalytic activity39−45.`）——`citation_stats.py` 的 `\[n\]` 正则与 `semantic_check.py contexts` 的 `CITE_GROUP_RE` **全部漏空**（实测上下文 0/137、未引用误报 83 篇）。**规避：配套使用新增的 `scripts/parse_refs_acs.py` + `scripts/superscript_citations.py` + `scripts/superscript_contexts.py`。**
  - **ACS 解析要点**：作者段正则须带重复量词 `(?:作者模式\s*;?\s*)+`——**漏写 `+` 会只吃到第一位作者，其余作者串会变成标题**（首轮即踩）；作者缩写的后续字母须写 `(?:\s+[A-Z]\.)*`，写成 `(?:\s*[A-Z]\.?)*` 会把下一位作者的姓氏首字母吞进缩写；条目收集须在 `Acknowledgements / Author contributions / Competing interests / Data availability` 处截断，否则末尾条目会吞入致谢与作者贡献正文；双栏 PDF 会把版权块（`Open Access This article is licensed…`、`creativecommons.org`、`and indicate if changes were made`）折行插进文献条目中间（实测 [127] 的页码被挤到版权块之后），须按关键词整行剔除后再重拼；期刊名从标题串末尾回扫，判据须**排除两字母全大写词**（`CO`/`RR` 等标题尾化学式会被误吞，实测 [66][137] 各一次）。本次 137/137 条字段完整、0 条解析失败。
  - **上标引用统计（判据是字号，不是位置）**：本稿正文 9.48 pt、引用上标 6.64 pt、化学式下标 6.16 pt、页眉页脚 8.0 pt。**Minion Pro 等 Type1 子集字体的 `top` 按字形高度计算——同一视觉行内 `'C'` 与 `'o'` 的 top 可相差 11 pt**，用 top 判上下标会随机成功/失败。判据取「`size < 正文中位字号 × 0.80`」+「候选 top ≤ 同行正文字符 top + 1.0」（下标 top 明显更大而被排除）；选取「同行正文字符」时的 top 容差**必须收紧到 4 pt**——取 10 pt 会把相邻行拉进来当参考，实测使 12 个引用组全部碎裂成单字符；分组须先按 top 容差 2.5 聚类成视觉行、行内再按 x 间隙 ≤2.5 合并（**不可用 `(round(top,1), x0)` 线性排序后直接合并**，同组字符 top 的微小差异会让排序交错而拆组）。单位幂次（`cm−2`、`mA cm−2`）用「单位前须为非字母字符」的边界正则排除——**不可只做词尾匹配**，否则 `solutions18−25` 的尾字母 `s`（秒）会把整组上标误杀（实测首轮漏掉 [18]–[25] 即因此）。修正后 137/137 被引用、0 未引用、0 越界。
  - **上标引用的语境提取**：不能沿用方括号正则。按「引用所在栏（左栏 x < gutter）+ 视觉行前后各一行」取文本；拼接字符时按 x 间隙 > 1.0 pt 补空格，否则得到 `greenhousegasemissions` 式粘连；构建行集合须用**含空格字符**的原始 chars（仅在判定上下标时才过滤空格）。本次 137/137 取得上下文。

- **二次清洗的参考文献结果必须覆盖写回 `refs.json` 本身（CESCI-D-26-00020 实测，CRITICAL）**：`gen_report.py` 只读 `work/<稿件标识>/refs.json`，**不读** `refs_clean.json` / `refs_doi.json` 等派生文件。因此当 `parse_refs.py` 解析失败、按既有流程改用二次清洗脚本（DOI 反查补全 + 启发式拆分）产出干净结果时，**必须把清洗结果覆盖写回 `refs.json`**（原始解析结果另存 `refs_parse_raw.json` 留档），否则报告 meta 的「参考文献」计数与 4.1 年份分布表会沿用旧解析数据（本稿曾渲染成 33 篇 / 合计 33，实际 36 篇，且分桶计数同步偏低）。**判断特征：报告年份表「合计」≠ 参考文献实际篇数，或 meta 计数与稿件文献条数不符。** 另：Elsevier 编号式（`[n]作者, 标题, 期刊 卷 (年) 页码. DOI`）在本稿再次触发 `parse_refs.py` 字段错位（title 取到页码、journal 为空、36 条只出 33 条）——处置办法同 EMD20260111：**不修解析器，写二次清洗脚本**，并在脚本内顺带做「稿内原文 vs Crossref」著录一致性审计（题名是否出现在原文、年份/卷/页码是否相符），可一次性筛出真实的著录错误与仅属解析差异的假警。可复用模板：`work/CESCI-D-26-00020/cleanup_refs.py`。

## Workflow（必须按顺序执行）

整体流程共 10 步，各维度所需信息缺失时该维度标「未检测」并跳过：

```
Step 0: 前置输入校验（preflight.py）
  → 校验失败则暂停，向用户提问；通过则继续
  → 盘点各维度所需信息，缺失项对应维度标「未检测」

Step 0.5: RW 数据准备（download_retraction_watch.py）
  → 版本检查 + 判断 + 下载，串行执行一次；确保 CSV 就绪且 FRESH 快筛命中

Step 0.6: 政治敏感词扫描（geo_check.py）
  → 命中 Taiwan/Tibet/Xizang 时，报告「0 政治风险」红字提示 + 句子/章节表格

Step 1: 检查1 — 内容相关性
Step 2: 检查2 — 作者诚信与机构适配性（retraction_watch.py + affiliation_check.py）
Step 2.5: 检查5 — 声明完整性
Step 3: 检查3 — 参考文献检测（crossref_check.py + retraction_watch.py）
Step 3.5: 检查6 — 参考文献语义相关性核对
Step 4: 检查4 — AIGC 检测
Step 5: 生成 HTML 报告
```

**并行规则（CRITICAL）**：
- RW 数据准备（Step 0.5）必须先于任何 RW 查询（Step 2 的 check-authors、Step 3 的 check-refs）**串行完成**；
- 数据就绪后（FRESH 快筛命中、不触发下载），check-authors 与 check-refs **可并行执行**——两者仅只读 CSV，无文件锁冲突；
- **严禁在数据未就绪或可能触发下载时并行**运行两个 RW 查询（并发下载共用 `.tmp` 路径 + `os.replace` 覆盖 vs 读取 → Windows 文件锁冲突，会导致其中一个查询失败一次）。

**检测结果落盘约定（work 目录，CRITICAL）**：
- 每次检测把各脚本 stdout JSON 写入 `<skill>/work/<稿件标识>/`（stdout/stderr 分离：`> xxx.json 2> xxx.log`），供 Step 5 渲染脚本读取。文件名映射：

| 脚本/子命令 | 落盘文件 |
|---|---|
| `geo_check.py` | `geo.json` |
| `parse_refs.py` | `refs.json` |
| `crossref_check.py verify` | `crossref.json` |
| `retraction_watch.py check-authors` | `authors.json` |
| `retraction_watch.py check-refs` | `refs_rw.json` |
| `affiliation_check.py` | `aff.json` |
| `aigc_stats.py` | `aigc.json`（**必落盘**，供 AIGC 定量指标表自动生成） |
| `semantic_check.py fetch` | `semantic_abs.json`（逐条摘要抓取，Crossref+OpenAlex 双源） |
| `semantic_check.py contexts` | `citation_contexts.json`（每条文献的正文引用上下文） |
| `semantic_check.py pair` | `semantic_pairs.json`（摘要+引用上下文合并的逐条比对清单） |

- 示例：`python scripts/geo_check.py --text <全文文本> > work/<稿件标识>/geo.json 2> work/<稿件标识>/geo.log`
- 某文件缺失时，对应自动表格在报告中按「未检测」呈现（渲染脚本容错，不中断）。

---

### Step 0: 前置输入校验

**目的**：确保用户提供了完整的检测所需信息，否则暂停并引导用户补充。

调用脚本：
```bash
python scripts/preflight.py --paper <论文路径> [--scope-url <URL>] [--journal <期刊全名>] [--abbrev <缩写>]
```
注：preflight 仅直接解析 Word(docx)/txt；若输入为 **PDF**，**必须先跑 `scripts/extract_pdf.py`**（分栏感知提取，禁止手写 pdfplumber 提取代码），再走 preflight 与后续流程（如 CESCI 稿件处理）：

```bash
python scripts/extract_pdf.py <paper.pdf> <work目录>/out_text.txt <work目录>/out_paras.json
```
输出 `out_text.txt`（阅读顺序：满宽 F → 左栏 L → 右栏 R）/ `out_paras.json`（段落 + col 标记）/ 同目录 `body.txt`（References 之前正文，供 aigc_stats）。stdout 为一行 JSON（含 `gutter_pages`——**为 0 说明未识别出分栏，需人工确认是否单栏稿**）。

脚本返回 JSON（stdout），agent 读取后按以下逻辑处理：

```json
{
  "status": "ok" | "incomplete",
  "paper": {
    "has_authors": true/false,
    "has_references": true/false
  },
  "scope": {
    "source": "url" | "journal_lookup" | "user_input" | "none",
    "url": "...",
    "text": "...",
    "valid": true/false
  },
  "actions_required": []  // 需要用户补充的事项
}
```

**Agent 处理逻辑**：

1. **文件完整性检查**：若 `paper.has_authors == false` 或 `paper.has_references == false`，向用户提示：
   > "检测到文件可能不完整（缺少[参考文献 / 作者信息]）。是否仅对已上传内容做检测？"
   - 用户确认 → 继续
   - 用户拒绝 → 暂停，等待完整文件
   - ⚠️ **has_authors 仅粗检正则**：`(?i)(author|作者)` 会把文末声明 "All authors declared that there are no conflicts of interest." 等字样误判为有作者。即使 `has_authors == true`，agent 也必须人工确认稿件中是否真实存在作者姓名/单位/邮箱；若无（如 Clean/双盲版），按"缺作者名单"处理并询问用户是否提供名单或跳过检查 2。

2. **Scope 信息来源判断**：
   - `source == "url"` 且 `valid == true` → ✅ 通过
   - `source == "url"` 且 `valid == false` → 提示链接无效，执行下方逻辑
   - `source == "journal_lookup"` 且找到记录 → ✅ 通过
   - `source == "journal_lookup"` 且未找到记录 → 执行下方逻辑
   - `source == "none"` → 执行下方逻辑

2.5. **链接内容 vs 本地记录差异比对**（`source == "url"` 时，preflight 自动抓取链接文本并与本地匹配记录的 `scope_text` 比对，输出 `scope.diff`）：
   - `diff.action == "update"`（差异 <10%）→ 用 `diff.fetched_text` 更新本地记录 `scope_text` 与 `updated_at`，告知用户「线上 scope 内容已同步本地记录」；
   - `diff.action == "review"`（差异 ≥10%）→ 提示用户「链接内容与本地记录差异较大（相似度 X%），请确认所提供链接/信息是否正确」，由用户决定是否覆盖，**不得擅自覆盖**（遵循红线①）；
   - 本地无匹配记录 → 无 `diff` 字段，按下方「保存记录」询问是否保存新记录；
   - ⚠️ 机器抓取文本可能含页面噪声（导航/版权/404 页），`diff` 结果仅供参考；若抓取内容明显异常（如 404 页面），请用户人工确认链接有效性或直接粘贴 scope 文本。

3. **首次/非首次判断**：
   - 若 `journal_scopes.json` 中无任何记录（首次运行），询问：
     > "本次为首次检测，请提供期刊全名、缩写、aims & scope 链接或文档。"
   - 若非首次但无匹配记录，询问 scope 信息，并询问是否保存到记录

4. **保存记录**：用户提供信息后，更新 `<skill>/assets/journal_scopes.json`。记录字段：`full_name` / `abbreviation` / `scope_url` / `scope_text` / `added_at`；可选编委名单字段 `editorial_board`（姓名列表）/ `editorial_board_url` / `editorial_board_text` / `editorial_board_updated_at` / `editorial_board_source`——编委名单由用户提供 Editorial Board 页面链接 / PDF / 文字 / 本地名单表时录入，未提供则整组字段留空（或保留 `editorial_board: []`）。**下次运行仅输入期刊缩写（如 `--abbrev EMD`）即可命中本地记录快速调用**；记录含编委名单时，维度⑤「COI 对照编委」子项可直接复用本地名单。

   **编委名单字段口径**（对齐现有 EMD / CES 记录）：
   - `editorial_board`：姓名列表；**领导层标注角色**（如 `Dongping Fang (Editor-in-Chief)`、`Jun Yi (Honorary Editor-in-Chief)`），普通编委只写姓名（不带角色后缀）；
   - `editorial_board_text`：分组人读摘要，格式 `组名 (人数): 姓名1, 姓名2, …`，组间用 `; ` 分隔，中文名可括注在英文名后（如 `Dongping Fang (方东平)`），末尾给 `Total N members.`；
   - `editorial_board_updated_at`：**写入本文件的日期**（非名单本身的版本日期）；
   - `editorial_board_source`：来源与版本（本地源表路径 + sheet 名 + 名单版本日期 + 可比的印刷定稿文件），供日后溯源与判断是否需要更新；
   - `editorial_board_url`：仅当确有**可正常访问**的官方 Editorial Board 页面时才填；不可访问则省略并在 `editorial_board_source` 里说明原因。

   **编委名单补录 / 更新（三步）**：
   ① **取名单**——优先级：本 skill 本地记录 > **期刊信息库**（`panda-kb` 建成的期刊总表 `编委-*` sheet 及其 `templates/journal.<刊>.json` 的 `editorial_sources`，含源文件路径、sheet、分组行、列映射） > 用户直接提供（xlsx / PDF / 文字）；
   ② **核对**——统计总人数与各组人数，与源表逐组对齐；若为更新，与上一版比对增减并回报（名单增减要看得见）；
   ③ **写入**——写前先备份原 `journal_scopes.json`，写后重新加载校验 JSON 合法、总刊数不变、目标刊人数正确。

   **红线②（名单回写）**：编委名单在**信息库侧**更新（或用户在任何其他场合提供过）后，**必须回写本文件 `assets/journal_scopes.json`**，否则本 skill 无从感知，维度⑤「COI 对照编委」子项会静默退回「未检测」。信息库与检测器是**两套独立数据、无自动同步机制**——**不得假设「给过一次就已有记录」**（CES 实证：名单 2026-09-10 已汇入信息库，而本文件最后写入停在 2026-08-21，导致 2026-09-15 检测时编委子项被判未检测）。

   **不抓 CES 官网**：CES 官方页面不可访问 / 不可抓取，其 scope、编委等数据一律从本地文件、期刊信息库或用户提供内容获取，**不得尝试联网抓取**。

5. **维度所需信息盘点（本 skill）**：对照以下清单，逐维度确认本次可用的信息；缺失项对应维度标「未检测」并跳过，不自行搜索、不猜测、不反复重试：
   - ① 内容相关性：论文标题/摘要/关键词 + 期刊 scope 文本（scope 缺失 → 该维度未检测）
   - ② 作者诚信：作者列表 + 全文文本（缺失 → 该维度未检测；机构提取不到 → 仅 2b 机构适配子节未检测，2a 撤稿检索照常）
   - ③ 参考文献：参考文献列表（缺失 → 该维度未检测）
   - ④ 参考文献语义相关性：论文全文 + 参考文献列表 + 联网定位能力（缺任一项 → 该维度未检测）
   - ⑤ 声明完整性：论文声明段 + 编委会名单（**优先复用本地记录 `editorial_board`**；本地无则询问用户提供；均无 → 仅「COI 对照编委」子项未检测，其余子项照常）
   - ⑥ AIGC：论文全文（缺失 → 该维度未检测）
   - **红线①（跳过语义）**：某维度所需信息缺失时，该维度标「未检测」并跳过，**不得自行搜索、不得猜测、不得反复重试**；用户提供的链接被 Cloudflare / 五秒盾拦截、超时或返回非页面内容 → 视为"无法获取信息"，要求用户改传 PDF 或粘贴文字内容；若用户无法提供，则该维度未检测，继续其余维度。

---

### Step 0.6: 政治敏感词扫描

**目的**：扫描全文识别关键词 **Taiwan / Tibet / Xizang**（含 Taiwanese / Tibetan 等词干变体，忽略大小写）。命中任意一个时，在报告中以**第 0 条「0 政治风险」**红字提示"潜在政治风险，请人工核查"，并以表格列出含关键词的完整句子与所属一级标题。

**调用脚本**：
```bash
python scripts/geo_check.py --text <全文文本文件>
```
（全文文本须为 agent 提取合并后的纯文本，含 Title page；与 preflight / affiliation_check 输入一致）

脚本返回 JSON（stdout）：
```json
{
  "status": "found" | "not_found",
  "hits": [
    {
      "keyword": "Taiwan",
      "sentence": "The samples were obtained from Taiwan, China.",
      "section": "Introduction"
    }
  ],
  "note": null | "未检测到 Taiwan/Tibet/Xizang"
}
```

**匹配规则**：
- Taiwan → `\btaiwan\w*`（含 Taiwanese）；Tibet → `\btibet\w*`（含 Tibetan）；Xizang → `\bxizang\b`（精确）；全部忽略大小写。
- 句子按 `[.!?]\s+` 切分提取；章节归属通过识别一级标题（Abstract / Introduction / Methods / Results / Conclusion / References 等，支持数字编号前缀如 "1 Introduction"）确定。
- 命中即提示（不区分 "Taiwan, China" 等表述是否合规——是否为风险由人工判断）。

**Agent 处理逻辑**：
- `status=found` → 填充模板中的 `{{POLITICAL_RISK}}`（位于稿件基本信息之后、第 1 节之前）：
  - 红色小字标注："**0 政治风险：潜在政治风险，请人工核查。**"
  - 下方表格三列：关键词 / 完整句子 / 所属一级标题
- `status=not_found` → `{{POLITICAL_RISK}}` 填充为空字符串，报告中不显示（无任何痕迹）。

---

### Step 1: 检查1 — 内容相关性

**输入**：论文标题 + 摘要 + 关键词；期刊 aims & scope 文本（来自 Step 0）

**方法**：
1. 从论文中提取标题、摘要、关键词（读取 Word/PDF 文件；PDF 用 pdfplumber 提取）
2. 读取或获取期刊 scope 文本
3. Agent 做语义比对，判断：
   - 论文主题是否在 scope 列出的领域中
   - 论文类型（research article / review / case report）是否在期刊接受类型中

**输出要求**：
- 第 2 节起始处固定渲染「期刊收稿范围对照依据」块（来源 URL + 版本日期 + 概括性中文收稿范围，**纯文本段落表述，非表格**），由 gen_report.py 自动从 `assets/journal_scopes.json` 读取（`scope_source` / `scope_version_date` / `scope_summary_zh`），**agent 无需手写**
- 相关性分析以 **4 列表格** 呈现（占位符 `{{SCOPE_ANALYSIS_TABLE}}`，数据来自 report_content.json 的 `scope_analysis` 字段，**必填**）：
  - 列：`分析维度` / `稿件特征` / `对应期刊领域` / `匹配度`
  - 匹配度徽章三档：`高度相关`（绿 ok）/ `部分匹配`（黄 warn）/ `不相关`（红 bad）
  - 每行一个分析维度（如研究主题、研究类型），agent 填入稿件特征与期刊领域对应关系
- 如 scope 中无明确对应领域但论文有交叉可能，匹配度标注 `部分匹配`（黄 warn）并在要点中注明"需人工判断"

---

### Step 2: 检查2 — 作者诚信与机构适配性

**输入**：论文作者列表（来自 Step 0 解析结果）+ 全文文本

本步骤分两个子步骤：
- **2a 作者撤稿检索**（retraction_watch.py check-authors）
- **2b 作者机构与论文领域适配性**（affiliation_check.py 提取机构 + agent 语义判断；缺机构信息 → 该子节标「未检测」）

#### Step 2a: 作者撤稿检索

**调用脚本**：
```bash
python scripts/retraction_watch.py check-authors --authors "Author1,Author2,..."
```

脚本返回 JSON：
```json
{
  "csv_source": "downloaded_YYYY-MM-DD" | "cached_YYYY-MM-DD" | "download_timeout" | "download_failed" | "cached_YYYY-MM-DD (download incomplete, kept previous version)" | "input_error",
  "authors": [
    {
      "name": "Author Name",
      "hits": [
        {
          "author_in_csv": "...",
          "title": "...",
          "subject": "(ENV) Environmental Sciences;...",
          "retraction_date": "...",
          "reason": "...",
          "institution": "...",
          "original_paper_doi": "...",
          "retraction_doi": "..."
        }
      ],
      "risk": "high" | "medium" | "low" | "none"
    }
  ]
}
```

**Agent 输出要求**：
- 数据来源说明：`downloaded_YYYY-MM-DD` 表示本次刚完成下载；`cached_YYYY-MM-DD` 表示复用本地已有文件（日期为数据源端更新日期 `update_date`）；含 `download_timeout` / `download_failed` / `incomplete`，须向用户提示数据可能非最新或缺失，并给出手动下载地址 https://gitlab.com/crossref/retraction-watch-data；含 `input_error` 表示作者名格式错误，需按提示改用 "First Last" 顺序重试
- 检索方法说明（token-level exact match，防 substring 误报）
- 每位作者的结果：命中数 / 匹配度（如有命中，列出相似论文的 title + subject + institution）
- 整体评估：给出作者存在撤稿记录的可能性大小，**明确提示用户需人工判断**

**三档分类规则（作者领域相近性判断）**：
脚本对每位作者返回 `hits`，命中项含 `subject`（撤稿库学科分类，如 `(ENV) Environmental Sciences`）、`institution`、`retraction_doi`、`original_paper_doi`。agent 据此做**三档提示**：
1. **无命中** → 直接说明"该作者在 Retraction Watch 中无撤稿记录"。
2. **有命中但领域不同** → 说明"同名命中，但所涉撤稿论文的 Subject/机构与待查稿件领域不相关，基本判定为同名误报"，列出 subject + institution。
3. **有命中且领域相同** → 醒目警示"同名且领域相近，需人工重点核实"，务必列出 `retraction_doi` 供编辑逐条人工核对。

**关键规则**：
- 使用精确 token 匹配（surname + first-name token），防止 substring 误报（如 "Bhattacharya" 中的 "Acharya"）
- 原始命中可能包含大量假阳性，必须做二次校验（同名作者尤其常见，务必比对 subject/institution 判断是否同一人）
- 不在报告中要求用户下载文件，由 agent 完成所有操作
- `--authors` 参数用逗号分隔不同作者，姓名必须用 **"First Last" 顺序**（如 `"Dengyang Guo, Di Yang"`）；若误用 "Last, First" 会被逗号拆成伪作者，脚本已内置校验并返回 `input_error`
- 撤稿检索表格填入报告第 3 节子节「3.1 作者撤稿检索」（占位符 `{{AUTHOR_RESULTS}}`，不含 h3 标题）

---

#### Step 2b: 作者机构与论文领域适配性

**目的**：判断作者机构与论文研究领域是否适配，作为诚信初筛的补充信号。

**调用脚本**：
```bash
python scripts/affiliation_check.py --text <全文文本文件>
```
（全文文本须为 agent 提取合并后的纯文本，含 Title page；与 preflight 输入一致）

脚本返回 JSON（stdout）：
```json
{
  "status": "found" | "not_found",
  "affiliations": ["Shandong Key Laboratory of Intelligent Energy Materials, School of Materials Science and Engineering, China University of Petroleum (East China), Qingdao 266580"],
  "matched_lines": ["a Shandong Key Laboratory ..."],
  "note": null | "未检测到机构信息"
}
```

**Agent 处理逻辑**：

1. **提取不到机构（`status=not_found`）→ 缺信息跳过**：
   - 询问用户："未检测到作者机构信息，是否提供机构名称？"
   - 用户提供 → 用用户提供的机构做适配性判断（来源标注"用户提供"）
   - 用户不提供 → 该子节标注「**未检测（未提供机构信息）**」，不判定适配性（遵循缺信息跳过语义，**禁止**标「通过」或「不相关」）

2. **提取到机构（`status=found`）→ agent 语义判断**：
   - **仅依据机构名称做语义理解，禁止联网搜索机构信息**（不调用 WebSearch/WebFetch 核实机构）
   - 判断方法：机构名称中的领域关键词（Materials / Energy / Chemical / Electrochemical / Battery / Physics / Mechanical / Civil / 材料 / 能源 / 化学 / 电池 等）与论文主题（标题/摘要）交叉比对
   - 两档结果：
     - **适配**：机构领域词与论文主题匹配（如能源材料重点实验室 + 电池论文）→ 直接给结论，**不附提示**
     - **不相关**：机构为完全无关领域（如医学/农业机构投电池论文）→ **必须附提示**："机构名称不含论文领域相关词，但机构可能为跨学科/综合机构（如大学、科学院系统），建议人工检查该机构是否有相关研究团队"
   - 若机构名既无明显领域词、也无法明确判定（如仅"XX University"无院系信息）→ 归入「不相关」并附人工检查提示

**报告输出要求**（填入第 3 节子节「3.2 作者机构与论文领域适配性」，占位符 `{{AFFILIATION_RESULTS}}`，不含 h3 标题）：
- 机构列表（含提取来源：Title page / 正文 / 用户提供）；**机构名称用中文**：中国机构（含港澳台）= 学校+学院，国外机构 = 国名+学校+学院，不含省市/街道/邮编
- badge：`适配`（绿）/ `不相关`（红，附人工检查提示）/ `未检测（未提供机构信息）`（灰 info）
- 判断依据：机构领域词 vs 论文主题词对照
- 注明：本子节判断仅基于机构名称语义，未联网核实机构信息

---

### Step 2.5: 声明完整性检测

**输入**：论文声明段（COI / Author contribution / Ethic 等小节）；编委会名单（**可选**，仅用于 COI 对照编委子项）

**(1) 利益冲突（COI）**：
- 对照编委会名单（如有）：若作者列表出现编委姓名，检查 COI 声明部分是否声明该作者为编委；**无编委会名单时仅「对照编委」子项标未检测，其余子项照常检测**；
- 若某作者所属机构为公司（机构名含 co./ltd./Inc./GmbH 等），检查 COI 声明部分是否声明其公司雇员身份；
- 若 COI 段落形式缺失但无实质冲突，结论写「形式缺失，无实质冲突」，**不得**直接标「通过」。

**(2) 作者贡献**：若文章含 Author contribution（或类似）小节，对照作者列表与声明中姓名是否完全相符；允许姓名简写/缩写/首字母。

**(3) 研究伦理**：若正文出现人类样本/人类被试/实验动物表述，检测是否存在 Ethic（或类似）小节，且是否声明了机构伦理委员会审查情况与参与者知情同意（consent）。

**输出**：三段式 finding 卡片（声明原文位置 / 判定 / 问题分析），无问题则标 `pass`。未提供的子项（如无编委名单）标 `未检测`，**禁止**标「通过」。上述内容填入报告第 6 节（`{{EXT_SECTIONS}}` 后半），h3 按 6.1 利益冲突 / 6.2 作者贡献 / 6.3 研究伦理 / 6.4 致谢·数据可用性·AI 使用声明 分组。

---

### Step 3: 检查3 — 参考文献检测

**输入**：论文参考文献列表（从 Step 0 解析结果中提取）

**参考文献解析（脚本化）**：
```bash
python scripts/parse_refs.py <全文文本> <out_refs.json>
```
从全文 References 节解析 `[n]` 编号参考文献，输出 `index/authors/title/journal/volume/year/page/doi`（与 crossref_check 输入格式一致）：以年份 `(YYYY)` 为锚回溯卷/页/期刊（兼容 `Science, 334 (2011)` 与 `J. Am. Chem. Soc. 135 (2013)` 两种格式）；作者/标题按「首字母缩写+姓」正则分界；行尾 DOI（`https://doi.org/...`）自动剥离并提取到 `doi` 字段（有/无 DOI 均适用）；解析失败项列于 `parse_failed` 供 agent 手工补全（复姓如 R. Van Noorden 可能误判为标题开头，需人工核对）。

- **APA 风格 + 折行（双栏 PDF）**：若稿件为 APA 式著录（`作者 (年). 标题. 期刊 卷, 页码.`）且来自 PDF 提取（文献条目被折成多行、条间夹杂页眉/页脚），用 `python scripts/parse_refs_apa_wrapped.py <全文文本> <out_refs.json>`（先剔噪声、合并续行，再按年份锚定解析；OCE20260029 实测 25/25 条字段完整）。

此步骤分三个子步骤（注：报告章节编号为 4.x，见 Step 5，与本文档工作流子步骤 3.x 编号不同）：

#### 3.0 DOI 锚点提取（优先执行，v3.14.0 新增）

**何时用**：稿件或**其作者/编辑预处理过的「统一格式版」**（文献管理软件导出，条目末带 `[LinkOut]` / `[PubMed]` 标记）可能**在文献条目上挂着超链接**——这些链接就是确定性的 DOI 锚点。**遇到此类稿件（或用户单独提供了这类文件）时，先跑本步再验证**。

```bash
python scripts/extract_doi_anchors.py <docx> --out anchors.json
python scripts/extract_doi_anchors.py <docx> --merge refs.json --out refs_doi.json   # 直接补进 refs.json
```

**收益（CESCI-D-26-00015 受控 A/B 实测，同一 36 篇文献、同一脚本、清空响应缓存冷启动）**：

| 通道 | 耗时 | 真实命中 | 说明 |
|---|---|---|---|
| DOI 直连（31 篇有锚点） | **21.6 s** | 31 条定位 | 无相似标题误配风险 |
| 仅标题检索（0 锚点） | 56.8 s | 30 条定位 | 1 篇被「低分未接受」判为 not_found |

即 **快 2.6 倍，且把 1 篇误判「未找到」救回**。实证结论：**统一格式、带 DOI 锚点的文献表显著优于未统一格式**——应当在稿件接收/退修阶段就向作者索取。同时注意统一化过程可能**反向损伤**著录（该稿有 3 处页码/期号被截断、1 处模板占位符未填），须逐字段比对原稿并回补。

**判读要点**：arXiv 类 DOI（`10.48550/...`）由 DataCite 注册，Crossref 返回 404 属正常，须回退标题检索并标注「引用版本为预印本、建议改引正式发表版本」。

#### 3.1 Crossref 真实性验证

**调用脚本**：
```bash
python scripts/crossref_check.py verify --refs <references_json_file>
```

**验证策略**：

1. **DOI 优先**：有 DOI → 直接 GET `/works/{DOI}`（DOI 大小写不敏感，统一小写），DOI 精确解析的匹配置信度最高。
2. **无 DOI 时标题搜索+评分匹配**：
   - 调用 Crossref query API（`/works?query=标题+作者`），返回最多 3 条候选结果
   - 对每条候选进行**4 维度评分**（满分 8 分）：
     - 标题 token 重叠 ≥ 70% → +3 分
     - 第一作者姓氏匹配 → +2 分
     - 期刊名匹配（支持缩写展开）→ +2 分
     - 年份匹配 → +1 分
   - 取得分最高者，且 **总分 ≥ 4 才接受**该匹配
3. **核对项**（全部来源）：
   - 标题（模糊匹配，忽略大小写）、年份（精确）、第一作者姓氏
4. **额外核对项**（仅标题搜索来源）：
   - 期刊名、卷号、页码
   - ⚠️ **page_mismatch 需人工甄别**：Crossref 常只返回起始页，脚本会把 ref="1563-1572" 清洗为 "15631572" 与 "1563" 比对而**误报** page_mismatch。仅当起始页本身不同（如 ref=4016 vs crossref=4011）才确认为真实差异；起页一致仅格式不同的，按"通过"处理并在报告中说明。
   - ⚠️ **author_mismatch 常见三类误报，报告阶段须人工甄别**：① 多作者文献脚本只取 ref 的**末位姓氏**与 Crossref 第一作者比对（如 "R. Adhikari and D. Gautam" 取 gautam vs adhikari）→ 误报；② `et al.` 占位被当姓氏（ref=al）→ 误报；③ 姓氏引号字符差异（弯引号 D’Ayala vs 直引号 D'Ayala）→ 误报。判据：DOI 精确解析 + 标题/期刊一致时，author_mismatch 一律按比对逻辑误报处理，不构成真实性风险。
   - ⚠️ **CNKI 中文文献无 DOI、Crossref 未收录的甄别（EMD20260111 实测）**：中文期刊（如《广东电力》Guangdong Electr. Power）常无 DOI 且该刊未被 Crossref 收录。此时标题搜索会**误匹配相似英文文献**，产生年份/期刊 mismatch 假象。判据：① 先人工拆分作者/标题/期刊补全元数据（启发式：作者按「首字母缩写+姓」、标题到首个期刊名句点）；② Crossref 查不到属预期，判「**无法定位，非真实性风险**」，**不可据标题误匹配标真实性问题**；③ 报告 4.3 节按「无法定位（未收录）」列出并在处理建议中请作者补 DOI 便于核验。

**礼貌池与并发**：请求通过 `mailto` 参数加入 Crossref 礼貌池（限速 10 req/s、并发上限 3），脚本以并发 3 执行，429/5xx 自动指数退避重试，避免限流误判 not_found。

**输入 JSON 格式**（增加字段）：
```json
{
  "index": 1,
  "title": "...",
  "authors": "Author1, Author2",
  "year": "2020",
  "journal": "Journal Name",
  "volume": "12",
  "page": "1234",
  "doi": "10.xxx/yyy"
}
```

#### 3.2 发表年份统计

**调用脚本**：
```bash
python scripts/crossref_check.py year-stats --refs <references_json_file>
```

输出按 5 年跨度的年份分布表格（**零计数分桶同样列出**，含 `≤2000` / `≥2026` 两端与 `合计` 行；与 `scripts/crossref_check.py year-stats` 的输出保持一致，不得过滤空行——v3.15.0 修复）：
| 年份区间 | 数量 | 占比 |
|---|---|---|
| ≤2000 | N | X% |
| 2001-2005 | N | X% |
| 2006-2010 | N | X% |
| 2011-2015 | N | X% |
| 2016-2020 | N | X% |
| 2021-2025 | N | X% |
| ≥2026 | N | X% |
| 合计 | N | 100% |

> 脚本 `gen_report.py::build_year_stats_table` 读 `refs.json` 现场分桶（不依赖 `yearstats.json`），两端区间与合计行必须齐全，否则读者无法判断「±两端确已纳入统计」。

#### 3.3 Retraction Watch 撤稿检索

**调用脚本**：
```bash
python scripts/retraction_watch.py check-refs --refs <references_json_file>
```

匹配优先级：
1. **DOI 锚定优先**：参考文献的 `doi` 与撤稿库 `OriginalPaperDOI` 精确匹配（大小写不敏感）→ 最高置信（`match_type="doi"`, `confidence="high"`）。
2. **标题模糊匹配**：DOI 无命中时，用标题做 `token_sort_ratio` + `partial_ratio` 模糊匹配，**阈值 ≥ 90**，忽略大小写。命中项含 `match_type="title"`，`confidence` 为 `high`（≥95）或 `review`（90–95，需人工复核）。
3. **去噪过滤（双向子串型误报，v3.11.1 补规则 B）**：命中需同时通过两条过滤，否则不报告——
   - **规则 A（撤稿库侧短条目）**：命中标题（撤稿库条目）的 token 数 ≤ 3，且与 ref 标题的共同单词数 ≤ 3 → 过滤。解决撤稿库 1-3 词占位条目对长 ref 标题 `partial_ratio` 高分命中（实测：EMD20260109 [115] 被单词条目 "Monitoring" 100 分命中）。
   - **规则 B（文献侧短通用短语）**：ref 标题 token 数 ≤ 4、其 token 集合**完全包含于**命中标题，且命中标题 token 数 ≥ 2 倍 → 过滤。解决反方向子串误报：文献标题本身是通用短语（"Compressed sensing" / "Convex Optimization"），恰为某条主题完全不同的撤稿标题的子串而拿满分（实测：CESCI-D-26-00025 [23] "Compressed sensing" 100 分命中肺部超声撤稿文；CESCI-D-26-00019 [34] "Convex Optimization" 100 分命中在线凸优化撤稿文）。
   - **反向保护**：同一篇的「正标题 vs 正标题+副标题」情形，ref token 数通常 ≥ 5 或命中标题不满足 2 倍关系，不会被规则 B 误杀（回归验证：Kincho 稿 [32] SLAM part I、cesci20260019 [32] 均保留）。实现见 `check_reference_titles` 内 `_common_word_count` 与规则 B 分支。

**Agent 输出要求**：
- 命中的参考文献编号 + 标题 + 撤稿原因 + 匹配类型（doi/title）+ 置信度 + `retraction_doi`
- 如无命中，说明"0 篇参考文献存在撤稿记录"
- 如有命中，提示用户核实这些被撤稿文献是否影响本文论证（`confidence="review"` 的尤其需人工确认）

**Agent 综合输出结构**（报告章节编号为 4.x，见 Step 5）：
```
### 4.1 发表年份分布
[年份分布表格]

### 4.2 引用分布与著录问题
- 正文实际引用统计
- 未引用文献编号列表
- 重复引用检测
- 缺失 DOI 编号列表
- 合引编号升序检查（v3.18.2）：用 `_DASH` 四字符类正则抽出全部 `[n,m,…]` 组并做区间展开，`nums != sorted(nums)` 即非升序组，属体例问题（ECM20260043 实测 `[64,54]`、`[83, 19, 84]` 两处）
- ⚠️ **引用统计必须覆盖表格**：对比方法表/实验设置表（如 "Detailed introduction of comparison methods"）常直接以 `[n]` 标注各方法出处（如 OpenMax[3]、[27]、[28]）。仅统计正文段落会漏掉这些引用、误报"文献未引用"。统计范围 = 正文段落（References 之前）+ 全部表格单元格。同一文献在正文/表格多处引用属正常，不计为问题。

### 4.3 Crossref 真实性验证
- 总数 N，带 DOI 的 M 篇，无 DOI 的 K 篇
- 核验后通过 X 篇（仅汇总数量，**不逐一列出**）
- 信息不一致/无法定位 Y 篇以表格形式列出（文献编号、差异所在/原因）；无不一致则不显示表格
- 「页码起页一致、仅格式差异」按通过处理（见上文 page_mismatch 甄别规则）

### 4.4 Retraction Watch 撤稿检索
[命中结果或"0 命中"]
```

---

### Step 3.5: 参考文献语义相关性核对（全检不抽样）

**输入**：论文全文引用上下文 + 参考文献列表（Step 0 解析）

> **强制工具链（v3.11.0 起，杜绝退化为抽样）**：本步骤必须运行 `scripts/semantic_check.py` 三个子命令，对**每一篇**参考文献取摘要 + 引用上下文，再由 agent 逐条语义判定。**禁止**仅凭 Crossref 书目命中或抽样抽查即下「语义一致」结论。
> ```bash
> # ① 摘要抓取：Crossref（复用 crossref_check 缓存/API）→ 无摘要则 OpenAlex 兜底（inverted index 重建）
> python scripts/semantic_check.py fetch --refs work/<稿件标识>/refs.json --out work/<稿件标识>/semantic_abs.json
> # ② 引用上下文：以正文中引用标记为中心的滑窗（双栏 PDF 按句点切句会错栏，滑窗不依赖句子边界）
> python scripts/semantic_check.py contexts --body work/<稿件标识>/body.txt --refs work/<稿件标识>/refs.json --out work/<稿件标识>/citation_contexts.json
> # ③ 合并比对清单 → agent 逐条精读判定（写 semantic_judgments.json，供报告第 5 节汇总）
> python scripts/semantic_check.py pair --abs work/<稿件标识>/semantic_abs.json --ctx work/<稿件标识>/citation_contexts.json --out work/<稿件标识>/semantic_pairs.json
> ```
> **摘要覆盖口径**：摘要可得（Crossref 或 OpenAlex）→ 按摘要比对；双源均无摘要（书章/会议/经典文献/中文期刊常见）→ 用 Crossref 全维命中书目 + 标题主题级比对**降级处理**，报告中必须标注「仅元数据」篇数与编号，不得与摘要级混同、也不得因此标「无法核实」跳过；双源均无法定位 → 人工联网核实后归「经人工核实」或「无法核实」并说明原因。
> **判定记录**：agent 逐条比对后把结果写入 `work/<稿件标识>/semantic_judgments.json`（每条 verdict=ok/flag + flag 原因），报告第 5 节只呈现统计与问题项（用户口径：只报告问题项）。

对参考文献列表中的**每一篇**逐一执行：

#### 3.5.1 定位与取证
(1) 定位（按优先级递减）：DOI 检索 → 标题检索 → 卷/期号检索（WebSearch + WebFetch / Crossref API）。
(2) 获取程度分级（报告第 5 节按此统计，**摘要级与仅元数据级必须分列**）：
    - **摘要级**：Crossref/OpenAlex 抓到摘要，按摘要内容比对；
    - **仅元数据级**：双源无摘要但 Crossref 书目全维命中，按「标题主题 + 引用语境」降级比对（书章/会议/经典文献/中文期刊常见，报告中标注「仅元数据」篇数与编号）；
    - **人工核实**：双源均无法定位，联网检索核实（含无 DOI 文献）；
    - **无法获取**：联网检索后仍无任何可核实内容。
(3) 记录候选文献的题名、期刊、年份、作者、摘要/关键段落。

#### 3.5.2 数据质量门槛
以下情况**不得**标为「可比对」或「内容一致」：
- 元数据解析失败，仅有书目条目；
- 命中候选为 `Author response`、`Back Cover`、`Front Matter`、`Editorial`、`Table of Contents` 等非研究型条目；
- 候选主题与论文主题明显跨域；
- 标题被截断或无法读取完整信息。

上述情况一律归入「无法核实」并在报告中列出。

#### 3.5.3 语义判定（必须由 agent 完成）
(1) 在论文全文中找到该文献的**引用上下文**（直接引用该文献编号的句子/段落）。
    - **双栏 PDF 陷阱（OCE20260026 实测）**：pdfplumber 会把左右栏文本拼进同一行流，导致引用标记的宿主句被错栏碎片污染（引用句看似挂在无关内容后）。处理：先回 `fulltext.txt` **行级**原文核实；仍无法还原宿主句时，**不得**据此判「不相关/误引」，按其标题主题与所在章节语境降级判定，报告标注「引用位置受版式限制建议核对」（如 OCE [71]）。
(2) 阅读候选文献的实际内容（摘要或全文）。
(3) 判断论文中的描述是否与候选文献一致：
    - **表述一致**：论文对该文献的贡献、结论、数据描述准确；
    - **表述偏差 / 描述不一致**：论文概括、夸大、歪曲了文献内容；
    - **文献不相关**：文献主题与论文论点无直接关联，不能支撑当前引用位置；
    - **疑似虚假 / 无法核实**：查无此文献、出版信息矛盾、或无法获取任何可核实内容。
(4) 对存在问题的文献生成 **三段式 finding 卡片**：
    - **引用上下文**：论文中引用该文献的原文句子（必须引用，不得省略）；
    - **文献实际内容**：该文献实际研究主题与结论；
    - **问题分析**：为何判定为偏差/不相关/虚假，并附 `likely_benign` 良性解释（如适用）。

#### 3.5.4 去噪规则
- **禁止**使用「关键词无重叠即提示」等机械规则。
- 宽泛背景引用、领域综述、方法论文献若与论文主题无直接矛盾，**不出 finding 卡片**，仅在经核实列表中体现。
- 只有 agent 明确判定为「不相关」「描述不一致」「虚假」时才写入报告。

#### 3.5.5 报告呈现
- 以次要信息汇总：获取全文篇数及编号、仅获摘要篇数及编号、无法获取篇数及编号。
- 单独列出「经核实内容一致的参考文献」——**准入条件**：已解析到可靠元数据 **且** agent 完成语义核对无问题。未解析条目必须排除。
- 单独列出「无法核实的参考文献」及其原因。
- 上述汇总填入报告第 5 节『5 参考文献语义相关性检测』（`{{EXT_SECTIONS}}` 前半，含 h2 标题）。

---

### Step 4: 检查4 — AIGC 检测

**输入**：论文全文文本（正文）

**方法（脚本算指标 + agent 判级）**：

1. **定量指标由脚本计算**（确定性、可复现，避免 agent 手算慢且易错）：
   ```bash
   python scripts/aigc_stats.py <全文文本文件>
   ```
   输出 JSON（stdout）：`word_count` / `sentence_count` / `avg_sentence_len` / `sentence_len_cv` / `ttr` / `ai_phrase_total` / `ai_phrase_density_per_1000` / `ai_phrases`（19 个短语逐项计数）/ `first_person_count` / `near_duplicate_pairs`。脚本自动排除 References 节（独立行标题 / 带编号标题 / 回退首个 `[N]` 文献行）。
   **输出必须落盘**：`python scripts/aigc_stats.py <全文文本> > work/<稿件标识>/aigc.json 2> work/<稿件标识>/aigc.log`（Step 5 渲染脚本据此自动生成 AIGC 定量指标表）。

2. **agent 定性分析**（脚本无法替代的部分）：
   - **引用空洞**：检查是否有"研究表明…"类无具体出处的断言（脚本不统计此项）
   - **综合判级**：基于脚本指标做判断——AI 提示语密度 >2/千词 可疑、>5/千词 高度可疑；句长 CV >0.7 异常均匀；首人称完全缺失为附加信号；命中短语是否含强 AI 特征词（delve into / pivotal role / underscores 等）
   - 结合学科特点权衡（如材料类论文 "significantly" 高发常见于非母语作者），给出 `未见痕迹` / `轻度可疑` / `高度可疑`

**输出要求**：
- 定量指标表格（词数、句数、平均句长、句长变异系数、TTR、AI 提示语密度、首人称次数、近重复句数）——直接取脚本 JSON 填表
- 命中 AI 提示语的具体列表（脚本 `ai_phrases` 字段）
- 引用空洞检查结果（agent）
- 综合判断：`未见痕迹` / `轻度可疑` / `高度可疑`
- 附注：此为启发式筛查，非确定性判定，建议配合专业 AIGC 检测工具交叉验证

---

### Step 5: 生成 HTML 报告

**流程（固定渲染脚本模式）**：
1. 各检测脚本结果已按「落盘约定」写入 `<skill>/work/<稿件标识>/`（含 `aigc.json`）；
2. Agent 完成各维度**判定**（内容相关性 4 列分析、机构适配结论、引用分布、Crossref 人工甄别、④ 语义相关性、⑤ 声明完整性 finding、⑥ AIGC 综合判级等），写入 `work/<稿件标识>/report_content.json`（字段见下；只放判定内容，数据表格由脚本自动生成）；
3. 运行渲染脚本：
   ```bash
   python scripts/gen_report.py --work work/<稿件标识> --content work/<稿件标识>/report_content.json --out <输入稿件所在目录> --msid <稿件标识>
   ```
   - 脚本读取 work 检测 JSON + report_content.json + `assets/report_template.html` → 输出 HTML；
   - stdout 为一行机器可读 JSON：`{"status":"ok"|"warn"|"error","out_file","size","leftover"}`；`status=error` 时按 stderr 提示修复；`status=warn` 表示有残留占位符（`leftover` 列出），需检查 report_content 字段；
   - 自动生成的数据表格：稿件基本信息中「参考文献/撤稿数据库版本/检测工具(含生成日期)」、政治风险（`geo.json`）、作者撤稿检索表与受检作者（`authors.json`）、发表年份分布（`refs.json`）、撤稿检索（`refs_rw.json`）、AIGC 定量指标表与提示语明细（`aigc.json`）。
   - **v3.19.0（F-01）所有动态值经 HTML 转义后注入**（含稿件标题/作者/机构/摘要要点、撤稿库作者/标题/撤稿原因、scope 来源与概述、agent 手写的 HTML 字段）；**转义双轨**：纯文本走 `esc()`（全量 `html.escape`），agent 手写 HTML 的字段走 `rich()`（先全转义、再按白名单放行无属性格式标签与 `class`，并对预写实体做幂等保护，避免 `&amp;` 二次转义为 `&amp;amp;`）；**任何新增动态内容渲染时必须经过转义，禁止直接拼接**。历史 `report_content.json` 中手写的 `<table>/<div>/<h3>` 等结构标签由 `rich()` 白名单覆盖，无需改写。

**report_content.json 字段说明**（`schema_version: 1`；徽章用 `{"badge":"ok|warn|bad|info","verdict":"文案"}` 表达，脚本渲染徽章 HTML）：

| 字段 | 必填 | 说明 |
|---|---|---|
| `meta.manuscript_id/title/authors/affiliations/journal/manuscript_type/files` | 是 | 稿件基本信息 7 字段（机构用中文：学校+学院） |
| `manuscript_domain` | 否 | 稿件领域短语（如 `固态电池硅碳负极`），供作者撤稿说明自动生成 |
| `summary.relevance/author/refs/aigc` | 是 | 摘要表 ①②③⑥ 四行，各 `{badge, verdict, text}`；`verdict`=仅风险徽章文案（无风险/低风险/需修改/需修订），`text`=「要点」列全文（须以判定短语开头，如 `高度相关，…`）；未检测时 `{badge:"info", verdict:"未检测", text:"原因"}`。**要点列只写汇总数据**——禁止出现作者名、撤稿数据库版本、具体机构名、文献编号、AIGC 特征词汇（如 comprehensive×6）等细节（与新稿 v2.11.0 同步） |
| `summary.ext` | 否 | 摘要表 ④⑤ 两行 `[{label, badge, verdict, text}]`；label 须含圈号（`④ 参考文献语义相关性` / `⑤ 声明完整性`）——脚本**按 label 中的名称认行**（历史稿写 `⑥ 参考文献语义相关性` 亦可识别），不依赖数组顺序。缺省→脚本渲染两行 `.info`「未检测（子项未提供）」。⚠️ **必须嵌套在 `summary` 内**——写成顶层 `summary_ext` 会被静默忽略（不报错、`leftover` 为空）；生成后须 grep 确认 ④⑤ 行使用的是你写的文案 |
| `scope_analysis` | 是 | 第 2 节 4 列表格数据 `[{dimension, paper_feature, journal_area, match}]`（列：分析维度 / 稿件特征 / 对应期刊领域 / 匹配度）；`match` 内 `badge` 三档 `ok`=高度相关 / `warn`=部分匹配 / `bad`=不相关，徽章文案键 **`verdict` 与 `text` 均可**（脚本取 `verdict or text`）——历史数据多用 `text`，早期文档写 `verdict`，二者兼容；若只写其中一个即可（**曾出现整列显示「未判定」的踩坑，即键名写错且无兜底**）。**第 2 节的「期刊收稿范围对照依据」段与表头均由脚本自动渲染，agent 不写**；缺失→脚本输出 `.info`「内容相关性分析未执行」占位 |
| `affiliation_results` | 是 | 3.2 节机构适配结果（HTML，机构用中文） |
| `refs_citation_issues` | 是 | 4.2 节引用分布与著录问题（HTML） |
| `refs_verify.summary` | 是 | 4.3 节前导段（总数/通过数/问题数）——**必须 agent 写**（crossref.json 原始计数是复核前数据，不能自动算） |
| `refs_verify.issues` | 否 | 4.3 节问题表行 `[{ref, issue}]`；空/缺省→不渲染表格 |
| `refs_verify.manual` | 否 | 人工复核明细 `{index: note}`；存在时渲染为「人工复核明细」note |
| `refs_rw.verdicts` / `refs_rw.note` | 否 | 4.4 节每条匹配的判定（如 `误报`）与表下说明 |
| `year_stats_note` | 否 | 4.1 节年份表下解读 note |
| `aigc_judgments` | 否 | AIGC 指标表「判断」列覆盖 `{metric: 文案}`（未覆盖行由脚本阈值规则自动算） |
| `aigc_note` | 是 | AIGC 节综合判断段（脚本自动在其前加「命中提示语明细」行） |
| `ext_sections.semantic_refs` | 否 | 第 5 节「参考文献语义相关性检测」小节正文（HTML，**不含 h2 标题**——5 节与 6 节标题均由 gen_report.py `build_ext_sections` 统一生成，content 字段自带 h2 会产生重复标题）；缺省→`.info`「未检测（子项未提供）」占位 |
| `ext_sections.declaration_cards` | 否 | 第 6 节 finding 卡片数组 `[{title, location, badge, verdict, analysis}]`（6.1-6.4，`location` 可为 null）；缺省→`.info` 占位 |
| `rw_timeout_note` | 否 | RW 数据下载异常提示（默认空） |

**报告结构**（主节编号为「数字+空格+标题」无点号，子节为「x.y 标题」）：
```
# 稿件技术检查报告 · [稿件编号或标题摘要]

[稿件基本信息]：不编号、小号字（meta div，font-size 13px），9 字段固定顺序：
  文件名 / 期刊全名 / 标题 / 作者 / 机构（中文：中国=学校+学院，国外=国名+学校+学院，不含省市街道邮编） / 类型 / 参考文献 / 撤稿数据库版本 / 检测工具（含生成日期）

[0 政治风险]：仅命中 Taiwan/Tibet/Xizang 时显示，位于稿件基本信息之后；
  红色小字 + 表格（关键词 / 完整句子 / 所属一级标题）；未命中不显示（{{POLITICAL_RISK}} 填空串）

## 1 检测结论摘要    —— 合并摘要表（**六行**：检测维度 | 结论 | 要点；结论列=仅风险徽章，未检测维度显示灰「未检测」；**无结论区**）。**维度编号 = 正文节序 − 1，摘要表行序与维度编号、正文节序三者一致**：① 内容相关性(§2) / ② 作者诚信(§3) / ③ 参考文献(§4) / **④ 参考文献语义相关性(§5)** / **⑤ 声明完整性(§6)** / **⑥ AIGC(§7)**
## 2 内容相关性    —— 「期刊收稿范围对照依据」段 + 4 列表格（分析维度 / 稿件特征 / 对应期刊领域 / 匹配度），均由脚本自动渲染
## 3 作者诚信检测
##   3.1 作者撤稿检索
##   3.2 作者机构与论文领域适配性
## 4 参考文献可靠性检测
##   4.1 发表年份分布
##   4.2 引用分布与著录
##   4.3 Crossref 真实性验证（通过文献仅汇总数量不列出；信息不一致/无法定位文献以表格列出编号/差异所在）
##   4.4 Retraction Watch 撤稿检索
## 5 参考文献语义相关性检测    （由 {{EXT_SECTIONS}} 前半提供，始终渲染）
## 6 声明完整性                （由 {{EXT_SECTIONS}} 后半提供，始终渲染）
##   6.1 利益冲突 / 6.2 作者贡献 / 6.3 研究伦理 / 6.4 致谢·数据可用性·AI 使用声明
## 7 AIGC 生成痕迹检测
```
（5/6 节缺失维度以 .info「未检测」占位；EXT_SECTIONS 位于第 4 节与第 7 节之间）

**样式对齐参考**：
- 蓝色主色调（`#2c6fbb` header border, `#1a4f8a` h2）
- 彩色 badge：`.ok` (绿) / `.warn` (黄) / `.bad` (红) / `.info` (灰，用于「未检测」)
- `.meta` 信息块（灰底圆角，稿件基本信息为不编号 13px 小号字）、`.note` 提示块（黄底左边框）、`.mono` 代码块
- 所有数据以表格呈现

**模板占位符**（除新稿模板原有占位符外，本次新增/变更；标注填充来源：`[脚本自动]` = gen_report.py 从检测 JSON 自动生成，`[report_content]` = 来自 report_content.json）：
- `{{MANUSCRIPT_ID}}` / `{{FILES}}` / `{{JOURNAL}}` / `{{TITLE}}` / `{{AUTHORS}}` / `{{AFFILIATIONS}}` / `{{MANUSCRIPT_TYPE}}` — `[report_content]` meta 字段
- `{{REFS_COUNT}}` — `[脚本自动]` 参考文献数量（refs.json）
- `{{RW_UPDATE_DATE}}` — `[脚本自动]` Retraction Watch 数据 `update_date`
- `{{TOOL_NAME}}` — `[脚本自动]` 脚本常量 "熊猫找茬-已出版 v3.19.3"（模板在该字段后追加 `，生成日期：{{REPORT_DATE}}`）
- `{{REPORT_DATE}}` — `[脚本自动]` 生成时间
- `{{POLITICAL_RISK}}` — `[脚本自动]` geo.json 命中时红字+表格；未命中空
- `{{SUMMARY_RELEVANCE_BADGE}}` / `{{SUMMARY_AUTHOR_BADGE}}` / `{{SUMMARY_REFS_BADGE}}` / `{{SUMMARY_AIGC_BADGE}}` — `[report_content]` summary.*.verdict 渲染为**仅风险徽章**（如 `<span class="badge ok">无风险</span>`）；未检测维度显示 `<span class="badge info">未检测</span>`
- `{{SUMMARY_RELEVANCE}}` / `{{SUMMARY_AUTHOR}}` / `{{SUMMARY_REFS}}` / `{{SUMMARY_AIGC}}` — `[report_content]` summary.*.text（「要点」列，判定短语开头）
- `{{SUMMARY_SEMANTIC_BADGE}}` / `{{SUMMARY_SEMANTIC}}` — `[脚本自动]` 由 `[report_content]` `summary.ext` 中名称含「语义相关性」的那行渲染（摘要表第 4 行 = ④，对应正文 §5）
- `{{SUMMARY_DECLARATION_BADGE}}` / `{{SUMMARY_DECLARATION}}` — `[脚本自动]` 由 `summary.ext` 中 label 含 `⑤` 的那行渲染（摘要表第 5 行 = ⑤，对应正文 §6 声明完整性）；两行缺省均→`.info`「未检测（子项未提供）」
- `{{SCOPE_HEADER}}` — `[脚本自动]` 第 2 节起始固定段（纯文本 `<p>`）：来源 + 版本日期 + 中文收稿范围概括，取自 `assets/journal_scopes.json`；未收录期刊→降级提示人工核对官网（非 https 来源自动遮蔽）
- `{{SCOPE_ANALYSIS_TABLE}}` — `[脚本自动]` 由 `[report_content]` `scope_analysis` 渲染 4 列表格（分析维度/稿件特征/对应期刊领域/匹配度徽章）；缺失→`.info`「未检测」占位
- `{{RW_TIMEOUT_NOTE}}` — `[report_content]` rw_timeout_note（默认空）
- `{{AUTHOR_LIST}}` — `[脚本自动]` authors.json 作者名列表
- `{{AUTHOR_RESULTS}}` — `[脚本自动]` authors.json 逐作者撤稿表 + 表下说明（含 manuscript_domain）
- `{{AFFILIATION_RESULTS}}` — `[report_content]` 3.2 机构适配结果（机构用中文）
- `{{REFS_YEAR_STATS_TABLE}}` — `[脚本自动]` refs.json 年份分桶表 + `[report_content]` year_stats_note
- `{{REFS_CITATION_ISSUES}}` — `[report_content]` 4.2 引用分布与著录
- `{{REFS_VERIFY_RESULTS}}` — `[report_content]` refs_verify（summary 必填 + issues 问题表 + manual 明细）
- `{{REFS_RETRACTION_CHECK}}` — `[脚本自动]` refs_rw.json matches（**缺 `total_references` 键 → `.info`「未执行」**；空数组→「0 篇存在撤稿记录」；非空→表）+ `[report_content]` refs_rw.verdicts/note（零命中与未执行两分支均拼接 note）
- `{{AIGC_TABLE}}` — `[脚本自动]` aigc.json 8 指标行（参考区间/判断=脚本内置，可被 aigc_judgments 覆盖）
- `{{AIGC_NOTE}}` — `[脚本自动]` ai_phrases 明细 + `[report_content]` aigc_note
- `{{EXT_SECTIONS}}` — `[脚本自动]` 由 `[report_content]` ext_sections 渲染：h2「5 参考文献语义相关性检测」（semantic_refs）+ h2「6 声明完整性」（declaration_cards → finding 卡片：声明原文位置/判定 badge/问题分析）；缺省→两节 `.info`「未检测（子项未提供）」占位

**脚本编码注意**：report_content.json 中的 HTML 字符串字段若含 ASCII 双引号须 `\"` 转义；建议一律用**中文引号**（`"..."`）避免转义混乱（已踩坑 3 次：EMD20260053「pivotal role」、CESCI-D-26-00011「construction industry」、CESCI-m26-00013「Allergic Bronchopulmonary Aspergillosis」）。

报告文件名格式：`manuscript_integrity_check_report_[YYMMDD]_[稿件标识].html`

**报告保存位置与数据来源标注**：
- 报告保存到**输入稿件文件所在的目录**（与 Word/PDF 输入文件同目录），运行 `gen_report.py` 时通过 `--out` 传入该目录，不可硬编码。
- 报告须注明本次撤稿检测所依据的 Retraction Watch 数据更新时间：读取 `data/retraction_watch_meta.json` 的 `update_date`（数据源端数据集日期），填入稿件基本信息「撤稿数据库版本」字段（`{{RW_UPDATE_DATE}}`）。该日期由该字段承载，正文不再重复注明。

**多篇批量（可选）**：用户提交多篇时，每篇独立 HTML 报告 + 汇总表（作者 / 期刊 / 风险等级 / 主要问题）。

---

## 下载与更新判定（retraction_watch.csv）

- 由 `scripts/download_retraction_watch.py` 统一负责下载、新鲜度判定、完整性校验与重试；`scripts/retraction_watch.py` 的 `ensure_csv` 直接委托该脚本，避免逻辑分散。
- **两步判定（降低下载频率、减少联网）**：
  - **无条件下载**：`--force`；或 **CSV 不存在**（无可检测数据）。
  - **第 1 步（本地快筛，纯本地、不联网）**：以本地 `update_date`（数据版本日期）为基准，缺失/解析失败回退 CSV 文件 mtime；**版本日期距今 < 3 天 → 直接复用本地文件，不发任何网络请求**（因源端日期 ≤ 今天，差异必然 < 3 天，不可能触发下载）。未命中则进入第 2 步。
  - **第 2 步（联网精确判定，仅版本日期距今 ≥ 3 天时执行）**：通过 GitLab Commits API 查询 `retraction_watch.csv` 最近一次提交的日期（即**数据源端更新日期**），与本地版本日期比对：**`(gitlab_date - 本地版本日期) > 3 天` 才重新下载**；≤ 3 天 → 复用本地。
    - 该 API 仅返回几 KB JSON，**不是** 62MB CSV，开销极小。
    - **GitLab API 不可达 → 回退保守下载一次**（保证不因查不到源头而用旧数据），`update_date` 记录为旧基线或今天。
- 下载后完整性校验：字节数 **≥ 50MB** 且 行数 **≥ 50000**，否则视为**不完整**。
- 失败/不完整时重试：**最多 3 次、指数退避**；先写 `.tmp` 临时文件，校验通过才 `os.replace` 原子覆盖正式 CSV。
- 重试耗尽仍不完整：若本地已有完整 CSV 则**保留上一版并继续检测**（source 标注 `download incomplete, kept previous version`）；仅当本地无任何 CSV 时才返回 `download_failed`（此时撤稿检测无法正常进行）。
- 下载使用标准库 `urllib` 并显式带 `User-Agent`，规避 GitLab raw 的 302 跳转与默认 UA 的 403。
- 强制重新下载（手动刷新）：`python scripts/download_retraction_watch.py --force` 或 `python scripts/retraction_watch.py download`。
- **并发注意（CRITICAL）**：RW 数据准备（版本检查 + 判断 + 下载）须作为**前置步骤串行执行一次**（`python scripts/download_retraction_watch.py`），确保 CSV 就绪且 FRESH 快筛命中后，`check-authors` 与 `check-refs` **方可并行执行**（此时仅只读 CSV，不再触发下载）；**严禁在数据未就绪或可能触发下载时并行**运行两个 RW 查询（并发下载会共用 `.tmp` 路径 + `os.replace` 覆盖 vs 读取 → Windows 文件锁冲突）。
- 报告中撤稿相关部分按 `csv_source` 标识提示：
  - 含 `download_timeout` / `download_failed` → 标记为 "⚠ 未执行 — 撤稿数据下载失败/超时"，并提示用户从 https://gitlab.com/crossref/retraction-watch-data 手动下载；
  - 含 `incomplete` → 标注"Retraction Watch 数据最近一次更新下载不完整，已保留上一版完整数据，结果仅供参考"，建议稍后重跑或人工经 retractiondatabase.org 复核。
- 其他检测（内容相关性 / Crossref 验证 / AIGC）不受影响，正常完成。

## Data Safety

- `retraction_watch.csv` 存储在**本 skill 目录下** `<skill>/data/retraction_watch.csv`（首次运行自动从旧位置 `~/.workbuddy/data` 迁移，成功后旧文件删除，避免双份）
- `retraction_watch_meta.json` 存储在同目录 `<skill>/data/retraction_watch_meta.json`，字段：`update_date`（**数据源端数据集日期**，来自 GitLab Commits API；用作第 1 步快筛基准与源端比对基线；不可达/首次时回退为本地日期）、`downloaded_at`（精确 ISO 时间戳，供溯源）、`bytes`（下载字节数）、`rows`（数据行数）、`source`
- `journal_scopes.json` 存储在**本 skill 目录下** `<skill>/assets/journal_scopes.json`（期刊 scope 缓存，随 skill 可移植；`assets/journal_scopes_template.json` 为模板）。记录含期刊全名 / 缩写 / scope URL / scope 文本 / 添加日期，可选编委名单字段（`editorial_board` / `editorial_board_url` / `editorial_board_text` / `editorial_board_updated_at`）；用户提供链接时，`preflight.py` 自动比对链接内容与本地记录差异（`diff_scope_text`，difflib，差异<10%→`update` 更新本地、≥10%→`review` 请用户确认，不擅自覆盖）
- Crossref API 通过 `mailto` 参数加入礼貌池（10 req/s、并发 3），脚本以并发 3 执行，429/5xx 自动指数退避；附 `User-Agent: panda-ms-check/1.0` header
- 不做任何 paywall 绕过或爬虫行为

---

## 版本与变更记录

| 版本 | 日期 | 变更 |
|---|---|---|
| v3.19.3 | 2026-10-12 | **摘要表维度编号重排（用户决策，正式翻转 v3.19.1 的行序依据）：维度号 = 正文节序 − 1，使「维度编号 / 摘要表行序 / 正文节序」三者一致**。① **背景**——v3.19.1 为保「行序与正文节序一致」而沿用旧编号体系（④=AIGC、⑤=声明完整性、⑥=语义相关性），致摘要表编号呈 ①②③⑥⑤④：AIGC 位于正文 §7（第 6 个维度）却标 ④，读者按号去正文会找错节。用户要求三者顺序一致，故重编维度号：**① 内容相关性(§2) / ② 作者诚信(§3) / ③ 参考文献(§4) / ④ 参考文献语义相关性(§5) / ⑤ 声明完整性(§6) / ⑥ AIGC(§7)**（即 ④↔⑥ 对调，⑤ 不变）。② **改动面**——`assets/report_template.html`（摘要表 2 行圈号 + 注释块）、`scripts/gen_report.py`（`_EXT_SLOTS` 圈号 / 注释 / `build_summary_ext_map` 认行逻辑）、`SKILL.md`（frontmatter description 六维列举顺序、Step 0.5 维度信息盘点清单、Step 5 判定清单、`summary.*` 与 `summary.ext` 字段说明、报告结构 §1 行、占位符说明；`TOOL_NAME` 文档行由陈旧 v3.16.1 校正为 v3.19.3）、`README.md` / `功能说明.md` / `references/interpretation.md`（六维表重排）。**历史变更记录不追溯改写**（记录当时事实，旧条目仍按当时编号表述）。③ **向后兼容（关键）**——`build_summary_ext_map` 原按圈号认行（`⑥`=语义），而 v3.19.2 及更早的 `report_content.json` 均写 `⑥ 参考文献语义相关性`；现改为**以 label 中的名称为主**（「语义相关性」/「声明完整性」），圈号退为兜底（`_EXT_SLOTS` 第 4 元 `legacy_marks` 保留旧圈号 `⑥`），故历史 content 无需改写即可正确渲染。④ **验证**——`gen_report.py` 通过 `py_compile`；用历史稿 `report_content.json` 重渲染，摘要表 6 行齐全、序号 ①②③④⑤⑥ 与正文 §2-§7 逐一对齐、`leftover:[]`。`gen_report.py` TOOL_NAME 升 v3.19.3。 |
| v3.19.2 | 2026-09-30 | **CF2024-9200019（Carbon Future 2024, 1, 9200019，17 页双栏 Review）实测驱动：新增「ACS 编号式参考文献 + 裸上标数字引用」完整工具链（第三条格式线）**。① **两条新格式线**——该稿参考文献为 ACS 式（`[n] 作者. 标题. 期刊 年, 卷, 页.`）、正文引用为无括号上标数字（`…selectivity39−45.`），既有 `parse_refs.py`/`parse_refs_apa*.py` 与 `citation_stats.py`/`semantic_check.py contexts` 全部不适用（实测引用上下文 0/137、未引用误报 83 篇）。② **新增三个脚本**：`scripts/parse_refs_acs.py`（ACS 解析，137/137 字段完整、0 解析失败）、`scripts/superscript_citations.py`（字号判据的上标引用统计，137/137 被引用、0 未引用、0 越界）、`scripts/superscript_contexts.py`（按栏 + 视觉行取语境，137/137 取得上下文）。③ **固化 7 条实测坑**（详见「运行环境陷阱」）：作者正则漏写 `+` 只吃首位作者；`(?:\s*[A-Z]\.?)*` 吞下一位作者姓名首字母；文末致谢/版权块被折行并入条目；两字母全大写词（`CO`/`RR`）被误判为期刊名；**Minion Pro 字符 top 按字形高度计算，同行内 `'C'` 与 `'o'` 相差 11 pt → 判上下标必须用字号**；参考正文字符的 top 容差 >4 pt 会拉入邻行致引用组碎裂；单位过滤只做词尾匹配会误杀 `solutions18−25`（尾字母 s 被当「秒」）。④ **CF 期刊记录入库**——`journal_scopes.json` 新增第 9 刊 Carbon Future（scope 四大方向原文 + 官方编委会 52 人：主编 1 / 副主编 3 / 顾问编委 12 / 编委 36），备 `.bak-20260930`。⑤ **六维结论**：① 内容相关性高度相关（催化/CO2 转化/碳材料/体裁四类全中）；② 作者诚信无风险（2 位作者撤稿库零命中，清华大学化学系与领域适配）；③ 参考文献无风险（137 篇 100% 被正文引用、无越界无重复；Crossref 129 篇全维一致、8 篇 Angew. Chem. 刊名显示差异经甄别为误报、[118] 刊名简写不完整建议补全；撤稿 0 命中）；④ AIGC 未见痕迹（7339 词、468 句、CV 0.614、TTR 0.371、强特征词密度 0.55/千词）；⑤ 声明需修订（COI/作者贡献齐备，但「convinced」应为「conceived」、缺数据可用性与 AI 使用声明）；⑥ 语义需修订（96 摘要级 + 41 仅元数据级 + 0 无法核实；**14 篇引用与所在论述主题不相关**，集中于 39−45 / 46−51 / 63−70 / 88−92 / 124−128 五处连续区间合引）。TOOL_NAME 升 v3.19.2。⑥ **分享包打包规范补记**——明确 `dist/` 为技能目录的**同级兄弟目录**（故天然不进包）、版本号**三处同步**（SKILL.md frontmatter / README / 打包脚本 VER）与固定发版顺序（改版本 → commit → 重建包 → 打 tag）、新增脚本按 `scripts/*.py` 通配**自动进包无需登记**、打包后必须跑 `_verify_pack.py` 六组检查**全 PASS 方可交付**；同时同步 README（版本号校正、目录结构补全新脚本、删去已废弃的「处理建议」表述）与功能说明（摘要表改述为六行）。 |
| v3.19.1 | 2026-09-29 | **摘要表恢复为六行、行序改按正文节序（用户决策）；`scope_analysis` 徽章键双兼容**。① **背景**——v3.19.0 删除了 ⑤⑥ 两行，导致摘要表只覆盖 ①-④，而正文 §5 语义相关性 / §6 声明完整性两维在摘要中**无任何痕迹**（读者仅看摘要会漏掉两维）。用户决定恢复六行。② **行序按正文节序**（用户明确要求「和下方详细报告一样」）——`① 内容相关性(§2) → ② 作者诚信(§3) → ③ 参考文献(§4) → ⑥ 语义相关性(§5) → ⑤ 声明完整性(§6) → ④ AIGC(§7)`。**注意 ⑥ 排在 ⑤ 之前**：正文里 §5 语义相关性先于 §6 声明完整性，但六维编号中语义是 ⑥、声明是 ⑤，故编号呈 ①②③⑥⑤④ 的跳跃。已在模板注释、SKILL.md 报告结构段、占位符说明三处显式记录此序，避免后人「按编号顺序纠正」而改错。③ **实现**——模板第 1 节改为 6 行、新增 4 个占位符（`SUMMARY_SEMANTIC_BADGE/TEXT`、`SUMMARY_DECLARATION_BADGE/TEXT`）；`gen_report.py` 新增 `build_summary_ext_map()`：从 `summary.ext` **按 label 中的圈号（⑤/⑥）认行**再按节序输出，不依赖数组顺序，缺行→`.info`「未检测」占位。实测 21/21 历史稿 label 写法完全一致（`⑤ 声明完整性` / `⑥ 参考文献语义相关性`），识别可靠。④ **`scope_analysis` 徽章键双兼容**——`build_scope_analysis_table` 由只读 `match.text` 改为 `match.verdict or match.text`。原实现与 SKILL.md 文档口径不一致（文档写 `verdict`、代码读 `text`），agent 若按文档写 `verdict` 会让「匹配度」整列显示「未判定」（本轮 ECM20260043 重渲染实测命中）。现两者皆可，文档亦已订正。（同一缺陷存在于「熊猫找茬-新稿」，**待同步**。）⑤ **数据迁移实践**——ECM20260043 重出报告时，把原 `scope_content` 中 agent 手写的 3 列表格（稿件主题要素/收稿范围对应条目/匹配）语义转换为新 4 列 `scope_analysis`（补「分析维度」列：研究主题/政策与治理维度/转型融资机制/区域侧重/文章体裁），并删除废弃的 `conclusion` / `scope_content`；`summary.ext` 原样保留（脚本自动重排）。原文件备份 `report_content.json.bak-20260929`。⑥ **验证**——占位符与 `repl` 键双向零差集（37:37）；`py_compile` 通过；重渲染 `status:ok`、`leftover:[]`；摘要表 6 行齐全且序号与正文节序逐一对齐；裸 `&` 全部转义、无 `<script>`、无处理建议/总体评估残留。`gen_report.py` TOOL_NAME 升 v3.19.1。 |
| v3.19.0 | 2026-10-09 | **报告格式与新稿版对齐（XSS 全量转义 + 第 2 节 4 列表格迁移 + 摘要表瘦身）**。① **XSS 全量转义（F-01，移植新稿 v2.15.0）**——此前本 skill 所有动态值直接拼接进 HTML，存在注入面；现引入**转义双轨**：纯文本字段走 `esc()`（`html.escape(quote=True)`），agent 手写 HTML 的字段走 `rich()`（先全转义、再按白名单放行无属性格式标签 + 受控 `class`，且**仅当同名开标签已放行时才放行关闭标签**，避免「开标签被拦、关闭标签放行」的不配对残留）。② **实体幂等保护（`esc_keep_entities`）**——历史 `report_content.json` 中预写的 `&amp;` / `&nbsp;` 等实体会被二次转义成 `&amp;amp;`，故 `rich()` 先以占位符摘出既有实体、转义后再还原。③ **`rich()` 白名单按路线 B 扩大**——实测 20 份历史 content、178 个富文本字段：若照搬新稿 7 标签最小白名单，`scope_content`(名已废) 81%、`affiliation_results` 83%、`refs_citation_issues` 73% 的字段内表格会崩坏；现白名单含 `table/thead/tbody/tr/th/td/div/span/h2/h3/p/b/strong/em/i/br/ul/ol/li/blockquote/code`＋受控 `class`（badge/ok/warn/bad/info/note/mono/okc/warnc/finding/blk），实测 178/178 逐字保真。（`style=` 属性在历史 content 中出现 0 次，故不纳入白名单。）④ **第 2 节迁移为脚本渲染**——`{{SCOPE_CONTENT}}`（agent 手写整段 HTML）替换为 `{{SCOPE_HEADER}}`（脚本从 `assets/journal_scopes.json` 自动生成「期刊收稿范围对照依据」纯文本段，非 https 来源自动遮蔽）+ `{{SCOPE_ANALYSIS_TABLE}}`（脚本由新增**必填**字段 `scope_analysis` 渲染 4 列表格：分析维度 / 稿件特征 / 对应期刊领域 / 匹配度徽章三档 ok·warn·bad）；缺失→`.info`「内容相关性分析未执行」占位。⑤ **第 1 节摘要表瘦身**——删除 `{{SUMMARY_EXT_BADGES}}`（⑤⑥ 两行）与 `{{CONCLUSION}}`（总体结论+处理建议区），摘要表定为 ①-④ 四行；同步删除 `build_summary_ext_badges()` 整函数与 report_content 的 `summary.ext` / `conclusion` 字段，并在 SKILL.md 的 Step 1 输出要求、字段表、报告结构、占位符说明、frontmatter description 五处**回头核查去残留**（原 description 仍称「含…处理建议」，属删区后未清理的不实描述，已订正）。⑥ **要点列禁止清单补齐**——与新稿 v2.11.0 对齐：要点列只写汇总数据，禁止出现作者名、撤稿数据库版本、具体机构名、文献编号、AIGC 特征词汇等细节。⑦ **`esc()` 覆盖范围**——`repl` 中元信息 7 字段、`summary.*.text` 4 项、`rw_timeout_note` 走 `esc()`；`affiliation_results` / `refs_citation_issues` 走 `rich()`；脚本自产字段（政治风险/年份表/作者表/撤稿表/AIGC 表/EXT_SECTIONS）在各自 `build_*` 内部完成转义。⑧ **静态自检**——模板占位符与 `repl` 键双向零差集（33:33）；`gen_report.py` 通过 `py_compile`；用 3 份真实历史稿（ECM20260043 / OCE20260027 / EMD20260105）做渲染回归 diff，验证既有报告逐字不变。`gen_report.py` TOOL_NAME 升 v3.19.0。⑨ **遗留不一致（未改动，待用户决策）**——`scripts/config.py` 的 `TOOL_VERSION = "4.0.0"` 与本 skill 版本体系（3.x）脱节，其 git 历史仅 v3.15.0 入库一次；该常量经 `USER_AGENT` 用于 Crossref API 请求标识，**不影响报告输出**（`gen_report.py` 用自身硬编码 `TOOL_NAME`，不读取 config），故本轮未随升。 |
| v3.18.2 | 2026-09-28 | **ECM20260043（Energy and Climate Management 已接收稿，15 页双栏 APA 式 Article，单作者）实测驱动：固化双栏 PDF 文献表「DOI 提取 / 噪声清洗 / verified 误判」五条经验，无脚本逻辑改动**。① **DOI 提取必须在「去空白」文本上做**——URL/DOI 跨行折断致逐行正则把 DOI 截断（`10.1016/j.ese`）；且**本稿页脚 DOI 会并入相邻条目**（[3][59][78] 被吞入 `10.26599/ECM.2026.9400043` 并向后吞字），须先整行剔除页脚 DOI 行 + `MANUSCRIPT_DOI` substring 黑名单。② **尾部修剪判据收窄**——只在「句点后接大写开头词」时截断（按「末段以大写开头」判会把 `10.1039/D0EE02681F` 砍成 `10.1039`）；**不可加「必须含字母」守卫**（ISBN 型纯数字 DOI `10.1017/9781009157926.013` 会被误杀）；取最短合法候选、>70 字符视为吞并正文丢弃。清理后 7 篇 DOI 全部正确（逐行法 2 篇截断）。③ **URL slug 截断规则只能作用于 journal 字段**——题名里 `Re-examining`、`grid-enhancing` 等合法连字符词会被误截（实测砍成 `Re-examining rates of`），且 slug 正则须带 `(?<=\s)`/`(?=\s|/|$)` 边界；页眉词 `Article` 与页码标记 `9400043 (14 of 15)` 会内联进题名中段，须在 `clean_text()` 剔除；题名在无空格缩写（`U.S`/`vs`）处被首个句点截断，续接修复须在折叠换行后的原文里定位。④ **`verified` 计数不可直接采信**——[24][31][45] 三条短题名/泛用词型误配通过了 4 分接受阈（如 `Critical raw materials act` → `Unpacking the Critical Raw Materials Act`），报告 4.3 的「通过」篇数须逐条比对 `crossref_title`；本次人工剔除 3 篇。⑤ **新增「DOI 未注册 + 刊名卷页不符」判定路径**：[15] 稿内 DOI 404、刊名 Nature Climate Change，经 **OpenAlex 题名反查**确认该文实为 *Nature Communications* 11(1): 2096、DOI `10.1038/s41467-020-15414-6`，作者序列一致 → 判为同一文献的**三项著录错误**（不得按「同题异著」归入无法定位）。⑥ **新增可复用检出项：合引编号升序检查**（本稿 `[64,54]`、`[83, 19, 84]` 两处）。**本稿六维结论**：① 内容相关性高度相关（政策/经济/治理/金融四类范围全覆盖，与 2026 重点方向「转型融资机制、发展中国家路径」重合；唯一说明：同时以美欧为分析对象，与「发展中国家」侧重略异，不构成障碍）；② 作者诚信无风险（唯一作者 Valerie J. Karplus 0 命中；机构卡内基梅隆大学工程与公共政策系 / 威尔顿·E·斯科特能源创新研究所，与领域适配）；③ 参考文献需修订（104 篇 1–104 号全部被正文引用、无重复著录、撤稿 0 命中；Crossref 可定位同一文献 16 篇、著录错误 1 篇 [15]、无法定位 87 篇均为机构/政府/国际组织报告与企业新闻稿，Crossref 未收录属正常）；④ AIGC 无痕迹（11,010 词、455 句、CV 0.560、TTR 0.366、提示语密度 0.36/千词）；⑤ 声明基本完整（COI/数据可用性/AI 使用/致谢四项齐备，作者不在 ECM 编委 15 人名单内；建议「Author contribution statement: Not applicable」改为实际贡献说明）；⑥ 语义 104/104 有上下文、问题项 0（摘要级 23／仅元数据级 81）。TOOL_NAME 升 v3.18.2 |
| v3.18.1 | 2026-09-28 | **ECM20260041（Energy and Climate Management 已接收稿，12 页双栏 Article）实测驱动：`geo_check.py` 修复「完整句子」被 PDF 折行截断（报告第 0 条政治风险块失真）**。① **问题**——`scan()` 逐行调用 `extract_sentences()`，而分栏 PDF 提取后一个自然句常被拆成 3–4 个物理行，导致报告中「完整句子」列只显示断句碎片（本稿实测显示为 `(Xizang Autonomous Region, Hong Kong Special Administrative` 与 `Region, Macau Special Administrative Region, and Taiwan` 两段残句），人工核查时看不到完整语境。② **修复**——新增 `expand_wrapped(lines, i)`：以命中行为中心向前/向后补齐到句子边界（遇空行、遇一级标题、或上一行本身已以句末标点结束即停，最多前 4 行/后 8 行），`extract_sentences()` 改为作用于回拼后的整段；回拼后若因长度过滤丢弃全部候选则回退用整段文本。③ **新增 `_dedupe_hits()` 后缀合并**——同一自然句被其多个折行行各触发一次、且向前补齐起点不同（本稿两条分别为含 `The model covers…` 前缀与从 `(Xizang` 起），指纹不同故按键去重失效；现按「后缀包含」合并，保留更完整者并合并关键词（本稿由 2 条碎片合并为 1 条完整句，关键词列合并为 `Taiwan、Xizang`）。④ **回归**——三路径复测：本稿得 1 条完整句；单行含 Taiwan 文本不失真、无过度合并；无关键词文本仍返回 `not_found`。⑤ **本稿六维结论**：① 内容相关性高度相关；② 作者诚信低风险（5 位中 4 位 0 命中；Ying Zhou 22 条、Xiliang Zhang 1 条为医学等跨领域同名误报；Sheng Zhou 5 条中含 1 条能源-气候经济领域撤稿文 10.1007/s10644-024-09790-y，机构为新疆大学/南开大学而非清华 → 走覆盖文案标为「同名·领域相近，建议人工重点核实」）；③ 参考文献无风险（39 篇全部被正文与 Table 1 引用、撤稿 0 命中；Crossref 26 篇全维一致 + 2 篇同载体 + 11 篇报告/标准/数据集未收录；全部条目按本刊体例不著录 DOI，经与已出版 ECM 文章比对确认为期刊风格而非著录缺陷）；④ AIGC 无痕迹（7542 词、255 句、CV 1.023、TTR 0.3445、提示语密度 1.33/千词、近重复 0）；⑤ 声明完整（COI 已主动披露作者 Xiliang Zhang 为本刊主编，与 ECM 编委 15 人名单一致；CRediT 覆盖全部 5 位作者；唯一建议：数据可用性仅写 available on request）；⑥ 语义 39/39 有上下文、问题项 0（摘要级 17／仅元数据级 11／无法定位 11）。TOOL_NAME 升 v3.18.1 |
| v3.18.0 | 2026-09-20 | **ECM20260039（Energy and Climate Management 已接收稿，16 页双栏 Article）实测驱动：`gen_report.py` 新增作者表文案覆盖机制（移植新稿 v2.19.0）**。① **问题**——`build_author_results()` 对「有命中」作者一律输出默认文案「命中 N 条，领域均非{domain}相关（如 {subj}），基本判定为同名误报」，`{subj}` 直接取 Retraction Watch 的 `subject` 前 3 项。本稿作者 Lei Zhang 命中 116 条，其中恰含 `(B/T) Business - Economics` / `(B/T) Business - Management` 等**与本稿领域（政治不确定性与企业绿色投资）相邻**的学科 → 报告渲染成「领域均非政治不确定性与企业绿色投资相关（如 (B/T) Business - Economics …）」，**示例与结论自相矛盾**，属 v3.16.1 同类「默认文案与实际命中不符」的语义错误。② **修复**——`build_author_results(authors, domain, verdicts=None, note_override='')` 新增两个可选参数：`verdicts`（按作者名精确匹配，命中则 `badge` / `conclusion` / `note` 三字段整体覆盖该行）+ `note_override`（非空时**优先于**默认表下说明返回）。调用点改为 `s.get('author_verdicts') or content.get('author_verdicts')` 与 `content.get('author_note') or ''`，即 **report_content.json 写入 `author_verdicts` / `author_note` 即可覆盖，与新稿 v2.19.0 同构**。③ **使用规则（重要）**——凡命中条目的 `subject` 与本稿领域**相邻或重合**、或需按 SKILL.md 三档分类判为**档 3（需重点核实）**时，**必须**写入覆盖文案，禁止沿用默认「领域均非…相关」。④ **本稿结论**：六维**均未见实质风险**（详见下条 v3.17.0 之后新增的 ECM20260039 实测记录）；Lei Zhang 116 条命中经逐条比对 institution + subject，全部为医学/生物/电气/材料领域、机构为各地医院与工科院校，无一条来自中国人民大学生态环境学院 → 基本判定为同名误报（档 2，但示例学科相邻，故走覆盖文案）。**六维结论**：① 内容相关性高度匹配（唯一说明：样本为欧洲企业，与 2026 重点方向「发展中国家」侧重不同，标 🟡 非重点方向，不构成障碍）；② 作者诚信无风险（5 作者中 4 位 0 命中）；③ 参考文献无风险（41 篇全部被正文引用、撤稿 0 命中；Crossref 34 直接匹配 + 7 人工甄别——[6] Duke 1993 vs Routledge 2002 多版本、[21] print 2023 vs online 2021、[30] 欧盟政策文件 COM(2019)640 final、[41] 容器名、[9][10][20] 专著/机构报告未注册 DOI，均属正常）；④ AIGC 无痕迹（8583 词、448 句、CV 0.663、TTR 0.3915、提示语密度 3.26/千词）；⑤ 声明完整（COI/CRediT 贡献/致谢/数据可用性/AI 使用五项齐备，5 作者均不在 ECM 编委 15 人名单内；唯一建议：数据可用性写 Not applicable 宜补数据来源）；⑥ 语义 41/41 有上下文、问题项 0（摘要级 20 / 仅元数据级 21；[4][36][37][38][39] 因双栏跨栏错拼降级比对）。TOOL_NAME 升 v3.18.0。⑤ **分享包发布**：本文档新增「分享包打包规范」小节，固化排除项（data/ cache/ work*/ journal_scopes.json *.bak-* _user_meta.json *.log）与打包后五项自检；`README.md` 版本号由陈旧 v3.7.0 校正为 v3.18.0、目录结构按双层数据源改写并新增「分享包包含/不包含」表；`requirements.txt` 头注释「熊猫找茬-新稿」更正为「熊猫找茬-已出版」（复制粘贴残留）；SKILL.md「Prerequisites」中的本机 venv 绝对路径（含系统用户名）改为通用占位。⑥ **打包期修正（交付包 v3.18.0，源提交见 dist 清单）**：frontmatter 版本号被同轮后续编辑回退（残留 3.17.0）→ 订正并强化「同一文件多处编辑」条目；`scripts/gen_report_emd*.py` 定为不进分享包（硬编码本机路径 + 具体稿件元数据、在接收方不可运行）；自检项 3 改为引用打包脚本内置扫描，避免把本机路径字面量写进本文档。 |
| v3.17.0 | 2026-09-18 | **ECM20260040（Energy and Climate Management 已出版稿，6 页双栏 Perspective）实测驱动：修复 U+2212 MINUS SIGN 正则漏匹配（2 个脚本同类 Bug）+ ECM 编委名单入库**。① **【CRITICAL】`citation_stats.py` 漏匹配 minus sign 分隔符**——本稿正文出现 `[1,16−18]`，分隔符是 **U+2212 MINUS SIGN**（PDF 排版常见），而 `PAT_REF` 原先只认 `-`(U+002D) 与 `–`(U+2013)，导致整组 `[1,16−18]` 被当作单个 token 丢弃 → [16][18] 被误报「未引用文献」；`PAT_RANGE` 同理只认 `[-–]`，展开也会错。修复：抽出统一字符类 `_DASH = r'\-\u2013\u2014\u2212'`（hyphen / en-dash / em-dash / minus sign 四者齐备），`PAT_REF` 与 `PAT_RANGE` 共用；`collect_cited` 内补 `if not part: continue` 防空段。**修复后 cited_count 21 → 23、uncited 归零**。② **`semantic_check.py` 同源 Bug**——`CITE_GROUP_RE` 缺 U+2212 且 line 201 的 normalize 只替换 en/em dash，导致 [16][18] 抓不到引用上下文（21/23，恰好与①同一组编号）；修复后 **23/23 全部拿到上下文**。**教训：凡是「按引用标记切分/展开」的正则，破折号字符类必须四者齐全——PDF 提取文本里的范围连接符可能是任何一种，缺一种就静默漏匹配、且不报错。** ③ **ECM 期刊记录入库**——`journal_scopes.json` 补齐 ECM `editorial_board`（15 人：主编 1 / 副主编 1 / 顾问编委 4 / 编委 9）+ `editorial_board_text` / `editorial_board_url` / `editorial_board_updated_at`(2026-09-18) / `editorial_board_source`；此前 ECM 记录编委为空致 ⑤ 的「COI 对照编委」子项只能标未检测，本次用户提供编委页 URL 后抓取校验回写，该子项正式激活。备 `journal_scopes.json.bak-2026-09-18`。④ **本稿结论**：内容相关性高度匹配；唯一作者 Behrouz Gholamahmadi 无撤稿记录，机构（阿威罗大学 CESAM / Ibero Massa Florestal）与领域适配；23 篇文献全部被正文引用、撤稿 0 命中、Crossref 可定位 11 篇、10 篇为法规/网页/预印本类（实测可达，Crossref 未收录）、语义 23/23 逐条比对 0 问题项（摘要级 8／仅元数据级 8／人工核实 7）；AIGC 无痕迹（3526 词，提示语密度 0.0/千词）；最需修订项为 5.1「Author contribution statement 写 Not applicable」（单作者稿建议写明实际贡献）。TOOL_NAME 升 v3.17.0 |
| v3.16.1 | 2026-09-17 | **OCE20260027（Ocean 已接收稿，11 页双栏 PDF，单作者 Perspective）实测驱动：修复作者撤稿说明的「零命中自相矛盾」+ 固化 4 条复用要点**。① **`gen_report.py` `build_author_results` 表下说明改为按命中分支（CRITICAL）**——原 note 无条件输出「同名命中均为跨领域论文…基本判定为同名误报」，在**零命中**稿件中与表格（0 条命中）直接矛盾（本稿单作者无命中，说明却称存在同名命中），属语义错误而非措辞问题；现改为 `any_hits` 分支：有命中→原文案，零命中→「本次受检作者均未命中，无撤稿记录」并补全姓名顺序兼容说明。② **新增「PDF 字形探测」判据，用于区分「原稿笔误」与「提取丢字」**——本稿 [3] 出现 `Prtner, H.-O.`、[39] 出现 `Plike, H.`（应为 Pörtner / Pälike），用 pdfplumber 逐字符（`page.chars` 的 text/fontname/size）打印目标词邻域即可定性：字符对象序列为 `P r t n e r ,`，字体为 `EPXLGD+TimesNewRomanPSMT`（含 ö/ä 字形），且同页 Müller（[36]）、Niño、Skákala（[24]）等变音符号均正常 → **可排除提取失真，判定为原稿用字缺失**；反之若目标词邻域出现字体突然切换/空字符，则按提取局限处理。可复用脚本模式见 `work/OCE20260027/glyph_probe.py`。③ **文末页码类噪声会污染文献解析字段（本稿两处实测）**——`parse_refs_apa_wrapped.py` 把页脚 `Ocean, 2026, 2, 9470027` 与版权行并入相邻条目，致 [40] 期刊字段吞入页眉文案、[43] 期刊字段变为 `Ocean, 2026, 2, 9470027 Joule`；且**文献条目内搜 DOI 时会捞到本文自身 DOI**（页脚 `https://doi.org/10.26599/OCEAN.2026.9470027`），使 [40][43] 被误挂上本稿 DOI。二次清理须同时做「字段噪声剔除」与「**本稿 DOI 黑名单**」（`cleanup_refs.py` 的 `MANUSCRIPT_DOI` 常量），否则 DOI 优先核验会走错通道。④ **Crossref 同题异著须单独甄别（本稿 2 例）**——[1] 稿件所引为 2022 年 UNESCO《State of the Ocean Report 2022: Pilot Edition》，Crossref 却以同题命中 1981 年书章《Intergovernmental Oceanographic Commission (IOC)》（且 `semantic_check fetch` 会把该错误 DOI 的摘要挂上）；[6] 联合国 SDG 14 网页被同名命中德文 SDG 评注。判据：报告类/网页类文献被「高分命中」时须核对命中条目是否同指一物，不符则归「无法定位（Crossref 未收录）」，**不得据同题异著标真实性风险**。⑤ **DataCite 注册 DOI 的核验出口**——[34] Zenodo DOI `10.5281/zenodo.1464816` Crossref 必然 404，应改走 `https://api.datacite.org/dois/{doi}` 核验（本稿实测题名/出版者/作者序列与著录完全一致），避免把它计入「无法定位」。⑥ 本稿结论：内容相关性高度相关；唯一作者（Weicheng Cui，西湖大学）无撤稿记录且姓名变体复检 0 命中；44 篇文献全部被正文引用、撤稿 0 命中、Crossref 可定位 39 篇、语义逐条比对 0 问题项（摘要级 27／仅元数据级 12／无法定位 5）；AIGC 未见痕迹（7041 词，提示语密度 1.7/千词）；声明体系齐备，唯 Ocean 编委名单未录入致 6.1「COI 对照编委」子项未检测；可改进项集中在著录规范（41 篇缺 DOI、风格不统一、[1] 题名与出版者位置疑颠倒、[6] 缺 URL、[3][39] 姓名变音符号缺失）。TOOL_NAME 升 v3.16.1 |
| v3.16.0 | 2026-09-17 | **OCE20260029（Ocean 已接收稿，14 页 PDF）实测驱动：修复两处「静默失真」缺陷 + 新增折行 APA 解析器**。① **`aigc_stats.py` 正文截断（CRITICAL）**——无 References 标题时回退取「首个 `[N]` 开头行」，被分栏 PDF 的**折行引用标记**误触发（正文明细行以 `[15] proposed using...` 开头），正文被截断（7196 词 → 640 词）而**不报错**，句长/变异系数/TTR/首人称/提示语密度全部失真；历史 OCE20260026 报告同样受影响（5497 → 8288 词），其 AIGC 指标须以新脚本重测；现加严为「`[N]` 行 ≥5 且首行编号 ≤2 且下降次数 ≤20%」。② **`crossref_check.py` 泛用词误配（CRITICAL）**——`titles_match` 仅按 token 重叠 ≥0.65 判定，[1] GWEC《Global wind report 2025》被 OECD《Global Debt Report 2025》以 0.75 重叠、8/13 分接受为「通过」，并在 `semantic_check.py fetch` 的标题反查中连带挂上错误摘要（DOI 10.3987 系 OECD 报告），不复核将产出「真实性通过 + 语义一致」双重假结论；现新增**特征词守卫**（稿内长度 ≥4 的非泛用、非数字词一个都对不上即判非同篇），回归 4/4 用例通过（U. S. 缩写、副标题、大小写差异均不回归）。③ **新增 `scripts/parse_refs_apa_wrapped.py`**——APA 式 + 双栏 PDF 折行文献表解析器，输出纯 list；与本次临时脚本结果**逐字段零差异**（25 条）。④ **同一修复已同步「熊猫找茬-新稿」v2.19.1**（同源脚本）。⑤ **本稿结论**：内容相关性高度相关；4 位作者中 3 位有同名命中但均跨领域（Yu Zhang 112 条全为医学/计算机/农业等），基本判定为同名误报；25 篇文献 20 篇通过、5 篇为行业报告/标准（Crossref 未收录，非真实性风险）、撤稿 0 命中；无未引用文献；声明体系齐备（仅 Data availability 跨页断句待生产校对、编委名单缺失致 COI 对照子项未检测）；AIGC 未见痕迹。TOOL_NAME 升 v3.16.0 |
| v3.15.0 | 2026-09-16 | **CS20260009（Carbonsphere 已接收稿）实测驱动，`gen_report.py` 三处「文档/代码漂移」修复**：① **AIGC 句长变异系数判级方向打通**——`AIGC_ROWS` 参考区间由 `'>0.7 异常均匀'` 改为 `'越低越趋同（AI 特征）'`（与 `aigc_stats.py` v2.15.0 注释、SKILL.md 方向一致），并同步 `auto_judge` 的 `sentence_len_cv` 分支——**删除原 `val > 0.7 则「异常均匀」` 的反向内置阈值**（该分支与同一张表的参考区间列自相矛盾），改为返回方向性提示、具体判读交由 `aigc_judgments` 定性给出；② **年份分布表零计数分桶不再被过滤**——`build_year_stats_table` 移除 `if c:`，`≤2000` / `≥2026` 两端与 `合计` 行必须齐全，与 `crossref_check.py year-stats` 输出对齐（此前同一份 refs.json 在两个脚本下给出不同表格）；③ **`build_refs_rw_check` 新增「未执行」判定**——以 `total_references` 键是否存在为判据，缺失时输出 `.info`「撤稿检索未执行」，杜绝 v3.12.0「用户指定跳过」流程下零命中分支输出 `0 篇存在撤稿记录` 的**未执行却看似已核验**残留；同时零命中措辞去掉「真实」限定词（取 SKILL.md Step 3.3 标准表述「0 篇参考文献存在撤稿记录」）。④ **新增 `scripts/extract_pdf.py`（分栏感知 PDF 提取正式入库）**——把本次为 CS20260009 双栏 PDF 临时写的提取脚本固化为通用工具（CLI 与 `extract_docx.py` 对齐：`<paper.pdf> <out_text.txt> <out_paras.json>`，附 `body.txt`；stdout 一行 JSON 含 `gutter_pages`）；核心是「按行统计中部大空档取中位中心作 gutter → 逐行切 L/R → F→L→R 拼接」，并把上/下标合并收紧为「小字号 + 垂直偏移 ≥ 0.8pt + 间隙 ≤ 3pt」三条同时满足（此前仅按字号判断会把低栏 8.5pt 参考文献词跨栏并入 10pt 正文，产生 `andtechnology` 式粘连并破坏分栏切分）；**回归验证：新脚本在 CS20260009 上输出与临时脚本 SHA256 完全一致（`BED5CCF5…`，10 页全部识别出 gutter）**，SKILL.md Step 0 的 PDF 输入指引由「agent 用 pdfplumber 提取」改为「必须跑此脚本」；⑤ **「同一文件多处编辑禁止并行发出」陷阱升级为 CRITICAL 并补实证书**——本次对 `gen_report.py` 连发 3 处编辑，落盘后**仅最后 1 处生效、前 2 处被整体回退**（工具三次均报成功），与 v3.13.0 在 `report_content.json` 上的观测一致，现已写明判断特征（编辑报成功但 grep 仍是旧文案）与修复方式（逐条重发 + 逐条 grep 复验）；⑥ **Carbonsphere（CS）期刊记录入库**——`journal_scopes.json` 新增第 7 刊：scope 文本 + 官方编委会名单 45 人（主编 1 / 荣誉主编 1 / 执行主编 1 / 副主编 4 / 顾问编委 18 / 编委 11 / 青年编委 9），来源 SciOpen 官方页面，供 ① 维度与 6.1 节 COI 比对复用；TOOL_NAME 升 v3.15.0 |
| v3.14.0 | 2026-09-15 | **新增 DOI 锚点通道 + 统一格式文献表 A/B 实证（CESCI-D-26-00015 善峰版实测）**：① **新增 `scripts/extract_doi_anchors.py`**——从 docx 参考文献条目的 `[LinkOut]`/`[PubMed]` 超链接提取确定性 DOI 锚点（`w:hyperlink` 命名空间 + rels 解析 + PubMed→DOI eutils 换算 + 畸形链接回退文本行内 DOI + `--merge` 直接补进 refs.json），实测该稿 36 条中 31 条带锚点、全部成功取到 DOI；② **Step 3 新增 3.0「DOI 锚点提取（优先执行）」**，含受控 A/B 实测数据（同稿同脚本、清缓存冷启动）：**DOI 直连 21.6 s / 31 条定位 vs 仅标题检索 56.8 s / 30 条定位**——快 2.6 倍且救回 1 篇被判 not_found 的真实文献；结论固化：**统一格式、带 DOI 锚点的文献表显著优于未统一格式，应在接收/退修阶段向作者索取**；同时警示统一化可能**反向损伤**著录（该稿 3 处页码/期号被截断、1 处模板占位符未填），须逐字段比对原稿回补；③ **`gen_report.py` `build_refs_rw_check` 根因修复**——零命中分支原先丢弃 `note` 参数（导致「用户指定跳过」说明无法落进 4.4 节、每次都要打 HTML 后处理补丁），现已在零命中分支拼接 `note`，该处不再需要生成后补丁；④ 「运行环境陷阱」新增两条：`w:hyperlink` 查错命名空间会**得到 0 个结果且不报错**（曾误判文档无链接）、DOI 锚点提取的三个隐藏坑（ASCE 系 DOI 含括号不能排除 `)`、链接畸形须回退文本行内提取、PubMed 的 idconv 接口返回 HTML 导致 JSONDecodeError 须改用 eutils esummary；附 arXiv DOI 由 DataCite 注册故 Crossref 404 属正常）；⑤ 本次核验另产出一项可复用工作流——**「作者/编辑预处理版」独立文件**（与正文分开提交的统一格式版）是提取锚点的最佳来源，遇到时应优先索取并做两版文献表逐字段比对（Crossref 仲裁），本次据此发现 11 处字段差异（8 处统一版更准、3 处原稿更准）；TOOL_NAME 升 v3.14.0 |
| v3.13.0 | 2026-09-15 | **补录 CES 编委名单（58 人）+「名单在别处」事故固化**：① 补录 CES `editorial_board`（58 人：名誉主编 2 / 主编 2 / 副主编 5 / 国内编委 24 / 国际编委 25），数据取自**期刊信息库**（`CES文章总表.xlsx`「编委-编委会」sheet，源自 `编委名单` sheet（2026-01-28 版））——首次把「信息库 → 检测器」这条路走通；② 字段口径对齐 EMD 记录（领导层标注角色、普通编委只写姓名），**新增 `editorial_board_source`** 记录来源与版本，便于溯源与判断是否需更新；③ **新增红线②「名单回写」**——编委名单在信息库侧更新或用户在其他场合提供后，必须回写 `assets/journal_scopes.json`；本次事故根因即「名单 2026-09-10 汇入信息库，而本文件最后写入停在 2026-08-21，两套数据无任何同步触发」，检测时维度⑤编委子项静默退回「未检测」；④ Step 1.4「保存记录」补充编委字段口径、补录三步流程、来源优先级（本地记录 > 期刊信息库 > 用户提供）与「不抓 CES 官网」约定；⑤ `preflight.py` 无需改动（`save_journal_scope` 已支持编委字段），改后回归验证 CES 记录仍可被 `--abbrev CES` 命中；⑥ **`gen_report.py` `build_aigc_note` 双 `<p>` 修复**——agent_note 已是 HTML 片段（含 `<p>`/`<ul>` 等块级标签）时不再外包一层 `<p>`（曾产生 `<p><p>…</p></p>`）；⑦ **报告回填过程暴露的两个坑写入「运行环境陷阱」**：同一文件多处编辑**并行发出会静默互相覆盖**（实测连发 3 处仅 1 处生效、工具均报成功）、**重新生成报告会冲掉第 4 节「跳过」补丁**（须重打并 grep 复验 `0 篇存在真实撤稿记录`/`<p><p>`/占位符）；⑧ **CESCI-D-26-00015 报告按用户确认回填第 6.1 节编委比对结论**——6 位作者均不在编委会名单内，唯作者主单位（阿德莱德大学）有 1 位国际编委（Michael Evan Goodsite），提示编辑部确认其未参与本稿审稿与处理；TOOL_NAME 升 v3.13.0 |
| v3.12.0 | 2026-09-15 | **CESCI-D-26-00015 实战（CES 已接收稿）固化 4 条**：① **`affiliation_check.py` 误杀修复**——`is_noise()` 原将含 `email`/`@` 的整行判为噪声丢弃，而 Elsevier/AAAS 风格 Title page 把「作者角色 + 机构 + 邮箱」写在同一行（本稿 6 行全被滤掉、`status=not_found`）；改为**先剔邮箱片段再判噪声**，机构行得以保留（同时补 `Adjunct Lecturer`/`Director`/`Professor` 等角色前缀与 `South Australia, SA 5005` 式地名邮编的归一化）；② **`retraction_watch.py` 规则 B 单复数归一**——集合包含判定新增 `_singularize()`，「Squeeze-and-excitation networks」（ref）与撤稿标题中 `network` 单复数不一致曾致通用短语型子串误报（partial_ratio 90）逃逸去噪；③ **`semantic_check.py` 无 DOI 反查**——`fetch` 原仅在 refs 带 DOI 时抓摘要，Vancouver 列表整体无 DOI 时 36/36 全空、语义维度被迫整体降级；新增 `resolve_doi_by_title()`，复用 `crossref_check` 的 `query_crossref_by_title_exact` + `score_title_search_result`（阈值 6）反查 DOI，输出新增 `doi_resolved_by_title` 标记区分「原生 DOI」与「反查 DOI」；④ **新增「用户指定跳过维度」处理流程**（本次用户要求跳过参考文献检查）——见「缺信息跳过说明」块：③⑥ 标 `.info` 未检测、content 字段写跳过说明，并**警示 4.4 `build_refs_rw_check` 空 matches 分支不追加 note、须 HTML 后处理替换第 4 节**，否则会残留未执行却看似已核验的结论 |
| v3.11.1 | 2026-09-10 | **撤稿检索去噪补规则 B（CESCI-D-26-00025 实测）**：原去噪只覆盖「撤稿库侧短条目」方向，未覆盖「文献侧短通用短语」方向——ref 标题为通用短语时（`Compressed sensing`、`Convex Optimization`）会因是某条主题完全不同的撤稿标题的子串而拿 `partial_ratio` 满分误报（本稿 [23] 命中肺部超声撤稿文；历史 Kincho 稿 [34] 命中在线凸优化撤稿文）。`retraction_watch.py` 新增规则 B：ref token ≤4 且全部包含于命中标题、且命中标题 ≥2 倍长 → 过滤；SKILL.md Step 3.3 去噪条目 3 改写为「双向子串型误报」并修正原描述与实现的漂移（原文档写「文献标题字符数>3」，实际实现是「命中标题 token 数 ≤3」）。回归验证 Kincho/cesci20260019 真命中（SLAM part I）未被误杀 |
| v3.11.0 | 2026-09-07 | **⑥ 语义相关性升级为「逐条文献摘要级比对」并强制工具链（OCE20260026 实测驱动）**：新增 `scripts/semantic_check.py`（fetch/contexts/pair 三子命令）——fetch 逐条抓摘要（Crossref 复用 crossref_check 缓存+API → 无摘要则 OpenAlex 兜底 inverted index 重建；实测 149 条得摘要 99 条：Crossref 55 + OpenAlex 44，双源较单源覆盖近翻倍）；contexts 以引用标记为中心取滑窗（双栏 PDF 按句点切句会错栏产生碎片句，滑窗不依赖句子边界）；pair 合并逐条比对清单。SKILL.md：Step 3.5 加「强制工具链」块（禁止仅凭 Crossref 书目命中或抽样即下语义结论）、落盘约定新增 semantic_abs.json/citation_contexts.json/semantic_pairs.json、取证分级改四档（摘要级/仅元数据级/人工核实/无法获取，报告必须分列统计）、新增双栏 PDF 错拼陷阱规则（宿主句无法还原时不得判不相关，按主题+章节语境降级并标注「引用位置建议核对」）、判定逐条写 semantic_judgments.json（只报告问题项）。OCE20260026 实测产出 2 条提示：[17] whale falls 群引主题偏移（EPSL 1992 蛤类群落流体建模）、[71] 双栏错拼宿主句不可定位 |
| v3.10.2 | 2026-09-07 | **补修 gen_report.py 作者撤稿表下 note 旧措辞（OCE20260026 实测，v3.9.1 漏改触点）**：v3.9.1 只改了作者表格「说明」列（build_authors_table 行内），`build_authors_table` 返回的 `<p class="note">` 表下说明仍为「基本排除为同一人」。修复：同文件 140 行 note 文案改为「基本判定为同名误报」，与 SKILL.md 三档分类档2 及用户措辞规则一致；frontmatter/TOOL_NAME 升 v3.10.2 |
| v3.10.1 | 2026-09-03 | **修复 gen_report.py 第 5 节标题缺失（CESCI20260009 实测）**：`build_ext_sections` 的 semantic 分支此前直接 append `ext_sections.semantic_refs`，若 content 字段不带 h2 则报告第 5 节「参考文献语义相关性检测」无标题（第 6 节标题由脚本生成故正常）。修复：5 节 h2 标题改为与 6 节一致由脚本统一生成，`semantic_refs` 字段只含正文；SKILL.md 字段说明同步（内容不含 h2 标题）。新稿脚本无 ext_sections 逻辑不受影响 |
| v3.10.0 | 2026-09-02 | **固化 EMD20260111 实战经验 3 条**：① 运行环境陷阱新增 EMD 惯用格式「作者, 标题, 期刊. 卷 (年) 页码」解析字段错位（整行吞入 authors、title 被页码污染、DOI 提取正确）→ 有 DOI 条目走 Crossref `/works/{doi}` 反查补全规范元数据（可复用模板 `work/EMD20260111_m20260044_李清/refs_clean.py`），反查返回的 HTML 标记（`<sub>`/`<mml:math>`/`&amp;`）须清理后再入库；② Step 3.1 新增 CNKI 中文文献甄别规则——无 DOI 且期刊未被 Crossref 收录（如《广东电力》）时标题搜索误匹配相似英文文献属预期，判「无法定位，非真实性风险」，不可据误匹配标真实性问题，建议作者补 DOI；③ 经验同步沉淀至「参考文献识别经验手册」v1.1（新增 F7 格式、Crossref 反查补全+HTML 清理规则、CNKI 假警案例） |
| v3.9.1 | 2026-08-24 | **同步新稿 v2.17.1 作者撤稿表格旧措辞修复（文档/代码漂移）**：`scripts/gen_report.py` 作者表格「说明」列及 `SKILL.md` 三档分类档2 文案「基本排除同名误报」→「基本判定为同名误报」（与用户规则一致）；两份历史参考脚本 gen_report_emd20260108/09.py 同改；frontmatter 版本号由陈旧 3.7.0 校正为 3.9.1；TOOL_NAME 升 v3.9.1 |
| v3.9.0 | 2026-08-18 | **固化 CESCI20260019 实战经验 2 条（运行环境陷阱）**：① 引用统计正则升级——支持带空格编号组（`[49, 50]`）与 **en-dash 范围**（`[5–7]`、`[12–15]`），正则 `\[(\d+(?:[-,–]\s*\d+)*)\]`（hyphen/en-dash 双支持），避免漏匹配误报未引用；② refs.json 必须为纯 list 格式——crossref_check/check-refs 不接受 dict 结构（`{"refs":[...]}` 会 TypeError），解析后须单独落盘 refs 数组 |
| v3.8.0 | 2026-08-17 | **固化 EMD20260105 实战经验 3 条（运行环境陷阱）**：① APA 解析后须二次清理卷/页/DOI（parse_refs_apa 不剥离行尾 DOI、卷页混入 journal 字段，用 `doi:\s*(10\.\S+)` 提取 + `^(.*?)\s+(\d+),\s*([\d\u2013-]+)$` 拆分）；② batch_check_refs.py 合并 `total_references` 只反映第一批（40/52），须核对并手动合并各批 out.json；③ 引用统计正则须支持带空格编号组 `\[(\d+(?:[-,]\s*\d+)*)\]`（表格引用 `[49, 50]`、`[25, 29, 31, 38, 39]` 漏匹配会误报未引用） |
| v3.7.0 | 2026-08-17 | **报告生成脚本化（固定渲染模式，与新稿 v2.7.0 同步）**：新增 `scripts/gen_report.py`（零第三方依赖，stdout 机器可读 JSON）；新增「检测结果落盘约定」——Step 1-4 结果写入 `work/<稿件标识>/`（geo.json/refs.json/crossref.json/authors.json/refs_rw.json/aff.json，新增 aigc.json 约定）；Step 5 改为「agent 写 report_content.json（仅判定内容）→ 运行 gen_report.py」；⑤⑥ 由 report_content 的 `summary.ext` 与 `ext_sections`（semantic_refs + declaration_cards 结构化 finding 卡片）驱动，缺失维度 .info「未检测」占位；年份分布/作者撤稿表/政治风险/撤稿检索/AIGC 指标表自动生成；`refs_verify.summary` 必须 agent 写；旧 `gen_report_emd20260108/09.py` 保留作历史参考 |
| v3.6.0 | 2026-08-17 | **摘要表结论列精简（与新稿 v2.6.0 同步）**：检测结论摘要表「结论」列仅保留风险徽章（无风险/低风险/需修改/需修订/未检测），删除「高度相关」「无撤稿记录命中」等判定徽章——判定已作为「要点」列开头文本体现，避免重复；SUMMARY_EXT_BADGES ⑤⑥ 行格式同步；gen_report 参考脚本同步 |
| v3.5.0 | 2026-08-17 | **输出格式六项规范（与新稿 v2.5.0 同步）**：① 机构名称中文化（中国=学校+学院、国外=国名+学校+学院，不含省市街道邮编）；② 删除副标题行、生成日期并入 meta「检测工具」行（TOOL_NAME 升 v3.5.0）；③ 删除 {{COVERAGE_NOTE}} 维度覆盖清单，未检测维度改为摘要表结论列灰「未检测」+要点列写原因；④ 第 1 节合并为单表（结论列=风险徽章+判定徽章并排、要点列=判定+详情，SUMMARY_EXT_BADGES 行格式同步），{{CONCLUSION}} 不再含表格；⑤ 删除 {{RW_SOURCE}} 数据来源重复说明（日期由 meta「撤稿数据库版本」承载，正文不再重复）；⑥ 4.3 Crossref 通过文献仅汇总数量、信息不一致/无法定位文献列表格（页码起页一致仅格式差异按通过）；gen_report 参考脚本同步 |
| v3.4.1 | 2026-08-17 | **撤稿检索去噪（共同单词数过滤）**：标题模糊匹配新增过滤——文献标题字符数>3 时，与撤稿库标题共同单词数≤3 的命中不报告（即使匹配分 100），解决短标题 partial_ratio 子串误报（如 EMD20260109 [115] "Monitoring" 单词语条目 100 分命中）；实现：`check_reference_titles` 新增 `_common_word_count` 辅助函数 + 两分支汇合后插入过滤；与新稿 v2.4.1 一致 |
| v3.4.0 | 2026-08-17 | **报告章节结构统一（与新稿一致）**：稿件基本信息改为不编号小号字 9 字段（文件名/期刊全名/标题/作者/机构/类型/参考文献/撤稿数据库版本/检测工具，新增 REFS_COUNT/RW_UPDATE_DATE/TOOL_NAME）；政治风险移至稿件基本信息后（POLITICAL_RISK 条件占位符）；MODE 更名 COVERAGE_NOTE 移入第 1 节；检测结论摘要并入总体结论(CONCLUSION)；EXT_SECTIONS 移第 4 节后并规范为 h2「5 参考文献语义相关性检测」+h2「6 声明完整性」(h3 6.1-6.4)；章节重排为 2 内容相关性 / 3 作者诚信(3.1 撤稿、3.2 机构适配，AFFILIATION_RESULTS 拆出) / 4 参考文献(4.1-4.4) / 7 AIGC；副标题行去除硬编码版本号；gen_report 参考脚本同步 |
| v3.3.3 | 2026-08-17 | **固化参考文献解析脚本（与新稿 v2.3.4 一致）**：Step 3 输入补充 `scripts/parse_refs.py` 解析说明（[n] 编号、年份锚定回溯、作者标题分界、行尾 DOI 自动剥离提取、parse_failed 人工补全）；同步脚本改进——行尾 DOI 兼容与 References 定位行级截断，有/无 DOI 均适用 |
| v3.3.2 | 2026-08-17 | **固化 AIGC 脚本化（与新稿 v2.3.3 一致）**：Step 4 改为「脚本算指标 + agent 判级」混合模式——调用 `scripts/aigc_stats.py` 计算 8 项定量指标（自动排除 References 节，行级截断兼容独立行/带编号标题/首个 `[N]` 回退），引用空洞与综合判级由 agent 负责；修复该脚本 References 排除的稳健性 |
| v3.3.1 | 2026-08-17 | **Mendeley 解法文字-脚本对齐**：SKILL.md「运行环境陷阱」Mendeley SDT 条目补充 `scripts/extract_docx.py` 深度提取工具引用（脚本已存在，docx 文本提取一律用它），与新稿 v2.3.2 保持完全一致 |
| v3.3.0 | 2026-08-17 | **移除⑦数据/图像异常维度 + 期刊本地记录增强**：① 按编辑部要求删除「⑦ 数据/图像异常」维度及全部 paperconan 调用/描述（SKILL.md/README/功能说明/interpretation/报告模板措辞同步「七维→六维」，扩展维度精简为 ⑤⑥）；② 期刊本地记录新增可选编委名单字段（`editorial_board` / `editorial_board_url` / `editorial_board_text` / `editorial_board_updated_at`）；③ preflight 新增 `diff_scope_text` 链接差异比对（difflib，差异<10%→update 更新本地，≥10%→review 请用户确认，红线①约束不擅自覆盖），`save_journal_scope` 签名扩展支持编委字段；④ 修复新稿 SKILL.md 过时路径与已出版 requirements.txt 头注释 |
| v3.2.0 | 2026-08-17 | **同步新稿 v2.3.0+v2.3.1 并补齐 v2.1.1**：① 政治敏感词扫描——复制 `scripts/geo_check.py`（Taiwan/Tibet/Xizang 词干匹配），Workflow 新增 Step 0.6，报告开头新增第 0 条红字「潜在政治风险，请人工核查」+ 句子/章节表格（未命中不显示）；② 运行环境陷阱小节（Git Bash heredoc 破坏反斜杠转义、docx 参考文献在 Mendeley SDT 字段须 XML 深度遍历）；③ Crossref 核对新增 page_mismatch 人工甄别（起页一致仅格式差异按通过）与 author_mismatch 三类误报甄别（多作者取末姓/et al./弯直引号）；④ Step 0 补 has_authors 粗检误判提醒；frontmatter 补 `agent_created: true` |
| v3.1.0 | 2026-08-14 | **同步机构-领域适配性检查**：从新稿同步 `scripts/affiliation_check.py`（启发式提取作者机构）与 Step 2b 流程（机构名称语义 vs 论文领域交叉比对，两档：适配 / 不相关附人工提示）；Step 2 拆为 2a 撤稿检索 / 2b 机构适配性；缺机构信息 → 2b 子节标「未检测（未提供机构信息）」不判定；报告「作者诚信」节新增机构适配子节；判断仅基于机构名称语义，禁止联网搜索机构信息 |
| v3.1.0 | 2026-08-14 | **降低 RW 下载频率 + 修复 RW 并发缺陷**：下载改为两步判定（第1步本地快筛：update_date 距今 <3 天不联网复用；第2步联网精确判定：(gitlab_date - 本地版本日期) > 3 天才下载；API 不可达回退保守下载一次）；csv_source 不再产生 `(GitLab API unreachable, source unverified)` 变体；Workflow 新增 Step 0.5 RW 数据准备前置步骤，明确数据就绪后 check-authors/check-refs 可安全并行（严禁未就绪时并行触发并发下载） |
| v3.1.0 | 2026-08-13 | **去双模式化 + 同步表格引用规则**：七个检测维度同等对待、无模式区分，缺信息维度标「未检测」并跳过；{{MODE}} 改为维度覆盖清单；声明完整性无编委名单时仅「COI 对照编委」子项未检测；红线①改为跳过语义；报告扩展维度小节始终渲染、缺失维度 .info 占位；同步新稿「引用统计必须覆盖表格」规则 |
| v3.0.0 | 2026-08-13 | **合并「熊猫找茬-新稿」**：四维检查（内容相关性/作者诚信/参考文献/AIGC）与脚本（preflight/crossref_check/retraction_watch/download_retraction_watch）完整并入，输入输出判定方式与新稿完全一致；保留已出版扩展维度（声明完整性/参考文献语义相关性/数据图像异常）为 enhanced 模式；双模式自动识别；保留红线①（enhanced 模式严禁自行搜索）；删除红线②③与 severity 五级/finding 卡片体系，改用新稿 badge 模板 |
| v2.x | 2026-07 | 原始已出版版本：六维筛查 + severity 五级 + finding 卡片（已废弃） |

## CRITICAL: signal, not verdict

本 skill 的所有发现都是**筛查信号**，不是定性结论。严禁：
- ❌ 说"这篇论文造假"、"这位作者有问题"、"这是 AI 写的"
- ❌ 用"实锤"等确定性表述
- ❌ 不点名作者：不公开说"X 教授的 Y 论文有问题"
- ❌ 不建议社交媒体披露：不建议发微博 / Twitter / 知乎 / 小红书 / 抖音 抨击作者
- ❌ 不替学术机构做裁定：不给出"应撤稿""应拒稿"等最终处理意见
- ✅ 只报告"命中 N 条可疑模式"并建议人工核实
- ✅ 推荐走期刊编辑部 / PubPeer 等正规反馈渠道

详细回复模板与边界案例见 `references/interpretation.md`。

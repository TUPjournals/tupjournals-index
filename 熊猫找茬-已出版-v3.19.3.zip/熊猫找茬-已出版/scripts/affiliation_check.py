#!/usr/bin/env python3
"""
affiliation_check.py — 作者机构信息提取

从稿件全文（含 Title page）中启发式提取作者机构信息，供「机构-领域适配性」分析使用。

Usage:
    python affiliation_check.py --text <全文文本文件>

Output (stdout): JSON
    {
      "status": "found" | "not_found",
      "affiliations": ["..."],
      "matched_lines": ["..."],
      "note": null | "未检测到机构信息"
    }
"""

import argparse
import json
import re
import sys
from pathlib import Path

# 机构关键词（英文词边界匹配，避免 "lab" 命中 "Eslab" 等子串；中文直接子串）
_ORG_EN_RE = re.compile(
    r"\b(?:university|college|school|institute|laboratory|lab|academy|"
    r"research center|research centre|department|hospital|faculty|"
    r"centre|center|corporation|company|ltd)\b",
    re.IGNORECASE,
)
ORG_CN = ["大学", "学院", "研究所", "研究院", "实验室", "医院", "中心",
          "学校", "科学院", "工程院", "集团", "公司"]

# 噪声行关键词（词边界匹配；多词短语整体匹配）
_NOISE_RE = re.compile(
    r"\b(?:supported by|funding|grant|sponsor|financed|declare|declaration|"
    r"corresponding|corresponding author|email|credit|competing|"
    r"data availability|conflicts|received|accepted|manuscript|submitted|"
    r"author details|title page)\b|@",
    re.IGNORECASE,
)

# 领域关键词（供 agent 参考，脚本不判定适配性；此处仅预置常见词便于输出提示）
DOMAIN_KEYWORDS = [
    "material", "energy", "chem", "electro", "battery", "supercapacitor",
    "solar", "fuel", "hydrogen", "catal", "physics", "mechanical", "civil",
    "electronic", "nano", "opt", "semiconductor", "environment", "bio",
    "材料", "能源", "化学", "电池", "催化", "物理", "机械", "土木",
    "电子", "纳米", "光学", "环境", "生物",
]

# v3.12.0：联系方式清理——很多期刊（Elsevier/AAAS/SPJ 风格）把
# 「作者角色 + 机构 + 邮箱」写在**同一行**（如
# "1 PhD candidate; School of ..., Adelaide University, SA 5005. Email: a@b.edu.au"）。
# 旧实现用整行 is_noise() 判断，line 内含 "email"/"@" 即整行丢弃 → 机构行全部漏检。
# 现改为：先剥离邮箱子句与裸邮箱地址，再对清理后的文本做噪声判断 / 机构判定。
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
_EMAIL_CLAUSE_RE = re.compile(
    r"\b(?:e-?mail|electronic\s+mail|corresponding\s+author)\s*[:：].*$",
    re.IGNORECASE,
)


def strip_contact(line: str) -> str:
    """剥离邮箱子句与裸邮箱地址，保留机构信息部分。"""
    s = _EMAIL_CLAUSE_RE.sub("", line)
    s = _EMAIL_RE.sub("", s)
    return s.strip(" \t;,.")


def is_noise(line: str) -> bool:
    return bool(_NOISE_RE.search(line))


def has_org_keyword(line: str) -> bool:
    low = line.lower()
    return bool(_ORG_EN_RE.search(low)) or any(k in low for k in ORG_CN)


def looks_like_affiliation(line: str) -> bool:
    """判断一行是否可能是机构行（两种特征满足其一）。"""
    # 特征 A：上标编号开头（a / a1 / 1 / 1,2 / b / 12 等）+ 后随机构关键词
    if re.match(r"^\s*[a-z](?:[0-9])?\s+[A-Z]", line) and has_org_keyword(line):
        return True
    # 特征 B：行内含机构关键词（排除已覆盖的噪声行）
    if has_org_keyword(line):
        # 排除过短行（<15 字符）与无实质内容的行
        if len(line.strip()) < 15:
            return False
        return True
    return False


def normalize(line: str) -> str:
    """归一化机构名：去作者角色前缀、去上标前缀、去邮编、去国家后缀、压缩空白。"""
    s = line.strip()
    # v3.12.0：合并行（"1 PhD candidate; School of ..."）优先取含机构关键词的分段
    if ";" in s:
        segs = [x.strip() for x in s.split(";")]
        org_segs = [x for x in segs if has_org_keyword(x)]
        if org_segs:
            s = org_segs[-1]
    # 去上标编号前缀（1 / 5* / a / a1 / 1,2 / b,c）
    m = re.match(r"^[a-z]?(?:\d+)?\*?(?:,[a-z\d]+)*[\s.]+", s)
    if m and m.end() < len(s):
        s = s[m.end():]
    # 去邮编（行尾 4-6 位数字）
    s = re.sub(r",?\s*\d{4,6}\s*$", "", s)
    # 去行尾州/省缩写残留（如 "..., SA"）
    s = re.sub(r",?\s*(?:SA|NSW|VIC|QLD|WA|TAS|NT|ACT)\s*$", "", s)
    # 去常见国家/地区后缀（英文结尾）
    s = re.sub(r",?\s*(China|P\.R\. China|PR China|United States|USA|US|UK|Japan|Korea|Germany|France|Australia|Canada|Singapore|Hong Kong, China|Taiwan, China|Macao, China|India|Netherlands|Switzerland|Sweden)\s*$", "", s, flags=re.IGNORECASE)
    s = re.sub(r",?\s*(中国|中华人民共和国|美国|日本|韩国|德国|英国|澳大利亚|加拿大|新加坡|中国香港|中国台湾|中国澳门|印度|荷兰|瑞士)\s*$", "", s)
    # 压缩空白
    s = re.sub(r"\s+", " ", s).strip()
    return s.strip(" ,")


def extract_affiliations(text: str) -> dict:
    """从全文提取机构行。"""
    lines = [ln.strip() for ln in text.split("\n")]
    matched_lines = []
    seen = set()
    for ln in lines:
        if not ln or len(ln) > 300:   # 机构行通常较短
            continue
        # v3.12.0：先剥离邮箱子句/裸邮箱，再判噪声与机构特征
        cand = strip_contact(ln)
        if not cand or len(cand) > 300:
            continue
        if is_noise(cand):
            continue
        if looks_like_affiliation(cand):
            key = normalize(cand)
            if not key:
                continue
            if key.lower() in seen:
                continue
            seen.add(key.lower())
            matched_lines.append(cand)

    if not matched_lines:
        return {
            "status": "not_found",
            "affiliations": [],
            "matched_lines": [],
            "domain_hint": {},
            "note": "未检测到机构信息",
        }

    # 去重并归一化输出（保留原始行供核对）
    affiliations = []
    for ln in matched_lines:
        norm = normalize(ln)
        if norm and norm not in affiliations:
            affiliations.append(norm)

    # v2.15.0 (P2-5): 领域关键词命中提示——仅有机构通名（university/institute 等）
    # 而无领域词的机构，agent 可据此判「待核实」而非直接「不相关」，减少误报噪声
    domain_hint = {}
    for aff in affiliations:
        low = aff.lower()
        hit = [k for k in DOMAIN_KEYWORDS if k.lower() in low]
        if hit:
            domain_hint[aff] = hit

    return {
        "status": "found",
        "affiliations": affiliations,
        "matched_lines": matched_lines,
        "domain_hint": domain_hint,
        "note": None,
    }


def main():
    parser = argparse.ArgumentParser(description="Extract author affiliations from manuscript text")
    parser.add_argument("--text", required=True, help="Path to the manuscript full-text file (txt)")
    args = parser.parse_args()

    try:
        text = Path(args.text).read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "affiliations": [],
            "matched_lines": [],
            "note": f"无法读取文本文件: {e}",
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    result = extract_affiliations(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

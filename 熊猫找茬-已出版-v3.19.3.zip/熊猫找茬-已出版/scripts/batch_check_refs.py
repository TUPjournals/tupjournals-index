#!/usr/bin/env python3
"""
batch_check_refs.py — 分批调用 retraction_watch check-refs（规避 rapidfuzz 累积崩溃）

背景：Windows 下 rapidfuzz process.extractOne 在同进程累积处理约 60+ 次后发生原生段错误
（静默退出，无 traceback）。本脚本将 refs 按 BATCH 分批，每批用独立子进程运行
check-refs，再合并各批 matches，等效全量结果。

v2.15.0 整改：
- S5: 默认 batch 40 → 20。每篇文献实际触发 2 次 extractOne（token_sort + partial），
  20 篇 = 40 次调用，低于约 60 次崩溃阈值并留足余量。
- S1: 子进程 subprocess.run 增加 timeout=600——rapidfuzz 挂起/意外阻塞时
  防止整条流水线无限卡死（超时按失败重试，与崩溃同处理）。
- S6: 合并时 total_references 统一取全量 refs 数（原实现只反映首批，数据缺陷）。
- F-09: 临时文件落系统 temp 隔离目录（tempfile.mkdtemp），不污染产物目录；
  由系统临时目录自动清理机制回收，不在此处显式删除
  （规避沙箱 safe-delete hook 拦截 Path.unlink 导致进程被宿主终止，v2.11.1 经验）。

Usage:
    python batch_check_refs.py <refs.json> <out.json> [batch_size=20]
"""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
RW_SCRIPT = SKILL_DIR / 'scripts' / 'retraction_watch.py'
PY = sys.executable
SUB_TIMEOUT = 600          # 子进程超时（秒）
DEFAULT_BATCH = 20         # v2.15.0: 40 → 20（2×extractOne/篇，20 篇 = 40 次调用 < 60 阈值）

# 若宿主已设置 RW_CSV_CACHE，透传给子进程：首个子进程构建 RW 索引缓存、后续批次复用
# （P3 性能优化，消除每批重解析 65MB CSV 的开销）
CSV_CACHE_ENV = os.environ.get('RW_CSV_CACHE')


def main():
    if len(sys.argv) < 3:
        print('usage: batch_check_refs.py <refs.json> <out.json> [batch_size=20]', file=sys.stderr)
        sys.exit(1)
    refs_path = Path(sys.argv[1])
    out_path = Path(sys.argv[2])
    batch = int(sys.argv[3]) if len(sys.argv) > 3 else DEFAULT_BATCH
    if batch < 1:
        batch = DEFAULT_BATCH

    try:
        refs = json.loads(refs_path.read_text(encoding='utf-8'))
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取 refs.json 失败: {e}'}, ensure_ascii=False))
        sys.exit(1)
    if not isinstance(refs, list):
        print(json.dumps({'status': 'error', 'error': 'refs.json 必须为纯 list'}, ensure_ascii=False))
        sys.exit(1)
    batches = [refs[i:i + batch] for i in range(0, len(refs), batch)]

    merged = {}
    all_matches = []
    tmp_dir = Path(tempfile.mkdtemp(prefix='batch_check_refs_'))
    # 注：临时目录由系统 temp 自动清理回收，不显式删除（见文件头 F-09 说明）

    for bi, b in enumerate(batches):
        tmp_refs = tmp_dir / f'_batch_{bi}.json'
        tmp_out = tmp_dir / f'_batch_{bi}_out.json'
        tmp_err = tmp_dir / f'_batch_{bi}_err.log'
        tmp_refs.write_text(json.dumps(b, ensure_ascii=False), encoding='utf-8')

        # 子进程可能因 rapidfuzz 原生崩溃（段错误，stdout 为空）或超时挂起 → 重试最多 3 次
        data = None
        for attempt in range(3):
            env = dict(os.environ)
            if CSV_CACHE_ENV:
                env['RW_CSV_CACHE'] = CSV_CACHE_ENV
            try:
                with open(tmp_out, 'w', encoding='utf-8') as fo, open(tmp_err, 'w', encoding='utf-8') as fe:
                    subprocess.run(
                        [PY, str(RW_SCRIPT), 'check-refs', '--refs', str(tmp_refs)],
                        stdout=fo, stderr=fe, check=False, timeout=SUB_TIMEOUT, env=env)
            except subprocess.TimeoutExpired:
                print(f'WARN batch {bi} attempt{attempt + 1}: 子进程超时（>{SUB_TIMEOUT}s），按失败重试',
                      file=sys.stderr)
                continue
            except Exception as e:
                print(f'WARN batch {bi} attempt{attempt + 1}: 子进程异常 {e}', file=sys.stderr)
                continue
            try:
                data = json.loads(tmp_out.read_text(encoding='utf-8'))
                break
            except Exception:
                continue
        if data is None:
            print(f'ERROR batch {bi}: 子进程 3 次输出无效（rapidfuzz 崩溃/超时？） | stderr: '
                  f'{tmp_err.read_text(encoding="utf-8", errors="replace")}', file=sys.stderr)
            sys.exit(1)

        # 合并：非 matches 字段取最后一批（csv_source 等）；total_references 统一用全量
        for k, v in data.items():
            if k == 'matches':
                continue
            merged[k] = v
        all_matches.extend(data.get('matches', []))

    merged['total_references'] = len(refs)   # S6: 不再只反映首批
    merged['matches'] = all_matches
    out_path.write_text(json.dumps(merged, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({'batches': len(batches), 'total_matches': len(all_matches)},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()

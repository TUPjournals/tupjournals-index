# -*- coding: utf-8 -*-
"""common_stats.py — 年份分桶公共实现（v2.15.0 新增）。

消除 crossref_check.compute_year_stats 与 gen_report.build_year_stats_table
两套独立实现的潜在分歧：分桶规则与计数逻辑统一在本文件，两处引用。

Usage:
    from common_stats import compute_year_stats
"""

import re

YEAR_BINS = [
    ('<=2000', None, 2000), ('2001-2005', 2001, 2005), ('2006-2010', 2006, 2010),
    ('2011-2015', 2011, 2015), ('2016-2020', 2016, 2020), ('2021-2025', 2021, 2025),
    ('>=2026', 2026, None),
]


def extract_year(year_str):
    """从年份字符串提取 int；缺失/非法返回 None。"""
    if not year_str:
        return None
    try:
        return int(re.sub(r'[^\d]', '', str(year_str)[:4]))
    except ValueError:
        return None


def compute_year_stats(references):
    """5 年分桶统计。

    references: list[dict]，每项含 year 字段。
    返回 {"total": N, "distribution": [{range,count,percentage}, ..., Unknown 桶]}。
    """
    years, unknown = [], 0
    for ref in references or []:
        y = extract_year((ref or {}).get('year', ''))
        if y is None:
            unknown += 1
        else:
            years.append(y)

    total = len(years) + unknown
    stats = []
    for label, low, high in YEAR_BINS:
        if low is None and high is not None:
            count = sum(1 for y in years if y <= high)
        elif high is None and low is not None:
            count = sum(1 for y in years if y >= low)
        else:
            count = sum(1 for y in years if low <= y <= high)
        stats.append({
            "range": label,
            "count": count,
            "percentage": round(count / total * 100, 1) if total > 0 else 0,
        })
    stats.append({
        "range": "Unknown",
        "count": unknown,
        "percentage": round(unknown / total * 100, 1) if total > 0 else 0,
    })
    return {"total": total, "distribution": stats}

# -*- coding: utf-8 -*-
"""config.py — 熊猫找茬-已出版 统一配置（v4.0.0 同步自新稿 v2.15.0，消除跨脚本常量漂移）。

被 download_retraction_watch.py / retraction_watch.py / crossref_check.py 引用；
SKILL.md「运行环境陷阱」要求任何路径/标识改动先改本文件。
"""

import os
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent          # 熊猫找茬-已出版/
DATA_DIR = SKILL_DIR / "data"                               # 下载数据目录
CSV_PATH = DATA_DIR / "retraction_watch.csv"
META_PATH = DATA_DIR / "retraction_watch_meta.json"
CACHE_DIR = SKILL_DIR / "cache"                             # 跨运行缓存（Crossref 响应 / RW 索引）
CROSSREF_CACHE = CACHE_DIR / "crossref_cache.json"
RW_INDEX_CACHE = CACHE_DIR / "rw_index.pkl"

# 工具标识（统一 User-Agent，跨脚本一致，便于服务端归因）
TOOL_NAME = "panda-ms-check"
TOOL_VERSION = "4.0.0"
USER_AGENT = f"{TOOL_NAME}/{TOOL_VERSION} (integrity check; +https://gitlab.com/crossref/retraction-watch-data)"

# Crossref 礼貌池 attribution 邮箱：默认占位，可用环境变量 PANDA_MAILTO 覆盖为真实邮箱
# （礼貌池限速 10 req/s、并发上限 3；普通池仅 5 req/s、并发 1）
MAILTO = os.environ.get("PANDA_MAILTO", "editor@example.com")

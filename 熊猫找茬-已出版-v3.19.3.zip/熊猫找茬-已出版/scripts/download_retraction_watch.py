# -*- coding: utf-8 -*-
"""
download_retraction_watch.py — Retraction Watch CSV 下载助手（熊猫找茬-新稿 调用）

逻辑（两步判定，降低下载频率、减少联网）：
  无条件下载（任一成立即下载）：
    A. 强制（--force）
    B. CSV 文件不存在（无可检测数据）
  第 1 步（本地快筛，不联网）：
    - 以本地 retraction_watch_meta.json 的 update_date（数据版本日期）为基准，
      缺失/解析失败时回退为 CSV 文件 mtime 日期；
    - 版本日期距今 < 3 天 → 直接复用本地，不发任何网络请求
      （因源端日期 ≤ 今天，差异必然 < 3 天，不可能触发下载）。
  第 2 步（联网精确判定，仅版本日期距今 >= 3 天时执行）：
    - 通过 GitLab Commits API 取源端最新提交日期（committed_date，即数据源端更新日期，
      仅几 KB JSON，开销极小）；
    - (gitlab_date - 本地版本日期) > 3 天 → 重新下载；<= 3 天 → 复用本地。
    - API 不可达 → 回退保守下载一次（保证不因查不到源头而用旧数据），
      此时 update_date 记录为旧基线或今天。
  2. 下载后完整性校验：字节数 >= RW_MIN_BYTES 且 行数 >= RW_MIN_ROWS，否则视为不完整。
  3. 失败/不完整时重试：最多 RW_MAX_RETRIES 次、指数退避；先写 .tmp 临时文件，
     校验通过才 os.replace 原子覆盖，绝不回退覆盖正式 CSV。
  4. 重试耗尽仍不完整时，保留上一版完整数据（若本地已有），不删除、不报错阻断检测。

v2.15.0 整改：
- F-08/S7: 临时文件路径唯一化（含 pid），并行触发下载时互不覆盖；
  os.replace 原子覆盖 + 字节/行数校验保持。
- F-04: 记录 GitLab 源端 commit SHA 与下载文件 SHA256 入 meta，
  供审计比对（下载后算 sha256 存 meta；下次下载前可人工比对历史 sha256 发现篡改）。
- P2-2: RW_MIN_ROWS 50000 → 55000（约 91% 完整度下限，减少漏检近 1 万条撤稿记录的可能）。
- S2: GitLab 返回日期解析 fromisoformat 包 try，失败按"未知源端日期"保守处理。
- 配置收敛：路径/UA 统一引自 scripts/config.py。

两种使用方式：
  - 命令行：python download_retraction_watch.py [--force]
      stdout 打印 FRESH / OK / INCOMPLETE；退出码 0 = 可用，1 = INCOMPLETE。
  - 作为模块：from download_retraction_watch import run
      run(force=False) -> (status, source, downloaded_now)
"""

import datetime
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from config import CSV_PATH, DATA_DIR, META_PATH, USER_AGENT

# ── 配置常量（集中管理，便于调参）──────────────────────────────────────
URL = "https://gitlab.com/crossref/retraction-watch-data/-/raw/main/retraction_watch.csv"
# 旧版数据位置（历史遗留），用于一次性迁移清理
LEGACY_DATA_DIR = Path.home() / ".workbuddy" / "data"

# GitLab Commits API：取 retraction_watch.csv 最近一次提交的 committed_date（源端更新日期）
# 与 commit id（源端版本指纹），用于精确判断是否比本地新 + 审计追溯（仅几 KB JSON）。
GITLAB_COMMITS_API = (
    "https://gitlab.com/api/v4/projects/crossref%2Fretraction-watch-data"
    "/repository/commits?path=retraction_watch.csv&ref_name=main&per_page=1"
)
GITLAB_API_TIMEOUT = 15        # 源端日期查询超时（秒）

RW_MAX_AGE_DAYS = 3            # 超过 3 天未更新则重新下载
RW_MIN_BYTES = 52_428_800      # 50MB，残缺的 2.5MB 必不过
RW_MIN_ROWS = 55000            # 完整库约 6 万+ 行；v2.15.0: 50000 → 55000（约 91% 下限）
RW_MAX_RETRIES = 3             # 失败/不完整重试次数
RW_TIMEOUT = 300               # 读取超时（秒），62MB 文件留足余量
RW_CHUNK = 1 << 20             # 1MB 分块写入
UA = USER_AGENT                # 统一 User-Agent（config 收敛）


def log(msg):
    print(f"[retraction_watch] {msg}", file=sys.stderr, flush=True)


def load_meta():
    """读取元数据，容错空文件/损坏 JSON。"""
    if not META_PATH.exists():
        return {}
    try:
        return json.loads(META_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _sha256(path):
    """计算文件 SHA256（分块，避免整文件读内存）。"""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def fetch_gitlab_update_date():
    """返回 (源端最新提交日期 YYYY-MM-DD, commit_sha)；不可达/解析失败返回 (None, None)。"""
    req = urllib.request.Request(GITLAB_COMMITS_API, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=GITLAB_API_TIMEOUT) as resp:
            if resp.status != 200:
                log(f"GitLab API HTTP 状态 {resp.status}")
                return (None, None)
            data = json.loads(resp.read().decode("utf-8"))
        if isinstance(data, list) and data:
            committed = data[0].get("committed_date", "")
            commit_sha = data[0].get("id", "")
            if committed:
                return (committed[:10], commit_sha or "")
    except Exception as e:
        log(f"GitLab API 不可达：{e}")
        return (None, None)
    return (None, None)


def _get_version_date(meta):
    """返回本地版本日期：update_date 优先；缺失/解析失败回退 CSV mtime。"""
    raw = meta.get("update_date")
    if raw:
        try:
            return datetime.date.fromisoformat(raw)
        except Exception:
            log(f"update_date 解析失败（{raw!r}），回退 CSV mtime")
    mtime_date = datetime.date.fromtimestamp(CSV_PATH.stat().st_mtime)
    log(f"update_date 缺失/无效，回退 CSV mtime={mtime_date}")
    return mtime_date


def count_rows(path):
    """统计 CSV 数据行数（不含表头），用纯行数计数以避免 csv 大字段限制。"""
    n = 0
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
        for _ in f:
            n += 1
    return max(n - 1, 0)


def download_once(tmp_path):
    """下载到临时文件；成功返回 True，失败返回 False。"""
    req = urllib.request.Request(URL, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=RW_TIMEOUT) as resp:
            if resp.status != 200:
                log(f"HTTP 状态 {resp.status}")
                return False
            with open(tmp_path, "wb") as out:
                while True:
                    chunk = resp.read(RW_CHUNK)
                    if not chunk:
                        break
                    out.write(chunk)
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError) as e:
        log(f"下载异常：{e}")
        return False
    return True


def save_meta(size, rows, update_date, commit_sha="", sha256=""):
    meta = {
        "update_date": update_date,
        "downloaded_at": datetime.datetime.now().astimezone().isoformat(),
        "bytes": size,
        "rows": rows,
        "source": "gitlab",
        "commit_sha": commit_sha,      # F-04: 源端 commit 指纹（审计追溯）
        "sha256": sha256,              # F-04: 本地文件哈希（比对发现篡改）
    }
    META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"已写元数据：update_date={update_date}, {size} bytes, {rows} rows, sha256={sha256[:12]}…")


def refresh_meta_if_incomplete():
    """FRESH 路径下，若 meta 缺 bytes/rows，补测现有 CSV 以保持格式一致。"""
    meta = load_meta()
    if "bytes" in meta and "rows" in meta:
        return
    if not CSV_PATH.exists():
        return
    log("meta 缺 bytes/rows，补测现有 CSV ...")
    size = CSV_PATH.stat().st_size
    rows = count_rows(CSV_PATH)
    meta.setdefault("update_date", datetime.date.today().isoformat())
    meta.setdefault("downloaded_at", datetime.datetime.now().astimezone().isoformat())
    meta["bytes"] = size
    meta["rows"] = rows
    meta.setdefault("source", "gitlab")
    meta.setdefault("commit_sha", "")
    meta["sha256"] = _sha256(CSV_PATH)
    META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"已补测：{size} bytes, {rows} rows, sha256={meta['sha256'][:12]}…")


def migrate_legacy_data():
    """
    一次性迁移：把旧位置 ~/.workbuddy/data 下的 CSV/meta 移到本 skill data 目录，
    并清理旧位置文件，避免双份数据。
    仅在新位置尚无 CSV 时才迁移（不覆盖已存在的 skill 目录数据）。
    """
    if CSV_PATH.exists():
        return
    legacy_csv = LEGACY_DATA_DIR / "retraction_watch.csv"
    legacy_meta = LEGACY_DATA_DIR / "retraction_watch_meta.json"
    if not legacy_csv.exists():
        return
    import shutil
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    shutil.move(str(legacy_csv), str(CSV_PATH))
    log(f"已迁移旧位置 CSV：{legacy_csv} -> {CSV_PATH}")
    if legacy_meta.exists():
        shutil.move(str(legacy_meta), str(META_PATH))
        log(f"已迁移旧位置 meta：{legacy_meta} -> {META_PATH}")


def _download_flow(recorded_update, gitlab_date, commit_sha, today_str):
    """执行下载+完整性校验+重试流程（原 run 的下载段）。返回 (status, source, downloaded_now)。"""
    # F-08/S7: 临时文件唯一化（含 pid），并行触发下载互不覆盖
    tmp_path = f"{CSV_PATH}.{os.getpid()}.tmp"
    for attempt in range(1, RW_MAX_RETRIES + 1):
        log(f"下载尝试 {attempt}/{RW_MAX_RETRIES} ...")
        if not download_once(tmp_path):
            time.sleep(2 ** (attempt - 1))
            continue
        if not os.path.exists(tmp_path):
            time.sleep(2 ** (attempt - 1))
            continue
        size = os.path.getsize(tmp_path)
        rows = count_rows(tmp_path)
        sha = _sha256(tmp_path)
        log(f"已下载 {size} bytes, {rows} rows, sha256={sha[:12]}…")
        if size >= RW_MIN_BYTES and rows >= RW_MIN_ROWS:
            os.replace(tmp_path, CSV_PATH)  # Windows 原子覆盖
            # 记录真实源端日期；若本次 API 不可达则保留旧基线（不回退为今天）
            new_update = gitlab_date if gitlab_date else (recorded_update or today_str)
            save_meta(size, rows, new_update, commit_sha or "", sha)
            return ("OK", f"downloaded_{today_str}", True)
        log(f"不完整（需 >= {RW_MIN_BYTES} bytes 且 >= {RW_MIN_ROWS} rows），删除临时文件重试")
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        time.sleep(2 ** (attempt - 1))

    # 重试耗尽：保留上一版完整数据（若本地已有），不删除、不阻断检测
    log("重试耗尽，保留上一版完整数据")
    if CSV_PATH.exists():
        mtime_date = datetime.date.fromtimestamp(CSV_PATH.stat().st_mtime)
        return ("INCOMPLETE",
                f"cached_{mtime_date.isoformat()} (download incomplete, kept previous version)",
                False)
    return ("INCOMPLETE", "download_failed", False)


def run(force=False):
    """
    执行下载判定（两步）与下载。

    返回 (status, source, downloaded_now)：
      status ∈ {FRESH, OK, INCOMPLETE}
      source 字符串沿用 retraction_watch.py 的报告约定：
        FRESH        -> "cached_<日期>"
        OK           -> "downloaded_<日期>"
        INCOMPLETE   -> 有上一版："cached_<日期> (download incomplete, kept previous version)"
                        无上一版："download_failed"
      downloaded_now -> 是否刚完成下载
    """
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    # 一次性迁移旧位置数据（若无 skill 目录数据），避免双份
    migrate_legacy_data()
    today = datetime.date.today()
    today_str = today.isoformat()
    meta = load_meta()
    recorded_update = meta.get("update_date")

    # 无条件下载：--force 或 CSV 不存在（无可检测数据）
    if force or not CSV_PATH.exists():
        log("无条件下载（--force 或 CSV 不存在）")
        gitlab_date, commit_sha = fetch_gitlab_update_date()   # 尽力取真实源端日期；失败 (None, None)
        return _download_flow(recorded_update, gitlab_date, commit_sha, today_str)

    # 第 1 步：本地快筛（不联网）
    version_date = _get_version_date(meta)   # update_date 优先，缺失回退 mtime
    local_age = (today - version_date).days
    if local_age < 0:                        # 未来日期等异常值 clamp 为 0
        log(f"版本日期在未来（{version_date}），clamp 为 0 天")
        local_age = 0
    if local_age < RW_MAX_AGE_DAYS:          # 0/1/2 天 → 不联网 FRESH
        log(f"本地版本距今 {local_age} 天（<{RW_MAX_AGE_DAYS}），不联网复用")
        refresh_meta_if_incomplete()
        return ("FRESH", f"cached_{recorded_update or today_str}", False)

    # 第 2 步：联网精确判定（仅 local_age >= 3 才走到）
    gitlab_date, commit_sha = fetch_gitlab_update_date()
    if gitlab_date is None:
        log("GitLab API 不可达 → 回退保守下载一次")
        return _download_flow(recorded_update, None, None, today_str)
    # S2: 源端日期解析失败（非标准 ISO 格式）→ 按保守下载处理
    try:
        gitlab_d = datetime.date.fromisoformat(gitlab_date)
    except ValueError:
        log(f"GitLab 返回日期格式异常（{gitlab_date!r}），按保守下载处理")
        return _download_flow(recorded_update, None, commit_sha, today_str)
    diff_days = (gitlab_d - version_date).days
    if diff_days > RW_MAX_AGE_DAYS:          # 严格 > 3 天才下载
        log(f"源端比本地新 {diff_days} 天（>{RW_MAX_AGE_DAYS}），触发下载")
        return _download_flow(recorded_update, gitlab_date, commit_sha, today_str)
    log(f"源端比本地新 {diff_days} 天（≤{RW_MAX_AGE_DAYS}），复用本地")
    refresh_meta_if_incomplete()
    return ("FRESH", f"cached_{recorded_update or today_str}", False)


def main():
    force = "--force" in sys.argv[1:]
    status, source, _ = run(force=force)
    print(status)
    return 0 if status != "INCOMPLETE" else 1


if __name__ == "__main__":
    sys.exit(main())

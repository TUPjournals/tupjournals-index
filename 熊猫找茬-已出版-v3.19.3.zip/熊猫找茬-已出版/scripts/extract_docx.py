#!/usr/bin/env python3
"""
extract_docx.py — 深度提取 docx：全文纯文本 + 段落列表（保持文档顺序，覆盖表格与 sdt 字段）

Usage:
    python extract_docx.py <paper.docx> <out_text.txt> <out_paras.json>

- 递归遍历 body（w:p / w:tbl / w:sdt 混合，保持顺序），表格行以 [TABLE] 标记包裹
- 全文纯文本写 out_text.txt（供 geo_check / affiliation_check / AIGC / preflight 使用）
- 段落列表写 out_paras.json（供参考文献解析使用）

v2.15.0 整改：
- F-06: XML 解析改用 defusedxml（未安装时回退 xml.etree 并警告）——
  防 billion-laughs 实体膨胀；zip 成员数 / document.xml 解压大小设上限（防 zip 炸弹）。
- S11: document.xml 上限 50MB，超限拒绝解析（避免整文件读内存峰值）。
- S8: 抽出公共函数 extract_paras(path) -> list[str]，preflight 复用同一提取逻辑
  （消除两套提取逻辑导致的 sdt 差异误警）。
"""

import json
import re
import sys
import zipfile
from pathlib import Path

try:
    from defusedxml import ElementTree as ET          # F-06: 防实体膨胀（首选）
    _XML_OK = True
except ImportError:
    from xml.etree import ElementTree as ET           # 回退（功能可用，但不防实体攻击）
    _XML_OK = False

W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
W = f'{{{W_NS}}}'

MAX_ZIP_MEMBERS = 1000        # F-06: zip 成员数上限（正常 docx < 100）
MAX_DOCXML_BYTES = 50 * 1024 * 1024   # S11/F-06: document.xml 解压上限 50MB


def para_text(p):
    texts = p.findall(f'.//{W}t')
    return ''.join(t.text or '' for t in texts)


def walk_body(elem, out, depth=0):
    """递归遍历 body 子元素，保持文档顺序；sdt / 表格均覆盖。"""
    for child in elem:
        tag = child.tag
        if tag == W + 'p':
            txt = para_text(child)
            out.append(txt)
        elif tag == W + 'tbl':
            out.append('[TABLE]')
            for tr in child.findall(f'{W}tr'):
                cells = []
                for tc in tr.findall(f'{W}tc'):
                    cell_text = []
                    walk_body(tc, cell_text, depth + 1)
                    cells.append(' '.join(x.strip() for x in cell_text if x.strip()))
                out.append(' | '.join(cells))
            out.append('[/TABLE]')
        elif tag == W + 'sdt':
            for sdt_content in child:
                if sdt_content.tag == W + 'sdtContent':
                    walk_body(sdt_content, out, depth + 1)
        else:
            walk_body(child, out, depth + 1)


def extract_paras(paper: Path) -> list[str]:
    """从 docx 提取全部段落（含表格与 sdt，保持顺序）；失败抛异常。

    v2.15.0: 公共入口，preflight.py 与 CLI 共用（S8）。
    """
    with zipfile.ZipFile(paper, 'r') as z:
        names = z.namelist()
        if 'word/document.xml' not in names:
            raise ValueError('word/document.xml not found')
        if len(names) > MAX_ZIP_MEMBERS:
            raise ValueError(f'zip 成员数 {len(names)} 超过上限 {MAX_ZIP_MEMBERS}，疑似 zip 炸弹')
        info = z.getinfo('word/document.xml')
        if info.file_size > MAX_DOCXML_BYTES:
            raise ValueError(f'document.xml 解压大小 {info.file_size} 超过上限 {MAX_DOCXML_BYTES}')
        with z.open('word/document.xml') as fh:
            xml_content = fh.read()

    tree = ET.fromstring(xml_content)
    body = tree.find(f'{W}body')
    if body is None:
        raise ValueError('body not found')

    paras = []
    walk_body(body, paras)
    return paras


def main():
    if len(sys.argv) < 4:
        print('usage: extract_docx.py <paper.docx> <out_text.txt> <out_paras.json>', file=sys.stderr)
        sys.exit(1)
    paper = Path(sys.argv[1])
    out_text = Path(sys.argv[2])
    out_paras = Path(sys.argv[3])

    if not _XML_OK:
        print('WARN: defusedxml 未安装，XML 解析回退 xml.etree（不防实体攻击）。'
              '建议 pip install defusedxml', file=sys.stderr)

    try:
        paras = extract_paras(paper)
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': str(e)}, ensure_ascii=False))
        sys.exit(1)

    # 过滤空行（保留结构），写纯文本
    non_empty = [p for p in paras if p.strip()]
    out_text.write_text('\n'.join(non_empty), encoding='utf-8')

    # 写段落 JSON（含序号，供引用定位）
    para_list = [{'idx': i, 'text': p} for i, p in enumerate(paras)]
    out_paras.write_text(json.dumps(para_list, ensure_ascii=False, indent=1), encoding='utf-8')

    print(json.dumps({
        'paras_total': len(paras),
        'paras_non_empty': len(non_empty),
        'chars': sum(len(p) for p in non_empty),
        'text_file': str(out_text),
        'paras_file': str(out_paras),
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""提取 docx 参考文献表中的 DOI / PubMed 超链接锚点，输出 编号 → DOI 映射。

为什么需要它：
  不少期刊要求作者提交「统一格式版」文献表（多为文献管理软件导出），该版本的
  每条文献末尾带 [LinkOut] / [PubMed] 标记，标记上挂着超链接。这些链接就是
  **确定性的 DOI 锚点**：用它核验文献，比标题模糊检索快得多（实测 2.6 倍）也更准
  （避免了相似标题误配，且能定位标题检索找不到的记录）。

  反之，未统一格式的稿件往往完全没有链接，只能走标题检索——慢且存在漏检。

用法：
  python extract_doi_anchors.py <docx> [--out anchors.json] [--ref-start 1] [--ref-end 200]
  python extract_doi_anchors.py <docx> --merge refs.json --out refs_with_doi.json

输出 JSON：{"1": {"url": "...", "doi": "10.xxxx/yyy", "anchor_type": "doi"},
            "2": {"url": "https://pubmed.../31536886/", "doi": "10.1016/...", "anchor_type": "pubmed"}}

实现要点（踩过的坑，勿改）：
  1. `<w:hyperlink>` 元素在 **wordprocessingml** 命名空间，只有 `r:id` 属性在
     relationships 命名空间。用 `{...relationships}hyperlink` 查找会得到 0 个结果，
     且不报错——曾因此误判「文档里没有链接」。
  2. DOI 里可能含**圆括号**（ASCE：10.1061/(asce)hy.1943-7900.0001476），
     正则不能排除 `)`，否则 DOI 被截断。
  3. 少数链接是畸形的（前导 "%20"、指向 arXiv 页面而非 DOI），需从链接没能取到 DOI 时
     回退到**文献文本行内**找 `10.xxxx/...`。
  4. PubMed 链接只有 PMID，需经 NCBI eutils esummary 换成 DOI；idconv 接口时常返回
     非 JSON（HTML 错误页）导致 JSONDecodeError——用 esummary 并逐条 try。
  5. 只认「以编号开头 + 含链接」的段落，且限定在 References 之后，否则正文里的
     超链接会被误当作文献锚点。
"""
import argparse
import json
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
R_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"

DOI_RE = re.compile(r"10\.\d{4,9}/[^\s\]]+")


def clean_doi(s: str) -> str:
    """从链接或文本片段里抽出规范 DOI。保留 DOI 内的括号，剥掉尾随标点与标记。"""
    s = (s or "").strip().replace("%20", " ")
    s = re.sub(r"\[(LinkOut|PubMed|PP/OL|J|C)\]", "", s)
    m = DOI_RE.search(s)
    if not m:
        return ""
    d = m.group(0).strip()
    d = re.sub(r"\[.*$", "", d).strip()
    d = re.sub(r"[.,;]+$", "", d)
    return d.lower()


def read_paragraphs(docx_path):
    """返回 [(文本, [hyperlink rId, ...]), ...]。"""
    z = zipfile.ZipFile(docx_path)
    rels = {}
    rels_path = "word/_rels/document.xml.rels"
    if rels_path in z.namelist():
        for rel in ET.fromstring(z.read(rels_path)):
            rels[rel.get("Id")] = {
                "target": rel.get("Target"),
                "mode": rel.get("TargetMode") or "",
            }
    doc = ET.fromstring(z.read("word/document.xml"))
    paras = []
    for p in doc.find(W_NS + "body").iter(W_NS + "p"):
        text = "".join(t.text or "" for t in p.iter(W_NS + "t"))
        rids = [h.get(R_NS + "id") for h in p.iter(W_NS + "hyperlink")]  # 坑 1
        paras.append((text, rids, rels))
    return paras


def pubmed_to_doi(pmids, mailto="panda-ms-check@example.org"):
    """PMID → DOI（NCBI eutils esummary）。失败返回空 dict，不抛异常。"""
    out = {}
    if not pmids:
        return out
    try:
        import requests
    except ImportError:
        return out
    for pm in sorted(set(pmids)):
        try:
            r = requests.get(
                "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
                params={"db": "pubmed", "id": pm, "retmode": "json",
                        "tool": "panda-ms-check", "email": mailto},
                timeout=25)
            rec = r.json().get("result", {}).get(pm, {})
            for a in rec.get("articleids", []):
                if a.get("idtype") == "doi" and a.get("value"):
                    out[pm] = clean_doi(a["value"])
                    break
        except Exception:
            continue
    return out


def extract(docx_path, ref_start=1, ref_end=200, resolve_pubmed=True, mailto=""):
    paras = read_paragraphs(docx_path)
    # 坑 5：定位 References 之后
    start = 0
    for i, (text, _rids, _r) in enumerate(paras):
        if re.search(r"references\s*$", text.strip(), re.I):
            start = i + 1
            break

    anchors = {}
    pmid_of = {}
    for text, rids, rels in paras[start:]:
        m = re.match(r"^\s*(\d{1,3})\s*\.", text)
        if not m or not rids:
            continue
        n = int(m.group(1))
        if not (ref_start <= n <= ref_end) or n in anchors:
            continue
        urls = [rels.get(r, {}).get("target", "") for r in rids]
        rec = {"url": urls[0] if urls else "", "doi": "", "anchor_type": ""}
        for u in urls:
            d = clean_doi(u)
            if d:
                rec["doi"], rec["anchor_type"] = d, "doi"
                break
            pm = re.search(r"pubmed\.ncbi\.nlm\.nih\.gov/(\d+)", u or "")
            if pm:
                rec["anchor_type"] = "pubmed"
                pmid_of[n] = pm.group(1)
        # 兜底：链接没给 DOI（畸形链接 / arXiv 页面）→ 文本行内找
        if not rec["doi"]:
            d = clean_doi(text)
            if d:
                rec["doi"], rec["anchor_type"] = d, rec["anchor_type"] or "text"
        anchors[n] = rec

    if resolve_pubmed and pmid_of:
        pm_doi = pubmed_to_doi(list(pmid_of.values()), mailto or "panda-ms-check@example.org")
        for n, pm in pmid_of.items():
            if not anchors[n]["doi"] and pm_doi.get(pm):
                anchors[n]["doi"] = pm_doi[pm]
    return anchors


def main():
    ap = argparse.ArgumentParser(description="提取 docx 参考文献表的 DOI/PubMed 锚点")
    ap.add_argument("docx", help="统一格式版稿件（.docx）")
    ap.add_argument("--out", default="", help="输出 JSON 路径（默认 stdout）")
    ap.add_argument("--ref-start", type=int, default=1)
    ap.add_argument("--ref-end", type=int, default=200)
    ap.add_argument("--no-pubmed", action="store_true", help="不做 PMID→DOI 解析（离线）")
    ap.add_argument("--mailto", default="", help="NCBI 礼貌池邮箱")
    ap.add_argument("--merge", default="", help="把 DOI 合并进已有 refs.json 并输出")
    args = ap.parse_args()

    anchors = extract(args.docx, args.ref_start, args.ref_end,
                      resolve_pubmed=not args.no_pubmed, mailto=args.mailto)

    n_doi = sum(1 for v in anchors.values() if v["doi"])
    n_pm = sum(1 for v in anchors.values() if v["anchor_type"] == "pubmed")
    summary = {
        "anchors_total": len(anchors),
        "with_doi": n_doi,
        "with_pubmed": n_pm,
        "anchors": {str(k): v for k, v in sorted(anchors.items())},
    }

    if args.merge and os.path.exists(args.merge):
        refs = json.load(open(args.merge, encoding="utf-8"))
        filled = 0
        for r in refs:
            n = str(r.get("index"))
            if not r.get("doi") and anchors.get(int(n), {}).get("doi"):
                r["doi"] = anchors[int(n)]["doi"]
                r["doi_source"] = "docx_anchor"
                filled += 1
        dest = args.out or args.merge
        json.dump(refs, open(dest, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"MERGE OK: {filled}/{len(refs)} 条补入 DOI -> {dest}")
        return

    text = json.dumps(summary, ensure_ascii=False, indent=1)
    if args.out:
        open(args.out, "w", encoding="utf-8").write(text)
        print(f"OK: {len(anchors)} 个锚点（带 DOI {n_doi}，PubMed {n_pm}）-> {args.out}")
    else:
        print(text)


if __name__ == "__main__":
    main()

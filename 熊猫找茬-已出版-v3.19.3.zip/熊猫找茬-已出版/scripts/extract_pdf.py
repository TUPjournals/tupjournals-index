#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""extract_pdf.py — 分栏感知的 PDF 文本提取（阅读顺序还原）

Usage:
    python extract_pdf.py <paper.pdf> <out_text.txt> <out_paras.json>

输出（与 extract_docx.py 对齐，供 preflight / geo_check / affiliation_check /
citation_stats / aigc_stats / 参考文献解析共用）：
  - out_text.txt   ：阅读顺序全文（满宽 F → 左栏 L → 右栏 R，逐页），供引用统计与 AIGC
  - out_paras.json ：段落列表 [{page, col, text}]，col ∈ {F, L, R}
  - body.txt       ：out_paras.json 同目录下的「References 之前」正文，供 AIGC 统计
                     （aigc_stats.py 自身也会排除参考文献节，此文件仅为便捷输入）

stdout 输出一行机器可读 JSON：{"status","pages","paras","body_paras","gutter_pages"}。

v3.15.0 首次固化（CS20260009 双栏 PDF 实测），解决两个静默错误：
  1. **双栏拼行**：pdfplumber 的 extract_words 按 x 排序后，左右栏文字会被并进同一
     行，导致「引用标记的宿主句」被错栏内容污染。本脚本先按行统计「中部大空档」，
     取其中位中心作为 gutter，再据此把每行切成 L / R，最后按 F→L→R 顺序拼接。
  2. **跨栏吞字（CRITICAL）**：把上/下标并回前一个词时，若只按「字号小」判断，会把
     低栏字号（参考文献 8.5pt vs 正文 10pt）在**同基线附近**的词跨栏并入正文，产生
     `andtechnology` / `intreatmentprocesses(inChinese)` 之类粘连，并破坏 gutter 切分。
     规避：合并必须同时满足「小字号 + 垂直偏移 ≥ 0.8pt + 与前词水平间隙 ≤ 3pt」。
"""
import json
import sys
from pathlib import Path

MIN_GAP = 6.0            # 认定为栏间空档的最小水平间隙（pt）
LINE_TOL = 4.0           # 同一行判定：top 差值容差（pt）
SUB_SIZE_RATIO = 0.86    # 上/下标字号上限：小于正文中位字号 × 0.86
SUB_OFFSET_PT = 0.8      # 上/下标垂直偏移下限（pt）
SUB_GAP_PT = 3.0         # 上/下标与前词的水平间隙上限（pt）——跨栏保护的关键阈值


def log(msg):
    print(msg, file=sys.stderr)


def cluster_lines(words, tol=LINE_TOL):
    """按 top 聚成行（近邻聚合，容差 tol），行内按 x0 排序。"""
    lines = []
    for w in sorted(words, key=lambda w: (w['top'], w['x0'])):
        for ln in lines:
            if abs(ln['top'] - w['top']) <= tol:
                ln['words'].append(w)
                break
        else:
            lines.append({'top': w['top'], 'words': [w]})
    for ln in lines:
        ln['words'].sort(key=lambda w: w['x0'])
    lines.sort(key=lambda ln: ln['top'])
    return lines


def merge_scripts(words):
    """仅把真正的上/下标并入前一个词：小字号 + 垂直偏移 ≥ 0.8pt + 与前词间隙 ≤ 3pt。

    注意：低栏字号（参考文献 8.5pt vs 正文 10pt）在同基线附近时**不得**合并，
    否则会跨栏吞字（间隙可达十几 pt）、破坏分栏切分（CS20260009 实测事故）。
    """
    if not words:
        return words
    sizes = sorted((w.get('size') or 0) for w in words)
    med = sizes[len(sizes) // 2] or 10
    out = []
    for w in words:
        if out:
            prev = out[-1]
            off = abs(w['top'] - prev['top'])
            near = (w['x0'] - prev['x1']) <= SUB_GAP_PT
            if (w.get('size') or med) < med * SUB_SIZE_RATIO and off >= SUB_OFFSET_PT and near:
                prev['text'] += w['text']
                prev['x1'] = w['x1']
                continue
        out.append({'text': w['text'], 'x0': w['x0'], 'x1': w['x1'], 'top': w['top']})
    return out


def detect_gutter(lines, width):
    """按行统计「中部大空档」的候选中心，取中位数作为 gutter；单栏页返回 None。"""
    cands = []
    for ln in lines:
        ws = ln['words']
        for a, b in zip(ws, ws[1:]):
            g = b['x0'] - a['x1']
            c = (a['x1'] + b['x0']) / 2
            if g >= MIN_GAP and 0.28 * width <= c <= 0.72 * width:
                cands.append(c)
                break
    # 候选行数不足（不足 5 行且不足总行数 30%）→ 视为单栏
    if len(cands) < max(5, 0.3 * len(lines)):
        return None
    cands.sort()
    return cands[len(cands) // 2]


def split_line(words, width, gut):
    """把一行切成 [(col, text)]，col ∈ {F, L, R}。"""
    ws = merge_scripts(words)
    if not ws:
        return []
    if gut is None:
        return [('L', ' '.join(w['text'] for w in ws))]
    # 优先找真正跨越 gutter 的断口（左右栏之间的空档）
    for a, b in zip(ws, ws[1:]):
        if a['x1'] <= gut <= b['x0'] and (b['x0'] - a['x1']) >= MIN_GAP:
            lt = ' '.join(w['text'] for w in ws if w['x1'] <= a['x1'] + 0.1)
            rt = ' '.join(w['text'] for w in ws if w['x1'] > a['x1'] + 0.1)
            res = []
            if lt.strip():
                res.append(('L', lt.strip()))
            if rt.strip():
                res.append(('R', rt.strip()))
            return res
    # 满宽行（跨过 gutter 但词间无明显断裂：标题、摘要、表格等）
    if ws[0]['x0'] < gut - 8 and ws[-1]['x1'] > gut + 8:
        return [('F', ' '.join(w['text'] for w in ws))]
    side = 'L' if (ws[0]['x0'] + ws[-1]['x1']) / 2 < width / 2 else 'R'
    return [(side, ' '.join(w['text'] for w in ws))]


def extract(pdf_path):
    """返回 (paras, gutter_pages)。paras = [{page, col, text}]。"""
    try:
        import pdfplumber
    except ImportError:
        log('缺少 pdfplumber：请在 venv 内 pip install pdfplumber，或改用 docx/txt 输入')
        raise SystemExit(1)

    paras, gutter_pages = [], 0
    with pdfplumber.open(pdf_path) as pdf:
        for pi, page in enumerate(pdf.pages, 1):
            width = page.width
            words = page.extract_words(extra_attrs=['size'])
            if not words:
                log(f'page {pi}: 无文本（扫描版？需 OCR 后重跑）')
                continue
            lines = cluster_lines(words)
            gut = detect_gutter(lines, width)
            if gut is not None:
                gutter_pages += 1
            streams = {'F': [], 'L': [], 'R': []}
            for ln in lines:
                for side, text in split_line(ln['words'], width, gut):
                    if text.strip():
                        streams[side].append(text.strip())
            # 阅读顺序：满宽（跨栏标题/摘要/表格）→ 左栏 → 右栏
            for side in ('F', 'L', 'R'):
                for text in streams[side]:
                    paras.append({'page': pi, 'col': side, 'text': text})
            log(f'page {pi} W={width:.0f} gutter={None if gut is None else round(gut, 1)} '
                f'F={len(streams["F"])} L={len(streams["L"])} R={len(streams["R"])}')
    return paras, gutter_pages


def main():
    if len(sys.argv) < 4:
        print(__doc__.strip().splitlines()[4].strip(), file=sys.stderr)
        print('用法：python extract_pdf.py <paper.pdf> <out_text.txt> <out_paras.json>',
              file=sys.stderr)
        return 2
    src, out_text, out_paras = sys.argv[1], sys.argv[2], sys.argv[3]
    if not Path(src).exists():
        log(f'输入不存在：{src}')
        return 1

    paras, gutter_pages = extract(src)
    Path(out_text).write_text('\n'.join(p['text'] for p in paras), encoding='utf-8')
    Path(out_paras).write_text(json.dumps(paras, ensure_ascii=False, indent=1), encoding='utf-8')

    # body.txt：References 之前的正文（便捷输入，供 aigc_stats 等）
    body, seen_ref = [], False
    for p in paras:
        t = p['text'].strip()
        if len(t) < 20 and t.lower().startswith('references'):
            seen_ref = True
        if not seen_ref:
            body.append(t)
    Path(Path(out_paras).parent / 'body.txt').write_text('\n'.join(body), encoding='utf-8')

    print(json.dumps({'status': 'ok', 'pages': paras[-1]['page'] if paras else 0,
                      'paras': len(paras), 'body_paras': len(body),
                      'gutter_pages': gutter_pages}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

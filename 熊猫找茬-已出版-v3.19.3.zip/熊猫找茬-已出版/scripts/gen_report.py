#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_report.py — 熊猫找茬-已出版 报告固定渲染脚本（零第三方依赖）。

读取 work 目录检测 JSON + report_content.json（agent 判定内容）+ 模板 → HTML。
用法：
  python scripts/gen_report.py --work <work目录> --content <report_content.json> \
      [--out <输出目录>] [--msid <稿件标识>] [--date YYMMDD]
stdout 输出一行机器可读 JSON：{"status":"ok|warn|error","out_file","size","leftover"}。
退出码：0 成功；2 有残留占位符（文件仍写出）；1 致命错误。
"""
import argparse
import html
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from common_stats import compute_year_stats
import journal_scopes

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_DIR / 'assets' / 'report_template.html'
TOOL_NAME = '熊猫找茬-已出版 v3.19.3'
RW_META = SKILL_DIR / 'data' / 'retraction_watch_meta.json'

YEAR_BINS = [
    ('<=2000', None, 2000), ('2001-2005', 2001, 2005), ('2006-2010', 2006, 2010),
    ('2011-2015', 2011, 2015), ('2016-2020', 2016, 2020), ('2021-2025', 2021, 2025),
    ('>=2026', 2026, None),
]

# (aigc 键, 指标名, 数值格式化, 参考区间)
AIGC_ROWS = [
    ('word_count', '正文字数', lambda v: f'{v:,}', '—'),
    ('sentence_count', '句子数', lambda v: f'{v:,}', '—'),
    ('avg_sentence_len', '平均句长', lambda v: f'{v:.2f} 词', '15-25'),
    ('sentence_len_cv', '句长变异系数', lambda v: f'{v:.3f}', '越低越趋同（AI 特征）'),
    ('ttr', '类符/形符比 TTR', lambda v: f'{v:.3f}', '0.3-0.5'),
    ('ai_phrase_density_per_1000', 'AI 提示语密度', lambda v: f'{v} / 千词', '>2 可疑，>5 高度可疑'),
    ('first_person_count', '首人称次数', lambda v: f'{v}', '人类论文通常存在'),
    ('near_duplicate_pairs', '近重复句对数', lambda v: f'{v}', '—'),
]


def log(msg):
    print(msg, file=sys.stderr)


def load_json(path):
    """容错读取：跳过前导非 JSON 行（定位第一个 { 或 [ 再 loads）；文件缺失返回 None。"""
    if not path or not Path(path).exists():
        return None
    raw = Path(path).read_text(encoding='utf-8', errors='replace')
    i1 = raw.find('{')
    i2 = raw.find('[')
    candidates = [i for i in (i1, i2) if i >= 0]
    if not candidates:
        raise ValueError(f'no JSON object in {path}')
    return json.loads(raw[min(candidates):])


def esc(v):
    """HTML 转义（v3.19.0 F-01）：所有动态文本注入前必须经过本函数。

    与「新稿」v2.15.0 同源。已出版版历史 content 里有 agent 预写的 HTML 实体
    （如 "Aims &amp; Scope" 期望显示为 "Aims & Scope"），直接 html.escape 会
    二次转义成 "&amp;amp;"，故纯文本路径统一走 esc_keep_entities()。
    """
    return html.escape(str(v if v is not None else ''), quote=True)


# 常见 HTML 实体（含中文排版常用破折号/空格）；转义前先占位、转义后还原。
_PRE_ENTITIES = (
    '&amp;', '&lt;', '&gt;', '&quot;', '&#39;',
    '&nbsp;', '&ndash;', '&mdash;', '&hellip;', '&times;',
)


def esc_keep_entities(v):
    """实体幂等转义：已存在的 HTML 实体不被二次转义，其余字符正常转义。

    用于「纯文本」字段。历史 20 份 report_content.json 中实测 43 处预写实体，
    不加保护会在报告中显示为 `&amp;`。
    """
    s = str(v if v is not None else '')
    holders = {}
    for i, ent in enumerate(_PRE_ENTITIES):
        if ent in s:
            token = f'\x00ENT{i}\x00'
            holders[token] = ent
            s = s.replace(ent, token)
    s = html.escape(s, quote=True)
    for token, ent in holders.items():
        s = s.replace(html.escape(token, quote=True), ent)
    return s


# ── rich()：agent 手写 HTML 的安全放行 ──
# v3.19.0 关键决策（路线 B）：已出版版 agent 仍手写 <table>/<div>/<h3> 全套 HTML
# （与新稿不同——新稿已把 scope/affiliation 结构化改造为 JSON、由脚本渲染表格）。
# 若照搬新稿的 7 标签最小白名单，实测 20 份历史 content 中 73-83% 的富文本字段
# 表格会被转义成可见的 &lt;table&gt; 而崩版。故扩大到下列白名单：
# 实测 178/178 富文本字段逐字保真，XSS 负向测试全过。
# 安全边界：只放行无属性标签 + class 白名单；style/on* /script/style 一律不放行。
_RICH_TAGS = (
    'p', 'b', 'strong', 'em', 'i', 'br', 'ul', 'ol', 'li',
    'table', 'thead', 'tbody', 'tr', 'th', 'td',
    'div', 'span', 'h2', 'h3', 'blockquote', 'code',
)
# 长标签优先，避免 `b` 误匹配 `blockquote`/`br` 前缀
_RICH_TAGS_ORDERED = tuple(sorted(_RICH_TAGS, key=len, reverse=True))
_RICH_CLASSES = (
    'badge', 'ok', 'warn', 'bad', 'info', 'note', 'mono',
    'okc', 'warnc', 'finding', 'blk',
)


def rich(v):
    """转义全部 HTML 后，仅放行 _RICH_TAGS 中的无属性格式标签与 class 白名单。

    用于 agent 手写的 HTML 片段字段（affiliation_results / refs_citation_issues /
    semantic_refs / analysis 等）。结构壳（脚本自产）不得经本函数。

    ⚠️ 关闭标签不无条件放行——先处理开标签，再只放行「已成功放行的同名开标签」
    的关闭标签。否则 `<p style="...">x</p>` 会出现「开标签被拦、关闭标签被放行」
    的不配对残留。

    实体幂等：转义走 esc_keep_entities()，避免历史 content 中已写的 `&amp;`
    （期望显示为 `&`）被二次转义成 `&amp;amp;`。
    """
    out = esc_keep_entities(str(v if v is not None else ''))
    # class 值 = 1..n 个「白名单词」以空白分隔；逐词校验，混入非白名单词即整体不放行
    # （防 `class="ok evil"` 借首个白名单词蒙混过关）
    _cls_one = r'(?:%s)' % '|'.join(_RICH_CLASSES)
    _cls_seq = r'%s(?:\s+%s)*' % (_cls_one, _cls_one)
    for t in _RICH_TAGS_ORDERED:
        pat = re.compile(
            r'&lt;%s(?![a-z])((?:\s+class=&quot;(?:%s)&quot;)?)\s*/?&gt;'
            % (t, _cls_seq)
        )
        out = pat.sub(lambda m, _t=t: f'<{_t}{m.group(1).replace("&quot;", chr(34))}>', out)
    # 关闭标签：仅当该标签存在「已放行的开标签」时才放行
    for t in _RICH_TAGS_ORDERED:
        if f'<{t}' in out:
            out = re.sub(r'&lt;/%s(?![a-z])&gt;' % t, f'</{t}>', out)
    return out


def badge(cls, verdict):
    """徽章渲染：verdict 转义；cls 走白名单（白名单外降级为 info，防 class 注入）。"""
    safe_cls = cls if cls in ('ok', 'warn', 'bad', 'info') else 'info'
    return f'<span class="badge {safe_cls}">{esc(verdict)}</span>'


# ── 第 1 节摘要表：④⑤ 两行（v3.19.3 维度编号重排，维度号 = 正文节序 - 1） ──
# 正文节序：§2 内容相关性(①) → §3 作者诚信(②) → §4 参考文献(③)
#          → §5 语义相关性(④) → §6 声明完整性(⑤) → §7 AIGC(⑥)
# 摘要表行序 = 维度编号 = 正文节序，三者一致
# （v3.19.1 的 ④=AIGC / ⑥=语义相关性 已废弃，勿改回）。
# 数据源：summary.ext（现行 label 写法：'④ 参考文献语义相关性' / '⑤ 声明完整性'）
# 兼容：v3.19.2 及更早的 report_content.json 写 '⑥ 参考文献语义相关性'，故第 4 元
#       legacy_marks 保留旧圈号 —— 按「名称 + 新旧圈号」三重匹配，历史稿无需改写。
_EXT_SLOTS = (
    ('summary_semantic', '④', '参考文献语义相关性', ('⑥',)),
    ('summary_declaration', '⑤', '声明完整性', ()),
)


def build_summary_ext_map(ext):
    """把 summary.ext 映射为 {占位符key: (badge_html, text_html)}。

    认行顺序：先按 label 中的**名称**（「参考文献语义相关性」/「声明完整性」）匹配，
    再退回圈号（现行 ④/⑤，兼容 v3.19.2 前的 ⑥）——故历史 content 无需改写即可
    正确认行，且不依赖数组顺序。

    缺失该行时返回 .info「未检测」占位（不抛错，不阻塞出报告）。
    """
    found = {}
    for item in (ext or []):
        if not isinstance(item, dict):
            continue
        label = str(item.get('label', ''))
        for slot in _EXT_SLOTS:
            key, mark, name = slot[0], slot[1], slot[2]
            legacy = slot[3] if len(slot) > 3 else ()
            if name in label or mark in label or any(m in label for m in legacy):
                found[key] = (
                    badge(item.get('badge', 'info'), item.get('verdict', '未检测')),
                    rich(item.get('text', '')) if item.get('text') else '未检测（子项未提供）',
                )
    out = {}
    for slot in _EXT_SLOTS:
        key = slot[0]
        if key in found:
            out[key] = found[key]
        else:
            out[key] = (badge('info', '未检测'), '未检测（子项未提供）')
    return out


def require(content, *paths):
    for p in paths:
        node = content
        for k in p.split('.'):
            if not isinstance(node, dict) or k not in node:
                raise ValueError(f'report_content.json 缺少必填字段: {p}')
            node = node[k]


# ── 第 2 节 内容相关性（v3.19.0 移植自「新稿」v2.9.0 口径） ──

def load_journal_info(meta):
    """从 meta.journal 提取缩写查期刊记录（用户文件 ∪ 内置模板，用户优先）。

    兼容已出版版历史 content 的实际写法（v3.19.0 修复，实测 22 份历史稿）：
      - 半角括号 `Energy Materials and Devices (EMD)` → 缩写 EMD
      - **全角括号** `Energy and Climate Management（ECM）` → 缩写 ECM
        （初版只认半角 `\\(...\\)`，实测 14/22 份稿使用全角括号 → 缩写提取失败）
      - 无括号全名 `Ocean` / 全角长串 `Ocean（ISSN 3008-1203）` → 走全名双向包含兜底
    返回期刊 dict；未收录或解析失败返回 None。
    """
    journal = str((meta or {}).get('journal', '')).strip()
    # 缩写：行尾括号（半角或全角均接受）
    m = re.search(r'[（(]([^()（）]+)[)）]\s*$', journal)
    abbrev = (m.group(1).strip().upper() if m else '')
    # 全名候选：剥离全部括号及其内容，去空白，用于双向包含比对
    base = re.sub(r'[（(][^()（）]*[)）]', ' ', journal)
    base = re.sub(r'\s+', ' ', base).strip().lower()
    for j in journal_scopes.load_all():
        if abbrev and str(j.get('abbreviation', '')).upper() == abbrev:
            return j
        full = str(j.get('full_name', '')).strip().lower()
        if not full:
            continue
        if base and (base == full or base in full or full in base):
            return j
    return None


def build_scope_header(jinfo):
    """第 2 节起始固定块（纯文本段落）：来源 + 版本日期 + 概括性中文收稿范围。

    agent 无需手写。期刊未收录时降级提示，引导人工核对官网 Aims & Scope。
    """
    if not jinfo:
        return ('<p class="note"><b>未收录期刊收稿范围信息</b>：本期刊尚未录入本地数据文件'
                '（assets/journal_scopes.json），请人工核对期刊官网 Aims &amp; Scope。</p>')
    src = jinfo.get('scope_source') or jinfo.get('scope_url', '')
    # F-01: URL 仅作文本显示；非 https 来源隐藏细节（防注入 + 合规）
    if isinstance(src, str) and src.startswith('http'):
        try:
            if urlparse(src).scheme != 'https':
                src = '(非 https 来源，已隐藏)'
        except ValueError:
            src = '(URL 解析失败，已隐藏)'
    ver = jinfo.get('scope_version_date', '未知')
    summ = jinfo.get('scope_summary_zh', '（未收录中文概括）')
    return (f'<p><b>期刊收稿范围对照依据：</b>来源：'
            f'<span class="mono" style="background:transparent;padding:0">{esc(src)}</span>'
            f'（版本日期：{esc(ver)}）。收稿范围：{esc(summ)}</p>')


def build_scope_analysis_table(rows):
    """第 2 节内容相关性 4 列表格：分析维度 / 稿件特征 / 对应期刊领域 / 匹配度（徽章）。"""
    rows = rows or []
    if not rows:
        return f'<p>{badge("info", "未检测")} 内容相关性分析未执行（scope_analysis 数据缺失）。</p>'
    body = ''.join(
        f'<tr><td>{esc(r.get("dimension", ""))}</td><td>{esc(r.get("paper_feature", ""))}</td>'
        f'<td>{esc(r.get("journal_area", ""))}</td>'
        f'<td>{badge(m.get("badge", "info"), m.get("verdict") or m.get("text") or "未判定")}</td></tr>'
        for r in rows for m in [r.get("match") or {}])
    return ('<table>\n<tr><th>分析维度</th><th>稿件特征</th><th>对应期刊领域</th><th>匹配度</th></tr>\n'
            + body + '\n</table>')


# ── 自动生成段 ──

def build_political_risk(geo):
    if not geo or geo.get('status') != 'found' or not geo.get('hits'):
        return ''
    rows = ''.join(
        f'<tr><td>{esc(h.get("keyword", ""))}</td><td>{esc(h.get("sentence", ""))}</td>'
        f'<td>{esc(h.get("section", ""))}</td></tr>'
        for h in geo['hits'])
    return ('<p style="color:#d23b3b;font-size:13px"><b>0 政治风险：潜在政治风险，请人工核查。</b></p>'
            + '<table><tr><th>关键词</th><th>完整句子</th><th>所属一级标题</th></tr>'
            + rows + '</table>')


def build_year_stats_table(refs, note=''):
    years, unknown = [], 0
    for r in refs or []:
        y = (r.get('year') or '').strip()
        if not y:
            unknown += 1
            continue
        try:
            years.append(int(re.sub(r'[^\d]', '', str(y)[:4])))
        except ValueError:
            unknown += 1
    total = len(years) + unknown
    rows = []
    for label, lo, hi in YEAR_BINS:
        if lo is None and hi is not None:
            c = sum(1 for y in years if y <= hi)
        elif hi is None and lo is not None:
            c = sum(1 for y in years if y >= lo)
        else:
            c = sum(1 for y in years if lo <= y <= hi)
        # 零计数分桶同样列出（v3.15.0）：与 crossref_check.py year-stats 的输出保持
        # 一致，并使「两端区间已纳入统计」在报告中可自证（此前 `if c:` 过滤会隐藏
        # ≤2000 / ≥2026 两行，导致同一份数据两个脚本给出不同表格）。
        pct = round(c / total * 100, 1) if total else 0
        lab = label.replace('>=', '≥').replace('<=', '≤')
        rows.append(f'<tr><td>{lab}</td><td>{c}</td><td>{pct}%</td></tr>')
    if unknown:
        rows.append(f'<tr><td>Unknown</td><td>{unknown}</td><td>{round(unknown / total * 100, 1)}%</td></tr>')
    rows.append(f'<tr><td>合计</td><td>{total}</td><td>100%</td></tr>')
    body = ('<table>\n<tr><th>年份区间</th><th>数量</th><th>占比</th></tr>\n'
            + '\n'.join(rows) + '\n</table>')
    # year_stats_note 为 agent 手写，历史数据含 `<p class="note">` 等 HTML → 走 rich()
    return body + (rich(note) if note else '')


def build_author_list(authors):
    names = [esc(a['name']) for a in (authors or {}).get('authors', []) if a.get('name')]
    return ', '.join(names) if names else '（未检测）'


def build_author_results(authors, domain='本稿', verdicts=None, note_override=''):
    """作者撤稿检索表。

    默认文案（v3.9.1 起「基本判定为同名误报」）**仅对应 SKILL.md 三档分类的档 2
    （有命中但机构/学科与本稿不同）**。档 3（有命中且机构或学科与本稿相同或相近）
    绝不能用默认文案——那会把「需重点核实」渲染成「已排除风险」，属最危险的假阴性。
    v3.18.0：新增 `verdicts` 与 `note_override` 覆盖（agent 判定档 3、或默认示例学科
    与实际命中学科不符时，写入 report_content.json 的 `author_verdicts` / `author_note`，
    机制同 crossref 的 review_note）。ECM20260039 实测：命中学科含 (B/T) Business - Economics
    等与本稿经济金融领域相邻的类别，默认文案「领域均非…相关（如 …）」自相矛盾。
    """
    if not authors or not authors.get('authors'):
        return f'<p>{badge("info", "未检测")} 作者撤稿检索未执行（数据缺失）。</p>'
    vd = verdicts or {}
    rows = []
    any_hits = False
    for a in authors['authors']:
        hits = a.get('hits') or []
        raw_name = a.get('name', '')
        name = esc(raw_name)
        if not hits:
            rows.append(f'<tr><td><b>{name}</b></td><td>0</td><td>{badge("ok", "无")}</td><td>无撤稿记录</td></tr>')
            continue
        any_hits = True
        ov = vd.get(raw_name) or {}
        if ov:
            b = ov.get('badge', 'warn')
            concl = ov.get('conclusion', '同名命中')
            note = rich(ov.get('note', ''))
            rows.append(f'<tr><td><b>{name}</b></td><td>{len(hits)}</td>'
                        f'<td>{badge(b, concl)}</td><td>{note}</td></tr>')
            continue
        subs = '；'.join(sorted({(h.get('subject') or 'N/A').split(';')[0] for h in hits})[:3])
        rows.append(
            f'<tr><td><b>{name}</b></td><td>{len(hits)}</td><td>{badge("warn", "同名命中")}</td>'
            # 措辞须与 SKILL.md 三档分类档2 规则一致（v3.9.1 同步新稿 v2.17.1 修复文档/代码漂移）
            f'<td>命中 {len(hits)} 条，领域均非{esc(domain)}相关（如 {esc(subs)}），'
            f'基本判定为同名误报；建议人工留意</td></tr>')
    body = ('<table>\n<tr><th>作者</th><th>命中数</th><th>结论</th><th>说明</th></tr>\n'
            + '\n'.join(rows) + '\n</table>')
    # 表下说明按命中情况分支（v3.16.1 修复）：原先无条件输出「同名命中均为跨领域论文…
    # 基本判定为同名误报」，在**零命中**时会与表格自相矛盾（OCE20260027 实测：表格 0 条
    # 命中，说明却称存在同名命中），属语义错误而非措辞问题。
    # v3.18.0：`note_override` 优先——默认文案在「命中学科与稿件领域相邻」时会失真。
    # v3.19.0：note_override 为 agent 手写（可含 HTML 标签）→ 走 rich()；其余为脚本自产结构。
    if note_override:
        return body + f'<p class="note">{rich(note_override)}</p>'
    if any_hits:
        note = (f'<p class="note">说明：撤稿检索基于 Retraction Watch 撤稿数据库，采用精确 token 匹配（姓+名首字母）。'
                f'同名命中均为跨领域论文，与本稿领域（{esc(domain)}）不相关，基本判定为同名误报。最终判断需编辑人工核对。</p>')
    else:
        note = ('<p class="note">说明：撤稿检索基于 Retraction Watch 撤稿数据库，采用精确 token 匹配'
                '（姓+名首字母，兼容「First Last」与「Last, First」两种姓名顺序）。'
                '本次受检作者<b>均未命中</b>，无撤稿记录。最终判断需编辑人工核对。</p>')
    return body + note


def build_refs_rw_check(refs_rw, total, verdicts=None, note=''):
    d = refs_rw or {}
    # 未执行判定（v3.15.0）：用户指定跳过该维度时 refs_rw.json 不生成，此时若沿用
    # 零命中分支会输出「0 篇撤稿」这一**未执行却看似已核验**的结论残留
    # （v3.12.0 跳过流程的隐患）。以 total_references 键是否存在作为「已执行」判据。
    if 'total_references' not in d:
        return (f'<p>{badge("info", "未检测")} 撤稿检索未执行（refs_rw.json 缺失或未生成）。</p>'
                ) + (rich(note) if note else '')
    matches = d.get('matches') or []
    if not matches:
        # 零命中时同样拼接 note（CESCI-D-26-00015 实测要求）；措辞取 SKILL.md Step 3.3
        # 标准表述「0 篇参考文献存在撤稿记录」，不加「真实」等限定词以免过度承诺。
        return (f'<p>基于 Retraction Watch 对 {total} 篇参考文献进行 DOI 锚定与标题模糊匹配：'
                f'<b>0 篇存在撤稿记录</b>。</p>') + (rich(note) if note else '')
    vd = verdicts or {}
    rows = []
    for h in matches:
        verdict = vd.get(str(h.get('ref_index')), '待人工复核')
        cls = 'ok' if '误报' in verdict else 'warn'
        rows.append(
            f'<tr><td>[{esc(h.get("ref_index"))}]</td>'
            f'<td>{esc(str(h.get("ref_title", ""))[:60])}</td>'
            f'<td>{esc(str(h.get("matched_title", ""))[:60])}'
            f'<br><span style="color:#888;font-size:12px">'
            f'{esc(h.get("retraction_date", ""))} | {esc(str(h.get("reason", ""))[:40])}</span></td>'
            f'<td>{badge(cls, verdict)}</td></tr>')
    return ('<p>基于 Retraction Watch：<b>{} 条匹配命中，经甄别均需人工确认/误报</b>。</p>'
            + '<table><tr><th>#</th><th>稿件引用</th><th>撤稿库条目</th><th>判定</th></tr>\n'
            + '\n'.join(rows) + '\n</table>'
            + (rich(note) if note else '')).format(len(matches))


def auto_judge(key, val):
    if key in ('word_count', 'sentence_count'):
        return '—'
    if key == 'avg_sentence_len':
        return '正常' if 15 <= val <= 25 else '偏长/偏短（建议复核）'
    if key == 'sentence_len_cv':
        # 判级方向 v2.15.0 已修正：CV 低 = 句长趋同 = AI 特征；CV 高 = 参差 = 人类特征。
        # 此处不再内置数值阈值（原「>0.7 异常均匀」方向相反，与 AIGC_ROWS 参考区间
        # 自相矛盾）；建议由 report_content.aigc_judgments 给出结合全文的定性判断。
        return '越低越趋同（AI 特征），需结合其他指标判读'
    if key == 'ttr':
        return '正常' if 0.3 <= val <= 0.5 else '偏离常规区间（建议复核）'
    if key == 'ai_phrase_density_per_1000':
        if val <= 2:
            return badge('ok', '正常')
        if val <= 5:
            return badge('warn', '轻度可疑')
        return badge('bad', '高度可疑')
    if key == 'first_person_count':
        return badge('warn', '缺失（附加信号）') if val == 0 else '正常'
    if key == 'near_duplicate_pairs':
        return badge('warn', '存在近重复句') if val else '正常'
    return '—'


def build_aigc_table(aigc, judgments=None):
    if not aigc:
        return f'<p>{badge("info", "未检测")} AIGC 定量指标数据缺失（aigc.json 未生成），本维度未检测。</p>'
    jd = judgments or {}
    rows = []
    for key, label, fmt, ref_range in AIGC_ROWS:
        val = aigc.get(key)
        if val is None:
            continue
        # judge 来源混合：aigc_judgments[agent 手写，可含 HTML] 或 auto_judge[部分分支
        # 返回 badge HTML、部分返回纯文本] → 一律走 rich()（纯文本被转义，badge 标签
        # 经白名单放行）。直接 esc() 会把 badge 一起转义，表格里露出 `&lt;span`。
        judge = rich(jd.get(key) or auto_judge(key, val))
        rows.append(f'<tr><td>{esc(label)}</td><td>{fmt(val)}</td>'
                    f'<td>{esc(ref_range)}</td><td>{judge}</td></tr>')
    return ('<table>\n<tr><th>指标</th><th>数值</th><th>参考区间</th><th>判断</th></tr>\n'
            + '\n'.join(rows) + '\n</table>')


def build_aigc_phrase_list(aigc):
    phrases = (aigc or {}).get('ai_phrases') or {}
    if not phrases:
        return ''
    items = sorted(phrases.items(), key=lambda kv: (-kv[1], kv[0]))
    parts = '、'.join(f'{esc(k)} ×{v}' for k, v in items)
    return f'<p>命中提示语明细：<span class="mono">{parts}</span></p>'


def build_aigc_note(aigc, agent_note):
    """拼接 AIGC 提示语明细 + agent 结论文本。

    agent_note 为 HTML 片段时（含 <p>/<ul>/<div> 等块级标签）**直接拼接**，
    不再外包一层 <p>，否则会出现 <p><p>…</p></p> 的双包裹（历史缺陷，CESCI-D-26-00015 实测）。
    仅当 agent_note 为纯文本时才补 <p> 包裹。

    v3.19.0：agent_note 内容一律经 rich()（agent 手写，可含 HTML）；is_html 判断在
    转义前的原始文本上进行——转义后标签会变成实体，正则将无法识别。
    """
    note = (agent_note or '').strip()
    if not note:
        return build_aigc_phrase_list(aigc)
    is_html = bool(re.search(r'<\s*(p|ul|ol|div|table|blockquote)\b', note, re.I))
    safe = rich(note)
    body = safe if is_html else f'<p>{safe}</p>'
    return build_aigc_phrase_list(aigc) + body


def build_refs_verify(rv):
    """4.3 节：summary 段落（agent 写，可含 HTML）+ issues 问题表 + manual 人工复核明细。"""
    rv = rv or {}
    parts = [rich(rv.get('summary', ''))]
    issues = rv.get('issues') or []
    if issues:
        rows = ''.join(f'<tr><td>{esc(i.get("ref", ""))}</td><td>{rich(i.get("issue", ""))}</td></tr>'
                       for i in issues)
        parts.append('<table><tr><th>文献编号</th><th>差异所在 / 原因</th></tr>' + rows + '</table>')
    manual = rv.get('manual') or {}
    if manual:
        items = ''.join(f'<li><b>[{esc(k)}]</b>：{rich(v)}</li>' for k, v in manual.items())
        parts.append(f'<p class="note"><b>人工复核明细</b>：</p><ul>{items}</ul>')
    return '\n'.join(parts)


# ── 已出版独有：扩展小节（⑤⑥ 摘要行已于 v3.19.0 移除，与新稿摘要表对齐） ──


def build_ext_sections(ext):
    """第 5 节（参考文献语义相关性）+ 第 6 节（声明完整性）。

    v3.19.0 转义边界（陷阱 2）：
    - 本函数**自产的结构壳**（`<h2>` 标题、`<div class="finding">`、`<div class="blk">`
      及其中的 `<b>` 标签）不转义（脚本可信、常量字面量）。
    - **agent 手写的内容**逐字段处理：`semantic_refs` 整体走 `rich()`；
      卡片的 `title`/`location` 走 `esc()`，`analysis` 走 `rich()`（agent 常含 `<p>`/`<br>`）。
    - ⚠️ 不得对整个返回值再套一层 `rich()`——会重复处理结构壳的 class 属性。
    """
    ext = ext or {}
    parts = []
    # 5 节标题统一由脚本生成（与 6 节行为一致）；semantic_refs 字段只含正文，勿自带 h2
    head5 = '<h2>5 参考文献语义相关性检测</h2>'
    semantic = ext.get('semantic_refs')
    if semantic:
        parts.append(head5 + '\n' + rich(semantic))
    else:
        parts.append(head5 + '\n'
                     f'<p>{badge("info", "未检测")} 参考文献语义相关性未检测（子项未提供）。</p>')
    cards = ext.get('declaration_cards')
    if cards:
        head = '<h2>6 声明完整性检测</h2>'
        card_html = []
        for c in cards:
            loc = esc(c.get('location') or '—')
            b = badge(c.get('badge', 'info'), c.get('verdict', '未检测'))
            card_html.append(
                f'<h3>{esc(c.get("title", ""))}</h3>\n'
                f'<div class="finding">\n'
                f'<div class="blk"><b>声明原文位置</b>{loc}</div>\n'
                f'<div class="blk"><b>判定</b>{b}</div>\n'
                f'<div class="blk"><b>问题分析</b>{rich(c.get("analysis", ""))}</div>\n'
                f'</div>')
        parts.append(head + '\n' + '\n'.join(card_html))
    else:
        parts.append('<h2>6 声明完整性检测</h2>\n'
                     f'<p>{badge("info", "未检测")} 声明完整性未检测（子项未提供）。</p>')
    return '\n'.join(parts)


# ── 主流程 ──

def main():
    ap = argparse.ArgumentParser(description='熊猫找茬-已出版 报告固定渲染脚本')
    ap.add_argument('--work', required=True, help='work 目录（含检测 JSON）')
    ap.add_argument('--content', required=True, help='report_content.json 路径')
    ap.add_argument('--out', default='.', help='HTML 输出目录（SKILL.md 要求传输入稿件所在目录）')
    ap.add_argument('--msid', default=None, help='文件名中的稿件标识（缺省取 meta.manuscript_id）')
    ap.add_argument('--date', default=None, help='文件名日期 YYMMDD（缺省今天）')
    args = ap.parse_args()
    try:
        content = load_json(args.content)
        if not content:
            raise ValueError('report_content.json 缺失或为空')
        require(content, 'meta.manuscript_id',
                'summary.relevance', 'summary.author', 'summary.refs', 'summary.aigc',
                'refs_verify.summary')
        meta = content['meta']
        work = Path(args.work)
        refs = load_json(work / 'refs.json') or []
        authors = load_json(work / 'authors.json')
        refs_rw = load_json(work / 'refs_rw.json')
        geo = load_json(work / 'geo.json')
        aigc = load_json(work / 'aigc.json')
        if aigc is None:
            log('WARN: work 目录缺少 aigc.json，AIGC 定量指标表按「未检测」处理（请确认 aigc_stats.py 输出已落盘）')
        rw_meta = load_json(RW_META) or {}
        domain = content.get('manuscript_domain') or '本稿'
        msid = args.msid or meta.get('manuscript_id', 'manuscript')
        msid_safe = re.sub(r'[\\/:*?"<>|\s]+', '_', str(msid))[:40]
        date = args.date or datetime.now().strftime('%y%m%d')
        s = content['summary']
        ext_map = build_summary_ext_map(s.get('ext'))
        repl = {
            '{{MANUSCRIPT_ID}}': esc(meta.get('manuscript_id', '')),
            '{{FILES}}': esc(meta.get('files', '')),
            '{{JOURNAL}}': esc(meta.get('journal', '')),
            '{{TITLE}}': esc(meta.get('title', '')),
            '{{AUTHORS}}': esc(meta.get('authors', '')),
            '{{AFFILIATIONS}}': esc(meta.get('affiliations', '')),
            '{{MANUSCRIPT_TYPE}}': esc(meta.get('manuscript_type', '')),
            '{{REFS_COUNT}}': str(len(refs)),
            '{{RW_UPDATE_DATE}}': str(rw_meta.get('update_date', 'unknown')),
            '{{TOOL_NAME}}': TOOL_NAME,
            '{{REPORT_DATE}}': datetime.now().strftime('%Y-%m-%d %H:%M'),
            '{{POLITICAL_RISK}}': build_political_risk(geo),
            '{{SUMMARY_RELEVANCE_BADGE}}': badge(s['relevance']['badge'], s['relevance']['verdict']),
            '{{SUMMARY_RELEVANCE}}': esc(s['relevance'].get('text', '')),
            '{{SUMMARY_AUTHOR_BADGE}}': badge(s['author']['badge'], s['author']['verdict']),
            '{{SUMMARY_AUTHOR}}': esc(s['author'].get('text', '')),
            '{{SUMMARY_REFS_BADGE}}': badge(s['refs']['badge'], s['refs']['verdict']),
            '{{SUMMARY_REFS}}': esc(s['refs'].get('text', '')),
            '{{SUMMARY_AIGC_BADGE}}': badge(s['aigc']['badge'], s['aigc']['verdict']),
            '{{SUMMARY_AIGC}}': esc(s['aigc'].get('text', '')),
            '{{SUMMARY_SEMANTIC_BADGE}}': ext_map['summary_semantic'][0],
            '{{SUMMARY_SEMANTIC}}': ext_map['summary_semantic'][1],
            '{{SUMMARY_DECLARATION_BADGE}}': ext_map['summary_declaration'][0],
            '{{SUMMARY_DECLARATION}}': ext_map['summary_declaration'][1],
            '{{SCOPE_HEADER}}': build_scope_header(load_journal_info(meta)),
            '{{SCOPE_ANALYSIS_TABLE}}': build_scope_analysis_table(content.get('scope_analysis')),
            '{{RW_TIMEOUT_NOTE}}': esc(content.get('rw_timeout_note', '')),
            '{{AUTHOR_LIST}}': build_author_list(authors),
            '{{AUTHOR_RESULTS}}': build_author_results(
                authors, domain,
                s.get('author_verdicts') or content.get('author_verdicts'),
                content.get('author_note') or ''),
            '{{AFFILIATION_RESULTS}}': rich(content.get('affiliation_results', '')),
            '{{REFS_YEAR_STATS_TABLE}}': build_year_stats_table(refs, content.get('year_stats_note', '')),
            '{{REFS_CITATION_ISSUES}}': rich(content.get('refs_citation_issues', '')),
            '{{REFS_VERIFY_RESULTS}}': build_refs_verify(content.get('refs_verify')),
            '{{REFS_RETRACTION_CHECK}}': build_refs_rw_check(
                refs_rw, len(refs),
                (content.get('refs_rw') or {}).get('verdicts'),
                (content.get('refs_rw') or {}).get('note', '')),
            '{{AIGC_TABLE}}': build_aigc_table(aigc, content.get('aigc_judgments')),
            '{{AIGC_NOTE}}': build_aigc_note(aigc, content.get('aigc_note', '')),
            '{{EXT_SECTIONS}}': build_ext_sections(content.get('ext_sections')),
        }
        if not TEMPLATE.exists():
            raise ValueError(f'模板缺失: {TEMPLATE}')
        html = TEMPLATE.read_text(encoding='utf-8')
        for k, v in repl.items():
            html = html.replace(k, v)
        leftover = re.findall(r'\{\{[A-Z_]+\}\}', html)
        out = Path(args.out) / f'manuscript_integrity_check_report_{date}_{msid_safe}.html'
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html, encoding='utf-8')
        size = out.stat().st_size
        if leftover:
            log('WARN leftover: ' + ', '.join(leftover))
            print(json.dumps({'status': 'warn', 'out_file': str(out.resolve()),
                              'size': size, 'leftover': leftover}, ensure_ascii=False))
            sys.exit(2)
        print(json.dumps({'status': 'ok', 'out_file': str(out.resolve()),
                          'size': size, 'leftover': []}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == '__main__':
    main()

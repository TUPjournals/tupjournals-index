#!/usr/bin/env python3
"""
geo_check.py — 政治敏感词扫描

扫描全文，识别 Taiwan / Tibet / Xizang 关键词（词干匹配，忽略大小写）。
命中时输出完整句子与所属一级标题，供报告第 0 条「潜在政治风险，请人工核查」使用。

Usage:
    python geo_check.py --text <全文文本文件>

Output (stdout): JSON
    {
      "status": "found" | "not_found",
      "hits": [
        {
          "keyword": "Taiwan",
          "sentence": "The samples were obtained from Taiwan, China.",
          "section": "Introduction"
        }
      ],
      "note": null | "未检测到 Taiwan/Tibet/Xizang"
    }
"""

import argparse
import json
import re
import sys
from pathlib import Path

# 关键词正则（词干匹配，忽略大小写）
KEYWORD_PATTERNS = [
    ("Taiwan", r"\btaiwan\w*"),     # 覆盖 Taiwanese
    ("Tibet", r"\btibet\w*"),       # 覆盖 Tibetan
    ("Xizang", r"\bxizang\b"),      # 精确
]
COMPILED = [(name, re.compile(pat, re.IGNORECASE)) for name, pat in KEYWORD_PATTERNS]

# 一级标题词表（去掉数字编号前缀后匹配）
SECTION_TITLES = [
    "abstract", "introduction", "experimental", "experimental section",
    "methods", "methodology", "materials and methods", "results",
    "results and discussion", "discussion", "conclusion", "conclusions",
    "references", "bibliography", "acknowledgements", "acknowledgment",
    "acknowledgments", "supplementary", "appendix", "funding", "declarations",
    "摘要", "引言", "方法", "结果", "讨论", "结论", "参考文献", "致谢",
]
_HEADER_RE = re.compile(r"^\s*(?:\d+(?:\.\d+)*\s+)?(.+?)\s*$")


def extract_sentences(line: str):
    """按句号切分，返回句子列表（忽略过短片段）。"""
    parts = re.split(r"(?<=[.!?])\s+", line.strip())
    return [p.strip() for p in parts if len(p.strip()) >= 15]


# 句子结束标志：句末标点，允许其后跟右括号/右引号（如 "limitations)."、"limits.)"）
_END_PUNCT = re.compile(r"[.!?][\"'’”)）\]]*\s*$")
# 句子起始标志：首字母大写 / 括号引号开头 / 数字 / 汉字（英文科技稿通用判据）
_START_OK = re.compile(r"^[A-Z(\[“‘\"'0-9\u4e00-\u9fff]")


def expand_wrapped(lines, i, max_up=4, max_down=8):
    """把 PDF 提取折断的同一句重新拼合（V3.18.1 新增）。

    背景：PDF 正文按版心折行，分栏提取后一个自然句常被拆成 3–4 个物理行
    （ECM20260041 实测：地理区域列举句被拆成 "…Special Administrative" /
    "Region, Macau … and Taiwan" / "Province are not represented…)." 三段），
    而 `scan()` 逐行调用 `extract_sentences()`，导致报告第 0 条「完整句子」列
    只显示断句碎片。本函数以命中行为中心向前/向后补齐到句子边界。

    边界条件：遇空行、遇一级标题、或上一行本身已以句末标点结束即停止（避免
    把上一句并进来）；向后补齐到出现句末标点为止。
    """
    merged = lines[i].strip()
    j = i - 1
    steps = 0
    while j >= 0 and steps < max_up:
        prev = lines[j].strip()
        if not prev or _END_PUNCT.search(prev) or get_section(prev) is not None:
            break
        merged = prev + " " + merged
        steps += 1
        if _START_OK.match(merged):
            break
        j -= 1
    k = i + 1
    steps = 0
    while k < len(lines) and steps < max_down and not _END_PUNCT.search(merged):
        nxt = lines[k].strip()
        if not nxt or get_section(nxt) is not None:
            break
        merged += " " + nxt
        steps += 1
        k += 1
    return merged


def get_section(line: str) -> str | None:
    """判断一行是否是一级标题，是则返回标题文本（去掉编号前缀），否则 None。"""
    m = _HEADER_RE.match(line)
    if not m:
        return None
    title = m.group(1).strip()
    # 常见期刊标题带编号："1 Introduction"、"2. Materials and Methods"
    # _HEADER_RE 已去掉 "1 " / "2. " 前缀，此处再兼容 "1.1 " 子标题（不匹配，只认一级）
    low = title.lower().strip(" .:")
    for t in SECTION_TITLES:
        if low == t or low.startswith(t + " "):
            return title
    return None


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip().lower()


def _dedupe_hits(hits):
    """同一句因多行命中被重复提取时合并，保留最完整的那条（V3.18.1）。

    回拼后，同一自然句可能被其**多个折行行**各触发一次，且各次向前补齐的起点
    不同（ECM20260041 实测：一条含 "The model covers…" 前缀、一条从 "(Xizang"
    起），指纹不同故未被按键去重。此处按「后缀包含」合并——若新句子是已收录
    句子的后缀（或反之），说明同指一句，保留更长（更完整）者。
    """
    out = []
    for h in hits:
        key = _norm(h["sentence"])
        replaced = False
        for i, o in enumerate(out):
            okey = _norm(o["sentence"])
            if key == okey:
                # 完全相同 → 合并关键词，保留原句
                kws = o["keyword"].split("、") + h["keyword"].split("、")
                seen_kw = []
                for k in kws:
                    if k not in seen_kw:
                        seen_kw.append(k)
                o["keyword"] = "、".join(seen_kw)
                replaced = True
                break
            if key.endswith(okey) or okey.endswith(key):
                if len(key) > len(okey):
                    out[i] = h  # 新句更完整（覆盖旧句）→ 替换
                replaced = True
                break
        if not replaced:
            out.append(h)
    return out


def scan(text: str) -> dict:
    """扫描全文，返回命中结果。"""
    lines = text.split("\n")
    current_section = None
    hits = []
    seen = set()

    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            continue

        # 更新当前章节
        sec = get_section(stripped)
        if sec is not None:
            current_section = sec

        # 检查关键词
        matched_kws = [name for name, rx in COMPILED if rx.search(stripped)]
        if not matched_kws:
            continue

        # 提取含关键词的句子（V3.18.1：先回拼被 PDF 折行拆开的句子，再切句）
        merged = expand_wrapped(lines, i)
        sents = extract_sentences(merged)
        if not any(any(rx.search(s) for _, rx in COMPILED) for s in sents):
            # 回拼后仍无命中（极短片段被长度过滤丢弃）→ 回退用整段拼接文本
            sents = [merged]
        for sent in sents:
            hit_kws = [name for name, rx in COMPILED if rx.search(sent)]
            if not hit_kws:
                continue
            # 去重：按句子指纹
            fp = re.sub(r"\s+", " ", sent.lower())
            if fp in seen:
                continue
            seen.add(fp)
            hits.append({
                "keyword": "、".join(hit_kws),
                "sentence": sent[:500],
                "section": current_section or "（未识别章节）",
            })

    hits = _dedupe_hits(hits)
    if not hits:
        return {
            "status": "not_found",
            "hits": [],
            "note": "未检测到 Taiwan/Tibet/Xizang",
        }
    return {
        "status": "found",
        "hits": hits,
        "note": None,
    }


def main():
    parser = argparse.ArgumentParser(description="Scan manuscript for sensitive geo keywords")
    parser.add_argument("--text", required=True, help="Path to the manuscript full-text file (txt)")
    args = parser.parse_args()

    try:
        text = Path(args.text).read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "hits": [],
            "note": f"无法读取文本文件: {e}",
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    result = scan(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

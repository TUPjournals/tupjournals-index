# -*- coding: utf-8 -*-
"""journal_scopes.py — 双层期刊数据源（v2.17.0）。

文件角色（重要，打包规范同此）：
- journal_scopes_template.json  内置模板：进分享包、随版本更新，含官方内置期刊记录；
- journal_scopes.json          用户文件：禁止进分享包、升级永不覆盖，纯用户个人积累数据。

规则：
1. 用户文件不存在（首次安装）→ 自动从模板复制初始化一份，此后完全归用户所有；
2. 读取（load_all）= 模板 ∪ 用户 合并；同 abbreviation 冲突时**用户记录优先**
   （个人主权数据），并向 stderr 输出冲突提示；
3. 写入（save_scope）只写用户文件，模板保持只读。
"""

import json
import sys
from datetime import datetime
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = SKILL_DIR / 'assets'
TEMPLATE_FILE = ASSETS_DIR / 'journal_scopes_template.json'
USER_FILE = ASSETS_DIR / 'journal_scopes.json'


def _load_journals(path: Path) -> list:
    """容错读取 journals 列表；文件缺失/损坏返回 []。"""
    if not path or not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding='utf-8', errors='replace'))
        return data.get('journals', []) if isinstance(data, dict) else []
    except Exception:
        return []


def ensure_user_file() -> Path:
    """用户文件不存在时从模板初始化（首次安装开箱即用）。返回用户文件路径。"""
    if not USER_FILE.exists():
        if TEMPLATE_FILE.exists():
            USER_FILE.write_text(TEMPLATE_FILE.read_text(encoding='utf-8'),
                                 encoding='utf-8')
        else:
            USER_FILE.write_text(json.dumps({'journals': []},
                                            ensure_ascii=False, indent=2),
                                 encoding='utf-8')
    return USER_FILE


def load_all() -> list:
    """返回 模板 ∪ 用户 合并后的 journals 列表；同 abbreviation 冲突时用户优先。

    用户记录先行，模板仅在缩写不冲突时补入——用户永远拿回自己的数据，
    同时自动获得新版内置期刊记录（无需手动合并）。
    冲突提示规则：同缩写且 full_name 相同视为同一记录（静默）；
    同缩写但 full_name 不同才提示（用户自定义覆盖内置）。
    """
    ensure_user_file()
    merged, seen = [], {}
    for j in _load_journals(USER_FILE):
        merged.append(j)
        seen[str(j.get('abbreviation', '')).upper()] = str(j.get('full_name', '')).lower()
    for j in _load_journals(TEMPLATE_FILE):
        ab = str(j.get('abbreviation', '')).upper()
        if ab in seen:
            if ab and seen[ab] != str(j.get('full_name', '')).lower():
                print(f'[journal_scopes] 冲突：用户记录覆盖内置缩写 {ab}'
                      f'（内置：{j.get("full_name", "")}，用户：{seen[ab]}）',
                      file=sys.stderr)
            continue
        merged.append(j)
        seen[ab] = str(j.get('full_name', '')).lower()
    return merged


def save_scope(full_name: str, abbreviation: str, scope_url: str,
               scope_text: str) -> None:
    """写入/更新一条期刊记录（只写用户文件；同名 full_name 视为同一条更新）。"""
    ensure_user_file()
    data = {'journals': _load_journals(USER_FILE)}
    for j in data['journals']:
        if str(j.get('full_name', '')).lower() == (full_name or '').lower():
            j['abbreviation'] = abbreviation or j.get('abbreviation', '')
            j['scope_url'] = scope_url or j.get('scope_url', '')
            j['scope_text'] = scope_text or j.get('scope_text', '')
            j['updated_at'] = datetime.now().strftime('%Y-%m-%d')
            USER_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                 encoding='utf-8')
            return
    if abbreviation:
        for j in data['journals']:
            if str(j.get('abbreviation', '')).upper() == abbreviation.upper():
                print(f'[journal_scopes] 提示：缩写 {abbreviation} 已被'
                      f'「{j.get("full_name", "")}」占用，新增「{full_name}」后将同缩写并存'
                      f'（匹配时按用户文件顺序取第一条）', file=sys.stderr)
                break
    data['journals'].append({
        'full_name': full_name,
        'abbreviation': abbreviation or '',
        'scope_url': scope_url or '',
        'scope_text': scope_text or '',
        'added_at': datetime.now().strftime('%Y-%m-%d'),
    })
    USER_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                         encoding='utf-8')

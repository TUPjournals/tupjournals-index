#!/usr/bin/env python3
"""
parse_refs.py — 从全文 References 节解析参考文献（支持 [n] 编号格式，无 DOI）

Usage:
    python parse_refs.py <fulltext.txt> <out_refs.json>

解析策略：
- 主格式（EMD 常见）：[n] Authors. (Year). Title. Journal vol, pages.
- 兼容 Journal 后带 "; YYYY" 再卷号（如 "Adv.  Funct. Mater. 2026; 36:e74897."）
- 作者/标题/期刊/卷/页/年份结构化输出，行尾 DOI 自动剥离
"""

import json
import re
import sys
from pathlib import Path

# 标题与期刊的分界：从右往左收集期刊 token，遇到小写词 / 停用词 / 含数字 token 即停止。
_STOP = {
    'for', 'and', 'the', 'of', 'in', 'to', 'with', 'a', 'an', 'on', 'by', 'at', 'from',
    'via', 'using', 'as', 'is', 'are', 'into', 'between', 'toward', 'towards', 'against',
    'over', 'under', 'vs', 'versus', 'based', 'but', 'or', 'that', 'this', 'these',
    'their', 'its', 'et', 'al', 'we', 'our', 'study', 'review',
}

# 作者名片段：首字母缩写（可多点/连字符，可空格分隔多个缩写）+ 姓
_AUTH_WORD = r'[A-Za-z\u00C0-\u024F][A-Za-z\u00C0-\u024F\'\u2019\-]+'
AUTHOR_RE = re.compile(
    r'^[A-Z][A-Z.\-]*\.(\s+[A-Z][A-Z.\-]*\.)*\s+' + _AUTH_WORD + r'(\s+' + _AUTH_WORD + r')*$'
)


def _parse_emd(rest: str, index: int) -> dict:
    """EMD 常见格式：[n] Authors. (Year). Title. Journal vol, pages."""
    # 提取尾部 DOI（如存在），剥离后解析
    doi_m = re.search(r'https?://(?:dx\.)?doi\.org/(\S+)', rest)
    doi = ''
    if doi_m:
        doi = doi_m.group(1).rstrip('.,)')
        rest = rest[:doi_m.start()].strip().rstrip('., ')

    # 年份：括号内四位年份（如 "(2026)"）
    ym = re.search(r'\(\s*(\d{4})\s*\)', rest)
    if not ym:
        return {'index': index, 'raw': rest, 'parse_failed': True}
    year = ym.group(1)
    authors = rest[:ym.start()].strip().rstrip('., ').strip()
    post = rest[ym.end():].strip().lstrip('. ').strip()

    # 尾部：可选 ;YYYY 或 YYYY; + 卷号 + 可选 (:|,|空格) 页码 —— 先定位卷/页
    tail = re.search(
        r'(?:\s*(?:\d{4}\s*;|;\s*\d{4}))?\s+(\d[\d().&\-–—]*?)\s*(?::\s*|,\s*|\s+)?'
        r'([\dA-Za-z–—\-]+)?\s*$',
        post,
    )
    if not tail:
        return {
            'index': index, 'authors': authors, 'title': post,
            'journal': '', 'volume': '', 'year': year, 'page': '', 'doi': doi,
        }
    volume = (tail.group(1) or '').strip()
    page = (tail.group(2) or '').strip()
    pre_vol = post[:tail.start()].strip().rstrip('. ')

    # 标题/期刊分界：取最左侧的 ". "，使其后的整段均为期刊 token（单 token 大写缩写，无空格/数字）
    def _is_journal_token(tok):
        return bool(re.match(r'^[A-Z][A-Za-z.&/\-]*$', tok)) and not re.search(r'\d', tok)

    sep = None
    for mm in re.finditer(r'[.?!]\s+', pre_vol):
        suffix = pre_vol[mm.end():]
        toks = suffix.split()
        if toks and all(_is_journal_token(t) for t in toks):
            sep = mm.start()
            break
    if sep is not None:
        journal = pre_vol[sep + 1:].strip().lstrip('. ').strip()
        title = pre_vol[:sep].strip().rstrip('. ')
    else:
        journal = ''
        title = pre_vol

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal,
        'volume': volume,
        'year': year,
        'page': page,
        'doi': doi,
    }


def _parse_ces(rest: str, index: int) -> dict:
    """CES 常见格式：n. Authors, Title. Journal, Year. Vol(Issue): p. Pages.

    特征：点号编号、逗号分隔的年份（如 ", 2020."，亦可 ": 1941" 或末尾
    "(2020)"/" 2018."）、多词期刊名（含 of/and 等小写词）。作者与标题以
    "首词为真实单词且其后为空格（非逗号）" 的边界切分，规避 "M. Hosseini"
    这类 首字母+姓氏 误判。
    """
    rest = rest.strip().rstrip('. ')
    ym = re.search(r',\s*((?:19|20)\d{2})\s*[.;:]', rest)
    year = None; cpos = None
    if ym:
        year = ym.group(1); cpos = ym.start()
    else:
        ym2 = re.search(r'\(\s*((?:19|20)\d{2})\s*\)', rest)
        if ym2:
            year = ym2.group(1); cpos = ym2.start()
        else:
            ym3 = re.search(r'[.\s]\s*((?:19|20)\d{2})\s*[.;]?\s*$', rest)
            if ym3:
                year = ym3.group(1); cpos = ym3.start()
    if cpos is None:
        # 灰色文献（网页/软件手册等无标准期刊年份）→ 整条作标题
        return {'index': index, 'authors': '', 'title': rest,
                'journal': '', 'volume': '', 'year': '', 'page': '', 'doi': ''}
    pre = rest[:cpos]
    dp = pre.rfind('. ')
    if dp != -1:
        journal = pre[dp + 1:].strip()
        tpa = pre[:dp].strip()      # authors + title
    else:
        journal = ''
        tpa = pre.strip()
    # 作者/标题边界：首个分隔符，其后续词为真实单词（^[A-Z][a-z]）且该词后
    # 跟空格（标题短语 "Impacts of..."）而非逗号（作者姓氏 "Hosseini, and..."）。
    best = None
    for mm in re.finditer(r'[.,]\s+', tpa):
        r2 = tpa[mm.end():]
        toks = r2.split(None, 1)
        tok0 = toks[0].rstrip('.,;:') if toks else ''
        if re.match(r'^[A-Z][a-z]', tok0):
            after_first = r2[len(tok0):]
            if not after_first.startswith(','):
                best = mm.end(); break
    if best is not None:
        authors = tpa[:best].rstrip(',. ').strip()
        title = tpa[best:].strip()
    else:
        lc = tpa.rfind(', ')
        if lc != -1:
            authors = tpa[:lc].strip(); title = tpa[lc + 2:].strip()
        else:
            dd = tpa.rfind('. ')
            if dd != -1:
                authors = tpa[:dd].strip(); title = tpa[dd + 2:].strip()
            else:
                authors = ''; title = tpa
    # 卷/页（年份之后）
    after = rest[cpos:]
    after2 = re.sub(r'^,?\s*(?:19|20)\d{2}\s*[.;]?\s*', '', after).strip().rstrip('. ')
    vol = ''; page = ''
    pm = re.match(r'^p\.?\s*([\dA-Za-z–—\-]+)', after2)
    if pm:
        page = pm.group(1); vol = ''
    else:
        vm = re.match(
            r'^(\d[\d().&\-–—]*?)(?:\s*\([^)]*\))?'
            r'(?:\s*:\s*(?:p\.?\s*)?([\dA-Za-z–—\-]+))?'
            r'(?:\s*,\s*(?:p\.?\s*)?(\d[\dA-Za-z–—\-]+))?\s*$', after2)
        if vm:
            vol = (vm.group(1) or '').strip()
            page = (vm.group(2) or vm.group(3) or '').strip()
    return {'index': index, 'authors': authors, 'title': title,
            'journal': journal, 'volume': vol, 'year': year, 'page': page, 'doi': ''}


def parse_ref_line(line: str) -> dict | None:
    """解析单条参考文献：自动识别 EMD([n]) 与 CES(n.) 两种编号/年份格式。"""
    m = re.match(r'^\s*\[(\d+)\]\s*(.*)$', line)
    if m:
        return _parse_emd(m.group(2).strip(), int(m.group(1)))
    m2 = re.match(r'^\s*(\d+)\.\s*(.*)$', line)
    if m2:
        return _parse_ces(m2.group(2).strip(), int(m2.group(1)))
    return None


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs.py <fulltext.txt> <out_refs.json>', file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'}, ensure_ascii=False))
        sys.exit(1)
    out = Path(sys.argv[2])

    # 定位 References 节（行级截断，兼容独立行/带编号标题；回退首个 [N] 行）
    lines = text.split('\n')
    start = None
    for i, ln in enumerate(lines):
        s = ln.strip().lower().rstrip('.: ')
        if s in ('references', 'reference', 'bibliography') or re.fullmatch(r'[\d.\s]*references?', s) or re.fullmatch(r'[\d.\s]*bibliography', s):
            start = i + 1
            break
    if start is None:
        for i, ln in enumerate(lines):
            if re.match(r'^\s*\[\d+\]', ln):
                start = i
                break
    if start is None:
        print('ERROR: References section not found', file=sys.stderr)
        sys.exit(1)
    ref_body = '\n'.join(lines[start:])

    refs = []
    failed = []
    for raw_line in ref_body.split('\n'):
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        parsed = parse_ref_line(raw_line)
        if parsed is None:
            continue
        if parsed.pop('parse_failed', False):
            failed.append(parsed)
            continue
        refs.append(parsed)

    refs.sort(key=lambda r: r['index'])
    out.write_text(json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({
        'refs_total': len(refs),
        'parse_failed': failed,
    }, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

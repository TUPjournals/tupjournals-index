#!/usr/bin/env python3
"""
parse_refs_apa.py — 解析 APA 风格参考文献（[n] 作者 (年). 标题. 期刊 卷, 页码.）

Usage:
    python parse_refs_apa.py <fulltext.txt> <out_refs.json>

适配 EMD 编辑部风格 APA 引用：
    [1] Goodenough, J. B., Kim, Y. (2010). Challenges for rechargeable Li batteries. Chem. Mater. 22, 587-603.
    [5] Janek, J., Zeier, W. G. (2016). A solid future for battery development. Nat. Energy 1, 16141.
    [119] Jung, M., Razazzadeh, A., Khan, H., Kwon, S. (2025). ... Exploration 5, e20240010.
"""

import json
import re
import sys
from pathlib import Path


def parse_ref_line(line: str) -> dict | None:
    m = re.match(r'^\s*\[(\d+)\]\s*(.*)$', line)
    if not m:
        return None
    index = int(m.group(1))
    rest = m.group(2).strip()

    ym = re.search(r'\((\d{4})\)', rest)
    if not ym:
        return {'index': index, 'raw': line, 'parse_failed': True}

    year = ym.group(1)
    authors = rest[:ym.start()].strip().rstrip(', ').strip()
    after = rest[ym.end():].lstrip('. ').strip()  # 剥掉年份括号后的前导句点

    # 标题 = after 中第一个句点结束的内容（APA 标题后跟 ". " + 期刊）
    tm = re.search(r'^(.*?\.)\s+', after)
    if tm:
        title = tm.group(1).rstrip('.').strip()
        rest2 = after[tm.end():].strip()
    else:
        title, rest2 = '', after

    # 期刊部分：rest2 = "期刊 卷, 页码." / "期刊 卷." / "期刊 卷, 文章号."
    vm = re.match(r'^(.*?)\s+(\d+),?\s*([\w\-–—]*)\s*\.?\s*$', rest2)
    if vm:
        journal = vm.group(1).strip()
        volume = vm.group(2)
        page = vm.group(3)
    else:
        journal = rest2.rstrip('.').strip()
        volume, page = '', ''

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal,
        'volume': volume,
        'year': year,
        'page': page,
        'doi': '',
    }


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_apa.py <fulltext.txt> <out_refs.json>', file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'}, ensure_ascii=False))
        sys.exit(1)
    out = Path(sys.argv[2])

    ref_marker = re.search(r'(?im)^references\s*$', text)
    if not ref_marker:
        print('ERROR: References section not found', file=sys.stderr)
        sys.exit(1)
    ref_body = text[ref_marker.end():]

    refs = []
    failed = []
    for raw_line in ref_body.split('\n'):
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        # 跳过编辑批注行（非 [n] 开头且含中文/特殊标记）
        if not re.match(r'^\[\d+\]', raw_line):
            continue
        parsed = parse_ref_line(raw_line)
        if parsed is None:
            continue
        if parsed.pop('parse_failed', False):
            failed.append(parsed)
            continue
        refs.append(parsed)

    refs.sort(key=lambda r: r['index'])
    out.write_text(json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({
        'refs_total': len(refs),
        'parse_failed': failed,
    }, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

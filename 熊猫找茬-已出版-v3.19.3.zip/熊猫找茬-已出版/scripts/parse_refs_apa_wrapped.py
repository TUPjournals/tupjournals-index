#!/usr/bin/env python3
"""
parse_refs_apa_wrapped.py — APA 风格 + 分栏 PDF **折行**参考文献解析器

背景（OCE20260029 实测，v3.16.0）
--------------------------------
`parse_refs.py`（EMD 惯用「作者, 标题, 期刊, 卷 (年) 页码」）与 `parse_refs_apa.py`
（假定「单行 = 单条」）都无法处理**双栏 PDF 提取产生的折行文献表**：每条文献被
折成 2–4 行、且条间夹着页眉/版权/页码/页脚 DOI 等噪声行。直接套用会得到
「标题被截断、期刊/卷页空、末条被页脚污染」的结果（OCE20260029 首次实测：
parse_refs.py 把 25 条拆成 26 条且 21 条标题为空）。

本脚本做的事：定位 References → 去噪 → 折行合并（新条目 = 以 [n] 开头）→
APA 字段解析（年份 `(YYYY)` 为锚；标题按首个「句点+空格」切分，跳过 `U. S.`
式单字母缩写；先摘 DOI 再解析期刊/卷/页，避免 DOI 污染 journal 字段）。

输出：纯 list JSON（可直接喂给 crossref_check.py verify / year-stats、
retraction_watch.py check-refs、semantic_check.py fetch）。

用法：
    python parse_refs_apa_wrapped.py <fulltext.txt> <out_refs.json>
"""

import json
import re
import sys
from pathlib import Path

# 页眉 / 版权 / 页码 / 页脚等噪声行（先剔除行内 URL，再判定）
NOISE = [
    re.compile(r'^\s*©'),
    re.compile(r'^\s*[A-Z][A-Za-z\-\']+ et al\.?\s*$'),      # 页眉 "Wang et al."
    re.compile(r'^\s*Open Access\b'),
    re.compile(r'^\s*(This article|provided, and any changes|adapt, and build upon)'),
    re.compile(r'^\s*(Received|Revised|Accepted)\s*:', re.I),
]


def is_noise(line: str) -> bool:
    line = re.sub(r'https?://\S+', '', line).strip()   # 页脚 "14 https://doi.org/..." → "14"
    if not line:
        return True
    if re.fullmatch(r'\d+', line):
        return True
    return any(rx.search(line) for rx in NOISE)


def title_split(after: str):
    """标题 = 首个「句点+空格」处；跳过单字母缩写（U. S. / R.）造成的误切。"""
    for m in re.finditer(r'\.\s', after):
        prev = after[:m.start()].rstrip()
        tail = prev.split()[-1] if prev.split() else ''
        if len(tail.replace('.', '')) <= 1:
            continue
        return prev, after[m.end():].strip()
    return '', after


def parse_entry(idx: int, rest: str) -> dict:
    ym = re.search(r'\((\d{4})\)', rest)
    if not ym:
        return {'index': idx, 'raw': rest, 'parse_failed': True}
    year = ym.group(1)
    authors = rest[:ym.start()].strip().rstrip(', ').strip()
    after = rest[ym.end():].lstrip('. ').strip()

    # 先摘 DOI（行尾/句中），再删其片段，避免污染 journal 字段
    doi = ''
    dm = re.search(r'doi:\s*(10\.\S+)', after, re.I)
    if dm:
        doi = dm.group(1).rstrip('.').strip()
        after = (after[:dm.start()] + after[dm.end():]).strip().rstrip('.').strip()

    title, tailpart = title_split(after)
    if not title:            # 无内嵌期刊段的条目（网页 / 行业报告）：整段即标题
        title, tailpart = after.rstrip('.').strip(), ''

    journal = volume = page = ''
    vm = re.match(r'^(.*?)\s+(\d+),\s*([\d\u2013\u2014\-]+)\s*\.?$', tailpart)
    if vm:
        journal, volume, page = vm.group(1).strip(), vm.group(2), vm.group(3)
    else:
        vm2 = re.match(r'^(.*?)\s+(\d+)\s*\.?$', tailpart)
        if vm2:
            journal, volume = vm2.group(1).strip(), vm2.group(2)
        else:
            journal = tailpart.strip().rstrip('.')
    return {
        'index': idx, 'authors': authors, 'title': title, 'journal': journal,
        'volume': volume, 'year': year, 'page': page, 'doi': doi,
    }


def main():
    if len(sys.argv) < 3:
        print(json.dumps({'error': 'usage: parse_refs_apa_wrapped.py <fulltext.txt> <out_refs.json>'},
                         ensure_ascii=False))
        sys.exit(1)
    text = Path(sys.argv[1]).read_text(encoding='utf-8')
    out = Path(sys.argv[2])

    lines = text.split('\n')
    start = None
    for i, ln in enumerate(lines):
        if ln.strip().lower().rstrip('.: ') == 'references':
            start = i + 1
            break
    if start is None:
        print(json.dumps({'error': 'References 未定位（请确认全文文本含该标题行）'}, ensure_ascii=False))
        sys.exit(1)

    entries, cur = [], None
    for ln in lines[start:]:
        s = ln.strip()
        if not s or is_noise(s):
            continue
        m = re.match(r'^\[(\d+)\]\s*(.*)$', s)
        if m:
            if cur:
                entries.append(cur)
            cur = [int(m.group(1)), m.group(2).strip()]
        elif cur:
            cur[1] += ' ' + s          # 折行续接上一条
    if cur:
        entries.append(cur)

    refs, failed = [], []
    for idx, rest in entries:
        rest = re.sub(r'\s+', ' ', rest).strip()
        p = parse_entry(idx, rest)
        if p.pop('parse_failed', False):
            failed.append(p)
        else:
            refs.append(p)
    refs.sort(key=lambda r: r['index'])
    out.write_text(json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    ids = {r['index'] for r in refs}
    print(json.dumps({
        'refs_total': len(refs),
        'parse_failed': failed,
        'missing_index': [i for i in range(1, (refs[-1]['index'] if refs else 0) + 1) if i not in ids],
    }, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

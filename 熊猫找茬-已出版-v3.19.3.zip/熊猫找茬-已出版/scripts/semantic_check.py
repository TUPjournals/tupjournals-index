# -*- coding: utf-8 -*-
"""semantic_check.py — 参考文献语义相关性核对工具链（熊猫找茬-已出版 v3.11.0 新增）。

职责：把「逐条、基于文献摘要的语义比对」从人工抽样升级为可复现的正式流程。

子命令：
  fetch     --refs <refs.json> --out <semantic_abs.json>
            对每条带 DOI 的参考文献抓取摘要：
              ① Crossref（复用 crossref_check.query_crossref_by_doi 及其 7 天缓存）
              ② Crossref 无 abstract → OpenAlex works API 兜底
                  （abstract_inverted_index 按位置重建，免费 API 无需 key）
            无 DOI 或双源均无摘要 → abstract='' 并标注 source='none'（不得判「无法核实」而跳过，
            由 agent 用 元数据+标题+人工核实 降级处理并在报告标注）。
  contexts  --body <正文.txt> --refs <refs.json> --out <citation_contexts.json>
            从正文（References 之前的叙述文本）提取每条文献的全部引用句。
            引用编号组正则覆盖 [1]、[1,2]、[49, 50]、[1-3]、[12–15]（先归一并连字符）。
  pair      --abs <semantic_abs.json> --ctx <citation_contexts.json> --out <semantic_pairs.json>
            合并摘要与引用上下文为逐条比对清单（agent 精读判定用，含 source 分级）。

约定（落盘文件，供报告第 5 节汇总读取）：
  semantic_abs.json / citation_contexts.json / semantic_pairs.json

摘要覆盖口径（写入报告）：
  摘要可得（Crossref/OpenAlex 任一）→ 按摘要比对；
  仅元数据（双源无摘要但 Crossref 命中书目）→ 按「标题+元数据+人工核实」降级比对，标注「仅元数据」；
  双源均无法定位 → 人工联网核实后归入「经人工核实」或「无法核实」并说明原因。
"""

import argparse
import html
import json
import re
import sys
import time

import crossref_check  # 复用 query_crossref_by_doi + 缓存

OPENALEX_API = "https://api.openalex.org/works/https://doi.org/{doi}"

# 引用编号组：覆盖 [1] [1,2] [49, 50] [1-3] [1–3] [1−3]
# 破折号类必须四种全收：hyphen / en-dash / em-dash / **minus sign U+2212**
# （ECM20260040 实测：[1,16−18] 用的是 minus sign，旧类漏匹配 → [16][18] 上下文为空）
_DASH = ",\u2013\u2014\u2212-"
CITE_GROUP_RE = re.compile(r"\[(\d+(?:\s*[" + _DASH + r"]\s*\d+)*)\]")
ABSTRACT_MAX = 1800  # 截断上限（字符）
# 引用上下文 = 以引用标记为中心的滑窗。双栏 PDF 按句点切句会产生错栏碎片，
# 滑窗不依赖句子边界、天然跟随文本流，是双栏排版下更稳的上下文取法。
WIN_PRE = 140    # 标记前窗口（字符）
WIN_POST = 220   # 标记后窗口（字符）
WIN_LIMIT = 3    # 每条文献最多保留窗口数


def clean_abstract(raw: str) -> str:
    """剥 JATS 标签 + HTML 实体 + 压缩空白。"""
    if not raw:
        return ""
    t = re.sub(r"<[^>]+>", " ", raw)
    t = html.unescape(t)
    return re.sub(r"\s+", " ", t).strip()[:ABSTRACT_MAX]


def rebuild_openalex_abstract(inv: dict) -> str:
    """abstract_inverted_index: {word: [positions]} → 按位置排序重建文本。"""
    if not inv:
        return ""
    pos = {}
    for w, ps in inv.items():
        for p in ps:
            pos[p] = w
    if not pos:
        return ""
    text = " ".join(pos[i] for i in sorted(pos))
    return re.sub(r"\s+", " ", text).strip()[:ABSTRACT_MAX]


def fetch_abstract(doi: str):
    """返回 (abstract, source)。source: 'crossref' | 'openalex' | 'none'。"""
    doi = doi.rstrip(".").lower()
    # ① Crossref
    try:
        work = crossref_check.query_crossref_by_doi(doi)
        if isinstance(work, dict) and not work.get("_error"):
            abstract = clean_abstract(work.get("abstract") or "")
            if abstract:
                return abstract, "crossref"
    except Exception:
        pass
    # ② OpenAlex 兜底
    try:
        import requests
        resp = requests.get(
            OPENALEX_API.format(doi=doi),
            params={"mailto": crossref_check.MAILTO},
            headers={"User-Agent": crossref_check.USER_AGENT},
            timeout=20,
        )
        if resp.status_code == 200:
            msg = resp.json().get("abstract_inverted_index")
            abstract = rebuild_openalex_abstract(msg or {})
            if abstract:
                return abstract, "openalex"
    except Exception:
        pass
    finally:
        time.sleep(0.15)  # OpenAlex 免费层限速缓冲（保守）
    return "", "none"


def resolve_doi_by_title(ref: dict) -> str:
    """无 DOI 文献：用参考文献标题在 Crossref 反查 DOI（供摘要抓取）。

    v3.12.0（CESCI-D-26-00015 实测）：Vancouver 参考文献列表常整体不带 DOI，
    旧实现直接判"无自动摘要通道"，导致 36/36 全部无摘要、语义维度被迫整体降级为
    「仅元数据」——这是**工具能力缺口造成的降级**，而非源端确实无摘要。
    复用 crossref_check 的 query.title= 检索 + 评分（标题为必要项，阈值 6）定位 DOI。
    """
    title = ref.get("title") or ""
    if not title:
        return ""
    try:
        items = crossref_check.query_crossref_by_title_exact(title)
    except Exception:
        items = None
    if not items:
        return ""
    best, best_score = None, 0
    for it in items:
        try:
            sc = crossref_check.score_title_search_result(
                it, title, ref.get("authors", ""),
                ref.get("year", ""), ref.get("journal", ""))
        except Exception:
            continue
        if sc > best_score:
            best, best_score = it, sc
    if best is None or best_score < 6:
        return ""
    try:
        if not crossref_check.titles_match(title, crossref_check.get_crossref_title(best)):
            return ""
    except Exception:
        return ""
    return (best.get("DOI") or "").strip().lower()


def cmd_fetch(args):
    refs = json.load(open(args.refs, encoding="utf-8"))
    out = []
    n_doi = n_resolved = n_crossref = n_openalex = n_none = n_err = 0
    for i, r in enumerate(refs):
        doi = (r.get("doi") or "").strip()
        resolved_from_title = False
        if not doi:
            doi = resolve_doi_by_title(r)
            resolved_from_title = bool(doi)
            if resolved_from_title:
                n_resolved += 1
        rec = {
            "ref_index": r.get("index"),
            "doi": doi,
            "doi_resolved_by_title": resolved_from_title,
            "title": r.get("title", ""),
            "journal": r.get("journal", ""),
            "year": r.get("year", ""),
            "abstract": "",
            "source": "none",
        }
        if doi:
            n_doi += 1
            try:
                abstract, source = fetch_abstract(doi)
                rec["abstract"], rec["source"] = abstract, source
                if source == "crossref":
                    n_crossref += 1
                elif source == "openalex":
                    n_openalex += 1
                else:
                    n_none += 1
            except Exception as e:
                n_err += 1
                rec["error"] = str(e)
        else:
            n_none += 1  # 双源均无法定位 DOI → 交由 agent 降级处理
        out.append(rec)
        if (i + 1) % 25 == 0:
            print(f"  ...{i+1}/{len(refs)} (abs:{n_crossref + n_openalex})", flush=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(
        f"FETCH DONE: total={len(refs)} doi={n_doi} (resolved_by_title={n_resolved}) "
        f"crossref_abs={n_crossref} openalex_abs={n_openalex} "
        f"no_abstract={n_none} errors={n_err}"
    )
    print("OUT:", args.out)


def cmd_contexts(args):
    text = open(args.body, encoding="utf-8").read()
    refs = json.load(open(args.refs, encoding="utf-8"))
    # 归一 all dash variants → hyphen，便于区间解析
    # （en-dash U+2013 / em-dash U+2014 / minus sign U+2212；ECM20260040 实测缺 minus 会漏 [1,16−18]）
    for _d in ("\u2013", "\u2014", "\u2212"):
        text = text.replace(_d, "-")
    cited = {}  # idx -> [window...]

    def parse_group(g):
        nums = set()
        for part in g.split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-", 1)
                if a.strip().isdigit() and b.strip().isdigit():
                    nums.update(range(int(a), int(b) + 1))
            elif part.isdigit():
                nums.add(int(part))
        return nums

    for m in CITE_GROUP_RE.finditer(text):
        nums = parse_group(m.group(1))
        if not nums:
            continue
        s, e = m.start(), m.end()
        a = max(0, s - WIN_PRE)
        b = min(len(text), e + WIN_POST)
        win = " ".join(text[a:b].split())
        if a > 0:
            win = "…" + win
        if b < len(text):
            win = win + "…"
        # 过滤图表标题行等非叙述窗口
        if re.match(r"^(Fig(?:ure|s)?|Table|Scheme|Box)\b", win.strip()):
            continue
        for n in nums:
            cited.setdefault(n, []).append(win)
    # 截断每篇窗口数
    for n in cited:
        cited[n] = cited[n][:WIN_LIMIT]
    # 补全 refs 中未被引用的条目（空列表）——保持 1:1，便于全检覆盖核对
    for r in refs:
        cited.setdefault(r.get("index"), [])
    out = {str(k): cited[k] for k in sorted(cited)}
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    n_cited = sum(1 for v in cited.values() if v)
    print(f"CONTEXTS DONE: refs={len(refs)} with_context={n_cited} no_context={len(refs) - n_cited}")
    print("OUT:", args.out)


def cmd_pair(args):
    abs_data = json.load(open(args.abs, encoding="utf-8"))
    ctx_data = json.load(open(args.ctx, encoding="utf-8"))
    pairs = []
    for a in abs_data:
        idx = a["ref_index"]
        pairs.append({
            "ref_index": idx,
            "doi": a.get("doi", ""),
            "title": a.get("title", ""),
            "journal": a.get("journal", ""),
            "year": a.get("year", ""),
            "source": a.get("source", "none"),
            "abstract": a.get("abstract", ""),
            "contexts": ctx_data.get(str(idx), []),
        })
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False, indent=1)
    n_abs = sum(1 for p in pairs if p["abstract"])
    n_ctx = sum(1 for p in pairs if p["contexts"])
    n_none = sum(1 for p in pairs if not p["abstract"])
    print(f"PAIR DONE: total={len(pairs)} with_abstract={n_abs} no_abstract={n_none} with_context={n_ctx}")
    print("OUT:", args.out)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("fetch")
    p.add_argument("--refs", required=True)
    p.add_argument("--out", required=True)
    p = sub.add_parser("contexts")
    p.add_argument("--body", required=True)
    p.add_argument("--refs", required=True)
    p.add_argument("--out", required=True)
    p = sub.add_parser("pair")
    p.add_argument("--abs", required=True)
    p.add_argument("--ctx", required=True)
    p.add_argument("--out", required=True)
    args = ap.parse_args()
    if args.cmd == "fetch":
        cmd_fetch(args)
    elif args.cmd == "contexts":
        cmd_contexts(args)
    else:
        cmd_pair(args)


if __name__ == "__main__":
    main()

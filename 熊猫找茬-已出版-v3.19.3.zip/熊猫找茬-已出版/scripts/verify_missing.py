#!/usr/bin/env python3
"""
verify_missing.py — 对 not_found 的参考文献用 Crossref 标题搜索复核
（去除特殊字符、使用简化查询词，放宽匹配）
"""

import json
import re
import sys
import time
import urllib.parse
import urllib.request

QUERIES = {
    9: "Rechargeable lithium sulfur batteries Manthiram",
    20: "Sulfurized polyacrylonitrile high-performance lithium sulfur batteries advances prospects",
    26: "Cathode electrolyte interface enabling stable Li-S batteries",
    28: "Mechanistic understanding Sulfurized Poly acrylonitrile cathode lithium sulfur batteries",
    30: "Uniform Lithium Deposition Induced by ZnFx(OH)y High-Performance Sulfurized Polyacrylonitrile",
}


def fetch(query: str) -> dict:
    url = 'https://api.crossref.org/works?rows=3&query.bibliographic=' + urllib.parse.quote(query) + '&mailto=integrity-check@example.com'
    req = urllib.request.Request(url, headers={'User-Agent': 'panda-ms-check/1.0'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode('utf-8'))


def main():
    for idx, q in QUERIES.items():
        try:
            data = fetch(q)
            items = data.get('message', {}).get('items', [])
            print(f'=== [{idx}] query: {q[:60]} ===')
            for it in items[:3]:
                title = (it.get('title') or [''])[0][:90]
                journal = (it.get('container-title') or [''])[0]
                year = it.get('issued', {}).get('date-parts', [[None]])[0][0]
                doi = it.get('DOI', '')
                print(f'  - {title} | {journal} {year} | {doi}')
        except Exception as e:
            print(f'[{idx}] ERROR: {e}')
        time.sleep(0.5)


if __name__ == '__main__':
    main()

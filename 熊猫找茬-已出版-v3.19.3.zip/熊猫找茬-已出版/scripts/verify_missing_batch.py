#!/usr/bin/env python3
"""
verify_missing_batch.py — 对 Crossref 标题搜索低分（not_found）的参考文献批量复核

Usage:
    python verify_missing_batch.py <refs.json> <out.json> [--indexes 7,16,28...]

对指定编号的参考文献用 Crossref query.bibliographic 搜索 top-3 候选，
输出候选题录供 agent 人工甄别（特殊字符/缩写导致的自动匹配低分）。
"""
import json
import re
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path


def simplify_title(title: str) -> str:
    """去除特殊字符、压缩空白，便于检索。"""
    t = re.sub(r'[^\w\s\-]', ' ', title)
    t = re.sub(r'\s+', ' ', t).strip()
    return t


def search(query: str) -> list:
    url = ('https://api.crossref.org/works?rows=3&query.bibliographic='
           + urllib.parse.quote(query) + '&mailto=integrity-check@example.com')
    req = urllib.request.Request(url, headers={'User-Agent': 'panda-ms-check/1.0'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode('utf-8'))
    out = []
    for it in data.get('message', {}).get('items', []):
        out.append({
            'title': (it.get('title') or [''])[0][:150],
            'journal': (it.get('container-title') or [''])[0],
            'year': it.get('issued', {}).get('date-parts', [[None]])[0][0],
            'volume': it.get('volume', ''),
            'page': it.get('page', ''),
            'doi': it.get('DOI', ''),
        })
    return out


def main():
    if len(sys.argv) < 3:
        print('usage: verify_missing_batch.py <refs.json> <out.json> [--indexes 7,16]', file=sys.stderr)
        sys.exit(1)
    refs = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    out_path = Path(sys.argv[2])
    indexes = None
    if '--indexes' in sys.argv:
        i = sys.argv.index('--indexes')
        indexes = [int(x) for x in sys.argv[i + 1].split(',')]

    targets = [r for r in refs if indexes is None or r['index'] in indexes]
    results = {}
    for r in targets:
        q = simplify_title(r.get('title', ''))
        try:
            cands = search(q)
            results[r['index']] = {'query': q, 'candidates': cands}
            print(f"[{r['index']}] {r.get('title','')[:60]}")
            for c in cands:
                print(f"    - {c['title'][:70]} | {c['journal']} {c['year']} v{c['volume']} p{c['page']} | {c['doi']}")
        except Exception as e:
            results[r['index']] = {'query': q, 'error': str(e)}
            print(f"[{r['index']}] ERROR: {e}")
        time.sleep(0.4)

    out_path.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f'saved -> {out_path}')


if __name__ == '__main__':
    main()

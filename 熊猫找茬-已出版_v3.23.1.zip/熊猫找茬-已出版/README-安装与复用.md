# 熊猫找茬-已出版 · 安装与复用指引

> 给拿到分享包的同事：这份文件讲**怎么装、怎么用、经验怎么接着往下攒**。
> 规则细节在 `SKILL.md`（含参考文件索引），实战变更记录在 `references/changelog.md`、踩坑清单在 `references/pitfalls.md`，判定口径在 `references/interpretation.md`。

---

## 1. 这是什么

对处于**已接收 / 已出版**阶段的稿件做六维学术诚信辅助筛查，输出一份 HTML 报告。六维同等对待、无模式区分：

| 维度 | 做什么 |
|---|---|
| ① 内容相关性 | 稿件主题 ↔ 期刊 Aims & Scope 语义比对（需本地有该刊记录，否则降级为「未检测」） |
| ② 作者诚信 | 逐作者比对 Retraction Watch 撤稿库（三档：同名·低优先 / 领域相近·需核实 / 需重点核实）+ 机构与领域适配 |
| ③ 参考文献 | Crossref 逐条核验（DOI 优先）+ 撤稿检索 + 年份分布 + 引用统计（含表格单元格） |
| ④ 参考文献语义相关性 | 逐篇比对「引用上下文」与「文献实际内容」是否相符 |
| ⑤ 声明完整性 | COI / 作者贡献 / 研究伦理 / 数据可用性 / AI 使用；有编委名单时对照编委查 COI |
| ⑥ AIGC 痕迹 | 句长变异系数、TTR、提示语密度、首人称、近重复句等启发式指标 |

**前置**：政治敏感词扫描（Taiwan / Tibet / Xizang 及其变体），命中则报告顶部红字提示。

**输出**：`manuscript_integrity_check_report_<YYMMDD>_<稿件号>.html`。
所有结论均为**筛查信号**，不是定性判定，须人工核实后才可用于编辑决策。

---

## 2. 安装（三步）

```bash
# 1) 解压到技能目录，目录名保持「熊猫找茬-已出版」
#    Windows:      %USERPROFILE%\.workbuddy\skills\熊猫找茬-已出版\
#    macOS/Linux:  ~/.workbuddy/skills/熊猫找茬-已出版/

# 2) 装依赖（已锁精确版本，建议放独立 venv）
pip install -r requirements.txt

# 3) 首次运行会自动联网下载撤稿库（约 60MB → data/retraction_watch.csv）
#    网络不通时手动下载后放到 data/：
#    https://gitlab.com/crossref/retraction-watch-data
```

依赖：Python 3.10+；`rapidfuzz`（缺失自动回退 difflib，正确但慢）、`requests`、`pdfplumber`（PDF 稿件必需）、`python-docx`、`defusedxml`。

也可在 WorkBuddy 里用「技能 → 安装技能 → 从 zip 安装」直接装包。

---

## 3. 首次运行会发生什么

1. `data/` 自动创建并下载撤稿库；
2. `assets/journal_scopes.json` 自动从模板生成（**分享包里模板是空骨架，journal 记录需要你自己录**）；
3. `cache/` 首次查 Crossref 时逐步建立（后续同 DOI 不再重复请求）。

所以**开箱第一件事**：把自己刊的 scope 录一条（见第 5 节），否则维度①只会输出「未收录期刊收稿范围」降级提示。

---

## 4. 怎么用

对话里 @熊猫找茬-已出版，给出：

1. **论文文件**（Word / PDF，须含作者信息与参考文献）；
2. **期刊信息**：全名 / 缩写 / Aims & Scope 链接任一，命中本地记录即可只给缩写；
3. 可选：编委名单（页面链接 / PDF / 文字）、要跳过的维度、要重点核的对象。

缺信息不会中断流程：**对应维度标「未检测」并跳过**，其余照常跑。用户显式要求跳过某维度时，该维度在报告里同样标「未检测」，**不输出任何核验结论**（避免"未执行却看似已核验"）。

---

## 5. 录入自己刊的期刊记录

记录分两层，**互不覆盖**：

- `assets/journal_scopes_template.json`：内置模板，随升级覆盖 → **不要往里写个人数据**；
- `assets/journal_scopes.json`：你自己的记录，`load_all()` 时优先于模板，**升级永不覆盖**。

最简单：直接让 agent 录（"把 XX 刊的 scope 记下来，链接是 …"）。
命令行方式（只写缩写/名称/URL/原文四项）：

```bash
cd <skill>/scripts
python -c "import journal_scopes as js; js.save_scope('Energy Materials and Devices','EMD','https://…','<scope 原文>')"
```

其余字段（中文概括 `scope_summary_zh`、编委 `editorial_board` 及来源字段）直接编辑 `assets/journal_scopes.json`，字段含义写在包内模板的 `_fields` 里。

> 编委名单决定维度⑤「COI 对照编委」子项能否执行：**没有名单就是"未检测"，不是"无风险"**。名单在别处更新过（如期刊信息库），记得回写这个文件——两套数据没有自动同步。

---

## 6. 经验怎么复用（重点）

这个 skill 的价值一半在脚本，一半在**踩坑记录**。三个入口：

| 入口 | 内容 | 什么时候看 |
|---|---|---|
| `references/changelog.md` | 每条 = 一次真实稿件驱动的问题定位 + 修法 + 回归结果 | 遇到"看起来像 bug 但说不清"的现象，按关键词搜 |
| `references/pitfalls.md` | 可直接复用的硬坑清单（正则静默失效、PDF 分栏、rapidfuzz 崩溃等） | 动手改脚本前先扫一遍 |
| `references/interpretation.md` | 六维判定口径与措辞标准（什么算风险、什么算未检测） | 写报告结论前 |

**推荐的复用姿势**：新稿撞到新问题 → 定位 → 修脚本 → 跑回归 → 在「变更记录」加一行（版本号 + 触发稿件 + 问题 + 修法 + 回归证据）。这一行就是下一个人省下的两小时。

**新增一种参考文献格式解析的标准动作**（五种格式线都按这个套路加进来的）：

1. 用 `extract_pdf.py` / `extract_docx.py` 拿文本，**不要手写提取**；
2. 抽样 5 条看真实排版（折行、分号、年份位置、DOI 位置）；
3. 新写 `parse_refs_<format>.py`，输出**纯 list** 的 JSON（`crossref_check.py` / `retraction_watch.py` 只吃 list）；
4. 全量跑：解析成功数、字段完整率、失败条目逐条看；
5. 若正文引用是上标数字，配 `superscript_citations.py` + `superscript_contexts.py`（`[n]` 正则在这里全部失效）。

**脚本地图**（都在 `scripts/`，均可独立运行）：

| 类别 | 脚本 |
|---|---|
| 提取 | `extract_pdf.py`（分栏感知）、`extract_docx.py`（深度遍历 sdt/表格）、`extract_doi_anchors.py` |
| 解析 | `parse_refs.py`（EMD 式）、`parse_refs_apa.py`、`parse_refs_apa_wrapped.py`（折行 APA）、`parse_refs_acs.py`（ACS） |
| 核验 | `crossref_check.py`、`retraction_watch.py`、`verify_missing.py`、`verify_missing_batch.py`、`batch_check_refs.py` |
| 引用 | `citation_stats.py`、`superscript_citations.py`、`superscript_contexts.py` |
| 语义 | `semantic_check.py` |
| 其他 | `geo_check.py`、`affiliation_check.py`、`aigc_stats.py`、`common_stats.py`、`journal_scopes.py`、`config.py`、`preflight.py`、`download_retraction_watch.py`、`gen_report.py` |

---

## 7. 排错速查

| 现象 | 原因 / 处理 |
|---|---|
| JSON 读不出来、"数据未就绪" | 脚本结果走 **stdout**、日志走 **stderr**，重定向时**必须分开**：`> out.json 2> out.log`，禁用 `2>&1` |
| 参考文献 > 50 篇时进程静默退出（无 traceback） | rapidfuzz 累积原生崩溃 → 改 `batch_check_refs.py` 分批（默认 40/批） |
| `crossref_check.py` 报 TypeError | 传了 dict 结构；**refs.json 必须是纯 list** |
| 引用统计大面积"未引用" | 破折号字符类缺一种（hyphen / en-dash / em-dash / **U+2212 minus**）；用 `citation_stats.py`，别手写 |
| PDF 提取出 `andtechnology` 之类粘连 | 没走 `extract_pdf.py` 的分栏 + 上下标三条判据 |
| 报告里某维度写"0 篇存在撤稿记录"但其实没跑 | 该维度被跳过 / 数据缺失；正确表现应是「未检测」 |
| 改完文档版号没生效 | 同一文件多处编辑会被整体回写覆盖；**单点小改单独发一次并回读 grep 复验** |

---

## 8. 数据边界（升级安全）

属于**你**、升级/重装覆盖不到的：

- `assets/journal_scopes.json`（期刊记录，含编委名单）
- `data/`（撤稿库）、`cache/`（Crossref 缓存与 RW 索引）
- `work/`、`work_*/`（每份稿件的检测中间结果）
- 你自建的任何脚本

会被覆盖的：`SKILL.md`、`README*.md`、`功能说明.md`、`requirements.txt`、`scripts/*.py`、`assets/report_template.html`、`references/interpretation.md`、`assets/journal_scopes_template.json`。

> 想固化自己的改法：改 `scripts/` 里的脚本没问题（不在个人数据区），但升级会覆盖 → **把你的改法写进「变更记录」，或另存为 `scripts/my_*.py` 并在 SKILL.md 里注明调用点**。

---

## 9. 使用范围

- 报告结论是**筛查信号**，不可作为拒稿/撤稿的直接依据；
- 包内含历史实战案例的稿件编号、作者姓名与机构（写在变更记录里，属经验资产），**仅限编辑部内部流转，勿对外分发**；
- 撤稿库、Crossref 查询有速率限制，批量稿件请串行跑，别并发打接口。

# 熊猫找茬-已出版

对投稿或已出版论文做「六维」学术诚信辅助筛查，输出 HTML 报告。所有发现均为**筛查信号**，非定性结论，需人工核实。

## 功能

| 维度 | 说明 |
|---|---|
| ① 内容相关性 | 论文主题/类型 ↔ 期刊 Aims & Scope 语义比对 |
| ② 作者诚信 | 逐作者与 Retraction Watch 撤稿库比对（领域相近性三档分类，附撤稿 DOI）；作者机构与论文研究领域适配性（机构名称语义比对，两档：适配/不相关，缺机构信息则子项未检测） |
| ③ 参考文献 | Crossref 逐条验证（DOI 优先，其次标题搜索）；撤稿库检索；年份分布统计；引用统计覆盖表格单元格 |
| ④ 参考文献语义相关性 | **逐处**比对每一处引用位置的上下文与文献实际内容（表述一致 / 偏差 / 不相关 / 疑似虚假）；核对正文「人名 + 编号」与文献首作者是否对应；合并引用展开后 ≥5 篇给出「引用堆叠」提示（仅提示，不判定） |
| ⑤ 声明完整性 | COI 利益冲突（有编委名单时对照编委）、作者贡献、研究伦理 |
| ⑥ AIGC 痕迹 | 句长均匀度、AI 提示语密度、首人称、近重复句、词汇多样性等启发式分析 |

**前置扫描**：政治敏感词（Taiwan/Tibet/Xizang，含 Taiwanese/Tibetan 变体，忽略大小写）——命中时在第 0 节输出「政治敏感词命中提示」（红色小字：下列句子含 Taiwan / Tibet / Xizang 等词，仅作提示，是否构成风险须人工判断）+ 句子/所属章节表格（位于稿件基本信息之后）；未命中不显示。

六个维度同等对待，**无模式区分**；某维度所需信息缺失时该维度标「未检测」并跳过，不阻止整体流程。

## 安装

```bash
pip install -r requirements.txt
```

- Python 3.10+，任意环境（venv/conda/系统均可）
- 首次运行会自动联网下载 `retraction_watch.csv`（约 60MB，缓存在 `<skill>/data/`），网络不畅时可手动从 https://gitlab.com/crossref/retraction-watch-data 获取

## 放置位置

解压后放到用户 skill 目录（保持目录名 `熊猫找茬-已出版`）：

- Windows: `%USERPROFILE%\.workbuddy\skills\熊猫找茬-已出版\`
- macOS/Linux: `~/.workbuddy/skills/熊猫找茬-已出版/`

## 使用

在 WorkBuddy 对话中 @熊猫找茬-已出版，并提供：

1. **论文文件**（Word/PDF，须含作者信息与参考文献）
2. **期刊信息**（全名、缩写或 Aims & Scope 链接）

可选补充（提升相应维度检出深度）：编委会名单（⑤ 对照编委核 COI）。

输出：HTML 报告一份（保存到论文所在目录），含六维检查结论（检测结论摘要 + 各维度分节）。报告由 `scripts/gen_report.py` 依据检测结果 JSON（`work/<稿件标识>/`）与 `report_content.json` 自动生成（模板 `assets/report_template.html` 为唯一格式源）。

## 目录结构

```
熊猫找茬-已出版/
├── SKILL.md                    # 技能主文档（规则、工作流、参考文件索引）
├── README.md                   # 本文件
├── 功能说明.md                  # 面向使用者的功能/输入输出说明
├── requirements.txt            # 运行依赖
├── scripts/
│   ├── preflight.py                  # 前置校验（稿件完整性 + 期刊 scope 缓存）
│   ├── extract_docx.py               # docx 深度提取（XML 遍历，覆盖 Mendeley SDT / 表格）
│   ├── extract_pdf.py                # PDF 分栏感知提取（双栏 gutter 切分）
│   ├── extract_doi_anchors.py        # 文献条目超链接 → DOI 锚点（优先验证通道）
│   ├── parse_refs.py                 # 编号式参考文献解析（EMD 惯用格式）
│   ├── parse_refs_apa.py             # APA 式解析（单行 = 单条）
│   ├── parse_refs_apa_wrapped.py     # APA 式 + 双栏 PDF 折行文献表解析
│   ├── parse_refs_acs.py             # ACS 编号式解析（[n] 作者; 标题. 期刊 年, 卷, 页）
│   ├── citation_stats.py             # 正文 + 表格引用统计（四种破折号范围展开）
│   ├── superscript_citations.py      # 裸上标数字引用统计（ACS/Nature 式，字号判据）
│   ├── superscript_contexts.py       # 上标引用的引用语境提取
│   ├── crossref_check.py             # Crossref 真实性验证 + 年份分布（礼貌池并发 3）
│   ├── semantic_check.py             # 语义相关性六子命令（fetch/contexts/pair/instances/authors/report）
│   ├── retraction_watch.py           # 撤稿库检索（作者 / 参考文献）
│   ├── download_retraction_watch.py  # RW 数据下载与新鲜度管理
│   ├── geo_check.py                  # 政治敏感词扫描（Taiwan/Tibet/Xizang）
│   ├── affiliation_check.py          # 作者机构信息提取
│   ├── aigc_stats.py                 # AIGC 定量指标
│   ├── gen_report.py                 # 报告渲染（work JSON + report_content.json → HTML）
│   ├── config.py / journal_scopes.py # 统一配置 + 期刊记录双层数据源
│   └── batch_check_refs.py / common_stats.py / verify_missing*.py   # 辅助工具
├── references/interpretation.md       # finding 解读指南
└── assets/
    ├── report_template.html          # 报告模板（统一章节结构）
    └── journal_scopes_template.json  # 期刊内置记录模板（首次运行据此生成用户文件）
```

## 分享包包含 / 不包含

**包含**：`SKILL.md`、`README.md`、`README-安装与复用.md`（同事侧开箱指引）、`功能说明.md`、`requirements.txt`、`.gitignore`、`scripts/`（全部可复用脚本）、`references/`、`assets/`（报告模板 + **空骨架**期刊模板）。

**不包含**（首次运行自动生成，或属个人/运行数据）：

| 不包含 | 原因 |
|---|---|
| `data/`（retraction_watch.csv，约 60MB） | 运行数据，首次运行自动联网下载 |
| `cache/`（Crossref 响应缓存、RW 索引） | 运行缓存，可重建 |
| `work/`、`work_*/`（逐稿件检测结果） | 稿件工作数据，仅本机留存 |
| `assets/journal_scopes.json` | **个人积累的期刊记录**，升级永不覆盖、不随包分发；首次运行自动从模板初始化 |
| `scripts/gen_report_emd*.py` | 一次性报告脚本（硬编码本机路径与具体稿件信息，在他人环境不可运行）；通用能力见 `gen_report.py` |
| `_user_meta.json`、`*.log` | 本机技能元数据与日志 |

**包内改写**（v3.19.3 起）：`assets/journal_scopes_template.json` 随包分发时替换为**空骨架**（保留 `_readme` / `_fields` 字段说明，`journals: []`）——模板里的期刊记录同属个人整理的期刊信息，不对外分发。

> 因此同事解压后 `assets/journal_scopes_template.json` 是空骨架；首次使用某期刊时提供该刊 Aims & Scope / 编委页，记录写入自己的 `journal_scopes.json`。**录入之前，维度①会显示「未收录期刊收稿范围」**——这是预期降级，不是故障。

## 版本

当前版本 **v3.23.1**，变更记录见 `references/changelog.md`。

## 数据与隐私

- 不采集、不上传任何稿件内容；所有分析在本地 + Crossref/GitLab 官方公开 API 完成
- Retraction Watch 数据仅用于本地比对，不随 skill 分发

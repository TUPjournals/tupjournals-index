---
name: 熊猫找茬-已出版
version: 3.23.1
agent_created: true
description: 熊猫找茬-已出版：已接收/已出版论文的六维诚信辅助筛查，输出 HTML 报告；发现均为待人工核实信号。输入：论文（docx/PDF）+ 期刊名/缩写/收稿范围；首用需录刊，否则①降级；缺信息仅该维降级。触发：诚信核查、点名单一维度（撤稿库快照比对—数据有更新延迟、文献真实性、引用支持度、声明完整性、AI 痕迹）。不触发：入审前初筛（→熊猫找茬-新稿）、AI 率检测（→AI率检测助手）、查重降重、图像数据异常（→paperconan）、代写审稿意见。另含前置合规预筛（命中即提示，不判合规）。
description_zh: 熊猫找茬-已出版：已接收/已出版论文的六维诚信辅助筛查，输出 HTML 报告；发现均为待人工核实信号。输入：论文（docx/PDF）+ 期刊名/缩写/收稿范围；首用需录刊，否则①降级；缺信息仅该维降级。触发：诚信核查、点名单一维度（撤稿库快照比对—数据有更新延迟、文献真实性、引用支持度、声明完整性、AI 痕迹）。不触发：入审前初筛（→熊猫找茬-新稿）、AI 率检测（→AI率检测助手）、查重降重、图像数据异常（→paperconan）、代写审稿意见。另含前置合规预筛（命中即提示，不判合规）。
description_en: 熊猫找茬-已出版 — six-dimension integrity screening for accepted or published papers, output as an HTML report. Findings are screening signals for human verification, not verdicts. Input: paper file (docx/PDF) plus journal name, abbreviation or Aims & Scope; register the journal on first use, otherwise dimension ① degrades; missing information degrades only that dimension. Use for an integrity check on accepted or published papers, or one named dimension (retraction-database snapshot comparison with update lag, reference authenticity, citation-support check, declaration completeness, AI traces). Not for: pre-review screening of new submissions (use 熊猫找茬-新稿), standalone AI-rate detection (use AI率检测助手), plagiarism/similarity checking or reduction, image or data-image anomalies (use paperconan), drafting peer-review comments. A front-end compliance keyword pre-screen is included: hits are flagged, not judged.
author: Hejia Wei
---

# 熊猫找茬-已出版 — 稿件诚信检查（六维检测，缺信息维度标未检测）

## When to use

触发场景：
- 用户说"帮我做诚信检查"、"这篇已接收的稿子核查一下"、"这篇已发表论文核一下"
- 用户提交了论文文件（Word/PDF）+ 期刊 scope 信息（或期刊名）
- 用户提交已出版论文（链接 / DOI / 文件）要求做诚信核查
- 编辑要在**已接收稿件出版前**做一次全维度复核
- 用户提供编委会名单（可选）→ 声明完整性维度可对照编委核对 COI；缺名单仅「COI 对照编委」子项标未检测

**缺信息跳过说明**：
- 六个检测维度（①-⑥）同等对待，**无模式区分**。
- 某维度所需信息缺失时，该维度标「未检测」并跳过，**不阻止整体流程**，也不自行搜索、不猜测、不反复重试。
- 缺信息只影响对应维度（或子项），其余维度正常执行。

**用户指定跳过维度（v3.12.0）**：用户可显式要求跳过某维度（如「跳过参考文献的相关检查」），此时 ③④ 相关维度标 `.info`「未检测」，**报告中不得出现该维度的任何核验结论**。落盘/渲染步骤：
1. `summary.refs` = `{badge:"info", verdict:"未检测", text:"本维度按用户要求跳过：…"}`；`summary.ext` 中 ④ 行（参考文献语义相关性）同法处理。
2. `refs_verify.summary`（必填）与 `refs_citation_issues`、`year_stats_note`、`refs_rw.note` 均写跳过说明。
3. `ext_sections.semantic_refs` 写 `<p><span class="badge info">未检测</span> …</p>`（不含 h2）。
4. ⚠️ **模板第 4 节的表格覆盖不到**：4.1 年份分布表、4.2/4.3 由 content 字段驱动可覆盖，但 **4.4 的 `build_refs_rw_check` 在 `matches` 为空的分支只返回一句话、不追加 note**，会留下「…0 篇存在真实撤稿记录」这一**未执行却看似已核验**的结论。因此生成 HTML 后须用 Edit 将第 4 节整体（`<h2>4 参考文献可靠性检测</h2>` 至 `<h2>5` 之前）替换为「未检测」块（子项状态表 + 说明），并 grep 确认全文无 `0 篇存在真实撤稿记录` 等残留。
5. 与作者维度解耦：作者撤稿检索（3.1）属 ②，**不随参考文献跳过**，照常执行。

## When NOT to use

- **新投稿、入审前的初筛** → 用「熊猫找茬-新稿」（四维、更轻，不需要全文 DOI 解析与逐处语义判定）
- 用户只需要 AI 率检测 → 用 `AI率检测助手` skill
- 用户只需要某单一维度的脚本级结果 → 直接调对应脚本即可；也可走本技能的点名单维度模式（见 description）

## 不做什么（边界清单）

本技能只产「筛查信号」，下列七件事一律不做——每件事都有该去的地方，不要在本技能里找结论。

- **不做文字查重 / 重复率计算**（不读、不判、不复述重复率） → 应改用编辑部既有查重渠道：iThenticate / Crossref Similarity Check / 知网查重出报告。
- **不做图片与数据图像的异常核查**（拼接、重复区域、条带异常、Western blot 等） → 应改用「paperconan」（源数据表统计信号 + 图片资产登记）。
- **不核验伦理批号 / 基金号的真伪**（只核"声明是否写了、是否覆盖研究对象"） → 应改用作者单位伦理委员会批件原件 + 资助机构官网项目库人工核验。
- **不替代同行评审、不评价学术质量**（创新性、方法学、结论强度） → 应走编辑部外审/同行评审流程；只要编校质量意见用「熊猫审读」（它只做编校，不评学术质量）。
- **不做一稿多投 / 重复发表检测** → 应改用投稿系统历史稿件比对 + 查重系统 + 与作者/单位邮件核实。
- **不核验作者身份、ORCID、单位真实性**（只比"机构名称 ↔ 论文领域"适配性） → 应改用 ORCID 公开档案 + 单位官网 / 科研管理部门核实。
- **不受理作者申诉、不出具可申诉结论**（报告是内部筛查信号） → 应走编辑部正式申诉 / 复核流程，由人工重新核查并落书面答复。

## Prerequisites

```bash
pip install -r requirements.txt
```

- `rapidfuzz` — 用于作者名/标题的模糊匹配（缺失时脚本自动回退 difflib，功能正确但较慢）
- `requests` — Crossref API 查询、scope URL 可达性校验
- `pdfplumber` — PDF 输入稿件的文本提取（docx/txt 不需要）
- `python-docx` — docx 正文/表格提取（agent 工作流常用）
- `defusedxml` — **v4.0.0 起（同步新稿 v2.15.0）**：docx XML 安全解析（防 billion-laughs 实体膨胀；缺失时回退 xml.etree 并打警告，功能可用但不防实体攻击）
- Retraction Watch CSV 下载使用标准库 `urllib` 实现（见 `scripts/download_retraction_watch.py`）
- 首次运行需要联网下载 `retraction_watch.csv`（约 60MB），缓存在 `<skill>/data/` 下
- 运行环境：任何装有上述依赖的 Python 3.10+ 即可（示例 venv：`<你的Python环境>/Scripts/python.exe`；本机路径因机器而异，分享后按实际环境替换即可）

## 参考文件索引（何时读哪个文件）

本技能按需读取 `references/` 下的文件，**不要一次性全读**——只有命中下表场景时才打开对应文件：

| 文件 | 内容 | 何时读 |
|---|---|---|
| `references/interpretation.md` | 判定口径细则、红线、badge 语义 | 每次写结论前（必读，约 6 KB） |
| `references/changelog.md` | 版本与变更记录（每版改了什么、为什么改） | 修订规则前、怀疑「某坑以前踩过」时 |
| `references/pitfalls.md` | 运行环境陷阱 33 条（Windows/Git Bash、编码、PDF 提取） | 脚本报错或首次尝试失败时 |
| `references/packaging.md` | 分享包打包规范（白名单、脱敏、可复现构建） | 生成给同事的 zip 时 |

## 分享包打包规范（生成给同事的 zip 时逐条核对）

> 已迁出至 `references/packaging.md`。
> **何时读**：仅在生成给同事的分享包 zip 时读。

## 脚本运行注意（CRITICAL：stdout/stderr 分离）

所有脚本的 JSON 结果输出到 **stdout**，日志输出到 **stderr**（`download_retraction_watch.py` / `retraction_watch.py` 的 `log()` 均为 `print(..., file=sys.stderr)`）。因此：
- 后台/重定向运行时，**必须分离两个流**：`python xxx.py ... > result.json 2> result.log`，**严禁 `2>&1`**。
- 若误用 `2>&1`，stderr 日志会污染 JSON 文件开头，导致后续 `json.load` 失败、报告误显示"数据未就绪"。
- 报告生成脚本读取结果时，应做容错：跳过 JSON 前导的非 JSON 行（定位第一个 `{` 再 `json.loads`），双重保险。
- **`gen_report.py`（报告渲染）**：stdout 只输出**一行机器可读 JSON**（`{"status":"ok"|"warn"|"error","out_file","size","leftover"}`），日志/警告走 stderr；agent 读取 stdout 判断生成结果，`status=error` 时按 stderr 提示修复，`status=warn` 时按 `leftover` 补全 report_content 字段后重跑。

## 运行环境陷阱（Windows/Git Bash 实战经验）

> 已迁出至 `references/pitfalls.md`（33 条实战事故，约 29 KB）。
> **何时读**：脚本报错、路径/编码/PDF 提取异常且首次尝试失败时读；正常流程不必读。

## Workflow（必须按顺序执行）

整体流程共 10 步，各维度所需信息缺失时该维度标「未检测」并跳过：

```
Step 0: 前置输入校验（preflight.py）
  → 校验失败则暂停，向用户提问；通过则继续
  → 盘点各维度所需信息，缺失项对应维度标「未检测」

Step 0.5: RW 数据准备（download_retraction_watch.py）
  → 版本检查 + 判断 + 下载，串行执行一次；确保 CSV 就绪且 FRESH 快筛命中

Step 0.6: 政治敏感词扫描（geo_check.py）
  → 命中 Taiwan/Tibet/Xizang 时，第 0 节输出「政治敏感词命中提示」红字 + 句子/章节表格

Step 1: 维度① — 内容相关性
Step 2: 维度② — 作者诚信与机构适配性（retraction_watch.py + affiliation_check.py）
Step 2.5: 维度⑤ — 声明完整性
Step 3: 维度③ — 参考文献检测（crossref_check.py + retraction_watch.py）
Step 3.5: 维度④ — 参考文献语义相关性核对
Step 4: 维度⑥ — AIGC 检测
Step 5: 生成 HTML 报告
```

**并行规则（CRITICAL）**：
- RW 数据准备（Step 0.5）必须先于任何 RW 查询（Step 2 的 check-authors、Step 3 的 check-refs）**串行完成**；
- 数据就绪后（FRESH 快筛命中、不触发下载），check-authors 与 check-refs **可并行执行**——两者仅只读 CSV，无文件锁冲突；
- **严禁在数据未就绪或可能触发下载时并行**运行两个 RW 查询（并发下载共用 `.tmp` 路径 + `os.replace` 覆盖 vs 读取 → Windows 文件锁冲突，会导致其中一个查询失败一次）。

**检测结果落盘约定（work 目录，CRITICAL）**：
- 每次检测把各脚本 stdout JSON 写入 `<skill>/work/<稿件标识>/`（stdout/stderr 分离：`> xxx.json 2> xxx.log`），供 Step 5 渲染脚本读取。文件名映射：

| 脚本/子命令 | 落盘文件 |
|---|---|
| `geo_check.py` | `geo.json` |
| `parse_refs.py` | `refs.json` |
| `crossref_check.py verify` | `crossref.json` |
| `retraction_watch.py check-authors` | `authors.json` |
| `retraction_watch.py check-refs` | `refs_rw.json` |
| `affiliation_check.py` | `aff.json` |
| `aigc_stats.py` | `aigc.json`（**必落盘**，供 AIGC 定量指标表自动生成） |
| `semantic_check.py fetch` | `semantic_abs.json`（逐条摘要抓取，Crossref+OpenAlex 双源） |
| `semantic_check.py contexts` | `citation_contexts.json`（每条文献的正文引用上下文） |
| `semantic_check.py pair` | `semantic_pairs.json`（摘要+引用上下文合并的逐条比对清单） |
| `semantic_check.py instances` | `citation_instances.json`（每处引用标记的位置表：页 / 栏 / 段落序号 / 字符偏移 / 章节）+ `semantic_instances.json`（「位置×文献」判定单元，含上下文窗口） |
| `semantic_check.py authors` | `author_checks.json`（正文「人名 + 编号」与文献首作者的一致性核对） |
| `semantic_check.py report` | `semantic_refs.html`（报告第 5 节正文）+ `preview_section5.html`（独立预览页，可选） |
| agent 判定 | `semantic_instance_judgments.json`（逐「位置×文献」单元的 verdict + 三段式问题描述） |

- 示例：`python scripts/geo_check.py --text <全文文本> > work/<稿件标识>/geo.json 2> work/<稿件标识>/geo.log`
- 某文件缺失时，对应自动表格在报告中按「未检测」呈现（渲染脚本容错，不中断）。

---

### Step 0: 前置输入校验

**目的**：确保用户提供了完整的检测所需信息，否则暂停并引导用户补充。

调用脚本：
```bash
python scripts/preflight.py --paper <论文路径> [--scope-url <URL>] [--journal <期刊全名>] [--abbrev <缩写>]
```
注：preflight 仅直接解析 Word(docx)/txt；若输入为 **PDF**，**必须先跑 `scripts/extract_pdf.py`**（分栏感知提取，禁止手写 pdfplumber 提取代码），再走 preflight 与后续流程（如 CESCI 稿件处理）：

```bash
python scripts/extract_pdf.py <paper.pdf> <work目录>/out_text.txt <work目录>/out_paras.json
```
输出 `out_text.txt`（阅读顺序：满宽 F → 左栏 L → 右栏 R）/ `out_paras.json`（段落 + col 标记）/ 同目录 `body.txt`（References 之前正文，供 aigc_stats）。stdout 为一行 JSON（含 `gutter_pages`——**为 0 说明未识别出分栏，需人工确认是否单栏稿**）。

脚本返回 JSON（stdout），agent 读取后按以下逻辑处理：

```json
{
  "status": "ok" | "incomplete",
  "paper": {
    "has_authors": true/false,
    "has_references": true/false
  },
  "scope": {
    "source": "url" | "journal_lookup" | "user_input" | "none",
    "url": "...",
    "text": "...",
    "valid": true/false
  },
  "actions_required": []  // 需要用户补充的事项
}
```

**Agent 处理逻辑**：

1. **文件完整性检查**：若 `paper.has_authors == false` 或 `paper.has_references == false`，向用户提示：
   > "检测到文件可能不完整（缺少[参考文献 / 作者信息]）。是否仅对已上传内容做检测？"
   - 用户确认 → 继续
   - 用户拒绝 → 暂停，等待完整文件
   - ⚠️ **has_authors 仅粗检正则**：`(?i)(author|作者)` 会把文末声明 "All authors declared that there are no conflicts of interest." 等字样误判为有作者。即使 `has_authors == true`，agent 也必须人工确认稿件中是否真实存在作者姓名/单位/邮箱；若无（如 Clean/双盲版），按"缺作者名单"处理并询问用户是否提供名单或跳过检查 2。

2. **Scope 信息来源判断**：
   - `source == "url"` 且 `valid == true` → ✅ 通过
   - `source == "url"` 且 `valid == false` → 提示链接无效，执行下方逻辑
   - `source == "journal_lookup"` 且找到记录 → ✅ 通过
   - `source == "journal_lookup"` 且未找到记录 → 执行下方逻辑
   - `source == "none"` → 执行下方逻辑

2.5. **链接内容 vs 本地记录差异比对**（`source == "url"` 时，preflight 自动抓取链接文本并与本地匹配记录的 `scope_text` 比对，输出 `scope.diff`）：
   - `diff.action == "update"`（差异 <10%）→ 用 `diff.fetched_text` 更新本地记录 `scope_text` 与 `updated_at`，告知用户「线上 scope 内容已同步本地记录」；
   - `diff.action == "review"`（差异 ≥10%）→ 提示用户「链接内容与本地记录差异较大（相似度 X%），请确认所提供链接/信息是否正确」，由用户决定是否覆盖，**不得擅自覆盖**（遵循红线①）；
   - 本地无匹配记录 → 无 `diff` 字段，按下方「保存记录」询问是否保存新记录；
   - ⚠️ 机器抓取文本可能含页面噪声（导航/版权/404 页），`diff` 结果仅供参考；若抓取内容明显异常（如 404 页面），请用户人工确认链接有效性或直接粘贴 scope 文本。

3. **首次/非首次判断**：
   - 若 `journal_scopes.json` 中无任何记录（首次运行），询问：
     > "本次为首次检测，请提供期刊全名、缩写、aims & scope 链接或文档。"
   - 若非首次但无匹配记录，询问 scope 信息，并询问是否保存到记录

4. **保存记录**：用户提供信息后，更新 `<skill>/assets/journal_scopes.json`。记录字段：`full_name` / `abbreviation` / `scope_url` / `scope_text` / `added_at`；可选编委名单字段 `editorial_board`（姓名列表）/ `editorial_board_url` / `editorial_board_text` / `editorial_board_updated_at` / `editorial_board_source`——编委名单由用户提供 Editorial Board 页面链接 / PDF / 文字 / 本地名单表时录入，未提供则整组字段留空（或保留 `editorial_board: []`）。**下次运行仅输入期刊缩写（如 `--abbrev EMD`）即可命中本地记录快速调用**；记录含编委名单时，维度⑤「COI 对照编委」子项可直接复用本地名单。

   **编委名单字段口径**（对齐现有 EMD / CES 记录）：
   - `editorial_board`：姓名列表；**领导层标注角色**（如 `Dongping Fang (Editor-in-Chief)`、`Jun Yi (Honorary Editor-in-Chief)`），普通编委只写姓名（不带角色后缀）；
   - `editorial_board_text`：分组人读摘要，格式 `组名 (人数): 姓名1, 姓名2, …`，组间用 `; ` 分隔，中文名可括注在英文名后（如 `Dongping Fang (方东平)`），末尾给 `Total N members.`；
   - `editorial_board_updated_at`：**写入本文件的日期**（非名单本身的版本日期）；
   - `editorial_board_source`：来源与版本（本地源表路径 + sheet 名 + 名单版本日期 + 可比的印刷定稿文件），供日后溯源与判断是否需要更新；
   - `editorial_board_url`：仅当确有**可正常访问**的官方 Editorial Board 页面时才填；不可访问则省略并在 `editorial_board_source` 里说明原因。

   **编委名单补录 / 更新（三步）**：
   ① **取名单**——优先级：本 skill 本地记录 > **期刊信息库**（`panda-kb` 建成的期刊总表 `编委-*` sheet 及其 `templates/journal.<刊>.json` 的 `editorial_sources`，含源文件路径、sheet、分组行、列映射） > 用户直接提供（xlsx / PDF / 文字）；
   ② **核对**——统计总人数与各组人数，与源表逐组对齐；若为更新，与上一版比对增减并回报（名单增减要看得见）；
   ③ **写入**——写前先备份原 `journal_scopes.json`，写后重新加载校验 JSON 合法、总刊数不变、目标刊人数正确。

   **红线②（名单回写）**：编委名单在**信息库侧**更新（或用户在任何其他场合提供过）后，**必须回写本文件 `assets/journal_scopes.json`**，否则本 skill 无从感知，维度⑤「COI 对照编委」子项会静默退回「未检测」。信息库与检测器是**两套独立数据、无自动同步机制**——**不得假设「给过一次就已有记录」**（CES 实证：名单 2026-09-10 已汇入信息库，而本文件最后写入停在 2026-08-21，导致 2026-09-15 检测时编委子项被判未检测）。

   **不抓 CES 官网**：CES 官方页面不可访问 / 不可抓取，其 scope、编委等数据一律从本地文件、期刊信息库或用户提供内容获取，**不得尝试联网抓取**。

5. **维度所需信息盘点（本 skill）**：对照以下清单，逐维度确认本次可用的信息；缺失项对应维度标「未检测」并跳过，不自行搜索、不猜测、不反复重试：
   - ① 内容相关性：论文标题/摘要/关键词 + 期刊 scope 文本（scope 缺失 → 该维度未检测）
   - ② 作者诚信：作者列表 + 全文文本（缺失 → 该维度未检测；机构提取不到 → 仅 2b 机构适配子节未检测，2a 撤稿检索照常）
   - ③ 参考文献：参考文献列表（缺失 → 该维度未检测）
   - ④ 参考文献语义相关性：论文全文 + 参考文献列表 + 联网定位能力（缺任一项 → 该维度未检测）
   - ⑤ 声明完整性：论文声明段 + 编委会名单（**优先复用本地记录 `editorial_board`**；本地无则询问用户提供；均无 → 仅「COI 对照编委」子项未检测，其余子项照常）
   - ⑥ AIGC：论文全文（缺失 → 该维度未检测）
   - **红线①（跳过语义）**：某维度所需信息缺失时，该维度标「未检测」并跳过，**不得自行搜索、不得猜测、不得反复重试**；用户提供的链接被 Cloudflare / 五秒盾拦截、超时或返回非页面内容 → 视为"无法获取信息"，要求用户改传 PDF 或粘贴文字内容；若用户无法提供，则该维度未检测，继续其余维度。

---

### Step 0.6: 政治敏感词扫描

**目的**：扫描全文识别关键词 **Taiwan / Tibet / Xizang**（含 Taiwanese / Tibetan 等词干变体，忽略大小写）。命中任意一个时，在报告中以**第 0 节「政治敏感词命中提示」**红字提示"下列句子含 Taiwan / Tibet / Xizang 等词，仅作提示，是否构成风险须人工判断"，并以表格列出含关键词的完整句子与所属一级标题。

**调用脚本**：
```bash
python scripts/geo_check.py --text <全文文本文件>
```
（全文文本须为 agent 提取合并后的纯文本，含 Title page；与 preflight / affiliation_check 输入一致）

脚本返回 JSON（stdout）：
```json
{
  "status": "found" | "not_found",
  "hits": [
    {
      "keyword": "Taiwan",
      "sentence": "The samples were obtained from Taiwan, China.",
      "section": "Introduction"
    }
  ],
  "note": null | "未检测到 Taiwan/Tibet/Xizang"
}
```

**匹配规则**：
- Taiwan → `\btaiwan\w*`（含 Taiwanese）；Tibet → `\btibet\w*`（含 Tibetan）；Xizang → `\bxizang\b`（精确）；全部忽略大小写。
- 句子按 `[.!?]\s+` 切分提取；章节归属通过识别一级标题（Abstract / Introduction / Methods / Results / Conclusion / References 等，支持数字编号前缀如 "1 Introduction"）确定。
- 命中即提示（不区分 "Taiwan, China" 等表述是否合规——是否为风险由人工判断）。

**Agent 处理逻辑**：
- `status=found` → 填充模板中的 `{{POLITICAL_RISK}}`（位于稿件基本信息之后、第 1 节之前）：
  - 红色小字标注："**政治敏感词命中提示：下列句子含 Taiwan / Tibet / Xizang 等词，仅作提示，是否构成风险须人工判断。**"
  - 下方表格三列：关键词 / 完整句子 / 所属一级标题
- `status=not_found` → `{{POLITICAL_RISK}}` 填充为空字符串，报告中不显示（无任何痕迹）。

---

### Step 1: 维度① — 内容相关性

**输入**：论文标题 + 摘要 + 关键词；期刊 aims & scope 文本（来自 Step 0）

**方法**：
1. 从论文中提取标题、摘要、关键词（读取 Word/PDF 文件；PDF 用 pdfplumber 提取）
2. 读取或获取期刊 scope 文本
3. Agent 做语义比对，判断：
   - 论文主题是否在 scope 列出的领域中
   - 论文类型（research article / review / case report）是否在期刊接受类型中

**输出要求**：
- 第 2 节起始处固定渲染「期刊收稿范围对照依据」块（来源 URL + 版本日期 + 概括性中文收稿范围，**纯文本段落表述，非表格**），由 gen_report.py 自动从 `assets/journal_scopes.json` 读取（`scope_source` / `scope_version_date` / `scope_summary_zh`），**agent 无需手写**
- 相关性分析以 **4 列表格** 呈现（占位符 `{{SCOPE_ANALYSIS_TABLE}}`，数据来自 report_content.json 的 `scope_analysis` 字段，**必填**）：
  - 列：`分析维度` / `稿件特征` / `对应期刊领域` / `匹配度`
  - 匹配度徽章三档：`高度相关`（绿 ok）/ `部分匹配`（黄 warn）/ `不相关`（红 bad）
  - 每行一个分析维度（如研究主题、研究类型），agent 填入稿件特征与期刊领域对应关系
- 如 scope 中无明确对应领域但论文有交叉可能，匹配度标注 `部分匹配`（黄 warn）并在要点中注明"需人工判断"

---

### Step 2: 维度② — 作者诚信与机构适配性

**输入**：论文作者列表（来自 Step 0 解析结果）+ 全文文本

本步骤分两个子步骤：
- **2a 作者撤稿检索**（retraction_watch.py check-authors）
- **2b 作者机构与论文领域适配性**（affiliation_check.py 提取机构 + agent 语义判断；缺机构信息 → 该子节标「未检测」）

#### Step 2a: 作者撤稿检索

**调用脚本**：
```bash
python scripts/retraction_watch.py check-authors --authors "Author1,Author2,..."
```

脚本返回 JSON：
```json
{
  "csv_source": "downloaded_YYYY-MM-DD" | "cached_YYYY-MM-DD" | "download_timeout" | "download_failed" | "cached_YYYY-MM-DD (download incomplete, kept previous version)" | "input_error",
  "authors": [
    {
      "name": "Author Name",
      "hits": [
        {
          "author_in_csv": "...",
          "title": "...",
          "subject": "(ENV) Environmental Sciences;...",
          "retraction_date": "...",
          "reason": "...",
          "institution": "...",
          "original_paper_doi": "...",
          "retraction_doi": "..."
        }
      ],
      "risk": "high" | "medium" | "low" | "none"
    }
  ]
}
```

**Agent 输出要求**：
- 数据来源说明：`downloaded_YYYY-MM-DD` 表示本次刚完成下载；`cached_YYYY-MM-DD` 表示复用本地已有文件（日期为数据源端更新日期 `update_date`）；含 `download_timeout` / `download_failed` / `incomplete`，须向用户提示数据可能非最新或缺失，并给出手动下载地址 https://gitlab.com/crossref/retraction-watch-data；含 `input_error` 表示作者名格式错误，需按提示改用 "First Last" 顺序重试
- 检索方法说明（token-level exact match，防 substring 误报）
- 每位作者的结果：命中数 / 匹配度（如有命中，列出相似论文的 title + subject + institution）
- 整体评估：给出作者存在撤稿记录的可能性大小，**明确提示用户需人工判断**

**三档分类规则（作者领域相近性判断）**：
脚本对每位作者返回 `hits`，命中项含 `subject`（撤稿库学科分类，如 `(ENV) Environmental Sciences`）、`institution`、`retraction_doi`、`original_paper_doi`。agent 据此做**三档提示**：
1. **无命中** → 直接说明"该作者在 Retraction Watch 中无撤稿记录"。
2. **有命中但领域不同（档 2）** → 脚本默认文案**只报事实**（命中条数 + 学科/机构），不做同人比对；agent 判为档 2 时须在 `report_content.json` 的 `author_verdicts` 写入"同名命中，所涉撤稿论文的 Subject/机构与待查稿件领域无交集，据此建议按「同名不同人」作低优先处理"，列出 subject + institution 作为依据，并给 ORCID / 单位复核出口。**档 3 禁止套用本模板**。
3. **有命中且领域相同** → 醒目警示"同名且领域相近，需人工重点核实"，务必列出 `retraction_doi` 供编辑逐条人工核对。

**关键规则**：
- 使用精确 token 匹配（surname + first-name token），防止 substring 误报（如 "Bhattacharya" 中的 "Acharya"）
- 原始命中可能包含大量假阳性，必须做二次校验（同名作者尤其常见，务必比对 subject/institution 判断是否同一人）
- 不在报告中要求用户下载文件，由 agent 完成所有操作
- `--authors` 参数用逗号分隔不同作者，姓名必须用 **"First Last" 顺序**（如 `"Dengyang Guo, Di Yang"`）；若误用 "Last, First" 会被逗号拆成伪作者，脚本已内置校验并返回 `input_error`
- 撤稿检索表格填入报告第 3 节子节「3.1 作者撤稿检索」（占位符 `{{AUTHOR_RESULTS}}`，不含 h3 标题）

---

#### Step 2b: 作者机构与论文领域适配性

**目的**：判断作者机构与论文研究领域是否适配，作为诚信初筛的补充信号。

**调用脚本**：
```bash
python scripts/affiliation_check.py --text <全文文本文件>
```
（全文文本须为 agent 提取合并后的纯文本，含 Title page；与 preflight 输入一致）

脚本返回 JSON（stdout）：
```json
{
  "status": "found" | "not_found",
  "affiliations": ["Shandong Key Laboratory of Intelligent Energy Materials, School of Materials Science and Engineering, China University of Petroleum (East China), Qingdao 266580"],
  "matched_lines": ["a Shandong Key Laboratory ..."],
  "note": null | "未检测到机构信息"
}
```

**Agent 处理逻辑**：

1. **提取不到机构（`status=not_found`）→ 缺信息跳过**：
   - 询问用户："未检测到作者机构信息，是否提供机构名称？"
   - 用户提供 → 用用户提供的机构做适配性判断（来源标注"用户提供"）
   - 用户不提供 → 该子节标注「**未检测（未提供机构信息）**」，不判定适配性（遵循缺信息跳过语义，**禁止**标「通过」或「不相关」）

2. **提取到机构（`status=found`）→ agent 语义判断**：
   - **仅依据机构名称做语义理解，禁止联网搜索机构信息**（不调用 WebSearch/WebFetch 核实机构）
   - 判断方法：机构名称中的领域关键词（Materials / Energy / Chemical / Electrochemical / Battery / Physics / Mechanical / Civil / 材料 / 能源 / 化学 / 电池 等）与论文主题（标题/摘要）交叉比对
   - 两档结果：
     - **适配**：机构领域词与论文主题匹配（如能源材料重点实验室 + 电池论文）→ 直接给结论，**不附提示**
     - **不相关**：机构为完全无关领域（如医学/农业机构投电池论文）→ **必须附提示**："机构名称不含论文领域相关词，但机构可能为跨学科/综合机构（如大学、科学院系统），建议人工检查该机构是否有相关研究团队"
   - 若机构名既无明显领域词、也无法明确判定（如仅"XX University"无院系信息）→ 归入「不相关」并附人工检查提示

**报告输出要求**（填入第 3 节子节「3.2 作者机构与论文领域适配性」，占位符 `{{AFFILIATION_RESULTS}}`，不含 h3 标题）：
- 机构列表（含提取来源：Title page / 正文 / 用户提供）；**机构名称用中文**：中国机构（含港澳台）= 学校+学院，国外机构 = 国名+学校+学院，不含省市/街道/邮编
- badge：`适配`（绿）/ `不相关`（红，附人工检查提示）/ `未检测（未提供机构信息）`（灰 info）
- 判断依据：机构领域词 vs 论文主题词对照
- 注明：本子节判断仅基于机构名称语义，未联网核实机构信息

---

### Step 2.5: 声明完整性检测

**输入**：论文声明段（COI / Author contribution / Ethic 等小节）；编委会名单（**可选**，仅用于 COI 对照编委子项）

**(1) 利益冲突（COI）**：
- 对照编委会名单（如有）：若作者列表出现编委姓名，检查 COI 声明部分是否声明该作者为编委；**无编委会名单时仅「对照编委」子项标未检测，其余子项照常检测**；
  - **无冲突时的写法（v3.22.x 定稿）**：只写结论 + 出处，**不展开比对过程**——「作者非编委（来源：{名单来源}，版本：{版本日期}）」。不要写「逐一比对 13 人无同名交集」这类过程叙述，也不要罗列名单人数与分组；
  - **有冲突时才展开**：列出作者姓名、其在编委会的职务（主编/编委/执行编辑），并说明 COI 声明是否已声明该身份。
- 若某作者所属机构为公司（机构名含 co./ltd./Inc./GmbH 等），检查 COI 声明部分是否声明其公司雇员身份；
- 若 COI 段落形式缺失但无实质冲突，结论写「形式缺失，无实质冲突」，**不得**直接标「通过」。

**(2) 作者贡献**：若文章含 Author contribution（或类似）小节，对照作者列表与声明中姓名是否完全相符；允许姓名简写/缩写/首字母。

**(3) 研究伦理**：若正文出现人类样本/人类被试/实验动物表述，检测是否存在 Ethic（或类似）小节，且是否声明了机构伦理委员会审查情况与参与者知情同意（consent）。

**输出**：三段式 finding 卡片（声明原文位置 / 判定 / 问题分析），无问题则标 `pass`。未提供的子项（如无编委名单）标 `未检测`，**禁止**标「通过」。上述内容填入报告第 6 节（`{{EXT_SECTIONS}}` 后半），h3 按 6.1 利益冲突 / 6.2 作者贡献 / 6.3 研究伦理 / 6.4 致谢·数据可用性·AI 使用声明 分组。

---

### Step 3: 维度③ — 参考文献检测

**输入**：论文参考文献列表（从 Step 0 解析结果中提取）

**参考文献解析（脚本化）**：
```bash
python scripts/parse_refs.py <全文文本> <out_refs.json>
```
从全文 References 节解析 `[n]` 编号参考文献，输出 `index/authors/title/journal/volume/year/page/doi`（与 crossref_check 输入格式一致）：以年份 `(YYYY)` 为锚回溯卷/页/期刊（兼容 `Science, 334 (2011)` 与 `J. Am. Chem. Soc. 135 (2013)` 两种格式）；作者/标题按「首字母缩写+姓」正则分界；行尾 DOI（`https://doi.org/...`）自动剥离并提取到 `doi` 字段（有/无 DOI 均适用）；解析失败项列于 `parse_failed` 供 agent 手工补全（复姓如 R. Van Noorden 可能误判为标题开头，需人工核对）。

- **APA 风格 + 折行（双栏 PDF）**：若稿件为 APA 式著录（`作者 (年). 标题. 期刊 卷, 页码.`）且来自 PDF 提取（文献条目被折成多行、条间夹杂页眉/页脚），用 `python scripts/parse_refs_apa_wrapped.py <全文文本> <out_refs.json>`（先剔噪声、合并续行，再按年份锚定解析；OCE20260029 实测 25/25 条字段完整）。

此步骤分三个子步骤（注：报告章节编号为 4.x，见 Step 5，与本文档工作流子步骤 3.x 编号不同）：

#### 3.0 DOI 锚点提取（优先执行，v3.14.0 新增）

**何时用**：稿件或**其作者/编辑预处理过的「统一格式版」**（文献管理软件导出，条目末带 `[LinkOut]` / `[PubMed]` 标记）可能**在文献条目上挂着超链接**——这些链接就是确定性的 DOI 锚点。**遇到此类稿件（或用户单独提供了这类文件）时，先跑本步再验证**。

```bash
python scripts/extract_doi_anchors.py <docx> --out anchors.json
python scripts/extract_doi_anchors.py <docx> --merge refs.json --out refs_doi.json   # 直接补进 refs.json
```

**收益（CESCI-D-26-00015 受控 A/B 实测，同一 36 篇文献、同一脚本、清空响应缓存冷启动）**：

| 通道 | 耗时 | 真实命中 | 说明 |
|---|---|---|---|
| DOI 直连（31 篇有锚点） | **21.6 s** | 31 条定位 | 无相似标题误配风险 |
| 仅标题检索（0 锚点） | 56.8 s | 30 条定位 | 1 篇被「低分未接受」判为 not_found |

即 **快 2.6 倍，且把 1 篇误判「未找到」救回**。实证结论：**统一格式、带 DOI 锚点的文献表显著优于未统一格式**——应当在稿件接收/退修阶段就向作者索取。同时注意统一化过程可能**反向损伤**著录（该稿有 3 处页码/期号被截断、1 处模板占位符未填），须逐字段比对原稿并回补。

**判读要点**：arXiv 类 DOI（`10.48550/...`）由 DataCite 注册，Crossref 返回 404 属正常，须回退标题检索并标注「引用版本为预印本、建议改引正式发表版本」。

#### 3.1 Crossref 真实性验证

**调用脚本**：
```bash
python scripts/crossref_check.py verify --refs <references_json_file>
```

**验证策略**：

1. **DOI 优先**：有 DOI → 直接 GET `/works/{DOI}`（DOI 大小写不敏感，统一小写），DOI 精确解析的匹配置信度最高。
2. **无 DOI 时标题搜索+评分匹配**：
   - 调用 Crossref query API（`/works?query=标题+作者`），返回最多 3 条候选结果
   - 对每条候选进行**4 维度评分**（满分 8 分）：
     - 标题 token 重叠 ≥ 70% → +3 分
     - 第一作者姓氏匹配 → +2 分
     - 期刊名匹配（支持缩写展开）→ +2 分
     - 年份匹配 → +1 分
   - 取得分最高者，且 **总分 ≥ 4 才接受**该匹配
3. **核对项**（全部来源）：
   - 标题（模糊匹配，忽略大小写）、年份（精确）、第一作者姓氏
4. **额外核对项**（仅标题搜索来源）：
   - 期刊名、卷号、页码
   - ⚠️ **page_mismatch 需人工甄别**：Crossref 常只返回起始页，脚本会把 ref="1563-1572" 清洗为 "15631572" 与 "1563" 比对而**误报** page_mismatch。仅当起始页本身不同（如 ref=4016 vs crossref=4011）才确认为真实差异；起页一致仅格式不同的，按"通过"处理并在报告中说明。
   - ⚠️ **author_mismatch 常见三类误报，报告阶段须人工甄别**：① 多作者文献脚本只取 ref 的**末位姓氏**与 Crossref 第一作者比对（如 "R. Adhikari and D. Gautam" 取 gautam vs adhikari）→ 误报；② `et al.` 占位被当姓氏（ref=al）→ 误报；③ 姓氏引号字符差异（弯引号 D’Ayala vs 直引号 D'Ayala）→ 误报。判据：DOI 精确解析 + 标题/期刊一致时，author_mismatch 一律按比对逻辑误报处理，不构成真实性风险。
   - ⚠️ **CNKI 中文文献无 DOI、Crossref 未收录的甄别（EMD20260111 实测）**：中文期刊（如《广东电力》Guangdong Electr. Power）常无 DOI 且该刊未被 Crossref 收录。此时标题搜索会**误匹配相似英文文献**，产生年份/期刊 mismatch 假象。判据：① 先人工拆分作者/标题/期刊补全元数据（启发式：作者按「首字母缩写+姓」、标题到首个期刊名句点）；② Crossref 查不到属预期，判「**无法定位，非真实性风险**」，**不可据标题误匹配标真实性问题**；③ 报告 4.3 节按「无法定位（未收录）」列出并在处理建议中请作者补 DOI 便于核验。

**礼貌池与并发**：请求通过 `mailto` 参数加入 Crossref 礼貌池（限速 10 req/s、并发上限 3），脚本以并发 3 执行，429/5xx 自动指数退避重试，避免限流误判 not_found。

**输入 JSON 格式**（增加字段）：
```json
{
  "index": 1,
  "title": "...",
  "authors": "Author1, Author2",
  "year": "2020",
  "journal": "Journal Name",
  "volume": "12",
  "page": "1234",
  "doi": "10.xxx/yyy"
}
```

#### 3.2 发表年份统计

**调用脚本**：
```bash
python scripts/crossref_check.py year-stats --refs <references_json_file>
```

输出按 5 年跨度的年份分布表格（**零计数分桶同样列出**，含 `≤2000` / `≥2026` 两端与 `合计` 行；与 `scripts/crossref_check.py year-stats` 的输出保持一致，不得过滤空行——v3.15.0 修复）：
| 年份区间 | 数量 | 占比 |
|---|---|---|
| ≤2000 | N | X% |
| 2001-2005 | N | X% |
| 2006-2010 | N | X% |
| 2011-2015 | N | X% |
| 2016-2020 | N | X% |
| 2021-2025 | N | X% |
| ≥2026 | N | X% |
| 合计 | N | 100% |

> 脚本 `gen_report.py::build_year_stats_table` 读 `refs.json` 现场分桶（不依赖 `yearstats.json`），两端区间与合计行必须齐全，否则读者无法判断「±两端确已纳入统计」。

#### 3.3 Retraction Watch 撤稿检索

**调用脚本**：
```bash
python scripts/retraction_watch.py check-refs --refs <references_json_file>
```

匹配优先级：
1. **DOI 锚定优先**：参考文献的 `doi` 与撤稿库 `OriginalPaperDOI` 精确匹配（大小写不敏感）→ 最高置信（`match_type="doi"`, `confidence="high"`）。
2. **标题模糊匹配**：DOI 无命中时，用标题做 `token_sort_ratio` + `partial_ratio` 模糊匹配，**阈值 ≥ 90**，忽略大小写。命中项含 `match_type="title"`，`confidence` 为 `high`（≥95）或 `review`（90–95，需人工复核）。
3. **去噪过滤（双向子串型误报，v3.11.1 补规则 B）**：命中需同时通过两条过滤，否则不报告——
   - **规则 A（撤稿库侧短条目）**：命中标题（撤稿库条目）的 token 数 ≤ 3，且与 ref 标题的共同单词数 ≤ 3 → 过滤。解决撤稿库 1-3 词占位条目对长 ref 标题 `partial_ratio` 高分命中（实测：EMD20260109 [115] 被单词条目 "Monitoring" 100 分命中）。
   - **规则 B（文献侧短通用短语）**：ref 标题 token 数 ≤ 4、其 token 集合**完全包含于**命中标题，且命中标题 token 数 ≥ 2 倍 → 过滤。解决反方向子串误报：文献标题本身是通用短语（"Compressed sensing" / "Convex Optimization"），恰为某条主题完全不同的撤稿标题的子串而拿满分（实测：CESCI-D-26-00025 [23] "Compressed sensing" 100 分命中肺部超声撤稿文；CESCI-D-26-00019 [34] "Convex Optimization" 100 分命中在线凸优化撤稿文）。
   - **反向保护**：同一篇的「正标题 vs 正标题+副标题」情形，ref token 数通常 ≥ 5 或命中标题不满足 2 倍关系，不会被规则 B 误杀（回归验证：Kincho 稿 [32] SLAM part I、cesci20260019 [32] 均保留）。实现见 `check_reference_titles` 内 `_common_word_count` 与规则 B 分支。

**Agent 输出要求**：
- 命中的参考文献编号 + 标题 + 撤稿原因 + 匹配类型（doi/title）+ 置信度 + `retraction_doi`
- 如无命中，说明"0 篇参考文献存在撤稿记录"
- 如有命中，提示用户核实这些被撤稿文献是否影响本文论证（`confidence="review"` 的尤其需人工确认）

**Agent 综合输出结构**（报告章节编号为 4.x，见 Step 5）：
```
#### 3.4 引用分布与著录自检（v3.23.0）
```bash
python scripts/refs_audit.py --refs <work>/refs.json --paras <work>/out_paras.json \
    --body <work>/body.txt --crossref <work>/crossref.json --authors <work>/authors.json \
    --out <work>/refs_audit.json
```
- 只出数据、不写文案；四类数据分别喂给 4.2 的 ①②③④ 块。
- 稿件侧姓名一律以 `out_paras.json`（原始提取）为准——文献表可能已被人工修过或被 `et al.` 截断。
- `crossref.json` 需含 `crossref_authors`（v3.23.0 起 `crossref_check.py` 落盘）；无基准的条目自动降级为「列出非 ASCII 姓名」。
- 缺 `gen_report` 校验：4.2 缺子块/顺序错/写了「统计口径」「缺 DOI」时，`gen_report` 会在 stdout 的 `warnings` 里报，但不阻断渲染。


### 4.1 发表年份分布
[年份分布表格]

### 4.2 引用分布与著录
数据一律取自 `work/<稿件标识>/refs_audit.json`（`scripts/refs_audit.py` 生成）。**禁止手算引用数、禁止自行判定重复**。固定四块，顺序与圈号不得调整。

**① 正文引用覆盖**（必写，1–3 句）
- 写：文献总数 / 被正文引用篇数 / 未引用编号（无则「未引用 0 篇」）/ 超范围引用编号（无则「0 处」）。
- **不写**：统计口径说明（如「统计口径覆盖正文段落与全部表格单元格」）、区间展开过程与区间清单、脚本名与版本。区间展开仍在脚本内执行，但不写进报告。
- 条件句：仅当 `co_ascending.violations` 非空时，末尾追加「另有合引编号未升序 N 处：[a,b]…」；0 处不写此句。

**② 重复引用**（必写，1–3 句）
- 口径：文献表内两两标题归一化后相似度 **≥0.80** 即提示「可能存在重复」，**不看编号是否重复**。
- 写：命中对数；逐对写「[a] 与 [b]，相似度 0.XX」；统一结论「可能存在重复，需人工判断」。
  `level=near_identical`（≥0.95）的对加「标题几乎一致，优先核对是否同一文献的不同版本」；`same_first_author` 为真时补「两者为同一作者的系列论文」。
- **不写**：「重复著录」「应合并」「建议删除」等判定性结论；不写相似度算法。
- 无命中：写「未发现标题高度相似的重复条目（阈值 0.80）」，可附最高相似度对供复核。

**③ 自引分布（中性观察）**（必写，2–4 句）
- 写：作者本人文献编号清单 + 篇数 + 占比 + 一句中性说明（「属常见情形，不构成风险信号」）。
- `self_citation_candidates` 只是姓氏候选（常见姓会误命中），**必须逐条确认作者身份后才写入**；无法确认时写「按姓氏初筛 N 篇，作者身份未确认，供参考」。
- **不写**：「自引率偏高」「需警惕」「自引操纵」等风险判断；不与其他稿件横向比较。
- `authors.json` 无作者信息时写「作者信息缺失，自引未识别」，不得猜测。

**④ 作者姓名用字**（必写，1–4 句）
- 有 Crossref 基准且命中：写「[n] 原文「X」应为「Y」（疑似变音符缺失）」，并给合计条数。
- 有基准无命中：写「未发现姓名用字与 Crossref 著录不一致」。
- 无基准（`basis="none"`，即 Crossref 未命中）：列编号 + 姓名，注明「无外部基准，仅列出供校对」，并声明「此类条目无法识别变音符缺失，需人工核对」。
- **不写**：把「疑似」写成「应为/错误/错字」；不写 DOI 缺失、著录风格、条目要素。

- **agent 经验补位（v3.23.1）**：对 `names.unbaselined_indexes` 中的条目，须逐条目视 `raw_surnames`，基于对该作者/该文献的先验知识判断是否存在变音符缺失、字母错漏、姓名与文献不匹配。
  - 有把握时写：「[n] 原文「X」疑为「Y」（依据：模型对该作者姓名的先验知识；该条无 Crossref 基准），建议核对原始出版物」；
  - 无把握时**不写**，不得猜测，也不得为凑数把正常姓名标为可疑；
  - **禁止**写成「错误/应为/错字」等定性表述；**不得改动或推翻有基准条目的脚本结论**（脚本优先，agent 只补位）；
  - 两类发现合并表述时须分别标明依据（「经 Crossref 著录比对」vs「依模型经验判断」）。

**⑤ 已删除的三块（禁止恢复）**：著录完整性（含缺 DOI 清单）、著录风格、文献条目要素。
DOI 不是必著录项：**不得把「缺 DOI」计为风险或列清单**；确需补 DOI 时，只在 4.3「无法定位」条目的处理建议中提。
### 4.3 Crossref 真实性验证
- 总数 N，带 DOI 的 M 篇，无 DOI 的 K 篇
- 核验后通过 X 篇（仅汇总数量，**不逐一列出**）
- 信息不一致/无法定位 Y 篇以表格形式列出（文献编号、差异所在/原因）；无不一致则不显示表格
- 「页码起页一致、仅格式差异」按通过处理（见上文 page_mismatch 甄别规则）

### 4.4 Retraction Watch 撤稿检索
[命中结果或"0 命中"]
```

---

### Step 3.5: 参考文献语义相关性核对（全检不抽样）

**输入**：论文全文引用上下文 + 参考文献列表（Step 0 解析）

> **强制工具链（v3.20.0 起：判定粒度下沉到「引用位置」）**：本步骤必须运行 `scripts/semantic_check.py`——对**每一处引用标记**取上下文、对**每一篇**文献取摘要，再由 agent 逐「位置×文献」单元判定。**禁止**仅凭 Crossref 书目命中、或只对每篇文献给一个总评，即下「语义一致」结论。
> ```bash
> # 前置：PDF 必须先跑 extract_pdf.py，instances 依赖 out_paras.json（段落级坐标）
> # ① 摘要抓取：Crossref（复用 crossref_check 缓存/API）→ 无摘要则 OpenAlex 兜底（inverted index 重建）
> python scripts/semantic_check.py fetch --refs work/<稿件标识>/refs.json --out work/<稿件标识>/semantic_abs.json
> # ② 引用位置表：逐处抽滑窗（前 140 / 后 220 字符），带 页/栏/段号/字符偏移/章节 定位，**不截断**
> python scripts/semantic_check.py instances --paras work/<稿件标识>/out_paras.json --refs work/<稿件标识>/refs.json --abs work/<稿件标识>/semantic_abs.json --out work/<稿件标识>/citation_instances.json --out-instances work/<稿件标识>/semantic_instances.json
> # ③ 作者与编号一致性核对（必查项，不依赖摘要即可判定）
> python scripts/semantic_check.py authors --instances work/<稿件标识>/citation_instances.json --refs work/<稿件标识>/refs.json --judgments work/<稿件标识>/semantic_instance_judgments.json --out work/<稿件标识>/author_checks.json
> # ④ 第 5 节正文生成（脚本渲染，不再由 agent 手写 HTML）
> python scripts/semantic_check.py report --instances work/<稿件标识>/semantic_instances.json --judgments work/<稿件标识>/semantic_instance_judgments.json --author-checks work/<稿件标识>/author_checks.json --out-html work/<稿件标识>/semantic_refs.html
> # 兼容通道：ACS 裸上标引用或仅需文献级总评时，仍可用旧三子命令 fetch / contexts / pair
> ```
> **摘要覆盖口径**：摘要可得（Crossref 或 OpenAlex）→ 按摘要比对；双源均无摘要（书章/会议/经典文献/中文期刊常见）→ 用 Crossref 全维命中书目 + 标题主题级比对**降级处理**，报告中必须标注「仅元数据」篇数与编号，不得与摘要级混同、也不得因此标「无法核实」跳过；双源均无法定位 → 人工联网核实后归「经人工核实」或「无法核实」并说明原因。
> **判定记录**：agent 逐「位置×文献」单元比对后写入 `work/<稿件标识>/semantic_instance_judgments.json`（每条含 `instance_id` / `ref_index` / `position_id` / `verdict=ok|flag` / `evidence_level` / `context_quote` / `ref_actual` / `analysis` / `likely_benign`），报告第 5 节只呈现统计与问题项（用户口径：只报告问题项）。

对正文中的**每一处引用位置**逐一执行（同一文献在正文出现多次时，各处分别判定）：

#### 3.5.1 定位与取证
(1) 定位（按优先级递减）：DOI 检索 → 标题检索 → 卷/期号检索（WebSearch + WebFetch / Crossref API）。
(2) 获取程度分级（报告第 5 节按此统计，**摘要级与仅元数据级必须分列**）：
    - **摘要级**：Crossref/OpenAlex 抓到摘要，按摘要内容比对；
    - **仅元数据级**：双源无摘要但 Crossref 书目全维命中，按「标题主题 + 引用语境」降级比对（书章/会议/经典文献/中文期刊常见，报告中标注「仅元数据」篇数与编号）；
    - **人工核实**：双源均无法定位，联网检索核实（含无 DOI 文献）；
    - **无法获取**：联网检索后仍无任何可核实内容。
(3) 记录候选文献的题名、期刊、年份、作者、摘要/关键段落。

#### 3.5.2 数据质量门槛
以下情况**不得**标为「可比对」或「内容一致」：
- 元数据解析失败，仅有书目条目；
- 命中候选为 `Author response`、`Back Cover`、`Front Matter`、`Editorial`、`Table of Contents` 等非研究型条目；
- 候选主题与论文主题明显跨域；
- 标题被截断或无法读取完整信息。

上述情况一律归入「无法核实」并在报告中列出。

#### 3.5.3 语义判定（必须由 agent 完成，逐「位置×文献」单元）
(1) **判定单元 = 引用位置 × 文献**：一处合引 `[10,11]` 含 2 篇即 2 个单元，共享同一上下文窗口；同一文献在正文出现 N 次即 N 个单元，**不得合并成一个总评**（v3.20.0 取消 `WIN_LIMIT=3`——OCE20260027 实测该截断会丢 10 处位置）。判定时按 `instance_id` 取该处窗口，窗口即该次判定的全部证据。
    - **双栏 PDF 陷阱（OCE20260026 实测）**：pdfplumber 会把左右栏文本拼进同一行流，导致引用标记的宿主句被错栏碎片污染（引用句看似挂在无关内容后）。处理：先回 `fulltext.txt` **行级**原文核实；仍无法还原宿主句时，**不得**据此判「不相关/误引」，按其标题主题与所在章节语境降级判定，报告标注「引用位置受版式限制建议核对」（如 OCE [71]）。
(2) 阅读候选文献的实际内容（摘要或全文）。
(3) 判断论文中的描述是否与候选文献一致：
    - **表述一致**：论文对该文献的贡献、结论、数据描述准确；
    - **表述偏差 / 描述不一致**：论文概括、夸大、歪曲了文献内容；
    - **文献不相关**：文献主题与论文论点无直接关联，不能支撑当前引用位置；
    - **疑似虚假 / 无法核实**：查无此文献、出版信息矛盾、或无法获取任何可核实内容。
(4) 对存在问题的文献生成 **三段式 finding 卡片**：
    - **引用上下文**：论文中引用该文献的原文句子（必须引用，不得省略）；
    - **文献实际内容**：该文献实际研究主题与结论；
    - **问题分析**：为何判定为偏差/不相关/虚假，并附 `likely_benign` 良性解释（如适用）。

#### 3.5.4 去噪规则
- **禁止**使用「关键词无重叠即提示」等机械规则。
- 宽泛背景引用、领域综述、方法论文献若与论文主题无直接矛盾，**不出 finding 卡片**，仅在经核实列表中体现。
- 只有 agent 明确判定为「不相关」「描述不一致」「虚假」时才写入报告。

#### 3.5.5 作者与编号一致性核对（必查项，v3.20.0）
正文「Surname et al. [n]」形式的人名必须与该编号文献首作者一致——这是比「主题不相关」更硬的问题，且不需要摘要即可判定。

- **只核对「人名 + 本位标记」**：`instances` 为每个位置记录 `ctx_own_idx`（本位标记在折叠空白后的窗口内精确索引），`authors` 只认该处标记前后紧邻的人名。窗口 140/220 字符内会顺带扫到邻近位置引用的人名，若不排除，同一个 `Berger and Loutre [35]` 会在报告里出现两行、位置与摘录完全相同（OCE20260027 实测：正文各只出现 1 次，却被计为核对 9 处，实为 7 处，v3.21.1 修复）。
- 用 `semantic_check.py authors` 自动核对，**不得手工抽查**；非人名词（`Project [27]`、`ISOOS [44]` 这类全大写词或停用词）由脚本自动跳过，`skipped` 计数须在报告前导段体现。
- 姓氏比对已做变音符归一（`Pälike` vs PDF 丢失变音的 `Plike` 判为同一人）+ 相似度阈值 0.85 + 首字母守卫——**`Müller` 与 `Miller` 相似度 0.833，必须判为不同**，否则会误导作者改错编号（OCE20260027 实测事故）。
- 不一致时脚本按三种情形给结论，**结论强度不得超出实际核过的范围**：
  - **A 同篇合作者**（该名是 `[n]` 的第 2 位及以后作者）→ 编号可能无误，建议改为第一作者；若该处语义核对为「不符」，则说明仅改名不足以修正，须更换文献。
  - **B 他篇首作者**（该名是另一篇 `[m]` 的第一作者）→ 列候选编号与标题，建议人工核对是否改引；**不做标题词重合度排序**（排序会暗示强弱，v3.20.0 已撤掉）。
  - **C 无法定位**（既非 `[n]` 首作者，也非文献表中任何一篇的首作者）→ 只陈述这两项可核事实 + 「建议人工检索该作者的原始文献」，并说明可代为检索。**未做全表作者检索，禁止推断「该文献未列入参考文献表」**（该推断曾把可定位的编号错配误判为漏列文献）。

#### 3.5.6 报告呈现
- 第 5 节正文由 `semantic_check.py report --out-html` 直接生成，**不再由 agent 手写 HTML**（脚本内建 `rich()` 白名单预检，出现 `colspan/rowspan`、`style/id/href`、`{{` 一律 exit 2）。
- 结构固定为五段：① 统计段（位置数 / 合引数 / 单元数 / 文献数 / 完成判定数 / 无明显问题数 / 无法核实位置数 / 未引用文献数）；② 获取程度表（摘要级 / 仅元数据 / 无法核实**必须分列**）；③ 固定小字口径说明 + 作者核对结论（有错配才出表）；④ **引用堆叠提示**（有才出）；⑤ 问题卡片 `问题 N · pX · [m]` + 无法核实位置清单（有则列，无则不占篇幅）。
- **引用堆叠提示（v3.21.0）**：合并引用展开去重后 ≥ 5 篇（`--stack-min` 可调，默认 5，`0` 关闭）即提示「可能存在引用堆叠」，**仅提示、不判定**——不产生 verdict、不加徽章、不进问题卡片、不计入判定单元口径。口径边界：只覆盖进入位置表的引用标记（图表标题行已排除）、倒序区间（如 `[40-35]` 展开为空集）不纳入。
- **前导段的「无问题」结论**：仅当堆叠检查启用且**无堆叠**时输出「无引用堆叠（≥ 5 篇）问题。」；若作者核对同时**已执行且无错配**，再追加「作者与编号一致性核验无误。」。有堆叠时不追加（由堆叠段自行说明）；作者核对未执行不得冒充「核验无误」——`checked=0` 视为未核。
- **列表的位置列一律带上下文摘录（v3.21.0）**：堆叠表与作者核对表的「位置」列写成 `pX · 栏 · §节 —「…摘录…」`，摘录以引用标记（堆叠）或人名（作者核对）为中心、前后各约 38 字符、按词边界截断，便于在 PDF 内直接搜索定位；**不显示 `P00xx` 判定单元编号**（编号仅存于 JSON，供回查）。窗口内出现同名标记时，取「距本位标记预期位置最近」的一个（预期位置 = `min(WIN_PRE, len-WIN_POST)`），否则 `find()` 会取到相邻位置的标记（P0025 实测踩坑）。
- **只报问题项**：一致的位置只给数字，不逐条列出；卡片三段式为「引用上下文 / 文献实际内容 / 问题分析 + 良性解释」。
- 徽章类型：`文献不相关` / `表述不一致` / `表述夸大` / `疑似编号错配` / `无法核实`。**「疑似编号错配」须单独标注**——它与「文献不相关」的处置不同（前者改编号即可，后者需换文献）。

---

#### 3.5.7 重跑语义链路的副作用（v3.22.0）
- `instances --out-instances` 会重建 `semantic_instances.json`。脚本自 v3.22.0 起**合并保留**既有
  `source_suspect` / `suspect_reason` 与因此降级的 `evidence_level`，不再像旧版那样写回 `None`
  （旧版实测：重跑后 4 条人工标注全灭、2 处档位被打回 `abstract`）。
- 但**新增或删除的引用位置仍需重新核验**：合并只按 `instance_id` 匹配，位置变了就是新单元。
- 摘要可信性核验（`source_suspect`）目前**仍是 agent 手工步骤**，不是脚本结论；报告里的
  「其中 [n] 经核验为 Crossref 同题异著」一行由该标记驱动，无标记时不出现。

### Step 4: 维度⑥ — AIGC 检测

**输入**：论文全文文本（正文）

**方法（脚本算指标 + agent 判级）**：

1. **定量指标由脚本计算**（确定性、可复现，避免 agent 手算慢且易错）：
   ```bash
   python scripts/aigc_stats.py <全文文本文件>
   ```
   输出 JSON（stdout）：`word_count` / `sentence_count` / `avg_sentence_len` / `sentence_len_cv` / `ttr` / `ai_phrase_total` / `ai_phrase_density_per_1000` / `ai_phrases`（19 个短语逐项计数）/ `first_person_count` / `near_duplicate_pairs`。脚本自动排除 References 节（独立行标题 / 带编号标题 / 回退首个 `[N]` 文献行）。
   **输出必须落盘**：`python scripts/aigc_stats.py <全文文本> > work/<稿件标识>/aigc.json 2> work/<稿件标识>/aigc.log`（Step 5 渲染脚本据此自动生成 AIGC 定量指标表）。

2. **agent 定性分析**（脚本无法替代的部分）：
   - **引用空洞**：检查是否有"研究表明…"类无具体出处的断言（脚本不统计此项）
   - **综合判级**：基于脚本指标做判断——AI 提示语密度 >2/千词 可疑、>5/千词 高度可疑；句长 CV >0.7 异常均匀；首人称完全缺失为附加信号；命中短语是否含强 AI 特征词（delve into / pivotal role / underscores 等）
   - 结合学科特点权衡（如材料类论文 "significantly" 高发常见于非母语作者），给出 `未见痕迹` / `轻度可疑` / `高度可疑`

**输出要求**：
- 定量指标表格（词数、句数、平均句长、句长变异系数、TTR、AI 提示语密度、首人称次数、近重复句数）——直接取脚本 JSON 填表
- 命中 AI 提示语的具体列表（脚本 `ai_phrases` 字段）
- 引用空洞检查结果（agent）
- 综合判断：`未见痕迹` / `轻度可疑` / `高度可疑`
- 附注：此为启发式筛查，非确定性判定，建议配合专业 AIGC 检测工具交叉验证

---

### Step 5: 生成 HTML 报告

**流程（固定渲染脚本模式）**：
1. 各检测脚本结果已按「落盘约定」写入 `<skill>/work/<稿件标识>/`（含 `aigc.json`）；
2. Agent 完成各维度**判定**（内容相关性 4 列分析、机构适配结论、引用分布、Crossref 人工甄别、④ 语义相关性、⑤ 声明完整性 finding、⑥ AIGC 综合判级等），写入 `work/<稿件标识>/report_content.json`（字段见下；只放判定内容，数据表格由脚本自动生成）；
3. 运行渲染脚本：
   ```bash
   python scripts/gen_report.py --work work/<稿件标识> --content work/<稿件标识>/report_content.json --out <输入稿件所在目录> --msid <稿件标识>
   ```
   - 脚本读取 work 检测 JSON + report_content.json + `assets/report_template.html` → 输出 HTML；
   - stdout 为一行机器可读 JSON：`{"status":"ok"|"warn"|"error","out_file","size","leftover"}`；`status=error` 时按 stderr 提示修复；`status=warn` 表示有残留占位符（`leftover` 列出），需检查 report_content 字段；
   - 自动生成的数据表格：稿件基本信息中「参考文献/撤稿数据库版本/检测工具(含生成日期)」、政治风险（`geo.json`）、作者撤稿检索表与受检作者（`authors.json`）、发表年份分布（`refs.json`）、撤稿检索（`refs_rw.json`）、AIGC 定量指标表与提示语明细（`aigc.json`）。
   - **v3.19.0（F-01）所有动态值经 HTML 转义后注入**（含稿件标题/作者/机构/摘要要点、撤稿库作者/标题/撤稿原因、scope 来源与概述、agent 手写的 HTML 字段）；**转义双轨**：纯文本走 `esc()`（全量 `html.escape`），agent 手写 HTML 的字段走 `rich()`（先全转义、再按白名单放行无属性格式标签与 `class`，并对预写实体做幂等保护，避免 `&amp;` 二次转义为 `&amp;amp;`）；**任何新增动态内容渲染时必须经过转义，禁止直接拼接**。历史 `report_content.json` 中手写的 `<table>/<div>/<h3>` 等结构标签由 `rich()` 白名单覆盖，无需改写。

**report_content.json 字段说明**（`schema_version: 1`；徽章用 `{"badge":"ok|warn|bad|info","verdict":"文案"}` 表达，脚本渲染徽章 HTML）：

| 字段 | 必填 | 说明 |
|---|---|---|
| `meta.manuscript_id/title/authors/affiliations/journal/manuscript_type/files` | 是 | 稿件基本信息 7 字段（机构用中文：学校+学院） |
| `manuscript_domain` | 否 | 稿件领域短语（如 `固态电池硅碳负极`），供作者撤稿说明自动生成 |
| `summary.relevance/author/refs/aigc` | 是 | 摘要表 ①②③⑥ 四行，各 `{badge, verdict, text}`；`verdict`=仅风险徽章文案（无风险/低风险/需修改/需修订），`text`=「要点」列全文（须以判定短语开头，如 `高度相关，…`）；未检测时 `{badge:"info", verdict:"未检测", text:"原因"}`。**要点列只写汇总数据**——禁止出现作者名、撤稿数据库版本、具体机构名、文献编号、AIGC 特征词汇（如 comprehensive×6）等细节（与新稿 v2.11.0 同步） |
| `summary.ext` | 否 | 摘要表 ④⑤ 两行 `[{label, badge, verdict, text}]`；label 须含圈号（`④ 参考文献语义相关性` / `⑤ 声明完整性`）——脚本**按 label 中的名称认行**（历史稿写 `⑥ 参考文献语义相关性` 亦可识别），不依赖数组顺序。缺省→脚本渲染两行 `.info`「未检测（子项未提供）」。⚠️ **必须嵌套在 `summary` 内**——写成顶层 `summary_ext` 会被静默忽略（不报错、`leftover` 为空）；生成后须 grep 确认 ④⑤ 行使用的是你写的文案 |
| `scope_analysis` | 是 | 第 2 节 4 列表格数据 `[{dimension, paper_feature, journal_area, match}]`（列：分析维度 / 稿件特征 / 对应期刊领域 / 匹配度）；`match` 内 `badge` 三档 `ok`=高度相关 / `warn`=部分匹配 / `bad`=不相关，徽章文案键 **`verdict` 与 `text` 均可**（脚本取 `verdict or text`）——历史数据多用 `text`，早期文档写 `verdict`，二者兼容；若只写其中一个即可（**曾出现整列显示「未判定」的踩坑，即键名写错且无兜底**）。**第 2 节的「期刊收稿范围对照依据」段与表头均由脚本自动渲染，agent 不写**；缺失→脚本输出 `.info`「内容相关性分析未执行」占位 |
| `affiliation_results` | 是 | 3.2 节机构适配结果（HTML，机构用中文） |
| `refs_citation_issues` | 是 | 4.2 节引用分布与著录问题（HTML） |
| `refs_verify.summary` | 是 | 4.3 节前导段（总数/通过数/问题数）——**必须 agent 写**（crossref.json 原始计数是复核前数据，不能自动算） |
| `refs_verify.issues` | 否 | 4.3 节问题表行 `[{ref, issue}]`；空/缺省→不渲染表格 |
| `refs_verify.manual` | 否 | 人工复核明细 `{index: note}`；存在时渲染为「人工复核明细」note |
| `refs_rw.verdicts` / `refs_rw.note` | 否 | 4.4 节每条匹配的判定（如 `误报`）与表下说明 |
| `year_stats_note` | 否 | 4.1 节年份表下解读 note |
| `aigc_judgments` | 否 | AIGC 指标表「判断」列覆盖 `{metric: 文案}`（未覆盖行由脚本阈值规则自动算） |
| `aigc_note` | 是 | AIGC 节综合判断段（脚本自动在其前加「命中提示语明细」行） |
| `ext_sections.semantic_refs` | 否 | 第 5 节「参考文献语义相关性检测」小节正文（HTML，**不含 h2 标题**——5 节与 6 节标题均由 gen_report.py `build_ext_sections` 统一生成，content 字段自带 h2 会产生重复标题）；缺省→`.info`「未检测（子项未提供）」占位。**v3.20.0 起该字段由 `semantic_check.py report --out-html` 生成**，agent 只需把生成的 HTML 读入写入，不再手写结构 |
| `ext_sections.declaration_cards` | 否 | 第 6 节 finding 卡片数组 `[{title, location, badge, verdict, analysis}]`（6.1-6.4，`location` 可为 null）；缺省→`.info` 占位 |
| `rw_timeout_note` | 否 | RW 数据下载异常提示（默认空） |

**报告结构**（主节编号为「数字+空格+标题」无点号，子节为「x.y 标题」）：
```
# 稿件技术检查报告 · [稿件编号或标题摘要]

[稿件基本信息]：不编号、小号字（meta div，font-size 13px），9 字段固定顺序：
  文件名 / 期刊全名 / 标题 / 作者 / 机构（中文：中国=学校+学院，国外=国名+学校+学院，不含省市街道邮编） / 类型 / 参考文献 / 撤稿数据库版本 / 检测工具（含生成日期）

[0 政治敏感词命中提示]：仅命中 Taiwan/Tibet/Xizang 时显示，位于稿件基本信息之后；
  红色小字 + 表格（关键词 / 完整句子 / 所属一级标题）；未命中不显示（{{POLITICAL_RISK}} 填空串）

## 1 检测结论摘要    —— 合并摘要表（**六行**：检测维度 | 结论 | 要点；结论列=仅风险徽章，未检测维度显示灰「未检测」；**无结论区**）。**维度编号 = 正文节序 − 1，摘要表行序与维度编号、正文节序三者一致**：① 内容相关性(§2) / ② 作者诚信(§3) / ③ 参考文献(§4) / **④ 参考文献语义相关性(§5)** / **⑤ 声明完整性(§6)** / **⑥ AIGC(§7)**
## 2 内容相关性    —— 「期刊收稿范围对照依据」段 + 4 列表格（分析维度 / 稿件特征 / 对应期刊领域 / 匹配度），均由脚本自动渲染
## 3 作者诚信检测
##   3.1 作者撤稿检索
##   3.2 作者机构与论文领域适配性
## 4 参考文献可靠性检测
##   4.1 发表年份分布
##   4.2 引用分布与著录
##   4.3 Crossref 真实性验证（通过文献仅汇总数量不列出；信息不一致/无法定位文献以表格列出编号/差异所在）
##   4.4 Retraction Watch 撤稿检索
## 5 参考文献语义相关性检测    （由 {{EXT_SECTIONS}} 前半提供，始终渲染）
## 6 声明完整性                （由 {{EXT_SECTIONS}} 后半提供，始终渲染）
##   6.1 利益冲突 / 6.2 作者贡献 / 6.3 研究伦理 / 6.4 致谢·数据可用性·AI 使用声明
## 7 AIGC 生成痕迹检测
```
（5/6 节缺失维度以 .info「未检测」占位；EXT_SECTIONS 位于第 4 节与第 7 节之间）

**样式对齐参考**：
- 蓝色主色调（`#2c6fbb` header border, `#1a4f8a` h2）
- 彩色 badge：`.ok` (绿) / `.warn` (黄) / `.bad` (红) / `.info` (灰，用于「未检测」)
- `.meta` 信息块（灰底圆角，稿件基本信息为不编号 13px 小号字）、`.note` 提示块（黄底左边框）、`.mono` 代码块
- 所有数据以表格呈现

**模板占位符**（除新稿模板原有占位符外，本次新增/变更；标注填充来源：`[脚本自动]` = gen_report.py 从检测 JSON 自动生成，`[report_content]` = 来自 report_content.json）：
- `{{MANUSCRIPT_ID}}` / `{{FILES}}` / `{{JOURNAL}}` / `{{TITLE}}` / `{{AUTHORS}}` / `{{AFFILIATIONS}}` / `{{MANUSCRIPT_TYPE}}` — `[report_content]` meta 字段
- `{{REFS_COUNT}}` — `[脚本自动]` 参考文献数量（refs.json）
- `{{RW_UPDATE_DATE}}` — `[脚本自动]` Retraction Watch 数据 `update_date`
- `{{TOOL_NAME}}` — `[脚本自动]` 脚本常量 "熊猫找茬-已出版 v3.21.1"（模板在该字段后追加 `，生成日期：{{REPORT_DATE}}`）
- `{{REPORT_DATE}}` — `[脚本自动]` 生成时间
- `{{POLITICAL_RISK}}` — `[脚本自动]` geo.json 命中时红字+表格；未命中空
- `{{SUMMARY_RELEVANCE_BADGE}}` / `{{SUMMARY_AUTHOR_BADGE}}` / `{{SUMMARY_REFS_BADGE}}` / `{{SUMMARY_AIGC_BADGE}}` — `[report_content]` summary.*.verdict 渲染为**仅风险徽章**（如 `<span class="badge ok">无风险</span>`）；未检测维度显示 `<span class="badge info">未检测</span>`
- `{{SUMMARY_RELEVANCE}}` / `{{SUMMARY_AUTHOR}}` / `{{SUMMARY_REFS}}` / `{{SUMMARY_AIGC}}` — `[report_content]` summary.*.text（「要点」列，判定短语开头）
- `{{SUMMARY_SEMANTIC_BADGE}}` / `{{SUMMARY_SEMANTIC}}` — `[脚本自动]` 由 `[report_content]` `summary.ext` 中名称含「语义相关性」的那行渲染（摘要表第 4 行 = ④，对应正文 §5）
- `{{SUMMARY_DECLARATION_BADGE}}` / `{{SUMMARY_DECLARATION}}` — `[脚本自动]` 由 `summary.ext` 中 label 含 `⑤` 的那行渲染（摘要表第 5 行 = ⑤，对应正文 §6 声明完整性）；两行缺省均→`.info`「未检测（子项未提供）」
- `{{SCOPE_HEADER}}` — `[脚本自动]` 第 2 节起始固定段（纯文本 `<p>`）：来源 + 版本日期 + 中文收稿范围概括，取自 `assets/journal_scopes.json`；未收录期刊→降级提示人工核对官网（非 https 来源自动遮蔽）
- `{{SCOPE_ANALYSIS_TABLE}}` — `[脚本自动]` 由 `[report_content]` `scope_analysis` 渲染 4 列表格（分析维度/稿件特征/对应期刊领域/匹配度徽章）；缺失→`.info`「未检测」占位
- `{{RW_TIMEOUT_NOTE}}` — `[report_content]` rw_timeout_note（默认空）
- `{{AUTHOR_LIST}}` — `[脚本自动]` authors.json 作者名列表
- `{{AUTHOR_RESULTS}}` — `[脚本自动]` authors.json 逐作者撤稿表 + 表下说明（含 manuscript_domain）
- `{{AFFILIATION_RESULTS}}` — `[report_content]` 3.2 机构适配结果（机构用中文）
- `{{REFS_YEAR_STATS_TABLE}}` — `[脚本自动]` refs.json 年份分桶表 + `[report_content]` year_stats_note
- `{{REFS_CITATION_ISSUES}}` — `[report_content]` 4.2 引用分布与著录
- `{{REFS_VERIFY_RESULTS}}` — `[report_content]` refs_verify（summary 必填 + issues 问题表 + manual 明细）
- `{{REFS_RETRACTION_CHECK}}` — `[脚本自动]` refs_rw.json matches（**缺 `total_references` 键 → `.info`「未执行」**；空数组→「0 篇存在撤稿记录」；非空→表）+ `[report_content]` refs_rw.verdicts/note（零命中与未执行两分支均拼接 note）
- `{{AIGC_TABLE}}` — `[脚本自动]` aigc.json 8 指标行（参考区间/判断=脚本内置，可被 aigc_judgments 覆盖）
- `{{AIGC_NOTE}}` — `[脚本自动]` ai_phrases 明细 + `[report_content]` aigc_note
- `{{EXT_SECTIONS}}` — `[脚本自动]` 由 `[report_content]` ext_sections 渲染：h2「5 参考文献语义相关性检测」（semantic_refs）+ h2「6 声明完整性」（declaration_cards → finding 卡片：声明原文位置/判定 badge/问题分析）；缺省→两节 `.info`「未检测（子项未提供）」占位

**脚本编码注意**：report_content.json 中的 HTML 字符串字段若含 ASCII 双引号须 `\"` 转义；建议一律用**中文引号**（`"..."`）避免转义混乱（已踩坑 3 次：EMD20260053「pivotal role」、CESCI-D-26-00011「construction industry」、CESCI-m26-00013「Allergic Bronchopulmonary Aspergillosis」）。

报告文件名格式：`manuscript_integrity_check_report_[YYMMDD]_[稿件标识].html`

**报告保存位置与数据来源标注**：
- 报告保存到**输入稿件文件所在的目录**（与 Word/PDF 输入文件同目录），运行 `gen_report.py` 时通过 `--out` 传入该目录，不可硬编码。
- 报告须注明本次撤稿检测所依据的 Retraction Watch 数据更新时间：读取 `data/retraction_watch_meta.json` 的 `update_date`（数据源端数据集日期），填入稿件基本信息「撤稿数据库版本」字段（`{{RW_UPDATE_DATE}}`）。该日期由该字段承载，正文不再重复注明。

**多篇批量（可选）**：用户提交多篇时，每篇独立 HTML 报告 + 汇总表（作者 / 期刊 / 风险等级 / 主要问题）。

---

## 下载与更新判定（retraction_watch.csv）

- 由 `scripts/download_retraction_watch.py` 统一负责下载、新鲜度判定、完整性校验与重试；`scripts/retraction_watch.py` 的 `ensure_csv` 直接委托该脚本，避免逻辑分散。
- **两步判定（降低下载频率、减少联网）**：
  - **无条件下载**：`--force`；或 **CSV 不存在**（无可检测数据）。
  - **第 1 步（本地快筛，纯本地、不联网）**：以本地 `update_date`（数据版本日期）为基准，缺失/解析失败回退 CSV 文件 mtime；**版本日期距今 < 3 天 → 直接复用本地文件，不发任何网络请求**（因源端日期 ≤ 今天，差异必然 < 3 天，不可能触发下载）。未命中则进入第 2 步。
  - **第 2 步（联网精确判定，仅版本日期距今 ≥ 3 天时执行）**：通过 GitLab Commits API 查询 `retraction_watch.csv` 最近一次提交的日期（即**数据源端更新日期**），与本地版本日期比对：**`(gitlab_date - 本地版本日期) > 3 天` 才重新下载**；≤ 3 天 → 复用本地。
    - 该 API 仅返回几 KB JSON，**不是** 62MB CSV，开销极小。
    - **GitLab API 不可达 → 回退保守下载一次**（保证不因查不到源头而用旧数据），`update_date` 记录为旧基线或今天。
- 下载后完整性校验：字节数 **≥ 50MB** 且 行数 **≥ 50000**，否则视为**不完整**。
- 失败/不完整时重试：**最多 3 次、指数退避**；先写 `.tmp` 临时文件，校验通过才 `os.replace` 原子覆盖正式 CSV。
- 重试耗尽仍不完整：若本地已有完整 CSV 则**保留上一版并继续检测**（source 标注 `download incomplete, kept previous version`）；仅当本地无任何 CSV 时才返回 `download_failed`（此时撤稿检测无法正常进行）。
- 下载使用标准库 `urllib` 并显式带 `User-Agent`，规避 GitLab raw 的 302 跳转与默认 UA 的 403。
- 强制重新下载（手动刷新）：`python scripts/download_retraction_watch.py --force` 或 `python scripts/retraction_watch.py download`。
- **并发注意（CRITICAL）**：RW 数据准备（版本检查 + 判断 + 下载）须作为**前置步骤串行执行一次**（`python scripts/download_retraction_watch.py`），确保 CSV 就绪且 FRESH 快筛命中后，`check-authors` 与 `check-refs` **方可并行执行**（此时仅只读 CSV，不再触发下载）；**严禁在数据未就绪或可能触发下载时并行**运行两个 RW 查询（并发下载会共用 `.tmp` 路径 + `os.replace` 覆盖 vs 读取 → Windows 文件锁冲突）。
- 报告中撤稿相关部分按 `csv_source` 标识提示：
  - 含 `download_timeout` / `download_failed` → 标记为 "⚠ 未执行 — 撤稿数据下载失败/超时"，并提示用户从 https://gitlab.com/crossref/retraction-watch-data 手动下载；
  - 含 `incomplete` → 标注"Retraction Watch 数据最近一次更新下载不完整，已保留上一版完整数据，结果仅供参考"，建议稍后重跑或人工经 retractiondatabase.org 复核。
- 其他检测（内容相关性 / Crossref 验证 / AIGC）不受影响，正常完成。

## Data Safety

- `retraction_watch.csv` 存储在**本 skill 目录下** `<skill>/data/retraction_watch.csv`（首次运行自动从旧位置 `~/.workbuddy/data` 迁移，成功后旧文件删除，避免双份）
- `retraction_watch_meta.json` 存储在同目录 `<skill>/data/retraction_watch_meta.json`，字段：`update_date`（**数据源端数据集日期**，来自 GitLab Commits API；用作第 1 步快筛基准与源端比对基线；不可达/首次时回退为本地日期）、`downloaded_at`（精确 ISO 时间戳，供溯源）、`bytes`（下载字节数）、`rows`（数据行数）、`source`
- `journal_scopes.json` 存储在**本 skill 目录下** `<skill>/assets/journal_scopes.json`（期刊 scope 缓存，随 skill 可移植；`assets/journal_scopes_template.json` 为模板）。记录含期刊全名 / 缩写 / scope URL / scope 文本 / 添加日期，可选编委名单字段（`editorial_board` / `editorial_board_url` / `editorial_board_text` / `editorial_board_updated_at`）；用户提供链接时，`preflight.py` 自动比对链接内容与本地记录差异（`diff_scope_text`，difflib，差异<10%→`update` 更新本地、≥10%→`review` 请用户确认，不擅自覆盖）
- Crossref API 通过 `mailto` 参数加入礼貌池（10 req/s、并发 3），脚本以并发 3 执行，429/5xx 自动指数退避；附 `User-Agent: panda-ms-check/1.0` header
- 不做任何 paywall 绕过或爬虫行为

---

## 版本与变更记录

> 已迁出至 `references/changelog.md`（避免每次唤起注入 59 KB 历史）。
> **何时读**：修订规则前查「这条规则为什么这么定」、或怀疑某个坑以前踩过时读；日常执行不必读。

## CRITICAL: signal, not verdict

本 skill 的所有发现都是**筛查信号**，不是定性结论。严禁：
- ❌ 说"这篇论文造假"、"这位作者有问题"、"这是 AI 写的"
- ❌ 用"实锤"等确定性表述
- ❌ 不点名作者：不公开说"X 教授的 Y 论文有问题"
- ❌ 不建议社交媒体披露：不建议发微博 / Twitter / 知乎 / 小红书 / 抖音 抨击作者
- ❌ 不替学术机构做裁定：不给出"应撤稿""应拒稿"等最终处理意见
- ✅ 只报告"命中 N 条可疑模式"并建议人工核实
- ✅ 推荐走期刊编辑部 / PubPeer 等正规反馈渠道

详细回复模板与边界案例见 `references/interpretation.md`。

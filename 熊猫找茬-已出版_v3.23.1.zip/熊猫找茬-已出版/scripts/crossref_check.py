#!/usr/bin/env python3
"""
crossref_check.py — Crossref 参考文献验证

功能：
1. 验证参考文献元数据（标题/作者/年份/DOI）
2. 生成 5 年跨度的发表年份分布统计

Usage:
    python crossref_check.py verify --refs <references_json_file>
    python crossref_check.py year-stats --refs <references_json_file>

Input JSON format:
[
    {
        "index": 1,
        "raw_text": "Author A, Author B (2020). Title of paper...",
        "title": "Title of paper",
        "authors": "Author A, Author B",
        "year": "2020",
        "journal": "Journal Name",
        "doi": "10.xxx/yyy"
    },
    ...
]

Output (stdout): JSON

v2.15.0 整改：
- F-07: DOI 正则校验（^10.\\d{4,9}/...）+ urllib.parse.quote——杜绝 CRLF/请求拆分注入。
- S3: 网络失败（重试耗尽/异常）与「未检索到」区分：status=error（未能核验，非不可信），
  不再把瞬时网络故障误标为 not_found。
- P4: 响应缓存（DOI + 标题查询，TTL 7 天，落盘 cache/crossref_cache.json）——
  重跑/多稿件重复查询近零网络耗时。
- P6: 无 DOI 文献的首轮 query= 与兜底 query.title= 两查询并行提交（ThreadPool 2），
  慢路径等待约减半。
- P2-1: 期刊核对改用 strict 匹配（允许介词跳过与缩写展开，但禁止跳过多余实词，
  如 Nano Energy vs Nano Energy Letters 报 mismatch）；评分仍用宽松前缀匹配。
- P2-3: 首轮标题检索 rows 10 → 15。
- 年份分桶计算收敛到 common_stats.py（与 gen_report 共用）。
- MAILTO / User-Agent 收敛到 config.py（PANDA_MAILTO 环境变量可覆盖）。
- S9: CLI 读取输入包 try；S10: references 非 list 入口报错。

v2.16.0 整改：
- 期刊名归一化：_journal_tokens 先 html.unescape 解码 &amp; → &，再 & → and——
  仅因 "and" / "&" / "&amp;" 造成的差异不再产生 journal_mismatch（不报告，视为无差异）。
  根因：Crossref 返回的期刊名常带 HTML 实体（如 "Energy &amp; Environmental Science"），
  旧逻辑 &amp 成为卡死 strict 匹配的脏 token。
"""

import argparse
import difflib
import hashlib
import html
import json
import re
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

from config import CROSSREF_CACHE, MAILTO, USER_AGENT

# Crossref API config
CROSSREF_API = "https://api.crossref.org/works"
MAX_CONCURRENCY = 3  # 礼貌池并发上限
MAX_RETRIES = 3      # 429/5xx 指数退避重试次数
DOI_RE = re.compile(r'^10\.\d{4,9}/[^\s\r\n]+$')   # F-07: DOI 格式校验（防注入）
CACHE_TTL = 7 * 86400                              # P4: 响应缓存 7 天


# ── Crossref 响应缓存（P4）──────────────────────────────────────────────

_cache = {}   # key -> {"ts": epoch, "data": ...}


def _load_cache():
    global _cache
    if not CROSSREF_CACHE.exists():
        return
    try:
        raw = json.loads(CROSSREF_CACHE.read_text(encoding='utf-8'))
        now = time.time()
        _cache = {k: v for k, v in raw.items() if now - v.get('ts', 0) <= CACHE_TTL}
    except Exception:
        _cache = {}


def _save_cache():
    try:
        CROSSREF_CACHE.parent.mkdir(parents=True, exist_ok=True)
        CROSSREF_CACHE.write_text(json.dumps(_cache, ensure_ascii=False), encoding='utf-8')
    except Exception:
        pass  # 缓存为纯优化，写失败不影响功能


def _cache_get(key):
    item = _cache.get(key)
    if item and time.time() - item.get('ts', 0) <= CACHE_TTL:
        return (True, item.get('data'))
    return (False, None)


def _cache_set(key, data):
    _cache[key] = {"ts": time.time(), "data": data}


def _title_cache_key(title):
    clean = re.sub(r'\s+', ' ', (title or '').lower()).strip()[:200]
    return 't:' + hashlib.md5(clean.encode('utf-8')).hexdigest()


# ── Crossref API ────────────────────────────────────────────────────────

def _get_with_retry(url: str):
    """GET url with 429/5xx exponential backoff. Returns response or None."""
    import requests
    for attempt in range(MAX_RETRIES):
        try:
            resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=15)
            if resp.status_code == 429 or resp.status_code >= 500:
                # 触发限流/服务端错误 → 退避后重试，避免把可恢复失败误判为 not_found
                time.sleep(2 ** attempt)
                continue
            return resp
        except requests.exceptions.RequestException:
            if attempt == MAX_RETRIES - 1:
                raise
            time.sleep(2 ** attempt)
    return None


def query_crossref_by_doi(doi: str) -> dict | None:
    """Query Crossref by DOI. Returns work data / None(404) / {"_error": ...}(网络失败)."""
    import requests
    doi = doi.rstrip('.').lower()
    # F-07: 格式非法（含控制字符/空白）→ 视为无 DOI，走标题检索
    if not DOI_RE.match(doi):
        return None
    ck = 'doi:' + doi
    hit, cached = _cache_get(ck)
    if hit:
        return cached
    url = f"{CROSSREF_API}/{urllib.parse.quote(doi, safe='')}?mailto={MAILTO}"
    try:
        resp = _get_with_retry(url)
        if resp is None:
            return {"_error": "retries exhausted"}
        if resp.status_code == 404:
            _cache_set(ck, None)
            return None
        resp.raise_for_status()
        data = resp.json()
        work = data.get("message", {})
        _cache_set(ck, work)
        return work
    except Exception as e:
        return {"_error": str(e)}


def query_crossref_by_title_author(title: str, author: str = "", year: str = "") -> list | None:
    """Query Crossref by title + author. Returns list of works / None(网络失败)."""
    import requests

    query_parts = []
    if title:
        # Clean title for query
        clean_title = re.sub(r'[^\w\s]', ' ', title)
        clean_title = re.sub(r'\s+', ' ', clean_title).strip()[:300]
        query_parts.append(clean_title)
    if author:
        # Extract surname
        author_surname = author.split(',')[0].strip().split()[-1] if author else ""
        if author_surname:
            query_parts.append(author_surname)

    query_str = ' '.join(query_parts)
    encoded = urllib.parse.quote(query_str)

    # P4: 标题查询缓存（键含作者姓，减少不同稿件间的误命中）
    ck = _title_cache_key(query_str) + ':' + hashlib.md5((author or '').encode('utf-8')).hexdigest()[:8]
    hit, cached = _cache_get(ck)
    if hit:
        return cached

    # v2.13.0: rows 3 → 10；v2.15.0 (P2-3): 10 → 15——rows=10 时目标排 11-15 仍可能被截
    url = f"{CROSSREF_API}?query={encoded}&rows=15&mailto={MAILTO}"
    if year:
        url += f"&filter=from-pub-date:{year},until-pub-date:{year}"

    try:
        resp = _get_with_retry(url)
        if resp is None:
            return None
        resp.raise_for_status()
        data = resp.json()
        items = data.get("message", {}).get("items", [])
        _cache_set(ck, items)
        return items
    except Exception:
        return None


def query_crossref_by_title_exact(title: str, rows: int = 20) -> list | None:
    """Query Crossref by title field only (query.title=), more precise than query=.

    v2.13.0 兜底检索：`query=`（bibliographic 全字段）对通用词标题排序差，
    目标文献被海量同类文献淹没（EMD20260090 实测 [30][34][46] 3 条），
    `query.title=` 只匹配标题字段，rows=20，目标排第 1-2 位。
    """
    import requests

    if not title:
        return None
    clean_title = re.sub(r'[^\w\s]', ' ', title)
    clean_title = re.sub(r'\s+', ' ', clean_title).strip()[:300]
    encoded = urllib.parse.quote(clean_title)

    ck = _title_cache_key(clean_title) + ':exact'
    hit, cached = _cache_get(ck)
    if hit:
        return cached

    url = f"{CROSSREF_API}?query.title={encoded}&rows={rows}&mailto={MAILTO}"
    try:
        resp = _get_with_retry(url)
        if resp is None:
            return None
        resp.raise_for_status()
        data = resp.json()
        items = data.get("message", {}).get("items", [])
        _cache_set(ck, items)
        return items
    except Exception:
        return None


# ── Field extraction ────────────────────────────────────────────────────

def extract_surname_candidates(authors_str: str) -> set:
    """Extract surname candidates from an author string.

    宽松规则（供评分，不触发 mismatch）：
    - 按 ',' ';' '&' 与 and 拆分为多个作者片段（兼容多作者逗号分隔与 "Last, First" 倒置——
      倒置时逗号两侧片段分别取末词，两侧均入候选）
    - 每个片段取末词（"Dwi Yanto" → yanto，兼容缩写 "D. Yanto"）
    - 小写、去尾点、过滤单字母
    """
    if not authors_str:
        return set()
    parts = re.split(r'[,;&]|\band\b', authors_str, flags=re.IGNORECASE)
    surnames = set()
    for p in parts:
        p = p.strip()
        if not p:
            continue
        tokens = p.split()
        if not tokens:
            continue
        s = tokens[-1].strip('.').lower()
        if len(s) > 1:
            surnames.add(s)
    return surnames


def get_crossref_surname_candidates(work: dict) -> set:
    """Get surname candidates from all Crossref authors (family name last token)."""
    authors = work.get("author", [])
    surnames = set()
    for a in authors:
        family = a.get("family", "")
        # 复姓如 "Bojórquez Mora" 取末词 "mora"
        tokens = family.split()
        if tokens:
            surnames.add(tokens[-1].strip('.').lower())
    return surnames


def get_crossref_title(work: dict) -> str:
    """Get the title from a Crossref work."""
    titles = work.get("title", [])
    return titles[0] if titles else ""


def get_crossref_year(work: dict) -> int | None:
    """Get the publication year from a Crossref work."""
    # Try issued date first
    issued = work.get("issued", {})
    date_parts = issued.get("date-parts", [[None]])[0]
    if date_parts and date_parts[0]:
        return date_parts[0]

    # Try created date
    created = work.get("created", {})
    date_parts = created.get("date-parts", [[None]])[0]
    if date_parts and date_parts[0]:
        return date_parts[0]

    return None


def get_crossref_journal(work: dict) -> str:
    """Get the journal/conference name from a Crossref work."""
    container = work.get("container-title", [])
    return container[0] if container else ""


def get_crossref_volume(work: dict) -> str:
    """Get the volume from a Crossref work."""
    return work.get("volume", "")


def get_crossref_page(work: dict) -> str:
    """Get the starting page from a Crossref work."""
    page = work.get("page", "")
    if page and "-" in page:
        return page.split("-")[0].strip()
    return page


# ── Journal name matching ───────────────────────────────────────────────

_SKIP_WORDS = frozenset({'of', 'the', 'and', 'for', 'in', 'on', 'a', 'an', 'to', 'with', '&'})


def _journal_tokens(name: str) -> list[str]:
    """去标点小写分词（期刊名匹配专用）。

    v2.16.0: 先 html.unescape 解码 &amp; → &，再把 & 归一为 and——使
    "X and Y" / "X & Y" / "X &amp; Y" 视作相同，仅此差异不再报 journal_mismatch。
    """
    s = html.unescape(name or '')
    s = re.sub(r'&', ' and ', s)          # & → and（加空格防粘连）
    s = re.sub(r'[^\w\s]', ' ', s.lower())
    return re.sub(r'\s+', ' ', s).strip().split()


def _word_match(wa: str, wb: str) -> bool:
    """期刊名单词级缩写匹配（v2.16.2 补充子序列，替代纯 startswith 前缀）。

    规则（仍为纯字符串判断，无别名表/语义）：
    1. 相等；
    2. 字符串前缀（"Rev" ↔ "Revxxxx"、"mater" ↔ "materials"）；
    3. 字符子序列（"compd" ⊂ "compounds"、"abstr" ⊂ "abstract"——经典缩写省略中间字母，
       EMD20260110 实测 "J Alloys Compd" vs "Journal of Alloys and Compounds" 因此漏配 6 条）；
       短词长度 ≥ 2 才启用子序列（单字母由前缀覆盖，防过宽）。
    """
    if not wa or not wb:
        return False
    if wa == wb:
        return True
    if wb.startswith(wa) or wa.startswith(wb):
        return True
    short, long = (wa, wb) if len(wa) <= len(wb) else (wb, wa)
    # 子序列仅对非停用词启用（v2.16.2 修复：停用词如 'in' ⊂ 'semicond' 会误配、
    # 破坏 strict 的顺序消费——EMD20260110 'Mater Sci Semicond Process' 实测 2 条误报）
    if len(short) >= 2 and short not in _SKIP_WORDS:
        it = iter(long)
        if all(ch in it for ch in short):
            return True
    return False


def _seq_prefix_match(a: list[str], b: list[str]) -> bool:
    """a 的每个词在 b 中按顺序找到缩写匹配（_word_match：前缀或字符子序列），
    允许跳过 b 中不对应的词（如 of/the 等介词）——即"缩写展开"语义，纯字符串判断。"""
    i = 0
    for wa in a:
        while i < len(b) and not _word_match(wa, b[i]):
            i += 1
        if i == len(b):
            return False
        i += 1
    return True


def _seq_prefix_match_strict(a: list[str], b: list[str]) -> bool:
    """strict 版（v2.15.0 P2-1）：a 每个词按序在 b 中匹配（_word_match）；
    仅允许跳过 b 中的停用词（of/the 等），不允许跳过实词；
    匹配结束后 b 中剩余未消费词也只能是停用词。

    效果：缩写展开（Chem. Mater. ↔ Chemistry of Materials、J Alloys Compd ↔
    Journal of Alloys and Compounds）仍匹配；多余实词差异（Nano Energy vs
    Nano Energy Letters）判不匹配。
    """
    i = 0
    for wa in a:
        while i < len(b) and not _word_match(wa, b[i]):
            if b[i] in _SKIP_WORDS:
                i += 1
                continue
            return False
        if i == len(b):
            return False
        i += 1
    for rest in b[i:]:
        if rest not in _SKIP_WORDS:
            return False
    return True


def journals_match(ref_journal: str, cr_journal: str, strict: bool = False) -> bool:
    """Check if two journal names match.

    strict=False（评分用）：纯字符串前缀 + 允许跳过任意词（v2.14.0 语义）。
    strict=True（期刊核对信号用，v2.15.0）：仅允许跳过停用词 + 剩余词限停用词，
    真实刊名差异（如 Nano Energy vs Nano Energy Letters）仍被报告。
    """
    if not ref_journal or not cr_journal:
        return False
    r = _journal_tokens(ref_journal)
    c = _journal_tokens(cr_journal)
    if not r or not c:
        return False
    if strict:
        return _seq_prefix_match_strict(r, c) or _seq_prefix_match_strict(c, r)
    return _seq_prefix_match(r, c) or _seq_prefix_match(c, r)


def score_title_search_result(item: dict, ref_title: str, ref_authors: str,
                               ref_year: str, ref_journal: str) -> int:
    """Score a Crossref work against the reference.

    权重（标题 > 期刊 > 年份 > 作者）：标题 +6、期刊 +4、年份 +2（|diff|≤1 均给分）、作者 +1（宽松）；
    满分 13，接受阈值 6 且标题为必要项。DOI 命中确认与 title_search 候选选择共用本函数。
    """
    score = 0
    cr_title = get_crossref_title(item)
    cr_year_val = get_crossref_year(item)
    cr_journal = get_crossref_journal(item)
    cr_surnames = get_crossref_surname_candidates(item)
    if ref_title and cr_title and titles_match(ref_title, cr_title):
        score += 6
    if ref_journal and cr_journal and journals_match(ref_journal, cr_journal):
        score += 4
    if ref_year and cr_year_val:
        try:
            ref_yr = int(re.sub(r'[^\d]', '', str(ref_year)[:4]))
            if abs(ref_yr - cr_year_val) <= 1:
                score += 2
        except ValueError:
            pass
    if ref_authors and cr_surnames:
        ref_surnames = extract_surname_candidates(ref_authors)
        if ref_surnames & cr_surnames:
            score += 1
    return score


def titles_match(ref_title: str, crossref_title: str) -> bool:
    """Check if two titles match (fuzzy)."""
    if not ref_title or not crossref_title:
        return False

    # Normalize: strip HTML tags, lowercase, remove punctuation, collapse whitespace
    def normalize(t):
        # v2.11.1: <sub>/<sup> 下标连同周围空白删除（化学式紧贴：In<sub>2</sub>Se → In2Se）
        t = re.sub(r'\s*</?(?:sub|sup)[^>]*>\s*', '', t, flags=re.IGNORECASE)
        # 其他富文本标签（<i>/<b> 等）只删标签本身，保留词间空白
        t = re.sub(r'</?[a-z][^>]*>', '', t, flags=re.IGNORECASE)
        t = t.lower()
        t = re.sub(r'[^\w\s]', ' ', t)
        t = re.sub(r'\s+', ' ', t).strip()
        return t

    ref_norm = normalize(ref_title)
    cr_norm = normalize(crossref_title)

    # Exact match
    if ref_norm == cr_norm:
        return True

    # Token-based overlap
    ref_tokens = set(ref_norm.split())
    cr_tokens = set(cr_norm.split())
    if not ref_tokens or not cr_tokens:
        return False

    overlap = len(ref_tokens & cr_tokens) / max(len(ref_tokens), len(cr_tokens))
    # v3.16.0: 泛用词高重叠守卫 —— "global / report / 年份" 这类泛用 token 能让**完全不同的文献**
    # 拿到 ≥0.65 重叠而误判为同一篇（OCE20260029 [1]「Global wind report 2025」被
    # 「Global Debt Report 2025」以 0.75 命中、并以 8/13 被接受）。判据：稿内**特征词**
    # （长度≥4、非泛用词、非纯数字）若一个都无法在候选标题中找到，则判定不是同一文献。
    GENERIC_TOKENS = {'global', 'report', 'annual', 'review', 'study', 'analysis',
                      'overview', 'survey', 'research', 'progress', 'advances',
                      'perspective', 'update', 'series', 'volume', 'part'}
    ref_distinct = {t for t in ref_tokens
                    if len(t) >= 4 and t not in GENERIC_TOKENS and not t.isdigit()}
    if ref_distinct and not (ref_distinct & cr_tokens):
        return False
    # v2.13.0: 0.7 → 0.65（用户确认放宽文献一致性判定；防标题措辞小幅差异误报）
    return overlap >= 0.65


def title_diff(ref_title: str, cr_title: str, max_common: int = 3) -> str:
    """标题显著差异的纯文本对比（v2.14.0）：只列出差异片段，相同内容省略。

    词级 diff（difflib.SequenceMatcher opcodes）：
    - equal 块 ≤ max_common 词完全省略（不列相同内容）；> max_common 词双侧追加省略号 …
    - replace/delete 取稿内差异词；insert 取 Crossref 差异词
    返回格式（纯文本、无 HTML 高亮）：`稿内「…X…」vs Crossref「…Y…」`
    """
    if not ref_title or not cr_title:
        return ''
    ro = ref_title.split()
    co = cr_title.split()
    rn = [re.sub(r'[^\w]', '', w).lower() for w in ro]
    cn = [re.sub(r'[^\w]', '', w).lower() for w in co]
    if rn == cn:
        return ''
    ref_parts, cr_parts = [], []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, rn, cn).get_opcodes():
        if tag == 'equal':
            n = i2 - i1
            if n > max_common:
                ref_parts.append('…')
                cr_parts.append('…')
        elif tag == 'replace':
            ref_parts.extend(ro[i1:i2])
            cr_parts.extend(co[j1:j2])
        elif tag == 'delete':
            ref_parts.extend(ro[i1:i2])
        elif tag == 'insert':
            cr_parts.extend(co[j1:j2])
    ref_side = ' '.join(ref_parts).strip() or '…'
    cr_side = ' '.join(cr_parts).strip() or '…'
    return f'稿内「{ref_side}」vs Crossref「{cr_side}」'


# ── Verify references ───────────────────────────────────────────────────

def verify_one(ref: dict) -> dict:
    """Verify a single reference against Crossref. Returns entry dict."""
    ref_index = ref.get("index", 0)
    doi = ref.get("doi", "").strip().rstrip('.').lower()
    ref_title = ref.get("title", "").strip()
    ref_authors = ref.get("authors", "").strip()
    ref_year = ref.get("year", "").strip()
    ref_journal = ref.get("journal", "").strip()
    ref_volume = ref.get("volume", "").strip()
    ref_page = ref.get("page", "").strip()

    entry = {
        "index": ref_index,
        "doi": doi,
        "ref_title": ref_title[:200],
        "ref_year": ref_year,
        "ref_journal": ref_journal[:100],
        "status": "pending",
        "issues": [],
        "info": [],
        "crossref_year": None,
        "crossref_title": None,
        "crossref_journal": None,
    }

    work = None
    source = ""
    best_score = 0
    network_error = False

    # 1) DOI 优先：命中后按标题/期刊/年份/作者统一打分确认
    if doi and DOI_RE.match(doi):   # F-07: 格式非法（含控制字符）跳过 DOI 路径
        w = query_crossref_by_doi(doi)
        if isinstance(w, dict) and "_error" in w:
            network_error = True    # S3: 网络失败 ≠ not_found
        elif isinstance(w, dict) and w:
            work = w
            best_score = score_title_search_result(w, ref_title, ref_authors, ref_year, ref_journal)
            source = f"doi(score={best_score}/13)"

    # 2) 无 DOI 或 DOI 失败 → 标题检索（P6: 首轮 query= rows=15 与 query.title= rows=20 并行）
    best_item = None
    if work is None and ref_title:
        with ThreadPoolExecutor(max_workers=2) as ex:
            f1 = ex.submit(query_crossref_by_title_author, ref_title, ref_authors)
            f2 = ex.submit(query_crossref_by_title_exact, ref_title)
            items, items2 = f1.result(), f2.result()
        if items is None or items2 is None:
            network_error = True    # S3: 任一查询网络失败
        candidates = list(items or [])
        if items2:
            candidates.extend(items2)
        best_score = 0
        for item in candidates:
            s = score_title_search_result(item, ref_title, ref_authors, ref_year, ref_journal)
            if s > best_score:
                best_score = s
                best_item = item

        # v2.13.0 接受条件：score ≥ 6 且标题必须匹配（标题不匹配即使 7 分也拒绝，
        # 防 "期刊+年份+作者=7 但标题完全不同" 被误接受）
        def _accepted(item):
            return (item is not None and best_score >= 6
                    and titles_match(ref_title, get_crossref_title(item)))

        if _accepted(best_item):
            work = best_item
            source = f"title_search(score={best_score}/13)"
        else:
            # 无足够好的匹配 → 视为未检索到记录；保留最佳候选标题供报告具体对比（不显示分值）
            work = None
            if best_item is not None:
                entry["crossref_title"] = (get_crossref_title(best_item) or "")[:200]
                entry["crossref_year"] = get_crossref_year(best_item)
                entry["crossref_journal"] = (get_crossref_journal(best_item) or "")[:100]
            source = "title_search(low_score)"

    # S3: 网络失败单独状态（报告端标注"未能核验"，非"不可信"）
    if network_error:
        entry["status"] = "error"
        entry["error"] = "网络错误，未能核验（非不可信，请重试）"
        entry["source"] = source
        return entry

    if work is None:
        entry["status"] = "not_found"
        entry["source"] = source
        return entry

    cr_title = get_crossref_title(work)
    cr_year = get_crossref_year(work)
    cr_journal = get_crossref_journal(work)

    entry["crossref_title"] = (cr_title or "")[:200]
    entry["crossref_year"] = cr_year
    entry["crossref_journal"] = (cr_journal or "")[:100]
    # v3.23.0：为 4.2「作者姓名用字」核对保留 Crossref 基准（只对已接受的记录写入；
    # not_found 分支的 crossref_* 是低分最佳候选，可能整体错配，严禁当基准）。
    _au = work.get("author") or []
    entry["crossref_authors"] = [
        {"given": (a.get("given") or "")[:60],
         "family": (a.get("family") or a.get("name") or "")[:60]}
        for a in _au[:20] if (a.get("family") or a.get("name"))
    ]
    entry["crossref_author_total"] = len(_au)
    entry["source"] = source

    # 标题核对（所有来源；允许大小写/非字母符号差异，已归一化）
    # v2.14.0: title_mismatch 带词级差异片段（只列差异部分，相同内容省略）
    if ref_title and cr_title and not titles_match(ref_title, cr_title):
        diff = title_diff(ref_title, cr_title)
        entry["issues"].append(f"title_mismatch: {diff or '标题措辞差异'}")

    # 年份核对（所有来源）：|diff|≤1 → 信息差异（非不可信）；>1 → 不可信
    if ref_year and cr_year:
        try:
            ref_yr = int(re.sub(r'[^\d]', '', str(ref_year)[:4]))
            diff = abs(ref_yr - cr_year)
            if diff > 1:
                entry["issues"].append(f"year_mismatch: ref={ref_yr}, crossref={cr_year}")
            elif diff == 1:
                entry["info"].append(f"year_off_by_1: ref={ref_yr}, crossref={cr_year}")
        except ValueError:
            pass

    # 期刊核对（v2.15.0 P2-1: 用 strict 匹配——真实刊名差异仍被报告；评分仍用宽松）
    # v2.16.0: _journal_tokens 已归一化 and/&/&amp; 等价，仅此差异不会走到这里
    if ref_journal and cr_journal and not journals_match(ref_journal, cr_journal, strict=True):
        entry["issues"].append(f"journal_mismatch: ref={ref_journal[:80]}, crossref={cr_journal[:80]}")

    # 卷/页差异不作为信息差异或不可信信号；作者名允许缩写/姓名倒置（不核对、不评分报错）

    # DOI 命中但按标题/姓名等打分低于接受阈值 → 附加人工复核提示（非 not_found）
    # v2.13.0: 接受阈值 8 → 6 且标题必要（与 title_search 一致）
    if "doi(" in source and not (best_score >= 6 and titles_match(ref_title, cr_title)):
        entry["issues"].append(
            f"doi_low_score: DOI 记录已找到，按标题/姓名等打分 {best_score}/13 低于接受阈值 6（或标题不匹配），建议人工复核")

    if entry["issues"]:
        entry["status"] = "issues_found"
    else:
        entry["status"] = "verified"

    return entry


def verify_references(references: list[dict]) -> dict:
    """Verify each reference against Crossref (concurrent, polite pool).

    并发上限 = 礼貌池 concurrency limit（3）；429/5xx 已在 _get_with_retry 内
    指数退避，避免把可恢复的限流误判为 not_found（相比原串行 0.5s sleep 显著提速）。
    """
    if not isinstance(references, list):
        raise ValueError('references 必须为纯 list（SKILL.md：refs.json 须为 list）')

    _load_cache()
    try:
        # 兜底补 index，保证缺失 index 的 ref 也有稳定编号
        for i, ref in enumerate(references):
            if "index" not in ref or not ref["index"]:
                ref["index"] = i + 1

        with ThreadPoolExecutor(max_workers=MAX_CONCURRENCY) as ex:
            results = list(ex.map(verify_one, references))

        verified = sum(1 for r in results if r["status"] == "verified")
        has_issues = sum(1 for r in results if r["status"] == "issues_found")
        not_found = sum(1 for r in results if r["status"] == "not_found")
        errors = sum(1 for r in results if r["status"] == "error")

        return {
            "total": len(references),
            "verified": verified,
            "has_issues": has_issues,
            "not_found": not_found,
            "errors": errors,
            "results": results
        }
    finally:
        _save_cache()


# ── Year statistics ─────────────────────────────────────────────────────

def compute_year_stats(references: list[dict]) -> dict:
    """Compute publication year distribution in 5-year bins（v2.15.0: 收敛到 common_stats）。"""
    from common_stats import compute_year_stats as _cys
    return _cys(references)


# ── CLI ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Crossref reference verifier")
    subparsers = parser.add_subparsers(dest="command", help="Command")

    p_verify = subparsers.add_parser("verify", help="Verify references against Crossref")
    p_verify.add_argument("--refs", required=True, help="Path to JSON file with reference list")

    p_stats = subparsers.add_parser("year-stats", help="Compute publication year statistics")
    p_stats.add_argument("--refs", required=True, help="Path to JSON file with reference list")

    args = parser.parse_args()

    if args.command == "verify":
        try:
            with open(args.refs, 'r', encoding='utf-8') as f:
                refs = json.load(f)
        except Exception as e:
            print(json.dumps({"status": "error", "error": f"读取 refs.json 失败: {e}"},
                             ensure_ascii=False))
            sys.exit(1)
        if not isinstance(refs, list):
            print(json.dumps({"status": "error", "error": "refs.json 必须为纯 list"},
                             ensure_ascii=False))
            sys.exit(1)
        try:
            result = verify_references(refs)
        except Exception as e:
            print(json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False))
            sys.exit(1)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "year-stats":
        try:
            with open(args.refs, 'r', encoding='utf-8') as f:
                refs = json.load(f)
        except Exception as e:
            print(json.dumps({"status": "error", "error": f"读取 refs.json 失败: {e}"},
                             ensure_ascii=False))
            sys.exit(1)
        if not isinstance(refs, list):
            print(json.dumps({"status": "error", "error": "refs.json 必须为纯 list"},
                             ensure_ascii=False))
            sys.exit(1)
        try:
            result = compute_year_stats(refs)
        except Exception as e:
            print(json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False))
            sys.exit(1)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

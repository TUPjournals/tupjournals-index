#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Carbon Future (ACS 风格) 参考文献解析。

格式：`[n] Surname, A. B.; Surname, C. D. Title. Journal Year, Volume, Pages.`
输出纯 list JSON（index/authors/title/journal/volume/page/year/doi）
"""
import json
import re
import sys

def main():
    """命令行入口（v3.22.0：由模块顶层脚本改为函数，使其可被 import 复用）。"""
    TEXT = sys.argv[1]
    OUT = sys.argv[2]

    raw = open(TEXT, encoding='utf-8').read()
    i = raw.find('\nReferences\n')
    ref = raw[i:]

    # 页眉/页脚/版权噪声行
    NOISE = [
        re.compile(r'^\d{7}\s*\(\d+\s*of\s*\d+\)\s*Carbon Future\s*\d{4},\s*\d+,\s*\d+$'),
        re.compile(r'^Carbon Future\s*\d{4},\s*\d+,\s*\d+\s*\d{7}\s*\(\d+\s*of\s*\d+\)$'),
        re.compile(r'^Review$'),
        re.compile(r'^\u00a9.*Tsinghua University Press'),
        re.compile(r'^Carbon Future\s*\d{4},\s*\d+,\s*\d+$'),
        re.compile(r'^\(\d+\s*of\s*\d+\)$'),
        # 双栏 PDF 错拼进来的版权块续行
        re.compile(r'and indicate if changes were made'),
        re.compile(r'creativecommons\.org'),
        re.compile(r'so long as attribution is given'),
        re.compile(r'adapt, and build upon the material'),
        re.compile(r'^distribute, remix'),
    ]
    # 参考文献节结束标志（其后为致谢/声明等正文）
    END_RE = re.compile(
        r'^(Acknowledgements?|Author [Cc]ontributions?|Competing interests|'
        r'Conflict of interest|Conflicts? of interest|Data availability|'
        r'Supplementary[^ ]*|ORCID|Notes|Funding)\s*$')
    ITEM_RE = re.compile(r'^\[(\d+)\]\s*(.*)$')

    lines = []
    skip_open = False
    for ln in ref.split('\n'):
        s = ln.strip()
        if not s:
            continue
        if END_RE.match(s):
            break
        if any(p.search(s) for p in NOISE):
            skip_open = False
            continue
        if s.startswith('Open Access This article is licensed') or skip_open:
            skip_open = not ITEM_RE.match(s)
            if skip_open:
                continue
        lines.append(s)

    items = []
    cur = None
    for s in lines:
        m = ITEM_RE.match(s)
        if m:
            if cur:
                items.append(cur)
            cur = {'index': int(m.group(1)), 'text': m.group(2)}
        else:
            if cur is None:
                continue
            if cur['text'].endswith('-'):
                cur['text'] += s
            else:
                cur['text'] += ' ' + s
    if cur:
        items.append(cur)

    # 作者段：`Surname, A. B.; Surname, C. D.; ...` 或 `... et al.`
    _NAME = r'[A-Z][A-Za-z\u00C0-\u024F\u2019\'\-]+'
    _AUTH = (r'(?:' + _NAME + r'(?:\s+(?:' + _NAME + r'|van|de|der|von))?'
             r',\s*[A-Z]\.(?:\s+[A-Z]\.)*|et al\.)\s*;?\s*')
    AUTHOR_RE = re.compile(r'^(?:' + _AUTH + r')+')

    TAIL_RE = re.compile(
        r'(?P<year>(?:19|20)\d{2}),\s*(?P<vol>[^,]+),\s*(?P<tail>[^.]+)\.\s*$'
    )
    INPRESS_RE = re.compile(r',\s*in press\s*,\s*DOI:\s*(?P<doi>10\.\S+?)\.\s*$',
                            re.IGNORECASE)
    YRJ_RE = re.compile(
        r'^(?P<title>.+?)\.\s+(?P<journal>[A-Z][A-Za-z\.\-]*(?:\s+[A-Z][A-Za-z\.\-]*)*)'
        r'\s+(?P<year>(?:19|20)\d{2}),?\s*$')
    DOI_RE = re.compile(r'DOI:\s*(10\.\S+?)\.?\s*$', re.IGNORECASE)

    _STOPWORDS = {'of', 'and', 'the', 'in', 'for', 'on', '&', 'de', 'la', 'et'}


    def _journal_word(w):
        core = w.strip('.,;:')
        if not core:
            return False
        # 标题尾部的化学式/双字母缩写（CO / RR / Ni …）不是期刊词
        if re.match(r'^[A-Z]{2}$', core):
            return False
        if core.lower() in _STOPWORDS:
            return True
        if re.match(r'^[A-Z][A-Za-z]*\.?$', core):
            return True
        parts = core.split('-')
        if len(parts) > 1 and all(re.match(r'^[A-Z][A-Za-z]*\.?$', p) for p in parts):
            return True
        return False


    def split_journal(head):
        """从 head 末尾回扫出期刊名（缩写词/专名序列）。"""
        toks = head.split()
        jt = []
        for w in reversed(toks):
            if _journal_word(w):
                jt.append(w)
                if len(jt) >= 6:
                    break
            else:
                break
        if not jt:
            return None, head
        jt = list(reversed(jt))
        journal = ' '.join(jt)
        cut = head.rfind(jt[0])
        return journal, head[:cut].strip()


    out = []
    bad = []
    for it in items:
        text = it['text'].strip()
        text = re.split(r'Open Access This article is licensed', text)[0].strip()
        rec = {'index': it['index'], 'authors': '', 'title': '', 'journal': '',
               'volume': '', 'page': '', 'year': '', 'doi': ''}
        m = AUTHOR_RE.match(text)
        if m:
            rec['authors'] = m.group(0).strip().rstrip(';').rstrip(',').strip()
            rest = text[m.end():].strip()
        else:
            rest = text

        mi = INPRESS_RE.search(rest)
        if mi:
            head = rest[:mi.start()].strip()
            mm = re.match(r'^(?P<t>.+?\.)\s+(?P<j>[A-Z].*)$', head)
            if mm:
                rec['title'] = mm.group('t').strip().rstrip('.')
                rec['journal'] = mm.group('j').strip().rstrip(',').strip()
            else:
                rec['title'] = head.rstrip('.')
            rec['doi'] = mi.group('doi').strip()
            rec['year'] = 'in press'
            out.append(rec)
            continue

        md = DOI_RE.search(rest)
        doi = ''
        if md:
            doi = md.group(1).strip()
            rest = rest[:md.start()].strip().rstrip(',').strip()

        mt = TAIL_RE.search(rest)
        if mt:
            head = rest[:mt.start()].strip()
            rec['year'] = mt.group('year')
            rec['volume'] = mt.group('vol').strip()
            rec['page'] = mt.group('tail').strip().rstrip('.')
            journal, title = split_journal(head)
            rec['journal'] = journal or ''
            rec['title'] = title.rstrip('.').strip()
        else:
            m3 = YRJ_RE.match(rest)
            if m3:
                rec['title'] = m3.group('title').strip().rstrip('.')
                rec['journal'] = m3.group('journal').strip().rstrip(',').strip()
                rec['year'] = m3.group('year')
            else:
                rec['title'] = rest.rstrip('.')
                bad.append(it['index'])

        if doi and not rec['doi']:
            rec['doi'] = doi
        out.append(rec)

    json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(json.dumps({'status': 'ok', 'entries': len(out), 'no_tail': bad,
                      'with_doi': sum(1 for r in out if r['doi']),
                      'empty_title': [r['index'] for r in out if not r['title']],
                      'empty_journal': [r['index'] for r in out if not r['journal']]},
                     ensure_ascii=False))



if __name__ == "__main__":
    main()

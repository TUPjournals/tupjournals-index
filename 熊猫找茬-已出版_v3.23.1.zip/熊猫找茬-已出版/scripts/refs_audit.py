#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""refs_audit.py — 4.2「引用分布与著录」的数据审计（只出数据，不写文案）。

v3.23.0 新增。设计原则：**脚本只产数据，报告文案由 agent 按 SKILL.md 3.4 的四固定子块撰写。**
全部 stdlib，可离线运行；缺哪个输入就降级对应数据块，只有文件读不了才非零退出。

输出：
  coverage              正文引用覆盖（总数 / 被引 / 未引用 / 超范围 / 区间组 / 引用组数）
  co_ascending          合引编号是否升序（违规组列表）
  duplicates            文献表内标题相似度 ≥ 阈值的对（默认 0.80），含判别辅助位
  names                 作者姓名用字：T1 原文 vs Crossref / T2 原文 vs 文献表 / T3 无基准列非 ASCII
  self_citation_candidates  按姓氏比对的作者自引候选（仅为候选，须 agent 逐条确认）

用法：
  python refs_audit.py --refs refs.json --paras out_paras.json --body body.txt \
      --crossref crossref.json --authors authors.json --out refs_audit.json
"""
import argparse
import difflib
import html
import json
import re
import sys
import unicodedata
from datetime import datetime

sys.stdout.reconfigure(encoding="utf-8")

# 与 citation_stats.py 保持一致：hyphen / en-dash / em-dash / minus
_DASH = "\u002d\u2013\u2014\u2212"
CITE_RE = re.compile(r"\[(\d+(?:\s*[" + _DASH + r"]\s*\d+)*(?:\s*,\s*\d+(?:\s*[" + _DASH + r"]\s*\d+)*)*)\]")
# 参考文献条目内的姓名：姓 + 逗号 + 名首字母（容忍变音符号与连字符）
SURNAME_RE = re.compile(r"([A-Z][A-Za-z\u00c0-\u024f\-'\u0142\u00f8\u0111]{1,}),\s*(?=[A-Z]\.)")


def _skel(s):
    """姓氏骨架：NFKD 拆变音符 → 去组合符 → 仅留 a-z。与 semantic_check._norm_surname 同源同口径。"""
    s = unicodedata.normalize("NFKD", (s or "").lower())
    return re.sub(r"[^a-z]", "", "".join(c for c in s if not unicodedata.combining(c)))


def _has_mark(s):
    """是否含组合字符（即含变音符等符号）。"""
    return any(unicodedata.combining(c) for c in unicodedata.normalize("NFKD", s or ""))


def _non_ascii(s):
    return any(ord(c) > 127 for c in (s or ""))


def _norm_title(t):
    """标题归一化：保守口径——不截副标题、不去停用词（实测激进归一化会把同作者系列文推到 0.78）。"""
    t = html.unescape(t or "")
    t = re.sub(r"<[^>]+>", " ", t)
    t = unicodedata.normalize("NFKD", t).lower()
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r"\s*et\s+al\.?", " ", t)
    t = re.sub(r"[" + _DASH + r"]", " ", t)
    t = re.sub(r"[^0-9a-z]+", " ", t)
    return " ".join(t.split())


def expand_group(g):
    nums = set()
    for part in (g or "").split(","):
        part = part.strip()
        if not part:
            continue
        if re.search("[" + _DASH + "]", part):
            a, b = re.split("[" + _DASH + "]", part, maxsplit=1)
            if a.strip().isdigit() and b.strip().isdigit():
                lo, hi = int(a), int(b)
                if 0 < hi - lo <= 400:
                    nums.update(range(min(lo, hi), max(lo, hi) + 1))
        elif part.isdigit():
            nums.add(int(part))
    return nums


def split_body_references(text):
    """切出「References 之前」与「参考文献段」，与 citation_stats 的口径一致。"""
    m = re.search(r"^\s*(?:references|bibliography|literature\s+cited)\s*$", text, re.I | re.M)
    if not m:
        return text, ""
    return text[:m.start()], text[m.end():]


def audit_coverage(body_text, total_refs):
    before, _ = split_body_references(body_text)
    groups = []
    cited = set()
    over = []
    for m in CITE_RE.finditer(before):
        nums = expand_group(m.group(1))
        if not nums:
            continue
        groups.append((m.group(0), sorted(nums)))
        for n in nums:
            if 1 <= n <= total_refs:
                cited.add(n)
            elif n > total_refs:
                over.append(n)
    uncited = [i for i in range(1, total_refs + 1) if i not in cited]
    ranges = [g for g, _ in groups if re.search("[" + _DASH + "]", g)]
    # 区间组去重保序
    seen, range_groups = set(), []
    for g in ranges:
        if g not in seen:
            seen.add(g)
            range_groups.append(g)
    violations = []
    for raw, nums in groups:
        if len(nums) > 1 and nums != sorted(nums):
            violations.append({"marker": raw, "indices": nums})
    return {
        "total_refs": total_refs,
        "cited_count": len(cited),
        "uncited": uncited,
        "uncited_count": len(uncited),
        "max_cited": max(cited) if cited else 0,
        "over_range": sorted(set(over)),
        "range_groups": range_groups,
        "cited_groups": len(groups),
        "source": "正文（References 之前）段落 + 表格单元格；四种破折号统一展开",
    }, {"groups_checked": len(groups), "violations": violations}


def audit_duplicates(refs, threshold):
    items = [(r.get("index"), _norm_title(r.get("title"))) for r in refs]
    items = [(i, t) for i, t in items if t]
    pairs, best = [], {"a": None, "b": None, "ratio": 0.0}
    by_index = {r.get("index"): r for r in refs}
    for x in range(len(items)):
        for y in range(x + 1, len(items)):
            ia, ta = items[x]
            ib, tb = items[y]
            ratio = difflib.SequenceMatcher(None, ta, tb, autojunk=False).ratio()
            if ratio > best["ratio"]:
                best = {"a": ia, "b": ib, "ratio": round(ratio, 3)}
            if ratio >= threshold:
                ra, rb = by_index.get(ia, {}), by_index.get(ib, {})
                pairs.append({
                    "a": ia, "b": ib, "ratio": round(ratio, 3),
                    "level": "near_identical" if ratio >= 0.95 else "similar",
                    "same_first_author": bool(ra.get("authors") and rb.get("authors")
                                              and _skel(ra["authors"].split(",")[0])
                                              == _skel(rb["authors"].split(",")[0])),
                    "same_year": str(ra.get("year") or "") == str(rb.get("year") or "") != "",
                    "same_journal": _skel(ra.get("journal")) == _skel(rb.get("journal")) != "",
                })
    pairs.sort(key=lambda p: -p["ratio"])
    return {"method": "difflib.SequenceMatcher(autojunk=False).ratio() on normalized title",
            "threshold": threshold, "pairs": pairs, "max_pair": best,
            "compared": len(items) * (len(items) - 1) // 2}


def ref_blocks(raw_refs_text):
    """按 [n] 切分参考文献段，返回 {n: 该条文本}。"""
    out, cur, buf = {}, None, []
    for m in re.finditer(r"\[(\d+)\]", raw_refs_text):
        if cur is not None:
            out[cur] = " ".join(buf)
        cur = int(m.group(1))
        buf = [raw_refs_text[m.end():m.end() + 800]]
    if cur is not None:
        out[cur] = " ".join(buf)
    return out


def audit_names(refs, blocks, crossref_by_index):
    findings, with_base, without_base = [], 0, 0
    unbaselined = []
    for r in refs:
        idx = r.get("index")
        block = blocks.get(idx, "") or (r.get("authors") or "")
        raw_names = SURNAME_RE.findall(block) or SURNAME_RE.findall(r.get("authors") or "")
        refs_names = SURNAME_RE.findall(r.get("authors") or "")
        cr = crossref_by_index.get(idx) or {}
        base_names = [a.get("family") or "" for a in (cr.get("crossref_authors") or [])]
        base = base_names or refs_names
        if base_names:
            with_base += 1
        else:
            without_base += 1
            # v3.23.1：无 Crossref 作者基准的条目单独列出，供 agent 基于经验逐条复核
            unbaselined.append({"index": idx, "raw_surnames": raw_names[:20]})
        hit = None
        for raw in raw_names:
            if _non_ascii(raw):
                continue  # 已含变音符，不属「缺失」
            for b in base:
                if not b or _skel(raw)[:1] != _skel(b)[:1]:
                    continue
                ratio = difflib.SequenceMatcher(None, _skel(raw), _skel(b), autojunk=False).ratio()
                if _has_mark(b) and not _has_mark(raw) and ratio >= 0.85:
                    hit = {"index": idx, "raw": raw, "base": b,
                           "crossref": b if base_names else None,
                           "refs": (refs_names[raw_names.index(raw)]
                                    if raw in refs_names and raw_names.index(raw) < len(refs_names) else None),
                           "basis": "crossref" if base_names else "refs",
                           "kind": "diacritic_missing", "ratio": round(ratio, 3)}
                    break
            if hit:
                break
        if hit:
            findings.append(hit)
        elif not base_names:
            for raw in raw_names:
                if _non_ascii(raw):
                    findings.append({"index": idx, "raw": raw, "base": None, "crossref": None,
                                     "refs": raw, "basis": "none", "kind": "non_ascii",
                                     "ratio": None})
                    break
    return {"with_baseline": with_base, "without_baseline": without_base,
            "unbaselined_indexes": [u["index"] for u in unbaselined],
            "unbaselined": unbaselined,
            "findings": findings}


def audit_self_citation(refs, authors):
    names = []
    for a in (authors or {}).get("authors", []) or []:
        nm = a.get("name") or ""
        if nm:
            names.append(_skel(nm.split()[-1]))
    names = [n for n in names if len(n) >= 2]
    hits = []
    if names:
        for r in refs:
            aus = SURNAME_RE.findall(r.get("authors") or "")
            for au in aus:
                s = _skel(au)
                if s in names:
                    hits.append(r.get("index"))
                    break
    return {"author_surnames": sorted(set(names)), "indices": sorted(set(h for h in hits if h)),
            "count": len(set(h for h in hits if h)),
            "basis": "surname_match",
            "note": "姓氏匹配候选，作者身份须逐条人工确认，非结论"}


def main():
    ap = argparse.ArgumentParser(description="4.2 引用分布与著录数据审计（v3.23.0）")
    ap.add_argument("--refs", required=True)
    ap.add_argument("--paras", default=None, help="out_paras.json（原始提取，姓名核对的首选源）")
    ap.add_argument("--body", default=None, help="body.txt（正文引用统计源）")
    ap.add_argument("--crossref", default=None)
    ap.add_argument("--authors", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--dup-threshold", dest="dup_threshold", type=float, default=0.80)
    ap.add_argument("--no-crossref", dest="no_crossref", action="store_true")
    args = ap.parse_args()

    try:
        refs = json.load(open(args.refs, encoding="utf-8"))
        if isinstance(refs, dict):
            refs = refs.get("refs") or refs.get("references") or []
    except OSError as e:
        print("ERR: 读不到 refs: %s" % e, file=sys.stderr)
        return 2

    warnings = []
    body_text, blocks = "", {}
    if args.body:
        try:
            body_text = open(args.body, encoding="utf-8", errors="replace").read()
        except OSError:
            warnings.append("body.txt 读不到，引用覆盖块降级")
    if args.paras:
        try:
            paras = json.load(open(args.paras, encoding="utf-8"))
            full = "\n".join((p.get("text") or "") for p in paras)
            _, raw_refs = split_body_references(full)
            blocks = ref_blocks(raw_refs)
        except OSError:
            warnings.append("out_paras.json 读不到，姓名核对退回文献表")
    if not body_text and blocks:
        body_text = "\n".join(blocks.values())

    coverage, co_asc = audit_coverage(body_text, len(refs))
    dups = audit_duplicates(refs, args.dup_threshold)

    cr_index = {}
    if args.crossref and not args.no_crossref:
        try:
            cr = json.load(open(args.crossref, encoding="utf-8"))
            cr = cr.get("results") if isinstance(cr, dict) else cr
            cr_index = {x.get("index"): x for x in cr if x.get("status") != "not_found"}
        except OSError:
            warnings.append("crossref.json 读不到，姓名核对无 Crossref 基准")

    names = audit_names(refs, blocks, cr_index)

    authors = {}
    if args.authors:
        try:
            authors = json.load(open(args.authors, encoding="utf-8"))
        except OSError:
            warnings.append("authors.json 读不到，自引候选未计算")
    selfc = audit_self_citation(refs, authors)

    out = {
        "schema_version": 1,
        "generated_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "coverage": coverage,
        "co_ascending": co_asc,
        "duplicates": dups,
        "names": names,
        "self_citation_candidates": selfc,
        "warnings": warnings,
    }
    json.dump(out, open(args.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({
        "refs": len(refs), "cited": coverage["cited_count"],
        "uncited": coverage["uncited_count"], "over_range": len(coverage["over_range"]),
        "dup_pairs": len(dups["pairs"]), "max_ratio": dups["max_pair"]["ratio"],
        "name_findings": len(names["findings"]),
        "baseline": names["with_baseline"], "self_cand": selfc["count"],
        "warnings": warnings}, ensure_ascii=False))
    print("OUT:", args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""semantic_check.py — 参考文献语义相关性核对工具链（熊猫找茬-已出版 v3.11.0 新增）。

职责：把「逐条、基于文献摘要的语义比对」从人工抽样升级为可复现的正式流程。

子命令：
  fetch     --refs <refs.json> --out <semantic_abs.json>
            对每条带 DOI 的参考文献抓取摘要：
              ① Crossref（复用 crossref_check.query_crossref_by_doi 及其 7 天缓存）
              ② Crossref 无 abstract → OpenAlex works API 兜底
                  （abstract_inverted_index 按位置重建，免费 API 无需 key）
            无 DOI 或双源均无摘要 → abstract='' 并标注 source='none'（不得判「无法核实」而跳过，
            由 agent 用 元数据+标题+人工核实 降级处理并在报告标注）。
  contexts  --body <正文.txt> --refs <refs.json> --out <citation_contexts.json>
            从正文（References 之前的叙述文本）提取每条文献的全部引用句。
            引用编号组正则覆盖 [1]、[1,2]、[49, 50]、[1-3]、[12–15]（先归一并连字符）。
  pair      --abs <semantic_abs.json> --ctx <citation_contexts.json> --out <semantic_pairs.json>
            合并摘要与引用上下文为逐条比对清单（agent 精读判定用，含 source 分级）。

约定（落盘文件，供报告第 5 节汇总读取）：
  semantic_abs.json / citation_contexts.json / semantic_pairs.json

摘要覆盖口径（写入报告）：
  摘要可得（Crossref/OpenAlex 任一）→ 按摘要比对；
  仅元数据（双源无摘要但 Crossref 命中书目）→ 按「标题+元数据+人工核实」降级比对，标注「仅元数据」；
  双源均无法定位 → 人工联网核实后归入「经人工核实」或「无法核实」并说明原因。
"""

import argparse
import bisect
import difflib
import hashlib
import html
import json
import os
import re
import sys
import time
import unicodedata

import crossref_check  # 复用 query_crossref_by_doi + 缓存

OPENALEX_API = "https://api.openalex.org/works/https://doi.org/{doi}"

# 引用编号组：覆盖 [1] [1,2] [49, 50] [1-3] [1–3] [1−3]
# 破折号类必须四种全收：hyphen / en-dash / em-dash / **minus sign U+2212**
# （ECM20260040 实测：[1,16−18] 用的是 minus sign，旧类漏匹配 → [16][18] 上下文为空）
_DASH = ",\u2013\u2014\u2212-"
CITE_GROUP_RE = re.compile(r"\[(\d+(?:\s*[" + _DASH + r"]\s*\d+)*)\]")
ABSTRACT_MAX = 1800  # 截断上限（字符）
# 引用上下文 = 以引用标记为中心的滑窗。双栏 PDF 按句点切句会产生错栏碎片，
# 滑窗不依赖句子边界、天然跟随文本流，是双栏排版下更稳的上下文取法。
WIN_PRE = 140    # 标记前窗口（字符）
WIN_POST = 220   # 标记后窗口（字符）
WIN_LIMIT = 3    # 每条文献最多保留窗口数
STACK_MIN = 5    # 合并引用展开后 >= 该篇数即提示「引用堆叠」（<=0 关闭）


def clean_abstract(raw: str) -> str:
    """剥 JATS 标签 + HTML 实体 + 压缩空白。"""
    if not raw:
        return ""
    t = re.sub(r"<[^>]+>", " ", raw)
    t = html.unescape(t)
    return re.sub(r"\s+", " ", t).strip()[:ABSTRACT_MAX]


def rebuild_openalex_abstract(inv: dict) -> str:
    """abstract_inverted_index: {word: [positions]} → 按位置排序重建文本。"""
    if not inv:
        return ""
    pos = {}
    for w, ps in inv.items():
        for p in ps:
            pos[p] = w
    if not pos:
        return ""
    text = " ".join(pos[i] for i in sorted(pos))
    return re.sub(r"\s+", " ", text).strip()[:ABSTRACT_MAX]


def fetch_abstract(doi: str):
    """返回 (abstract, source)。source: 'crossref' | 'openalex' | 'none'。"""
    doi = doi.rstrip(".").lower()
    # ① Crossref
    try:
        work = crossref_check.query_crossref_by_doi(doi)
        if isinstance(work, dict) and not work.get("_error"):
            abstract = clean_abstract(work.get("abstract") or "")
            if abstract:
                return abstract, "crossref"
    except Exception:
        pass
    # ② OpenAlex 兜底
    try:
        import requests
        resp = requests.get(
            OPENALEX_API.format(doi=doi),
            params={"mailto": crossref_check.MAILTO},
            headers={"User-Agent": crossref_check.USER_AGENT},
            timeout=20,
        )
        if resp.status_code == 200:
            msg = resp.json().get("abstract_inverted_index")
            abstract = rebuild_openalex_abstract(msg or {})
            if abstract:
                return abstract, "openalex"
    except Exception:
        pass
    finally:
        time.sleep(0.15)  # OpenAlex 免费层限速缓冲（保守）
    return "", "none"


def resolve_doi_by_title(ref: dict) -> str:
    """无 DOI 文献：用参考文献标题在 Crossref 反查 DOI（供摘要抓取）。

    v3.12.0（CESCI-D-26-00015 实测）：Vancouver 参考文献列表常整体不带 DOI，
    旧实现直接判"无自动摘要通道"，导致 36/36 全部无摘要、语义维度被迫整体降级为
    「仅元数据」——这是**工具能力缺口造成的降级**，而非源端确实无摘要。
    复用 crossref_check 的 query.title= 检索 + 评分（标题为必要项，阈值 6）定位 DOI。
    """
    title = ref.get("title") or ""
    if not title:
        return ""
    try:
        items = crossref_check.query_crossref_by_title_exact(title)
    except Exception:
        items = None
    if not items:
        return ""
    best, best_score = None, 0
    for it in items:
        try:
            sc = crossref_check.score_title_search_result(
                it, title, ref.get("authors", ""),
                ref.get("year", ""), ref.get("journal", ""))
        except Exception:
            continue
        if sc > best_score:
            best, best_score = it, sc
    if best is None or best_score < 6:
        return ""
    try:
        if not crossref_check.titles_match(title, crossref_check.get_crossref_title(best)):
            return ""
    except Exception:
        return ""
    return (best.get("DOI") or "").strip().lower()


def cmd_fetch(args):
    refs = json.load(open(args.refs, encoding="utf-8"))
    out = []
    n_doi = n_resolved = n_crossref = n_openalex = n_none = n_err = 0
    for i, r in enumerate(refs):
        doi = (r.get("doi") or "").strip()
        resolved_from_title = False
        if not doi:
            doi = resolve_doi_by_title(r)
            resolved_from_title = bool(doi)
            if resolved_from_title:
                n_resolved += 1
        rec = {
            "ref_index": r.get("index"),
            "doi": doi,
            "doi_resolved_by_title": resolved_from_title,
            "title": r.get("title", ""),
            "journal": r.get("journal", ""),
            "year": r.get("year", ""),
            "abstract": "",
            "source": "none",
        }
        if doi:
            n_doi += 1
            try:
                abstract, source = fetch_abstract(doi)
                rec["abstract"], rec["source"] = abstract, source
                if source == "crossref":
                    n_crossref += 1
                elif source == "openalex":
                    n_openalex += 1
                else:
                    n_none += 1
            except Exception as e:
                n_err += 1
                rec["error"] = str(e)
        else:
            n_none += 1  # 双源均无法定位 DOI → 交由 agent 降级处理
        out.append(rec)
        if (i + 1) % 25 == 0:
            print(f"  ...{i+1}/{len(refs)} (abs:{n_crossref + n_openalex})", flush=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(
        f"FETCH DONE: total={len(refs)} doi={n_doi} (resolved_by_title={n_resolved}) "
        f"crossref_abs={n_crossref} openalex_abs={n_openalex} "
        f"no_abstract={n_none} errors={n_err}"
    )
    print("OUT:", args.out)


def cmd_contexts(args):
    text = open(args.body, encoding="utf-8").read()
    refs = json.load(open(args.refs, encoding="utf-8"))
    # 归一 all dash variants → hyphen，便于区间解析
    # （en-dash U+2013 / em-dash U+2014 / minus sign U+2212；ECM20260040 实测缺 minus 会漏 [1,16−18]）
    for _d in ("\u2013", "\u2014", "\u2212"):
        text = text.replace(_d, "-")
    cited = {}  # idx -> [window...]

    def parse_group(g):
        nums = set()
        for part in g.split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-", 1)
                if a.strip().isdigit() and b.strip().isdigit():
                    nums.update(range(int(a), int(b) + 1))
            elif part.isdigit():
                nums.add(int(part))
        return nums

    for m in CITE_GROUP_RE.finditer(text):
        nums = parse_group(m.group(1))
        if not nums:
            continue
        s, e = m.start(), m.end()
        a = max(0, s - WIN_PRE)
        b = min(len(text), e + WIN_POST)
        win = " ".join(text[a:b].split())
        if a > 0:
            win = "…" + win
        if b < len(text):
            win = win + "…"
        # 过滤图表标题行等非叙述窗口
        if re.match(r"^(Fig(?:ure|s)?|Table|Scheme|Box)\b", win.strip()):
            continue
        for n in nums:
            cited.setdefault(n, []).append(win)
    # 截断每篇窗口数
    for n in cited:
        cited[n] = cited[n][:WIN_LIMIT]
    # 补全 refs 中未被引用的条目（空列表）——保持 1:1，便于全检覆盖核对
    for r in refs:
        cited.setdefault(r.get("index"), [])
    out = {str(k): cited[k] for k in sorted(cited)}
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    n_cited = sum(1 for v in cited.values() if v)
    print(f"CONTEXTS DONE: refs={len(refs)} with_context={n_cited} no_context={len(refs) - n_cited}")
    print("OUT:", args.out)


def cmd_pair(args):
    abs_data = json.load(open(args.abs, encoding="utf-8"))
    ctx_data = json.load(open(args.ctx, encoding="utf-8"))
    pairs = []
    for a in abs_data:
        idx = a["ref_index"]
        pairs.append({
            "ref_index": idx,
            "doi": a.get("doi", ""),
            "title": a.get("title", ""),
            "journal": a.get("journal", ""),
            "year": a.get("year", ""),
            "source": a.get("source", "none"),
            "abstract": a.get("abstract", ""),
            "contexts": ctx_data.get(str(idx), []),
        })
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False, indent=1)
    n_abs = sum(1 for p in pairs if p["abstract"])
    n_ctx = sum(1 for p in pairs if p["contexts"])
    n_none = sum(1 for p in pairs if not p["abstract"])
    print(f"PAIR DONE: total={len(pairs)} with_abstract={n_abs} no_abstract={n_none} with_context={n_ctx}")
    print("OUT:", args.out)


# ============================================================================
# v3.20.0：逐处引用位置（position × ref）
#
# 判定粒度下沉：不再「一篇文献一个结论」，改为「每一处引用位置 × 该处引用的文献」。
# 与 cmd_contexts 共用 CITE_GROUP_RE / WIN_PRE / WIN_POST 口径（便于与历史
# citation_contexts.json 逐条对照），区别有两点：
#   ① **不截断**位置数量（去掉 WIN_LIMIT）——一篇文献被引 6 次就应产出 6 处；
#   ② 每个位置带可回溯坐标（page / col / para_idx / char_start）。
# 口径继承：滑窗不依赖句子边界（双栏 PDF 切句会错栏），合引 [10,11] 内每篇文献
# 各产一条 instance 但共享同一窗口。
# ============================================================================

HEAD_RE = re.compile(r"^(\d+(?:\.\d+){0,3})\.?\s+([A-Z][^\n]{2,90})$")
_DEFAULT_TEMPLATE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets", "report_template.html")
NAMED_HEADS = {
    "abstract", "keywords", "introduction", "conclusions", "conclusion",
    "acknowledgments", "acknowledgements", "author contribution statement",
    "data availability", "declaration of competing interest", "funding",
    "references", "methods", "results", "discussion", "materials and methods",
}


def expand_group(g):
    """引用编号组 → 编号集合（与 cmd_contexts 内 parse_group 同语义）。"""
    nums = set()
    for part in g.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            if a.strip().isdigit() and b.strip().isdigit():
                nums.update(range(int(a), int(b) + 1))
        elif part.isdigit():
            nums.add(int(part))
    return nums


def build_stream(idx_paras):
    """[(para_idx, para)] → (text, spans)。

    spans = [(start, end, para_idx, page, col)]，end 为开区间；段落以 '\\n' 拼接，
    分隔符不计入任何 span，故 offset 落在分隔符上时归属前一段（保守）。
    """
    pieces, spans, pos = [], [], 0
    for idx, p in idx_paras:
        t = (p.get("text") or "").strip()
        spans.append((pos, pos + len(t), idx, p.get("page"), p.get("col")))
        pieces.append(t)
        pos += len(t) + 1
    return "\n".join(pieces), spans


def para_at(spans, starts, off):
    """字符 offset → span（bisect 反查，O(log n)）。"""
    if not spans:
        return (0, 0, None, None, None)
    off = max(0, off)
    k = bisect.bisect_right(starts, off) - 1
    if k < 0:
        k = 0
    return spans[k]


def _is_heading(t):
    """轻量章节标题启发式。仅用于报告定位，**不参与 verdict**。

    误判风险：① 正文行恰以「数字+大写词」开头会被误标；② 公式碎片已由
    「必须含小写单词」挡掉；③ `Table 1` 类以字母开头不匹配。故字段标 conf。
    """
    s = (t or "").strip()
    if not s or len(s) > 100:
        return None
    m = HEAD_RE.match(s)
    if m and re.search(r"[a-z]", m.group(2)):
        return m.group(1), m.group(2).rstrip(" ,."), "numbered"
    low = s.lower().rstrip(":").strip()
    if low in NAMED_HEADS:
        return "", s.rstrip(":").strip(), "named"
    return None


def cmd_instances(args):
    paras = json.load(open(args.paras, encoding="utf-8"))
    refs = json.load(open(args.refs, encoding="utf-8"))
    abs_map = {}
    if args.abs:
        for a in json.load(open(args.abs, encoding="utf-8")):
            abs_map[a.get("ref_index")] = a

    # ① 裁掉 References 之后（判据同 extract_pdf.py 第 173-181 行）
    body, cut_at = [], None
    for idx, p in enumerate(paras):
        t = (p.get("text") or "").strip()
        if len(t) < 20 and t.lower().startswith("references"):
            cut_at = idx
            break
        body.append((idx, p))

    # ② 拼文本流（先拼后归一：三种破折号等长替换，字符偏移不变，bisect 仍有效）
    text, spans = build_stream(body)
    for _d in ("\u2013", "\u2014", "\u2212"):
        text = text.replace(_d, "-")
    starts = [s[0] for s in spans]

    # ③ 章节归属
    sec_of = {}
    cur = {"label": "", "title": "(未识别章节)", "para_idx": None, "conf": "none"}
    for idx, p in body:
        h = _is_heading(p.get("text"))
        if h:
            cur = {"label": h[0], "title": h[1], "para_idx": idx, "conf": h[2]}
        sec_of[idx] = dict(cur)

    # ④ 逐处开窗（不截断）
    positions, instances = [], []
    hash_seen, caption_like = {}, 0
    for m in CITE_GROUP_RE.finditer(text):
        nums = expand_group(m.group(1))
        if not nums:
            continue
        s, e = m.start(), m.end()
        a = max(0, s - args.win_pre)
        b = min(len(text), e + args.win_post)
        ctx = " ".join(text[a:b].split())
        if a > 0:
            ctx = "…" + ctx
        # 本位标记在（已折叠空白的）窗口内的精确索引：供作者核对区分
        # 「人名+本位标记」与「窗口里顺带扫到的别处人名」
        _seg = text[a:s]
        _own = (1 if a > 0 else 0) + len(" ".join(_seg.split()))
        if _seg and _seg[-1].isspace() and _seg.split():
            _own += 1
        if b < len(text):
            ctx = ctx + "…"
        # 去噪规则保持原样（图表标题行不立案），仅计数供核对
        if re.match(r"^(Fig(?:ure|s)?|Table|Scheme|Box)\b", ctx.strip()):
            caption_like += 1
            continue
        sp = para_at(spans, starts, s)
        pid = "P%04d" % (len(positions) + 1)
        ch = hashlib.md5(ctx.encode("utf-8")).hexdigest()[:12]
        dup = hash_seen.get(ch)
        hash_seen.setdefault(ch, pid)
        positions.append({
            "position_id": pid,
            "page": sp[3], "col": sp[4], "para_idx": sp[2],
            "char_start": s, "char_end": e,
            "marker_raw": m.group(0),
            "ref_indices": sorted(nums),
            "is_multi_ref": len(nums) > 1,
            "is_range": bool(re.search(r"[\u2013\u2014\u2212-]", m.group(1))),
            "ref_count": len(nums),
            "stacking": 0 < STACK_MIN and len(nums) >= STACK_MIN,
            "context": ctx,
            "ctx_own_idx": _own,
            "context_hash": ch,
            "dup_of": dup,
            "window": {
                "start_para": para_at(spans, starts, a)[2],
                "end_para": para_at(spans, starts, max(a, b - 1))[2],
            },
            "section": sec_of.get(sp[2], cur),
        })
        for n in sorted(nums):
            instances.append({
                "instance_id": "%s-R%d" % (pid, n),
                "position_id": pid,
                "ref_index": n,
            })

    ref_idx_all = [r.get("index") for r in refs]
    cited = sorted({i["ref_index"] for i in instances})
    meta = {
        "source_paras": args.paras, "source_refs": args.refs,
        "body_paras": len(body), "refs_cut_at": cut_at,
        "stream_chars": len(text), "win_pre": args.win_pre, "win_post": args.win_post,
        "positions": len(positions), "instances": len(instances),
        "refs_total": len(ref_idx_all), "refs_cited": len(cited),
        "refs_uncited": [r for r in ref_idx_all if r not in cited],
        "dropped_by_limit": 0, "caption_like": caption_like,
        "stack_positions": sum(1 for p in positions if p["stacking"]),
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "positions": positions, "instances": instances},
                  f, ensure_ascii=False, indent=1)
    print("INSTANCES DONE: positions=%d instances=%d refs_cited=%d/%d uncited=%d "
          "caption_like=%d body_paras=%d"
          % (len(positions), len(instances), len(cited), len(ref_idx_all),
             len(meta["refs_uncited"]), caption_like, len(body)))
    print("OUT:", args.out)

    # ⑤ 可选：与摘要/书目合并成判定输入
    if args.out_instances:
        pos_map = {p["position_id"]: p for p in positions}
        ref_by = {r.get("index"): r for r in refs}
        pairs = []
        n_abs = n_meta = n_unv = 0
        for ins in instances:
            pos = pos_map[ins["position_id"]]
            r = ref_by.get(ins["ref_index"]) or {}
            a = abs_map.get(ins["ref_index"]) or {}
            abstract = a.get("abstract") or ""
            if abstract:
                el = "abstract"
                n_abs += 1
            elif (r.get("title") or "").strip():
                el = "metadata_only"
                n_meta += 1
            else:
                el = "unverifiable"
                n_unv += 1
            pairs.append({
                "instance_id": ins["instance_id"],
                "position_id": ins["position_id"],
                "ref_index": ins["ref_index"],
                "page": pos["page"], "col": pos["col"], "para_idx": pos["para_idx"],
                "section": pos["section"],
                "marker_raw": pos["marker_raw"],
                "shared_with": [x for x in pos["ref_indices"] if x != ins["ref_index"]],
                "context": pos["context"],
                "context_flag": "normal",
                "ref": {
                    "authors": r.get("authors", ""), "title": r.get("title", ""),
                    "journal": r.get("journal", ""), "year": r.get("year", ""),
                    "volume": r.get("volume", ""), "page": r.get("page", ""),
                    "doi": r.get("doi", ""),
                },
                "abs": {
                    "source": a.get("source", "none"), "doi": a.get("doi", ""),
                    "doi_resolved_by_title": a.get("doi_resolved_by_title", False),
                    "abstract": abstract,
                    "source_suspect": None, "suspect_reason": "",
                },
                "evidence_level": el,
            })
        # v3.22.0：重跑时合并保留人工标注。旧实现每次都把 source_suspect 写回 None，
        # OCE20260027 实测重跑后 4 条标注全灭、2 处 evidence_level 被打回 abstract。
        # 规则：新文件里为空的 suspect 字段，用已有文件的值补齐；已有文件判为
        # metadata_only 且带 suspect 的，档位不回升。
        _merged = 0
        if os.path.exists(args.out_instances):
            try:
                _old = {x.get("instance_id"): x for x in json.load(
                    open(args.out_instances, encoding="utf-8")).get("instances", [])}
            except Exception:
                _old = {}
            for _p in pairs:
                _o = _old.get(_p["instance_id"])
                if not _o:
                    continue
                # 守卫：instance_id 是「位置序号-文献号」，正文改动会让序号整体平移。
                # 必须同时比对 ref_index 与窗口原文，避免把标注挂到另一处引用上。
                if (_o.get("ref_index") != _p.get("ref_index")
                        or (_o.get("context") or "") != (_p.get("context") or "")):
                    continue
                _oa = _o.get("abs") or {}
                if not _oa.get("source_suspect"):
                    continue
                _p["abs"]["source_suspect"] = _oa.get("source_suspect")
                _p["abs"]["suspect_reason"] = _oa.get("suspect_reason", "")
                if _o.get("evidence_level") == "metadata_only":
                    _p["evidence_level"] = "metadata_only"
                _merged += 1
        if _merged:
            print("MERGE: 保留 %d 条既有 source_suspect 人工标注" % _merged)
        n_abs = sum(1 for x in pairs if x["evidence_level"] == "abstract")
        n_meta = sum(1 for x in pairs if x["evidence_level"] == "metadata_only")
        n_unv = sum(1 for x in pairs if x["evidence_level"] == "unverifiable")
        meta2 = dict(meta)
        meta2.update({"instances_abstract": n_abs,
                      "instances_metadata_only": n_meta,
                      "instances_unverifiable": n_unv})
        with open(args.out_instances, "w", encoding="utf-8") as f:
            json.dump({"meta": meta2, "instances": pairs},
                      f, ensure_ascii=False, indent=1)
        print("SEM INSTANCES: abstract=%d metadata_only=%d unverifiable=%d"
              % (n_abs, n_meta, n_unv))
        print("OUT:", args.out_instances)


def _bg(cls, text):
    return '<span class="badge %s">%s</span>' % (cls, text)


def _snippet(ctx, anchor, width=38):
    """取以 anchor（引用标记 / 人名）为中心的上下文摘录，供人工在 PDF 内搜索核对。

    窗口内可能同时出现相邻位置的同名标记（同一句引两次），此时取「距本位标记
    预期位置最近」的那一个——理想窗口前置 WIN_PRE 字符，故本位标记约在
    min(WIN_PRE, len-WIN_POST) 处；直接 ctx.find() 会取到前一句的标记。
    """
    ctx = " ".join((ctx or "").split())
    if not ctx:
        return ""
    anchor = (anchor or "").strip()
    hits = [m.start() for m in re.finditer(re.escape(anchor), ctx)] if anchor else []
    if not hits:
        head = ctx[:width].strip()
        return "…" + head + ("…" if len(ctx) > width else "")
    if len(hits) > 1:
        target = min(WIN_PRE, max(0, len(ctx) - WIN_POST))
        i = min(hits, key=lambda x: (abs(x - target), x))
    else:
        i = hits[0]
    a = max(0, i - width)
    b = min(len(ctx), i + len(anchor) + width)
    if a > 0:                                  # 截断点回退到词边界，避免出现半截单词
        _sp = ctx.find(" ", a)
        if 0 <= _sp < i:
            a = _sp + 1
    if b < len(ctx):
        _sp = ctx.rfind(" ", a, b)
        if _sp > i + len(anchor):
            b = _sp
    return ("…" if a > 0 else "") + ctx[a:b].strip() + ("…" if b < len(ctx) else "")
    if a > 0:                                  # 截断点回退到词边界，避免出现半截单词
        _sp = ctx.find(" ", a)
        if 0 <= _sp < i:
            a = _sp + 1
    if b < len(ctx):
        _sp = ctx.rfind(" ", a, b)
        if _sp > i + len(anchor):
            b = _sp
    return ("…" if a > 0 else "") + ctx[a:b].strip() + ("…" if b < len(ctx) else "")


# ============================================================================
# 作者与编号一致性核对（必查项）
#
# 正文常以「Surname et al. [n]」形式归属文献。若作者名与该编号文献的首作者
# 不一致，属引用错配（比"主题不相关"更硬的问题，且不需要摘要即可判定）。
# OCE20260027 实测：P0029「Müller et al. [39]」而 [39] 首作者为 Pälike。
# 误报源是 "Challenger Deep Project [27]" / "ISOOS [44]" 这类非人名词，用
# 全大写判定 + 停用词表过滤；姓氏比对用 difflib 容忍变音符号缺失
# （refs 解析常把 Pälike 落成 Plike，不能因此误判错配）。
# ============================================================================

_NAME_STOP = {
    "project", "program", "programme", "mission", "challenge", "system", "model",
    "theory", "report", "ocean", "deep", "data", "study", "review", "figure",
    "table", "scheme", "box", "section", "refs", "reference", "supplementary",
}
AUTHOR_CITE_RE = re.compile(
    r"([A-Z][a-zA-Z\u00c0-\u024f\-]{2,})\s+"
    r"(?:et\s+al\.?|and\s+[A-Z][a-zA-Z\u00c0-\u024f\-]{2,})?\s*\[(\d+)\]")


def _first_surname(ref):
    a = (ref.get("authors") or "").strip()
    m = re.match(r"([A-Za-z\u00c0-\u024f\-]+)", a)
    return m.group(1) if m else ""


_AUTHOR_TOKEN_RE = re.compile(r"([A-Z][A-Za-z\u00c0-\u024f\-']{1,}),\s*[A-Z]\.")


def _author_surnames(ref):
    """从 authors 字段解析出全部姓氏（保序，首位即首作者）。"""
    a = (ref.get("authors") or "")
    names = _AUTHOR_TOKEN_RE.findall(a)
    if not names:
        m = re.match(r"([A-Za-z\u00c0-\u024f\-]+)", a.strip())
        if m:
            names = [m.group(1)]
    return names


def _diagnose_author_mismatch(claimed, n, refs, ctx, related=None, absm=None):
    """作者-编号不一致的成因判断与建议（结合语义相关性结论）。

    related 为该引用位置对编号 n 的语义核对结论：True=内容相符 / False=不符 / None=未核。
    三种情形：
      A 同篇合作者：仅当 related=True 才建议改作者名；related=False 时改作者名不足以修正。
      B 他篇首作者：列出候选编号与标题供人工判断，不计算重合度、不按相关性排序。
      C 无法定位：该作者既非 [n] 的首作者，也非文献表中任何一篇的首作者。因未做全表
        作者检索，不得推断"未列入参考文献表"，只陈述该可核事实并提示人工检索（可协助）。
    """
    absm = absm or {}
    cur = _author_surnames(refs.get(n, {}))
    cur_first = cur[0] if cur else "未能解析"
    rel_txt = ("该处论述与该文内容相符（语义核对一致）" if related is True
               else "该处论述与该文内容不符（语义核对不一致）" if related is False
               else "该处文献尚未完成语义核对")

    # A：同一篇的合作者（非首位）
    if cur and any(_same_surname(claimed, x) for x in cur[1:]):
        if related is True:
            return ("coauthor_in_same_ref",
                    "「%s」是 [%d] 的合作者之一，%s，编号无误；建议将正文作者名改为第一作者「%s」。"
                    % (claimed, n, rel_txt, cur_first), [], "auto")
        if related is False:
            return ("coauthor_in_same_ref_off",
                    "「%s」确为 [%d] 的合作者，但%s；仅更正作者名不足以修正该处引用，"
                    "建议人工核实是否需要更换文献。" % (claimed, n, rel_txt), [], "auto")
        return ("coauthor_in_same_ref",
                "「%s」是 [%d] 的合作者之一，该文首作者为 %s；编号可能无误，"
                "建议将正文作者名改为第一作者「%s」（该处语义相关性待核）。"
                % (claimed, n, cur_first, cur_first), [], "needs_review")

    # B：其他文献的首作者（只陈述事实 + 列候选，不计算重合度、不推荐编号）
    cands = []
    for m, r in refs.items():
        if m == n:
            continue
        ns = _author_surnames(r)
        if not ns or not _same_surname(claimed, ns[0]):
            continue
        cands.append({"ref_index": m, "first_author": ns[0],
                      "title": (r.get("title") or "")[:80],
                      "abstract_head": ((absm.get(m) or {}).get("abstract") or "")[:220],
                      "related": None})
    if cands:
        cands.sort(key=lambda x: x["ref_index"])  # 固定顺序，避免排序隐含强弱暗示
        head = "「%s」不是 [%d] 的首作者（该文首作者为「%s」）。" % (claimed, n, cur_first)
        if len(cands) == 1:
            c = cands[0]
            sug = (head + "「%s」是 [%d]《%s》的首作者。若该处论述确指该文，则属编号错配；"
                   "建议人工核对是否应改引 [%d]。"
                   % (claimed, c["ref_index"], c["title"], c["ref_index"]))
        else:
            desc = "、".join("[%d]《%s》" % (c["ref_index"], c["title"]) for c in cands[:3])
            if len(cands) > 3:
                desc += " 等 %d 篇" % len(cands)
            sug = (head + "文献表中以该名作为首作者的有：%s。建议人工核对是否应改引其中一篇。"
                   % desc)
        return ("other_ref_first_author", sug, cands, "needs_review")

    # C：无法定位（未做全表作者检索，只能说"不是任何一篇的首作者"）
    tail = ("该作者不是文献表中任何一篇的首作者，无法据此自动定位到具体文献；"
            "建议人工检索该作者的原始文献并核对编号，如需协助，我可以代为检索核对。")
    if related is False:
        return ("no_match",
                "作者名与编号不匹配：正文署「%s」，而 [%d] 的首作者为「%s」，"
                "且该处论述与 [%d] 内容不符。%s"
                % (claimed, n, cur_first, n, tail), [], "auto")
    if related is True:
        return ("no_match",
                "作者名与编号不匹配：正文署「%s」，[%d] 的首作者为「%s」，"
                "但该处论述与 [%d] 内容相符。%s"
                % (claimed, n, cur_first, n, tail), [], "auto")
    return ("no_match",
            "作者名与编号不匹配：正文署「%s」，[%d] 的首作者为「%s」；"
            "该处语义核对尚未完成。%s"
            % (claimed, n, cur_first, tail), [], "needs_review")



def _norm_surname(s):
    """姓氏归一化：小写 + 去变音符（Pälike → palike）+ 仅留字母。"""
    s = unicodedata.normalize("NFKD", (s or "").lower())
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[^a-z]", "", s)


def _same_surname(a, b):
    """判断是否同一姓氏。

    ⚠️ 阈值必须 ≥0.85 且首字母相同：Müller 与 Miller 的相似度为 0.833，
    若阈值取 0.75 会把二者判为同一人，进而错误建议"改引 [43]"
    （OCE20260027 实测事故）。而 Pälike 与解析残缺的 Plike 为 0.909，
    0.85 恰好能容忍变音符丢失又不误并近形异姓。
    """
    a, b = _norm_surname(a), _norm_surname(b)
    if not a or not b:
        return False
    if a == b:
        return True
    if len(a) >= 4 and len(b) >= 4 and (a in b or b in a):
        return True
    if a[0] != b[0]:
        return False
    return difflib.SequenceMatcher(None, a, b).ratio() >= 0.85


def cmd_authors(args):
    d = json.load(open(args.instances, encoding="utf-8"))
    refs = {r.get("index"): r for r in json.load(open(args.refs, encoding="utf-8"))}
    # 复用语义核对结论：该位置对该编号文献是否相符
    judg = {}
    jpath = getattr(args, "judgments", None)
    if jpath and os.path.exists(jpath):
        for j in json.load(open(jpath, encoding="utf-8")).get("instances", []):
            ev = j.get("evidence_level")
            if ev == "unverifiable":
                rv = None
            elif j.get("verdict") == "ok":
                rv = True
            elif j.get("verdict") == "flag":
                rv = False
            else:
                rv = None
            judg[(j.get("position_id"), j.get("ref_index"))] = rv
    absm = {}
    apath = getattr(args, "abs", None)
    if apath and os.path.exists(apath):
        for a in json.load(open(apath, encoding="utf-8")):
            absm[a.get("ref_index")] = a

    checks, skipped, seen = [], [], set()
    for pos in d.get("positions", []):
        for m in AUTHOR_CITE_RE.finditer(pos.get("context", "") or ""):
            name, n = m.group(1), int(m.group(2))
            # 只认「人名 + 本位标记」：窗口前后 140/220 字符内可能顺带扫到邻近
            # 位置引用的人名，那不是本处引用；不排除会在报告里生成内容完全相同
            # 的重复行（同名同编号、位置显示也一样，读者无法分辨）。
            _own = pos.get("ctx_own_idx")
            if _own is not None:
                _br = m.end() - len(m.group(2)) - 2
                if abs(_br - _own) > 2:
                    continue
            # 按位置去重：C 分支的措辞依赖该位置的语义结论，全局去重会串用别处的结论
            key = (pos.get("position_id"), name.lower(), n)
            if key in seen:
                continue
            seen.add(key)
            if name.isupper() or name.lower() in _NAME_STOP:
                skipped.append({"token": name, "ref_index": n, "reason": "非人名词"})
                continue
            first = _first_surname(refs.get(n, {}))
            ok = _same_surname(name, first)
            diag, sug, cands, status = "", "", [], ""
            if not ok:
                related = judg.get((pos.get("position_id"), n))
                diag, sug, cands, status = _diagnose_author_mismatch(
                    name, n, refs, pos.get("context", ""), related, absm)
            checks.append({
                "position_id": pos.get("position_id"),
                "ref_index": n,
                "claimed": name,
                "refs_first_author": first,
                "match": ok,
                "diagnosis": diag,
                "suggestion": sug,
                "semantic_status": status,
                "candidates": cands,
                "page": pos.get("page"), "col": pos.get("col"),
                "section": pos.get("section", {}),
                "snippet": m.group(0),
            })
    mism = [c for c in checks if not c["match"]]
    meta = {"checked": len(checks), "matched": len(checks) - len(mism),
            "mismatched": len(mism), "skipped": len(skipped)}
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "checks": checks, "skipped": skipped},
                  f, ensure_ascii=False, indent=1)
    print("AUTHORS DONE: checked=%d matched=%d mismatched=%d skipped=%d"
          % (meta["checked"], meta["matched"], meta["mismatched"], meta["skipped"]))
    for c in mism:
        print("  MISMATCH %s: 正文「%s」vs 文献[%d]首作者「%s」"
              % (c["position_id"], c["claimed"], c["ref_index"], c["refs_first_author"]))
        if c.get("suggestion"):
            print("    → [%s] %s" % (c.get("diagnosis", ""), c["suggestion"]))
    print("OUT:", args.out)


_COL_CN = {"L": "左栏", "R": "右栏", "F": "通栏"}
_EV_BADGE = {"abstract": ("ok", "摘要级"),
             "metadata_only": ("warn", "仅元数据"),
             "unverifiable": ("info", "无法核实")}
_ISSUE_CN = {"off_topic": ("bad", "文献不相关"),
             "misrepresented": ("bad", "表述不一致"),
             "overstated": ("warn", "表述夸大"),
             "citation_number_mismatch": ("bad", "疑似编号错配"),
             "unverifiable": ("info", "无法核实")}


def _lint_html(s):
    """rich() 白名单预检（gen_report.py 第 105-120 行只放行 class 属性）。"""
    bad = []
    if re.search(r"\b(colspan|rowspan)\s*=", s):
        bad.append("colspan/rowspan")
    if re.search(r"<[a-zA-Z][^>]*\s(style|id|href|target)\s*=", s):
        bad.append("style/id/href 属性")
    if "{{" in s:
        bad.append("残留占位符")
    return bad


def cmd_report(args):
    inst = json.load(open(args.instances, encoding="utf-8"))
    jd = json.load(open(args.judgments, encoding="utf-8"))
    meta = inst.get("meta", {})
    pairs = {p["instance_id"]: p for p in inst.get("instances", [])}
    judgments = jd.get("instances", [])

    total = len(pairs)
    judged = len(judgments)
    flags = [j for j in judgments if j.get("verdict") == "flag"]
    n_flag = len(flags)
    n_ok = sum(1 for j in judgments if j.get("verdict") == "ok")

    ev_inst, ev_ref = {}, {}
    for p in pairs.values():
        ev_inst[p["evidence_level"]] = ev_inst.get(p["evidence_level"], 0) + 1
        ev_ref.setdefault(p["ref_index"], p["evidence_level"])
    ev_ref_cnt = {}
    for v in ev_ref.values():
        ev_ref_cnt[v] = ev_ref_cnt.get(v, 0) + 1

    pos_flag = {j["position_id"] for j in flags}
    pos_ok = {j["position_id"] for j in judgments if j.get("verdict") == "ok"}
    ref_ok = {j["ref_index"] for j in judgments if j.get("verdict") == "ok"}
    n_positions = meta.get("positions", 0)
    _bypos = {}
    for p in pairs.values():
        _bypos.setdefault(p["position_id"], set()).add(p["ref_index"])
    n_multi = sum(1 for s in _bypos.values() if len(s) > 1)
    _ctx_by_pos = {}
    for _p in pairs.values():
        _ctx_by_pos.setdefault(_p["position_id"], _p.get("context", ""))

    # 堆叠与作者核对的前置结果（供前导段给「无问题」结论）
    _smin = getattr(args, "stack_min", STACK_MIN) or 0
    _stacks = (sorted(((pid, len(s)) for pid, s in _bypos.items() if len(s) >= _smin),
                      key=lambda x: x[0]) if _smin > 0 else [])
    _ac = {}
    if args.author_checks:
        try:
            _ac = json.load(open(args.author_checks, encoding="utf-8"))
        except Exception:
            _ac = {}
    _ac_checked = (_ac.get("meta", {}) or {}).get("checked", 0)
    _ac_mism = [c for c in _ac.get("checks", []) if not c.get("match")]

    pos_unv = {p["position_id"] for p in pairs.values()
               if p["evidence_level"] == "unverifiable"}

    H = []
    # 统计段（原 5.1 / 5.2 / 5.3 合并于此，减少小节层级）
    _clean_tail = ""
    if _smin > 0 and not _stacks:
        _clean_tail = "无引用堆叠（≥ 5 篇）问题。"
        if _ac_checked and not _ac_mism:
            _clean_tail = "无引用堆叠（≥ 5 篇）问题，作者与编号一致性核验无误。"
    H.append(
        '<p>正文共 <b>%d 处</b>引用标记（其中合引 <b>%d 处</b>），展开为 '
        '<b>%d 个「位置×文献」判定单元</b>，涉及 <b>%d 篇</b>文献，'
        '<b>%d/%d 完成判定</b>，<b>%d 个</b>判定单元无明显问题，'
        '无法核实的引用位置 <b>%d 处</b>，未引用文献 <b>%d 篇</b>。%s</p>'
        % (n_positions, n_multi, total, meta.get("refs_total", len(ev_ref)),
           judged, total, n_ok, len(pos_unv),
           len(meta.get("refs_uncited", [])), _clean_tail))

    H.append('<table><tr><th>获取程度</th><th>判定单元</th><th>涉及文献</th><th>说明</th></tr>')
    H.append('<tr><td>%s</td><td>%d</td><td>%d 篇</td><td>Crossref / OpenAlex 摘要，按摘要内容比对</td></tr>'
             % (_bg("ok", "摘要级"), ev_inst.get("abstract", 0), ev_ref_cnt.get("abstract", 0)))
    # v3.22.0：原此处硬编码「其中 [1]、[6] 经核验为 Crossref 同题异著」，会把某一稿的
    # 实测结论写进每一份报告。改为从实际 source_suspect 标记生成；无标记时不出现该短语。
    _sus_refs = sorted({p["ref_index"] for p in pairs.values()
                        if (p.get("abs") or {}).get("source_suspect")})
    _sus_txt = ("；其中 %s 经核验为 Crossref 同题异著，已剔除其摘要"
                % "、".join("[%d]" % _n for _n in _sus_refs)) if _sus_refs else ""
    H.append('<tr><td>%s</td><td>%d</td><td>%d 篇</td>'
             '<td>书章 / 报告 / 无摘要文献，按题名主题 + 引用语境降级比对%s</td></tr>'
             % (_bg("warn", "仅元数据"), ev_inst.get("metadata_only", 0),
                ev_ref_cnt.get("metadata_only", 0), _sus_txt))
    H.append('<tr><td>%s</td><td>%d</td><td>%d 篇</td><td>%s</td></tr>'
             % (_bg("info", "无法核实"), ev_inst.get("unverifiable", 0), ev_ref_cnt.get("unverifiable", 0),
                "本次无" if not ev_inst.get("unverifiable") else "双源均无法定位"))
    H.append('</table>')

    H.append('<p class="note">同一处合引内每篇文献单独判定、共享同一窗口。'
             '判定仅依据该窗口的表述与文献实际内容是否相符，不评价文献本身质量；'
             '宽泛背景引用、领域综述与方法论文献在无直接矛盾时判为一致，只报告问题项。</p>')

    # 引用堆叠提示（只提示，不判定；_stacks 已按 --stack-min 预先算好）
    if _stacks:
        H.append('<p><b>引用堆叠提示</b>：正文 <b>%d 处</b>合并引用展开后 ≥ %d 篇'
                 '（最多 %d 篇），可能存在引用堆叠。</p>'
                 % (len(_stacks), _smin, max(w for _, w in _stacks)))
        H.append('<table><tr><th>位置</th><th>引用标记</th><th>展开篇数</th></tr>')
        for _pid, _w in _stacks:
            _rp = next((q for q in pairs.values() if q["position_id"] == _pid), {})
            _sec = _rp.get("section", {}) or {}
            _snip = _snippet(_rp.get("context", ""), _rp.get("marker_raw", ""))
            H.append('<tr><td>p%s · %s · §%s%s</td><td>%s</td><td>%d</td></tr>'
                     % (_rp.get("page", 0), _COL_CN.get(_rp.get("col"), _rp.get("col", "")),
                        _sec.get("label", "") or "—",
                        (" —「%s」" % html.escape(_snip)) if _snip else "",
                        html.escape(_rp.get("marker_raw", "")), _w))
        H.append('</table>')

    # 作者与编号一致性核对（必查项：不依赖摘要即可判定引用错配）
    if args.author_checks:
        ac = _ac
        am = ac.get("meta", {})
        mism = _ac_mism
        H.append('<p><b>作者与编号一致性核对</b>：共核对 %d 处「人名 + 编号」引用，'
                 '%d 处与该编号文献的首作者一致%s。</p>'
                 % (am.get("checked", 0), am.get("matched", 0),
                    ('，<b>%d 处不符</b>' % len(mism)) if mism else '，未发现错配'))
        if mism:
            H.append('<table><tr><th>位置</th><th>正文声称</th><th>文献首作者</th><th>原因判断与建议</th></tr>')
            for c in mism:
                sec = c.get("section", {}) or {}
                _snip = _snippet(_ctx_by_pos.get(c.get("position_id"), ""), c.get("claimed", ""))
                H.append('<tr><td>p%s · %s · §%s%s</td><td>%s</td><td>%s</td><td>%s</td></tr>'
                         % (c.get("page"), _COL_CN.get(c.get("col"), c.get("col")),
                            sec.get("label", ""),
                            (" —「%s」" % html.escape(_snip)) if _snip else "",
                            html.escape(c.get("claimed", "")),
                            html.escape(c.get("refs_first_author", "") or "（未能解析）"),
                            html.escape(c.get("suggestion") or "建议人工核对原始出处")))
            H.append('</table>')

    # 无法核实清单（有则列，无则不占篇幅）
    if pos_unv:
        H.append('<p><b>无法核实的引用位置（%d 处）</b></p>' % len(pos_unv))
        H.append('<table><tr><th>位置</th><th>文献</th><th>原因</th></tr>')
        for iid, p in pairs.items():
            if p["evidence_level"] == "unverifiable":
                H.append('<tr><td>p%d · %s · §%s</td><td>[%d] %s</td><td>%s</td></tr>'
                         % (p["page"], _COL_CN.get(p["col"], p["col"]),
                            p["section"].get("label", ""), p["ref_index"],
                            html.escape((p["ref"].get("title") or "")[:60]),
                            html.escape(p["abs"].get("suspect_reason") or "双源均无法定位")))
        H.append('</table>')

    if not flags:
        H.append('<p class="note">未发现引用位置与文献内容不符的情况。</p>')
    else:
        H.append('<p>以下 <b>%d 处</b>引用位置的表述与文献实际内容不符（共 <b>%d 个</b>判定单元）：</p>'
                 % (len(pos_flag), n_flag))
    for k, j in enumerate(sorted(flags, key=lambda x: x["instance_id"]), 1):
        p = pairs.get(j["instance_id"], {})
        sec = p.get("section", {}) or {}
        ev = j.get("evidence_level", p.get("evidence_level", ""))
        cls, evtxt = _EV_BADGE.get(ev, ("info", ev))
        icls, itxt = _ISSUE_CN.get(j.get("issue_type", ""), ("warn", "需复核"))
        H.append('<h3>问题 %d · p%d · [%d]</h3>'
                 % (k, p.get("page", 0), j.get("ref_index", 0)))
        H.append('<div class="finding">')
        H.append('<div class="blk"><b>引用位置</b>正文第 %d 页%s，第 %s 节，引用标记 '
                 '<span class="mono">%s</span>（判定单元 %s）</div>'
                 % (p.get("page", 0), _COL_CN.get(p.get("col"), p.get("col", "")),
                    sec.get("label", "") or "—",
                    html.escape(p.get("marker_raw", "")), j["instance_id"]))
        H.append('<div class="blk"><b>引用上下文</b><blockquote>%s</blockquote></div>'
                 % html.escape(j.get("context_quote", "")))
        H.append('<div class="blk"><b>文献实际内容</b>%s %s</div>'
                 % (_bg(cls, evtxt), html.escape(j.get("ref_actual", ""))))
        H.append('<div class="blk"><b>问题分析</b>%s %s</div>'
                 % (_bg(icls, itxt), html.escape(j.get("analysis", ""))))
        if j.get("likely_benign"):
            H.append('<div class="blk"><b>良性解释</b>%s</div>'
                     % html.escape(j["likely_benign"]))
        H.append('</div>')

    frag = "\n".join(H)
    bad = _lint_html(frag)
    with open(args.out_html, "w", encoding="utf-8") as f:
        f.write(frag)
    print("REPORT DONE: positions=%d instances=%d ok=%d flag=%d problem_positions=%d"
          % (n_positions, total, n_ok, n_flag, len(pos_flag)))
    print("OUT:", args.out_html)

    if args.out_preview:
        tmpl_path = args.template or _DEFAULT_TEMPLATE
        css = ""
        try:
            tmpl = open(tmpl_path, encoding="utf-8").read()
            m = re.search(r"<style>.*?</style>", tmpl, re.S)
            css = m.group(0) if m else ""
        except Exception as e:
            print("WARN: 模板读取失败(%s)，预览页无样式" % e)
        preview = (
            '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n<meta charset="utf-8">\n'
            '<title>第 5 节预览 · 参考文献语义相关性</title>\n%s\n'
            '<style>body{max-width:960px;margin:0 auto;padding:28px 24px;'
            'font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;'
            'color:#222;line-height:1.7;background:#fff}</style>\n'
            '</head>\n<body>\n<h2>5 参考文献语义相关性检测</h2>\n%s\n</body>\n</html>\n'
            % (css, frag))
        with open(args.out_preview, "w", encoding="utf-8") as f:
            f.write(preview)
        print("PREVIEW:", args.out_preview)
    if bad:
        print("LINT FAIL:", "; ".join(bad))
        sys.exit(2)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("fetch")
    p.add_argument("--refs", required=True)
    p.add_argument("--out", required=True)
    p = sub.add_parser("contexts")
    p.add_argument("--body", required=True)
    p.add_argument("--refs", required=True)
    p.add_argument("--out", required=True)
    p = sub.add_parser("pair")
    p.add_argument("--abs", required=True)
    p.add_argument("--ctx", required=True)
    p.add_argument("--out", required=True)
    p = sub.add_parser("instances")
    p.add_argument("--paras", required=True)
    p.add_argument("--refs", required=True)
    p.add_argument("--abs", default=None)
    p.add_argument("--out", required=True)
    p.add_argument("--out-instances", dest="out_instances", default=None)
    p.add_argument("--win-pre", dest="win_pre", type=int, default=WIN_PRE)
    p.add_argument("--win-post", dest="win_post", type=int, default=WIN_POST)
    p = sub.add_parser("authors")
    p.add_argument("--instances", required=True)
    p.add_argument("--refs", required=True)
    p.add_argument("--judgments", default=None)
    p.add_argument("--abs", default=None)
    p.add_argument("--out", required=True)
    p = sub.add_parser("report")
    p.add_argument("--instances", required=True)
    p.add_argument("--judgments", required=True)
    p.add_argument("--out-html", dest="out_html", required=True)
    p.add_argument("--out-preview", dest="out_preview", default=None)
    p.add_argument("--author-checks", dest="author_checks", default=None)
    p.add_argument("--template", default=None)
    p.add_argument("--stack-min", dest="stack_min", type=int, default=STACK_MIN)
    args = ap.parse_args()
    if args.cmd == "fetch":
        cmd_fetch(args)
    elif args.cmd == "contexts":
        cmd_contexts(args)
    elif args.cmd == "pair":
        cmd_pair(args)
    elif args.cmd == "instances":
        cmd_instances(args)
    elif args.cmd == "authors":
        cmd_authors(args)
    else:
        cmd_report(args)


if __name__ == "__main__":
    main()

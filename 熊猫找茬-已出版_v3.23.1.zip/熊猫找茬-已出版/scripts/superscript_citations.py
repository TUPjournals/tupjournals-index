#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""上标数字引用统计（Carbon Future / Nature 式上标引用）。

用法：python superscript_citations.py <pdf> <out.json> <end_page> <total_refs>

判据（本稿实测：正文 9.48pt / 上标引用 6.64pt / 化学式下标 6.16pt / 页眉 8.0pt）：
- 字号：size < 正文中位字号 × 0.80 → 候选（排除页眉页脚与图表小字）；
- 基线：候选字符 top ≤ 同行正文 top + 1.0（下标 top 明显更大，被排除）；
- 分组：先按 top 聚类成视觉行，行内按 x 间隙合并为引用组；
- 单位幂次（cm^-2 等）通过「单位前须为非字母字符」判据剔除。
"""
import json
import re
import statistics
import sys

import pdfplumber

def main():
    """命令行入口（v3.22.0：由模块顶层脚本改为函数，使其可被 import 复用）。"""
    PDF, OUT, END = sys.argv[1], sys.argv[2], int(sys.argv[3])
    TOTAL = int(sys.argv[4])
    DASH = '\u002d\u2013\u2014\u2212'

    pdf = pdfplumber.open(PDF)
    pages = pdf.pages[:END]

    sizes = []
    for p in pages:
        for c in p.chars:
            if c['text'].strip():
                sizes.append(c['size'])
    med = statistics.median(sizes)
    thr_big = med * 0.80          # 正文字号下限
    thr_small = med * 0.80        # 上下标上限

    DIGITS = set('0123456789')
    SUPCH = DIGITS | set(DASH) | {','}

    UNIT_RE = re.compile(
        r'(?<![A-Za-z])(cm|mm|nm|um|\u03bcm|\u00b5m|mA|mV|kV|mol|mmol|mg|mL|kg|'
        r'eV|MeV|keV|ppm|bar|atm|min|rpm|Hz|kHz|MHz|GHz|Pa|kPa|MPa|GPa|wt|vol|at|'
        r'M|L|g|s|h|K|V|A|W|J|T)\s*$')

    found = set()
    groups = []
    for pi, p in enumerate(pages, 1):
        chars = [c for c in p.chars if c['text'].strip()]
        big = [c for c in chars if c['size'] >= thr_big]
        small = [c for c in chars if c['size'] < thr_small and c['text'] in SUPCH]
        sup = []
        for sc in small:
            near = [bc for bc in big if abs(bc['top'] - sc['top']) < 4]
            if not near:
                continue
            nb = min(near, key=lambda bc: min(abs(bc['x0'] - sc['x1']),
                                              abs(sc['x0'] - bc['x1'])))
            if sc['top'] <= nb['top'] + 1.0:        # 上标或同基线（下标排除）
                pre = [bc for bc in big if bc['x1'] <= sc['x0'] + 0.5
                       and abs(bc['top'] - nb['top']) < 2]
                pre.sort(key=lambda bc: bc['x0'])
                prestr = ''.join(bc['text'] for bc in pre[-8:])
                if UNIT_RE.search(prestr):
                    continue
                sup.append(sc)

        sup.sort(key=lambda c: (c['top'], c['x0']))
        rows = []
        for c in sup:
            if rows and abs(c['top'] - rows[-1]['last']) <= 2.5:
                rows[-1]['items'].append(c)
                rows[-1]['last'] = c['top']
            else:
                rows.append({'items': [c], 'last': c['top']})

        for row in rows:
            items = sorted(row['items'], key=lambda c: c['x0'])
            cur = ''
            prev = None
            for c in items:
                if prev is not None and c['x0'] - prev['x1'] > 2.5:
                    if cur:
                        groups.append((pi, cur))
                    cur = ''
                cur += c['text']
                prev = c
            if cur:
                groups.append((pi, cur))

    for pi, g in groups:
        if not re.fullmatch(r'[0-9' + DASH + r',]+', g):
            continue
        for part in g.split(','):
            part = part.strip()
            if not part:
                continue
            if re.search('[' + DASH + ']', part):
                a, b = re.split('[' + DASH + ']', part, maxsplit=1)
                if a.isdigit() and b.isdigit():
                    lo, hi = int(a), int(b)
                    if hi - lo <= 400:
                        found.update(range(min(lo, hi), max(lo, hi) + 1))
            elif part.isdigit():
                n = int(part)
                if n <= 500:
                    found.add(n)

    cited = sorted(n for n in found if 1 <= n <= TOTAL)
    uncited = [i for i in range(1, TOTAL + 1) if i not in found]
    out = {
        'method': 'superscript-char-detection',
        'body_size_median': round(med, 2),
        'total_refs': TOTAL,
        'cited_count': len(cited),
        'cited': cited,
        'max_cited': max(cited) if cited else 0,
        'uncited': uncited,
        'uncited_count': len(uncited),
        'out_of_range': sorted(n for n in found if n > TOTAL),
        'raw_groups': [{'page': pi, 'g': g} for pi, g in groups],
    }
    json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(json.dumps({k: out[k] for k in ('cited_count', 'max_cited',
                                          'uncited_count', 'out_of_range')},
                     ensure_ascii=False))



if __name__ == "__main__":
    main()

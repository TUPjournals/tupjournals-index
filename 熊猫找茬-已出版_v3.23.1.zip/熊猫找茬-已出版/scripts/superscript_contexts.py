#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""裸上标数字引用的上下文提取（Carbon Future / Nature 式）。

对每个上标引用组，取其所在栏的视觉行 + 前后各 1 行作为上下文。
输出 {index: [ctx, …]}，兼容 semantic_check.py pair 的输入结构。
"""
import json
import re
import statistics
import sys
from collections import defaultdict

import pdfplumber

def main():
    """命令行入口（v3.22.0：由模块顶层脚本改为函数，使其可被 import 复用）。"""
    PDF, REFS, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
    END = int(sys.argv[4]) if len(sys.argv) > 4 else 14
    GUTTER_FALLBACK = 306.0  # 仅当页面无宽度信息时使用（v3.22.0 改为按页宽推导）
    DASH = '\u002d\u2013\u2014\u2212'

    refs = json.load(open(REFS, encoding='utf-8'))
    total = len(refs)

    pdf = pdfplumber.open(PDF)
    pages = pdf.pages[:END]
    sizes = [c['size'] for p in pages for c in p.chars if c['text'].strip()]
    med = statistics.median(sizes)
    thr = med * 0.80
    SUPCH = set('0123456789') | set(DASH) | {','}
    UNIT_RE = re.compile(
        r'(?<![A-Za-z])(cm|mm|nm|um|\u03bcm|\u00b5m|mA|mV|kV|mol|mmol|mg|mL|kg|'
        r'eV|MeV|keV|ppm|bar|atm|min|rpm|Hz|kHz|MHz|GHz|Pa|kPa|MPa|GPa|wt|vol|at|'
        r'M|L|g|s|h|K|V|A|W|J|T)\s*$')

    ctx = defaultdict(list)


    def join_chars(seg):
        """按 x 间隙拼接字符，间隙 > 1.0pt 处补空格。"""
        out = ''
        prev = None
        for c in seg:
            if prev is not None:
                gap = c['x0'] - prev['x1']
                if gap > 1.0 and not out.endswith(' ') and c['text'] != ' ':
                    out += ' '
            out += c['text']
            prev = c
        return out


    for pi, p in enumerate(pages, 1):
        gutter = (getattr(p, 'width', 0) or 0) / 2.0 or GUTTER_FALLBACK
        chars_all = list(p.chars)
        chars = [c for c in chars_all if c['text'].strip()]
        big = [c for c in chars if c['size'] >= thr]
        small = [c for c in chars if c['size'] < thr and c['text'] in SUPCH]
        sup = []
        for sc in small:
            near = [bc for bc in big if abs(bc['top'] - sc['top']) < 4]
            if not near:
                continue
            nb = min(near, key=lambda bc: min(abs(bc['x0'] - sc['x1']),
                                              abs(sc['x0'] - bc['x1'])))
            if sc['top'] <= nb['top'] + 1.0:
                pre = [bc for bc in big if bc['x1'] <= sc['x0'] + 0.5
                       and abs(bc['top'] - nb['top']) < 2]
                pre.sort(key=lambda bc: bc['x0'])
                if UNIT_RE.search(''.join(bc['text'] for bc in pre[-8:])):
                    continue
                sup.append(sc)

        # 行集合（按 top 聚类，容差 4）
        rowmap = []
        for c in sorted(chars_all, key=lambda c: (c['top'], c['x0'])):
            if rowmap and abs(c['top'] - rowmap[-1]['t']) <= 4:
                rowmap[-1]['items'].append(c)
                rowmap[-1]['t'] = (rowmap[-1]['t'] + c['top']) / 2
            else:
                rowmap.append({'t': c['top'], 'items': [c]})
        for r in rowmap:
            r['items'].sort(key=lambda c: c['x0'])

        # 上标分组（同一行内 x 连续）
        sup.sort(key=lambda c: (c['top'], c['x0']))
        groups = []
        cur, prev = [], None
        for c in sup:
            if prev is not None and (abs(c['top'] - prev['top']) > 2.5
                                     or c['x0'] - prev['x1'] > 2.5
                                     or (c['x0'] < gutter) != (prev['x0'] < gutter)):
                if cur:
                    groups.append(cur)
                cur = []
            cur.append(c)
            prev = c
        if cur:
            groups.append(cur)

        for g in groups:
            gtxt = ''.join(c['text'] for c in g)
            if not re.fullmatch(r'[0-9' + DASH + r',]+', gtxt):
                continue
            nums = set()
            for part in gtxt.split(','):
                part = part.strip()
                if not part:
                    continue
                if re.search('[' + DASH + ']', part):
                    a, b = re.split('[' + DASH + ']', part, maxsplit=1)
                    if a.isdigit() and b.isdigit():
                        lo, hi = int(a), int(b)
                        if 0 < hi - lo <= 400:
                            nums.update(range(min(lo, hi), max(lo, hi) + 1))
                elif part.isdigit():
                    nums.add(int(part))
            nums = {n for n in nums if 1 <= n <= total}
            if not nums:
                continue
            left = g[0]['x0'] < gutter
            gt = g[0]['top']
            gi = min(range(len(rowmap)), key=lambda i: abs(rowmap[i]['t'] - gt))
            parts = []
            for k in (gi - 1, gi, gi + 1):
                if 0 <= k < len(rowmap):
                    seg = [c for c in rowmap[k]['items']
                           if (c['x0'] < gutter) == left]
                    if seg:
                        parts.append(join_chars(seg))
            txt = ' '.join(parts)
            txt = re.sub(r'\s+', ' ', txt).strip()
            if len(txt) < 30:
                continue
            for n in nums:
                key = str(n)
                if txt not in ctx[key]:
                    ctx[key].append(txt)

    json.dump(ctx, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    have = sum(1 for k in ctx if ctx[k])
    print(json.dumps({'refs': total, 'with_context': have,
                      'no_context': total - have,
                      'no_context_ids': [i for i in range(1, total + 1)
                                         if str(i) not in ctx or not ctx[str(i)]]},
                     ensure_ascii=False))



if __name__ == "__main__":
    main()

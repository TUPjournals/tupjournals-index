# 熊猫找茬-新稿（panda-ms-check）

对投稿论文做「入审前」四维度诚信检查（另附政治敏感词扫描），输出 HTML 报告。

## 功能

| 维度 | 说明 |
|---|---|
| ① 内容相关性 | 论文主题/类型 ↔ 期刊 Aims & Scope 语义比对 |
| ② 作者诚信与机构适配 | 逐作者与 Retraction Watch 撤稿库比对（领域相近性三档分类，附撤稿 DOI）；作者机构与论文研究领域适配性（两档：适配 / 不相关，检测不到机构则报「未提供机构信息」） |
| ③ 参考文献 | Crossref 逐条验证（DOI 优先，其次标题搜索）；撤稿库检索（DOI 锚定优先，标题模糊阈值 90）；年份分布统计 |
| ④ AIGC 痕迹 | 句长均匀度、AI 提示语密度、首人称、近重复句、词汇多样性等启发式分析 |
| ⑤ 政治敏感词扫描 | 扫描 Taiwan/Tibet/Xizang（含 Taiwanese/Tibetan 变体，忽略大小写）；命中时报告「0 政治风险」红字提示「潜在政治风险，请人工核查」+ 句子/章节表格（位于稿件基本信息之后） |

所有发现均为**筛查信号**，非定性结论，需人工核实。

## 安装

```bash
pip install -r requirements.txt
```

- Python 3.10+，任意环境（venv/conda/系统均可）
- 首次运行会自动联网下载 `retraction_watch.csv`（约 60MB，缓存在 `<skill>/data/`），网络不畅时可手动从 https://gitlab.com/crossref/retraction-watch-data 获取

## 放置位置

解压后放到用户 skill 目录（保持目录名 `panda-ms-check`）：

- Windows: `%USERPROFILE%\.workbuddy\skills\panda-ms-check\`
- macOS/Linux: `~/.workbuddy/skills/panda-ms-check/`

## 使用

在 WorkBuddy 对话中 @熊猫找茬-新稿，并提供：

1. **论文文件**（Word/PDF，须含作者信息与参考文献）
2. **期刊信息**（全名、缩写或 Aims & Scope 链接）

输出：HTML 报告一份（保存到论文所在目录），含四项检查结论与处理建议。报告由 `scripts/gen_report.py` 依据检测结果 JSON（`work/<稿件标识>/`）与 `report_content.json` 自动生成（模板 `references/report_template.html` 为唯一格式源）。

## 目录结构

```
panda-ms-check/
├── SKILL.md                    # 技能主文档（规则、工作流、变更记录）
├── _meta.json                  # WorkBuddy 技能元数据
├── requirements.txt            # 运行依赖
├── scripts/                    # 30 个可独立运行的脚本（均可 --help）
│   ├── config.py               # 统一配置：版本号、路径、Crossref 礼貌池 UA
│   ├── preflight.py            # 前置校验（稿件完整性 + 期刊 scope 缓存）
│   ├── extract_docx.py         # Word/PDF 文本与段落抽取
│   ├── parse_refs_auto.py      # 参考文献解析总调度（14 策略自动打分择优）
│   ├── parse_refs_*.py         # 各格式解析器：numbered / apa / noidx_apa /
│   │                           #   vancouver / noidx_vancouver / numbered_year /
│   │                           #   nature / gbt7714 / rsc / ieee / elsevier /
│   │                           #   springer / acs / numbered_jv
│   ├── ref_common.py           # 文献区定位、条目切分、字段清洗（被各解析器复用）
│   ├── crossref_check.py       # Crossref 逐条验证（礼貌池并发3 + 429退避）
│   ├── retraction_watch.py     # 撤稿库检索（作者/参考文献）
│   ├── citation_stats.py       # 引用标记统计（含上标式护栏）
│   ├── aigc_stats.py           # AI 痕迹文本特征（须先切掉文献区）
│   ├── geo_check.py            # 政治敏感词扫描（Taiwan/Tibet/Xizang）
│   ├── affiliation_check.py    # 作者机构提取与领域适配性
│   ├── journal_scopes.py       # 期刊 scope 记录读写（模板 ∪ 用户，用户优先）
│   ├── gen_report.py           # 报告渲染（读 work JSON + report_content.json → HTML）
│   ├── common_stats.py / batch_check_refs.py  # 统计汇总与批量核验
│   └── download_retraction_watch.py  # RW 数据下载与新鲜度管理
├── references/report_template.html   # 报告模板（唯一格式源）
└── assets/
    ├── journal_scopes_template.json # 内置模板：随包分发、只读、升级时更新
    └── journal_scopes.json          # 用户文件：本人积累的期刊 scope，升级永不覆盖
```

> `data/`（`retraction_watch.csv`，约 60MB）与 `cache/`、`work/` 均**不属于分享内容**，首次运行自动生成。

### 期刊 scope 双层数据源

- `journal_scopes_template.json`：**内置模板**，随包分发、只读，升级时被新版覆盖；
- `journal_scopes.json`：**用户文件**，首次运行时若不存在则从模板复制初始化，此后完全归使用者所有，升级**永不覆盖**；
- 读取时两者合并：同缩写冲突以**用户记录优先**（个人数据主权）。

## 版本

当前版本 **v2.30.1**，变更记录见 SKILL.md 末尾「版本与变更记录」表。

## 数据与隐私

- 不采集、不上传任何稿件内容；所有分析在本地 + Crossref/GitLab 官方公开 API 完成
- Retraction Watch 数据仅用于本地比对，不随 skill 分发

---
name: 熊猫找茬-新稿
version: 2.30.1
agent_created: true
description: 熊猫找茬-新稿 — 对投稿论文进行四项自动化检查。输入：论文文件（Word/PDF，须含作者与参考文献）+ 期刊全名、缩写或 aims & scope 链接。检测维度与原理：① 内容相关性——比对论文主题与期刊收稿领域是否匹配；② 作者撤稿——将每位作者姓名与 Retraction Watch 撤稿库逐一比对，同名同姓做二次核验；③ 参考文献真实性——通过 Crossref 逐条核对标题、作者、年份、期刊，检索这些文献是否被撤稿，统计引用年份分布；④ AI 痕迹——分析句长均匀度、高频 AI 用词、人称使用等文本特征。输出：HTML 报告一份，含四项检查结论与处理建议；所有发现均为筛查信号，建议人工核实。Use when user mentions 诚信检查、新收稿件检查、投稿审查、熊猫找茬、新稿筛查、稿件初筛、撤稿排查、参考文献真实性、引用验证、送审前筛查，或提交一篇新论文（Word/PDF）要求做入审前筛查。
---

# 熊猫找茬-新稿 — 新收稿件诚信检查

## When to use

触发场景：
- 用户说"检查这篇新投稿"、"帮我做诚信检查"、"看看这篇稿件能不能送审"
- 用户提交了论文文件（Word/PDF）+ 期刊 scope 信息（或期刊名）
- 编辑要在送外审前对稿件做一次全维度初筛
- 用户说"查撤稿/验证参考文献/查这篇稿子的引用是否真实/送审前筛查"（v2.15.0 补全触发）
- **区分「新稿」vs「已出版」**：本 skill 处理**新投稿**（未发表稿件）；用户明确说"已发表/已出版的文章"或引用出版 DOI 时用「熊猫找茬-已出版」skill

四项检查全部是**内容层**工作（文本分析、数据库检索、API 查询），不涉及数值源数据取证。

## When NOT to use

- 用户需要检查论文的**数值源数据**（.xlsx / .csv 表格）→ 用 `paperconan` skill
- 用户只需要 AI 率检测 → 用 `AI率检测助手` skill
- 用户只需要某单一检查项（如只看参考文献）→ 分别调用对应脚本即可，无需走完整流程

## Prerequisites

```bash
pip install -r requirements.txt
```

- `rapidfuzz` — 用于作者名/标题的模糊匹配（缺失时脚本自动回退 difflib，功能正确但较慢）
- `requests` — Crossref API 查询、scope URL 可达性校验
- `pdfplumber` — PDF 输入稿件的文本提取（docx/txt 不需要）
- `python-docx` — docx 正文/表格提取（agent 工作流常用）
- `defusedxml` — **v2.15.0 起**：docx XML 安全解析（防 billion-laughs 实体膨胀；缺失时回退 xml.etree 并打警告，功能可用但不防实体攻击）
- Retraction Watch CSV 下载使用标准库 `urllib` 实现（见 `scripts/download_retraction_watch.py`）
- 首次运行需要联网下载 `retraction_watch.csv`（约 60MB），缓存在 `<skill>/data/` 下
- 运行环境：任何装有上述依赖的 Python 3.10+ 即可（本机开发用 venv：`<venv>/Scripts/python.exe`，路径仅作本机示例，分享后可任意替换）

## 脚本运行注意（CRITICAL：stdout/stderr 分离）

所有脚本的 JSON 结果输出到 **stdout**，日志输出到 **stderr**（`download_retraction_watch.py` / `retraction_watch.py` 的 `log()` 均为 `print(..., file=sys.stderr)`）。因此：
- 后台/重定向运行时，**必须分离两个流**：`python xxx.py ... > result.json 2> result.log`，**严禁 `2>&1`**。
- 若误用 `2>&1`，stderr 日志会污染 JSON 文件开头，导致后续 `json.load` 失败、报告误显示"数据未就绪"。
- 报告生成脚本读取结果时，应做容错：跳过 JSON 前导的非 JSON 行（定位第一个 `{` 再 `json.loads`），双重保险。
- **`gen_report.py`（报告渲染）**：stdout 只输出**一行机器可读 JSON**（`{"status":"ok"|"warn"|"error","out_file","size","leftover"}`），日志/警告走 stderr；agent 读取 stdout 判断生成结果，`status=error` 时按 stderr 提示修复，`status=warn` 时按 `leftover` 补全 report_content 字段后重跑。

## 运行环境陷阱（Windows/Git Bash 实战经验）

- **Git Bash heredoc 会破坏反斜杠转义**：`python - <<'EOF' ... EOF` 方式传递 Python 源码时，MSYS 会把 `\s` `\.` `\S` 等静默改写为 `/s` `/./` `/S`，导致正则**静默失效**（不报错、匹配为空，如 `doi:\s*(10\.\S+)` 永远匹配不到）。排查特征：正则匹配结果异常为空、repr 显示 `\` 变成 `/`。**规避：所有含转义序列的脚本一律写成 .py 文件再运行，禁止用 heredoc 传递 Python 源码。**
- **docx 参考文献可能在 Mendeley SDT 字段中**：Word 引用管理器（Mendeley/Zotero）会把参考文献列表放进 `MENDELEY_BIBLIOGRAPHY` 的 `<w:sdt>` 结构化标签内，**python-docx 的 `document.paragraphs` 不会遍历 sdtContent 内段落**，导致提取出的文本只有 "References" 空标题、参考文献"缺失"（误判稿件不完整）。**规避：docx 提取必须用 XML 深度遍历**（`ElementTree.fromstring(document.xml)` + `tree.iter('{...}w:p')`，sdt 内的 `w:p` 也会被迭代），并保留文档顺序（body 子元素混合 `w:p`/`w:tbl`/`w:sdt` 时写递归 walker）。遇 docx 缺参考文献时先查 `word/endnotes.xml`/SDT 再判定不完整。**已提供 `scripts/extract_docx.py` 深度提取工具**（XML 递归遍历 body，覆盖 sdt/表格，输出全文 `out_text.txt` + 段落 `out_paras.json`），docx 文本提取一律用它，勿手工写提取代码。
- **rapidfuzz 累积处理原生崩溃（Windows，CRITICAL）**：`retraction_watch.py check-refs` 在同进程内对大批量参考文献（实测约 60+ 次 extractOne 调用，即 30+ 篇，因每篇触发 2 次 token_sort+partial）连续调用 `process.extractOne` 时，rapidfuzz C 扩展发生原生段错误，**进程静默退出（无 traceback、无 JSON 输出、退出码 1）**，临界点取决于累积处理量而非单条标题。表现：日志只有 `ensure_csv` 行、stdout 为空。**规避：参考文献 > 40 篇时用 `scripts/batch_check_refs.py <refs.json> <out.json> [batch_size=20]` 分批运行**（每批独立子进程调用 check-refs，再合并 matches，等效全量结果）；**v2.15.0 默认 batch 40→20**（20 篇 = 40 次 extractOne 调用，低于崩溃阈值留余量），且子进程已加 600s 超时（防挂起卡死）。v2.15.0 起 check-refs 内置倒排索引候选过滤（每文献只对 <600 条候选比对），单进程调用量大幅下降，但仍建议 >40 篇走 batch。
- **batch_check_refs.py 合并 total_references 缺陷（v2.15.0 已修复）**：分批运行后输出 JSON 的 `total_references` 曾只反映**第一批**（40/52）——v2.15.0 起合并逻辑改为取全量 refs 数，不再需要人工核对/手动合并；如遇旧版产物仍按旧法核对。
- **`parse_failed` 汇总为空 ≠ 解析成功（v2.18.2 修复，v2.19.0 加严，务必自检）**：`parse_refs_auto.py` 的 `_adapt_legacy` 曾弹出 `parse_failed` 后未回填，`run_strategy` 二次 pop 得 `False` → **解析失败被当成成功**写入 refs，条目字段全空而 stdout 的 `parse_failed` 仍为空 → Crossref 会把全部文献报成「无法定位」，制造"整篇文献不可信"的假象（CES 实测 30/30 全空）。**v2.19.0 补充第二类静默失败**：字段**非空但内容错位**（年份全空、作者混入标题、文章号被腰斩），同样不体现在 `parse_failed` 里——本稿 `numbered` 以 0.735 分被选中即属此类。**因此不能只看 `parse_failed` 是否为空**：必须抽查 refs.json 前几条的 `title`/`authors`/`year` 是否非空**且正确**（`is_healthy`：title ≥8 字符且 year/journal 至少有一），并看**所选策略得分是否接近 1.0**。发现"条目数正确但字段全空/错位"或"最高分明显偏低"即命中本坑。
- **参考文献格式五花八门（v2.18.0 已自动化，保留此条供排查）**：不同投稿的参考文献格式差异极大（编号式 / 编号 APA / 无编号 APA / Vancouver / Nature 等），旧做法是人工判断后手选 `parse_refs.py` 或 `parse_refs_apa.py`，失败率高且需反复试错。**v2.18.0 起一律用 `parse_refs_auto.py`**，它自动完成页码剥离、编号识别、续行合并、格式打分与字段清洗（详见 Step 3）。仅当自动识别不准时才用 `--strategy=` 手动指定。已知易错点（改造时踩过，新脚本已处理）：① PDF 提取的每行带页码数字（`544 [1] Cai...`），连 `References` 标题行都带（`543 References`）；② 一条文献跨多行时旧脚本丢弃续行；③ 年份被误当条目编号（`2023).` → index 2023）；④ 期刊名内部缩写句点（`Nat. Mater.` / `J. Electrochem. Soc.`）会把期刊切碎成 `Mater.` / `Soc.`；⑤ 补充材料的图注表注被当作末条文献的续行吞入。
- **APA 解析后须二次清理卷/页/DOI（EMD20260105 实测）**：`parse_refs_apa.py` 解析结果中行尾 DOI（`doi: 10.xxx`）未剥离、卷/页码混入 journal 字段（如 `"Adv. Mater. 30, 1800561. doi: 10.1002/adma.201800561"`），导致 Crossref 无法走 DOI 优先验证。**规避：解析后用清理脚本拆分**——先用 `doi:\s*(10\.\S+)` 提取 DOI 并删除该段，再用 `^(.*?)\s+(\d+),\s*([\d\u2013-]+)$` 拆分「期刊名 卷, 页码」；卷号为连字符区间（如 152–153）或页码为 e 文章号（如 e202413927）时拆分失败属正常（DOI 优先验证不受影响），无需强修。

  - **v2.29.0 已修根因（EMD20260091 实测，CRITICAL 假警源）**：`parse_refs_noidx_apa.py` 的尾部正则原无「期号」位（`^(.*?)\s+(\d+),?\s*([\w\-–—]*)\.?\s*$`），遇 **`期刊 卷(期), 页码`** 式（`Scientific Reports 15(1), 39225. https://doi.org/…`）时 `\s+(\d+)` 只能吃到末尾页码 → `journal="Scientific Reports 15(1)"`、`volume=39225`、`page=""`。后果：Crossref **DOI 与标题逐字匹配、评分 13/13**，但 strict 刊名核对必败 → **25 条中 15 条假报 `journal_mismatch`**（本稿合计 16 条「差异较大」，修后仅剩 1 条 `not_found`）。**识别特征：`journal_mismatch` 批量出现且稿内 journal 尾部带 `NN(N)`、同时 volume 恰好等于页码。** 修法：尾正则增加可选期号组 `(?:\s*\(\s*\d+(?:\s*[–\-]\s*\d+)?\s*\))?`，期号丢弃（口径同 `gbt7714`/`acs`）。**A/B 回归（39 份历史稿件）：34 份零变化；5 份 noidx_apa 稿件全部为净改进**——CESCI-D-26-00022 / EMD20260088 / EMD20260090 / EMD_DigitalTwin 的 `volume=页码起页 + page='–页码止页'` 一并纠正为「volume=卷号 + page=完整页域」（即本手册 v2.26.2 记的「刊名以数字结尾…page 以 – 开头」同源缺陷）。
- **Crossref 标题的「跨行下标富文本」会让真文献被误判 `not_found`（v2.30.0 修复，CRITICAL 假警源）**：Crossref 常把化学式写成 `<sub>` 富文本且**跨行排版**——`Sb\n<sub>2</sub>\nO\n<sub>3</sub>/MXene`、`ambient NH\n<sub>3</sub>\nsynthesis`。v2.11.1 起的归一化把「下标标签**连同周围空白**一并删除」（为把 `In<sub>2</sub>Se` 粘成 `In2Se`），遇到这类记录会把**真实词边界**一起吃掉 → `…Ti3C2TxMXene nanosheets… ambient NH3synthesis…`，token 全毁、重叠率跌到 0.643 < 0.65 → 两条真实文献（DOI 10.1039/d4cc03051f、10.1039/c7ta02689g）双双报 `not_found`（EMD20260093 [82][90] 实测）。**识别特征：`not_found` 且 `crossref_title` 里能看到 `<sub>`/换行残片、或被截断成半句。**修复：`titles_match` 改为**双归一化变体**——A（删标签并删周围空白，处理 `In2Se` 紧贴式）与 B（只删标签保留空白，处理跨行记录），任一通过即匹配；阈值、年份守卫、泛用词守卫全部不变（纯放宽）。**排查口诀：凡「标题看上去就是同一篇却报 low_score」的条目，先把 Crossref 原始 title 打印出来看有无 <sub>。**
- **作者名两类「合法但正则不认」的写法会让整段作者并入标题（v2.30.1 修复，静默假警源）**：Elsevier 编号式（作者逗号分隔、**无句点收尾**）里，只要**首个作者段**不匹配 `AUTHOR_RE`，`parse_refs.py` 就提前进入 `in_title` → 该作者之后的所有作者连同标题被 `' '.join` 压成**无逗号长串**写入 `title`、`authors` 置空 → Crossref 拿这串去比 → `title_mismatch` + `doi_low_score` 双报（EMD20260096 实测 9/135 条）。两类触发写法：① **组合附加符号**（`Koç`/`Sångeland`/`Černe`/`López` = 基字母 + U+0300–U+036F，不落在 `\u00C0-\u024F`）；② **缩写簇含小写**（EndNote 把 Jin-Cheng 导成 `J.i.`/`J.-c.`/`J.r.`）。**排查口诀：看 `refs.json` 里 `authors` 为空、且 `title` 以「X.Y. 姓」式缩写开头（或无逗号长串）时，先跑 `AUTHOR_RE.match(首段)` 定位不匹配的字符，别急着写 review_note。**
- **出版方把化学式下标「沉积成空格」而非 `<sub>` 标签 → 标题分词对不上（v2.30.1 修复）**：`TiS 2 /Li-In` … `Li 10 GeP 2 S 12`（Crossref 记录**无任何标签**，纯空格），A/B 两变体都救不了 → 实质相同的标题被判 `title_mismatch`。新增**变体 C（化式紧贴式）**：在 B 之上删去字母↔数字之间的空白，两侧同法处理（回归：3495 组历史比对，3 组 False→True 全为同篇，0 组反向）。**同批修复**：`clean_journal` 剥尾部 `n/a` / `n/a(n/a)` 卷期占位符（在线优先条目 `… Interfaces n/a(n/a) e00705` 曾被判 `journal_mismatch`）。
- **引用统计必须用 `scripts/citation_stats.py`，禁止手写（v2.12.0 强制）**：正文 `[49, 50]`、`[25, 29, 31, 38, 39]`（如 ESM 表 S2 对比标注）等带空格逗号形式，以及 `[5–7]`、`[12–15]`、`[2-5]` 等 **范围**（CESCI20260019 实测 en-dash、EMD20260103 实测 hyphen），统计必须**区间展开**（`[2-5]` → 2,3,4,5）。**踩坑记录（EMD20260103 实测 57 条全误报）**：手写代码若只 `re.split(r'[-,–]')` 取端点、不 range 展开，`[2-5]` 仅计 {2,5}，中间 3、4 漏掉 → 误报「文献未引用」。**用法：`python scripts/citation_stats.py <out_paras.json> <文献总数>`**，输出 cited/uncited/over_range（含 `uncited_count`），agent 取 `uncited` 填 4.2 节；统计范围 = 正文段落（References 之前）+ 全部表格单元格（out_paras.json 已含表格文本）。
- **【CRITICAL v2.19.2】引用范围连接符还有 U+2212 数学减号（ECM20260040 实测）**：范围分隔符可能是 **U+2212 MINUS SIGN**（`−`，PDF 排版高频），既非 hyphen(U+002D) 也非 en-dash(U+2013)；字符类只写 `[-–]` 时 `[1,16−18]` 整组被当单 token **静默丢弃** → [16][18] 误报「未引用文献」，且**不报错**。已修复为四字符类 `_DASH = r'\-\u2013\u2014\u2212'`（hyphen/en-dash/em-dash/minus sign）。**排查口诀：凡「按引用标记切分/展开」的正则结果异常（漏编号、上下文为空），先 `ord()` 打印该处字符码确认破折号类型——缺一种就静默漏。** ⚠️ **配套自查陷阱**：检查 `_DASH = r'\-\u2013\u2014\u2212'` 时 `repr(_DASH)` 显示 `'\\-\\u2013\\u2014\\u2212'`、`'\u2212' in _DASH` 为 `False`，**看似"raw string 使转义失效"，实为误判**——`re` 引擎会自己解释模式串中的 `\uXXXX`（与 Python 字符串层无关），验证字符类须跑 `PAT_REF.search('\u2212')` 而非查拼接变量，否则会把好代码改坏。
- **References 标题可能带尾随冒号，定位失败后会「误落到正文小节号」（v2.20.1 修复，CRITICAL）**：EMD20260068 实测标题写作 `References:`，原 `REF_HEADING_RE` 要求标题行以词结尾（`\s*$`）故不匹配 → 落到「首个编号行」兜底 → 兜底把正文小节号 `2.1. The experimental components:` 当起点 → 切出的"文献区"是全文 → 两种切分均 0 命中，报 `no reference entries found`。**识别特征：报"未找到条目"（而非"未找到标题"）+ 全策略 0 分**——此时**先怀疑标题/定位而非解析器**（本稿 9 策略全 0 分，极易误判为"格式不支持"）。**排查口诀：报错文案与阶段不符时，先打印 `locate_references()` 的返回值与命中位置上下文。** 已修：标题容忍 `[:.;]?`，兜底跳过 `^\d+\.\d` 章节号行。
- **PDF「逐行行号」水印会让参考文献全量欠解析（v2.21.0 新增判定 / v2.22.0 补齐第二种排版，CRITICAL）**：Word 导出 PDF 时可带**逐行行号**（每页 1–65 循环），pdfplumber 会把同一种水印提取成**两种排版**：① **独占式**——行号单独成行（纯数字行）；② **内联式**——行号与正文同列（数字前缀行）。**两种都必须能判出，否则全量欠解析**：`preprocess` 若漏判 → 行号残留 → 条目切不出，而 `parse_failed` 为空、所选策略得分虚高（1.0）或全 0，是「失败被当成功」的变体。v2.21.0 只认排版 ①，故 BUIL-D-25-00483（纯数字行占非空行 **65%**）能修好，而 CESCI-S-26-00047（**纯数字行仅 8.4%、数字前缀行 64.4%**）被判 False → 报 `no reference entries found` **且 9 种策略全 0 分**（最易误判为"格式不被支持"）。v2.22.0 起 `detect_line_numbering()` 走**双路径**（共享助手 `_ln_stats`）：Path A 纯数字行 ≥10 且占比 ≥25%；Path B 数字前缀行 ≥10 且占比 ≥50%。两路径**共用行号指纹**：整数近似连续递增（步长 ≤3 占 ≥80%）**且存在 ≥5 的大幅回落**（每页从 1 重起）。**Path B 的"大幅回落"是反向保险，不可省**——真实编号列表（`[1]`…`[N]`）单调递增、无回落，若去掉该条件会把正常文献列表当行号剥掉。修复效果：3 → 70/70、0 → 37/37。**排查口诀：条目数与稿件体量明显不符、或「报错阶段可疑 + 9 策略全 0 分」时，先打印文献区前 20 行看是否夹有大量纯数字/数字前缀行。** **推论：带行号水印的 PDF，引用统计必须在"已剥行号"的文本上跑**——行号会劈开成组引用（`[5, 12,\n42 13]` → 只捞到 `[5,12]`，误报 `uncited=[12,13]`）。
- **重复页脚/页眉水印会挂进参考文献字段（v2.22.0 修复）**：期刊模板常在每页页脚打印如 `Civil Engineering Sciences Manuscript Template Page N of 22` 的串，pdfplumber 会把它提取成**独立行并在文献区重复出现**（CESCI-S-26-00047 实测重复 22 次），被当成条目续行合并 → **期刊名字段尾部挂上该串**（`[7]` 实测）→ 策略得分被压低（`numbered` 0.07–0.14）。**识别特征：多条期刊名尾部出现同一段英文模板文案、且其中含 `Page N of M`。** v2.22.0 新增 `strip_running_headers(lines, min_repeat=3)`（`RUNNING_HEADER_RE` 要求含强结构 `Page N of M` + 数字归一化签名重复 ≥3 次），已接入 `preprocess()` 且置于水印分支之前。
- **`clean_journal` 必须「先去尾标点、再跑尾锚定剥离」（v2.21.0 修复，假警风暴）**：APA 式条目尾部普遍带标点（`"…, 1570."`、`"Sustainability, 16(14),"`）。若先跑 `,\s*\d+$` 一类**尾锚定**正则、最后才 `rstrip('.,;:')`，则这些正则**一律失配** → 卷/期/页永远剥不掉 → Crossref 把 **55/70** 条报成 `journal_mismatch`（verified 仅 3 条），制造「整篇文献刊名著录错误」的假象。**排查特征：`journal_mismatch` 批量出现、且稿内 journal 字段明显混着卷期页。** 另两个同类坑：① 尾锚定规则不可过贪（`,\s*[\w\-–—]+\s*$` 会吃掉真实期刊末词，如 `, Carbon`——须要求候选含数字）；② 分页标记须与实际提取器输出一致（实际为 `===== PAGE N =====`，而常量曾写 `===PAGE BREAK===`），否则标记会挂进字段尾部。
- **无编号 NLM 条目的 DOI 排在 `年;卷:页` 之后会让尾部锚定全败（v2.20.1 修复，CRITICAL）**：`parse_refs_noidx_vancouver` 原从**行尾**倒推年卷，而 EMD20260068 的 41 条几乎全部以 `… 2025;10:2616–32. https://doi.org/…` 结尾 → `_TAIL_YV` 全部失配（41/41 `no year;volume tail`）。**修复要点：先摘走 DOI/URL、再匹配尾部年卷**（顺序不可反——先提 DOI 再删链接，否则 DOI 随 URL 一起丢）。**同一修复根治了 EMD20260110 的历史遗留失败**（该稿当时 0 条、165 条全失败，靠临时解析器救回但未固化；本次 A/B 对照 0 → 164/165）。**同时注意年卷写法会在同一列表内混排**：`年;卷:页`（NLM）/ `年, 卷, 页`（ACS）/ `年:页`（无卷，页为文章号）/ 仅年份（报告类），现由 `_TAIL_PATTERNS` 四形态依次回退；页码字符类必须含 **U+2212 数学减号**（`1417−1427`），与 `citation_stats` 的 `_DASH` 同源教训。
- **混排列表的条目切分会漏条（v2.20.1 修复）**：无编号 NLM 列表里若混入少量"作者, …, et al., 标题. 期刊 年, 卷, 页"式条目（年卷间为逗号/冒号而非分号），`_is_nlm_start` 的 `年;卷` 单锚点会漏判 → 这些条目被并进上一条，条目数偏少（EMD20260068 实测 41 → 37）。已新增 `et al.,` 与「4 位年份 + DOI/URL」并列判据。**判据调整须防两类反向错误**：逗号制切段不能吃掉 NLM 的 `. ` 三段结构（用 `_looks_like_author_seg` 挡缩写句点碎片，如 `S. Devesa` 切出的 `S`），也不能过严（单作者条目 `Xin L` 仅有 5 字符，须放行——CESCI-D-26-00016 实测曾因此掉 1 条）。
- **上标式引用标记会让引用统计「全量误报」（v2.20.0 加护栏，CRITICAL）**：部分期刊模板用**上标数字**（Word `w:vertAlign="superscript"`）而非 `[n]` 标注引用（EMD20260066 实测 328 处），纯文本提取后标记全部消失——`citation_stats.py` 找不到任何引用即把 `uncited` 报成 **[1..116] 全量**（"116 篇文献全部未被引用"这种荒谬结论），而脚本本身不报错。**v2.20.0 起脚本自检**：`--total-refs` 给定了文献总数、但正文 0 命中引用标记时，输出 `not_applicable: true` + `warning`，**明确告知"本统计不适用、勿据此判定文献未被引用"**，不再输出全量 `uncited`。**回归**：脚本改动须复跑历史稿确认不误伤（EMD20260064 cited=79/uncited=0/na=False、CES Constraint-Aware Urban Scaling cited=30/uncited=30/na=False 均未被触发）。**人判要点**：看到 `uncited` 数量与文献总数相等，先怀疑标记形态（上标/尾注/作者-年份制），再看正文确认引用是否真实存在。
- **refs.json 必须为纯列表格式（CESCI20260019 实测；v2.15.0 起脚本侧已加防护）**：`crossref_check.py verify/year-stats` 与 `retraction_watch.py check-refs` 均期望 `--refs` 参数指向 **list of dict**（各条目含 index/authors/title/journal/volume/page/year/doi 字段）。若传入 parse_refs.py 的 dict 输出（`{"refs": [...], "parse_failed": [...], "raw_refs": [...]}` 结构）会直接 TypeError（`'str' object does not support item assignment` / `'str' object has no attribute 'get'`），crossref.json/refs_rw.json 落盘为空。**规避：解析脚本输出后，单独将 refs 数组写为纯 list JSON 再传给验证脚本**；自定义解析器（如 Vancouver/APA 二次清理）输出时直接落盘 list 格式。**v2.15.0 起脚本入口已加 `isinstance(references, list)` 校验，dict 输入会返回明确错误 JSON 而非裸 traceback。**
- **RW 查询性能（v2.15.0 索引化）**：`retraction_watch.py` 将 65MB/7 万行 CSV **只加载一次**并构建「姓索引 + 标题倒排索引 + DOI 索引」（缓存于 `<skill>/cache/rw_index.pkl`，按 CSV mtime/size 自动失效重建；环境变量 `RW_CSV_CACHE` 可覆盖缓存路径）。check-authors 每作者只查姓索引命中行（由全表扫描 6 万行 → 毫秒级）；check-refs 先经倒排索引取共享 token 候选（通常 <600 条）再跑 rapidfuzz（由全量 6 万标题比对 → 10-50× 提速）。**注意：缓存为纯性能优化，删除 cache/ 不影响功能（下次运行自动重建，约 2-3s）。**
- **Crossref 响应缓存（v2.15.0）**：`crossref_check.py` 按 DOI 与归一化标题缓存 Crossref 响应（`<skill>/cache/crossref_cache.json`，TTL 7 天），
- **AIGC 统计会被分栏 PDF 的「折行引用标记」截断（v2.19.1 实测，CRITICAL）**：`aigc_stats.py` 在找不到 References 标题时回退「首个 `[N]` 开头行」作为正文截断点；正文**换行**把引用标记载到行首时（`...Schnepf et al.` 换行 `[15] proposed using...`）会误触发，正文被截到该行之前——OCE20260029 实测7196 词 → **640 词**，句长/变异系数/TTR/首人称/提示语密度**全部失真且不报错**。**规避：已加严回退条件**（`[N]` 行 ≥5、首行编号 ≤2、编号下降次数 ≤20% 三者同时满足才认定参考文献节）；**判断特征：正文字数与稿件体量明显不符即命中本坑**，须核对 aigc.json 的 word_count。
- **泛用词高重叠会把「完全不同的文献」判为同一篇（v2.19.1 实测，CRITICAL）**：`titles_match` 原仅按 token 重叠率 ≥0.65 判定，`global / report / 年份` 这类泛用词足以让主题完全不同的文献拿高分——OCE20260029 [1]《Global wind report 2025》被《Global Debt Report 2025》以 0.75 重叠接受为「通过」。**规避：`_overlap_ok` 新增特征词守卫**（稿内长度 ≥4 的非泛用、非数字词一个都对不上即判非同篇）；**判断特征：报告/标准/网页类文献被判 verified 时，人工核对 crossref_title 是否与稿内标题同指一物**。重跑/多稿件重复查询近零网络耗时；缓存损坏自动忽略重建。

## Workflow（必须按顺序执行）

整体流程为 8 步（含 0 / 0.5 / 0.6 前置步骤）：

```
Step 0: 前置输入校验（preflight.py）
  → 校验失败则暂停，向用户提问；通过则继续

Step 0.5: RW 数据准备（download_retraction_watch.py）
  → 版本检查 + 判断 + 下载，串行执行一次；确保 CSV 就绪且 FRESH 快筛命中

Step 0.6: 政治敏感词扫描（geo_check.py）
  → 命中 Taiwan/Tibet/Xizang 时，报告「0 政治风险」红字提示 + 句子/章节表格

Step 1: 检查1 — 内容相关性
Step 2: 检查2 — 作者诚信与机构适配性（retraction_watch.py + affiliation_check.py）
Step 3: 检查3 — 参考文献检测（crossref_check.py + retraction_watch.py）
Step 4: 检查4 — AIGC 检测
Step 5: 生成 HTML 报告
```

**并行规则（CRITICAL）**：
- RW 数据准备（Step 0.5）必须先于任何 RW 查询（Step 2 的 check-authors、Step 3 的 check-refs）**串行完成**；
- 数据就绪后（FRESH 快筛命中、不触发下载），check-authors 与 check-refs **可并行执行**——两者仅只读 CSV，无文件锁冲突；
- **严禁在数据未就绪或可能触发下载时并行**运行两个 RW 查询（并发下载共用 `.tmp` 路径 + `os.replace` 覆盖 vs 读取 → Windows 文件锁冲突，会导致其中一个查询失败一次）。

**检测结果落盘约定（work 目录，CRITICAL）**：
- 每次检测把各脚本 stdout JSON 写入 `<skill>/work/<稿件标识>/`（stdout/stderr 分离：`> xxx.json 2> xxx.log`），供 Step 5 渲染脚本读取。文件名映射：

| 脚本/子命令 | 落盘文件 |
|---|---|
| `geo_check.py` | `geo.json` |
| `parse_refs_auto.py`（**v2.18.0 起统一入口**） | `refs.json` |
| `crossref_check.py verify` | `crossref.json` |
| `retraction_watch.py check-authors` | `authors.json` |
| `retraction_watch.py check-refs` | `refs_rw.json` |
| `affiliation_check.py` | `aff.json` |
| `aigc_stats.py` | `aigc.json`（**必落盘**，供 AIGC 定量指标表自动生成） |

- 示例：`python scripts/geo_check.py --text <全文文本> > work/<稿件标识>/geo.json 2> work/<稿件标识>/geo.log`
- 某文件缺失时，对应自动表格在报告中按「未检测」呈现（渲染脚本容错，不中断）。

---

### Step 0: 前置输入校验

**目的**：确保用户提供了完整的检测所需信息，否则暂停并引导用户补充。

调用脚本：
```bash
python scripts/preflight.py --paper <论文路径> [--scope-url <URL>] [--journal <期刊全名>] [--abbrev <缩写>]
```
注：preflight 仅直接解析 Word(docx)/txt；若输入为 **PDF**，先由 agent 用 pdfplumber 提取文本，再走 preflight 与后续流程（如 CESCI 稿件处理）。

脚本返回 JSON（stdout），agent 读取后按以下逻辑处理：

```json
{
  "status": "ok" | "incomplete",
  "paper": {
    "has_authors": true/false,
    "has_references": true/false
  },
  "scope": {
    "source": "url" | "journal_lookup" | "user_input" | "none",
    "url": "...",
    "text": "...",
    "valid": true/false
  },
  "actions_required": []  // 需要用户补充的事项
}
```

**Agent 处理逻辑**：

1. **文件完整性检查**：若 `paper.has_authors == false` 或 `paper.has_references == false`，向用户提示：
   > "检测到文件可能不完整（缺少[参考文献 / 作者信息]）。是否仅对已上传内容做检测？"
   - 用户确认 → 继续
   - 用户拒绝 → 暂停，等待完整文件
   - ⚠️ **has_authors 仅粗检正则**：`(?i)(author|作者)` 会把文末声明 "All authors declared that there are no conflicts of interest." 等字样误判为有作者。即使 `has_authors == true`，agent 也必须人工确认稿件中是否真实存在作者姓名/单位/邮箱；若无（如 Clean/双盲版），按"缺作者名单"处理并询问用户是否提供名单或跳过检查 2。

2. **Scope 信息来源判断**：
   - `source == "url"` 且 `valid == true` → ✅ 通过
   - `source == "url"` 且 `valid == false` → 提示链接无效，执行下方逻辑
   - `source == "journal_lookup"` 且找到记录 → ✅ 通过
   - `source == "journal_lookup"` 且未找到记录 → 执行下方逻辑
   - `source == "none"` → 执行下方逻辑

3. **首次/非首次判断（v2.17.0 双层数据源）**：
   - 用户文件 `assets/journal_scopes.json` 首次运行（不存在）时**自动从模板初始化**（含全部内置期刊记录），不视为"无记录首次运行"；
   - 仅当查的期刊既不在内置模板也不在用户文件中（`load_all()` 合并后仍未命中）时，询问 scope 信息
4. **保存记录（v2.17.0）**：用户提供信息后，写入 `<skill>/assets/journal_scopes.json`（**用户文件，禁止进分享包、升级永不覆盖**；内置模板 `journal_scopes_template.json` 只读）

---

### Step 0.6: 政治敏感词扫描

**目的**：扫描全文识别关键词 **Taiwan / Tibet / Xizang**（含 Taiwanese / Tibetan 等词干变体，忽略大小写）。命中任意一个时，在报告中以**第 0 条「0 政治风险」**红字提示"潜在政治风险，请人工核查"，并以表格列出含关键词的完整句子与所属一级标题。

**调用脚本**：
```bash
python scripts/geo_check.py --text <全文文本文件>
```
（全文文本须为 agent 提取合并后的纯文本，含 Title page；与 preflight / affiliation_check 输入一致）

脚本返回 JSON（stdout）：
```json
{
  "status": "found" | "not_found",
  "hits": [
    {
      "keyword": "Taiwan",
      "sentence": "The samples were obtained from Taiwan, China.",
      "section": "Introduction"
    }
  ],
  "note": null | "未检测到 Taiwan/Tibet/Xizang"
}
```

**匹配规则**：
- Taiwan → `\btaiwan\w*`（含 Taiwanese）；Tibet → `\btibet\w*`（含 Tibetan）；Xizang → `\bxizang\b`（精确）；全部忽略大小写。
- 句子按 `[.!?]\s+` 切分提取；章节归属通过识别一级标题（Abstract / Introduction / Methods / Results / Conclusion / References 等，支持数字编号前缀如 "1 Introduction"）确定。
- 命中即提示（不区分 "Taiwan, China" 等表述是否合规——是否为风险由人工判断）。

**Agent 处理逻辑**：
- `status=found` → 填充模板中的 `{{POLITICAL_RISK}}`（位于稿件基本信息之后、第 1 节之前）：
  - 红色小字标注："**0 政治风险：潜在政治风险，请人工核查。**"
  - 下方表格三列：关键词 / 完整句子 / 所属一级标题
- `status=not_found` → `{{POLITICAL_RISK}}` 填充为空字符串，报告中不显示（无任何痕迹）。

---

### Step 1: 检查1 — 内容相关性

**输入**：论文标题 + 摘要 + 关键词；期刊 aims & scope 文本（来自 Step 0）

**方法**：
1. 从论文中提取标题、摘要、关键词（读取 Word/PDF 文件；PDF 用 pdfplumber 提取）
2. 读取或获取期刊 scope 文本
3. Agent 做语义比对，判断：
   - 论文主题是否在 scope 列出的领域中
   - 论文类型（research article / review / case report）是否在期刊接受类型中

**输出要求**：
- 第 2 节起始处固定渲染「期刊收稿范围对照依据」块（来源 URL + 版本日期 + 概括性中文收稿范围，**纯文本段落表述，非表格**），由 gen_report.py 自动从 `assets/journal_scopes.json` 读取（`scope_source` / `scope_version_date` / `scope_summary_zh`），**agent 无需手写**
- 相关性分析以 **4 列表格** 呈现（占位符 `{{SCOPE_ANALYSIS_TABLE}}`，数据来自 report_content.json 的 `scope_analysis` 字段）：
  - 列：`分析维度` / `稿件特征` / `对应期刊领域` / `匹配度`
  - 匹配度徽章三档：`高度相关`（绿 ok）/ `部分匹配`（黄 warn）/ `不相关`（红 bad）
  - 每行一个分析维度（如研究主题、研究类型），agent 填入稿件特征与期刊领域对应关系
- 如 scope 中无明确对应领域但论文有交叉可能，匹配度标注 `部分匹配`（黄 warn）并在要点中注明"需人工判断"

---

### Step 2: 检查2 — 作者诚信与机构适配性

**输入**：论文作者列表（来自 Step 0 解析结果）+ 全文文本

本步骤分两个子步骤：
- **2a 作者撤稿检索**（retraction_watch.py check-authors）
- **2b 作者机构与论文领域适配性**（affiliation_check.py 提取机构 + agent 语义判断）

---

#### Step 2a: 作者撤稿检索

**调用脚本**：
```bash
python scripts/retraction_watch.py check-authors --authors "Author1,Author2,..."
```

脚本返回 JSON：
```json
{
  "csv_source": "downloaded_YYYY-MM-DD" | "cached_YYYY-MM-DD" | "download_timeout" | "download_failed" | "cached_YYYY-MM-DD (download incomplete, kept previous version)" | "input_error",
  "authors": [
    {
      "name": "Author Name",
      "hits": [
        {
          "author_in_csv": "...",
          "title": "...",
          "subject": "(ENV) Environmental Sciences;...",
          "retraction_date": "...",
          "reason": "...",
          "institution": "...",
          "original_paper_doi": "...",
          "retraction_doi": "..."
        }
      ],
      "risk": "high" | "medium" | "low" | "none"
    }
  ]
}
```

**Agent 输出要求**：
- 数据来源说明：`downloaded_YYYY-MM-DD` 表示本次刚完成下载；`cached_YYYY-MM-DD` 表示复用本地已有文件（日期为数据源端更新日期 `update_date`）；含 `download_timeout` / `download_failed` / `incomplete`，须向用户提示数据可能非最新或缺失，并给出手动下载地址 https://gitlab.com/crossref/retraction-watch-data；含 `input_error` 表示作者名格式错误，需按提示改用 "First Last" 顺序重试
- 每位作者的结果：命中数 / 匹配度（如有命中，列出相似论文的 title + subject + institution）
- 整体评估：给出作者存在撤稿记录的可能性大小，**明确提示用户需人工判断**
- **报告呈现**（v2.9.0 起）：报告不显示「检索方法」说明与「受检作者」列表；**所有作者的检索结果以表格列出**（占位符 `{{AUTHOR_RESULTS}}`，脚本自动渲染：作者 / 命中数 / 结论 / 说明）

**三档分类规则（作者领域相近性判断）**：
脚本对每位作者返回 `hits`，命中项含 `subject`（撤稿库学科分类，如 `(ENV) Environmental Sciences`）、`institution`、`retraction_doi`、`original_paper_doi`。agent 据此做**三档提示**：
1. **无命中** → 直接说明"该作者在 Retraction Watch 中无撤稿记录"。
2. **有命中但领域不同** → 说明"同名命中，但所涉撤稿论文的 Subject/机构与待查稿件领域不相关，基本判定为同名误报"，列出 subject + institution。
3. **有命中且领域相同** → 醒目警示"同名且领域相近，需人工重点核实"，务必列出 `retraction_doi` 供编辑逐条人工核对。

> ⛔ **档 3 必须覆盖默认文案（v2.19.0，最高优先级）**：`gen_report.py` 的 `build_author_results` 对**任何有命中的作者**硬编码默认说明「命中 N 条，领域均非本稿相关（如 …），基本判定为同名误报」——该文案**只对应档 2**。命中项若**机构或学科与待查稿件相同/相近（档 3）**，默认文案会把"需重点核实"渲染成"已排除风险"，是**最危险的假阴性**（本稿 Jun Ma 实测：39 条命中中 1 条为哈尔滨工业大学市政环境工程学院的水处理论文，与本稿同机构同领域）。
> **因此判定为档 3 时必须**：在 `report_content.json` 写 `author_verdicts`（见 Step 5 字段表）覆盖该作者的行；并在 `summary.author` 用 `{badge:"warn", verdict:"需人工核实", …}`。判定档 2 时才可使用默认文案。
> **判据（须留证据）**：命中项的 `institution` 是否含本稿机构名（或同校同院系）；`subject`/`title` 是否属本稿领域。**机构相同优先于学科分类相同**——Retraction Watch 的 subject 分类粒度粗（如 `(PHY) Engineering - General`），单看分类容易漏判。
> **检索方法**：`work/<稿件标识>/authors.json` 中逐条 grep 本稿机构关键词（如 `Harbin Institute of Technology`）与本领域关键词，勿只看命中数与前几条 subject。

**关键规则**：
- 使用精确 token 匹配（surname + first-name token），防止 substring 误报（如 "Bhattacharya" 中的 "Acharya"）
- 原始命中可能包含大量假阳性，必须做二次校验（同名作者尤其常见，务必比对 subject/institution 判断是否同一人）
- 不在报告中要求用户下载文件，由 agent 完成所有操作
- `--authors` 参数用逗号分隔不同作者，姓名必须用 **"First Last" 顺序**（如 `"Dengyang Guo, Di Yang"`）；若误用 "Last, First" 会被逗号拆成伪作者，脚本已内置校验并返回 `input_error`
- 撤稿检索表格填入报告第 3 节子节「3.1 作者撤稿检索」（占位符 `{{AUTHOR_RESULTS}}`，不含 h3 标题）

---

#### Step 2b: 作者机构与论文领域适配性

**目的**：判断作者机构与论文研究领域是否适配，作为诚信初筛的补充信号。

**调用脚本**：
```bash
python scripts/affiliation_check.py --text <全文文本文件>
```
（全文文本须为 agent 提取合并后的纯文本，含 Title page；与 preflight 输入一致）

脚本返回 JSON（stdout）：
```json
{
  "status": "found" | "not_found",
  "affiliations": ["Shandong Key Laboratory of Intelligent Energy Materials, School of Materials Science and Engineering, China University of Petroleum (East China), Qingdao 266580"],
  "matched_lines": ["a Shandong Key Laboratory ..."],
  "note": null | "未检测到机构信息"
}
```

**Agent 处理逻辑**：

1. **提取不到机构（`status=not_found`）→ 人工兜底**：
   - 询问用户："未检测到作者机构信息，是否提供机构名称？"
   - 用户提供 → 用用户提供的机构做适配性判断（来源标注"用户提供"）
   - 用户不提供 → 报告该子节标注「**未提供机构信息**」，此维度不判定适配性

2. **提取到机构（`status=found`）→ agent 语义判断**：
   - **仅依据机构名称做语义理解，禁止联网搜索机构信息**（不调用 WebSearch/WebFetch 核实机构）
   - 判断方法：机构名称中的领域关键词（Materials / Energy / Chemical / Electrochemical / Battery / Physics / Mechanical / Civil / 材料 / 能源 / 化学 / 电池 等）与论文主题（标题/摘要）交叉比对
   - 两档结果：
     - **适配**：机构领域词与论文主题匹配（如能源材料重点实验室 + 电池论文）→ 直接给结论，**不附提示**
     - **不相关**：机构为完全无关领域（如医学/农业机构投电池论文）→ **必须附提示**："机构名称不含论文领域相关词，但机构可能为跨学科/综合机构（如大学、科学院系统），建议人工检查该机构是否有相关研究团队"
   - 若机构名既无明显领域词、也无法明确判定（如仅"XX University"无院系信息）→ 归入「不相关」并附人工检查提示

**报告输出要求**（填入第 3 节子节「3.2 作者机构与论文领域适配性」，占位符 `{{AFFILIATION_TABLE}}`，不含 h3 标题；v2.9.0 起为脚本渲染的 **3 列表格**，agent 只需在 report_content.json 填 `affiliation_analysis` 结构化字段）：
- **3 列表格，一行一个机构**：`机构` / `判断依据` / `适配度`
- 机构名称用中文：中国机构（含港澳台）= 学校+学院，国外机构 = 国名+学校+学院，不含省市/街道/邮编
- **判断依据列只写机构领域词 vs 论文主题词对照**（如"机构名称含「土木工程」，与论文结构抗震主题直接匹配"）；机构来源（Title page / 正文 / 用户提供）**不展示**（v2.9.1 起）
- 适配度徽章：`适配`（绿 ok）/ `不相关`（红 bad，附人工检查提示）/ `未提供机构信息`（黄 warn）
- 表格下方固定 note（脚本自动渲染，agent 无需写）：「注：本子节判断仅基于机构名称语义，未联网核实机构信息。」

---

### Step 3: 检查3 — 参考文献检测

**输入**：论文参考文献列表（从 Step 0 解析结果中提取）

**参考文献解析（v2.18.0 起统一入口，自动识别格式）**：
```bash
python scripts/parse_refs_auto.py <全文文本> <out_refs.json> [--strategy=...] [--sample=10]
```
**不要再人工判断格式后手选 `parse_refs.py` / `parse_refs_apa.py`**——本脚本自动完成全部前置处理：

| 阶段 | 处理内容 |
|---|---|
| ① 预处理 | 去 PDF 分页标记；**稳健识别并剥离行首页码水印**（三重判定：覆盖率≥60% + 相邻差 0~2 + 首值 1~2000，避免误删以数字开头的条目） |
| ② 编号识别 | 支持 `[1]`、`(1)`、`1.`、`1)`、`1␣␣`，以及**无编号**；编号带连续性校验（防 `2023).` 这类年份被误当条目编号） |
| ③ 条目切分 | 按编号/作者起始切分，**续行自动并入上一条**（旧脚本逐行处理会丢弃续行）；遇补充材料（Electronic Supplementary Material / Figure S1 / [TABLE] 等）自动停止，防图注表注被吞入末条 |
| ④ 格式识别 | 取前 10 条为样本，**14 种策略**各跑一遍并打分（0.6×成功率 + 0.2×字段完整度 + 0.2×年份命中率），取最优；并列时优先匹配编号模式的策略 |
| ⑤ 全量解析 | 用最优策略解析全部条目；失败条目自动用次优策略兜底重试 |
| ⑥ 统一清洗 | DOI 回捞（ `10\.\d{4,9}/\S+` ）、期刊名迭代剥离卷/期/页与"In "前缀、标题混入作者的二次切分、预印本标记 |

支持的 14 种策略（均可通过 `--strategy=` 手动指定，用于自动识别不准时兜底）：

| 策略 | 适用格式 | 样例 |
|---|---|---|
| `numbered` | 编号式，年份在尾部 | `[1] Goodenough, J. B. ... Chem. Mater. 22, 587-603 (2010).` |
| `apa` | 编号 APA，年份在作者后 | `[1] Cai, F. Y. (2024). Title. Energy Convers. Manage. 307, 118348.` |
| `noidx_apa` | **无编号** APA | `Nguyen, L. T., Cava, R. J. (2021). Title. Chemical Reviews 121, 2935–2965.` |
| `vancouver` | 编号 + **裸年份**（年份前为逗号） | `[1]. Lee, S. and Kang, S., 2025. Title. Energy, 318, p.134731.` |
| `nature` | 无编号，`et al./&`，年份在末尾 | `Xu, W. et al. Title. Energy Environ. Sci. 7, 513–537 (2014).` |
| `noidx_vancouver` | **无编号** NLM/Vancouver，作者「姓+缩写」；v2.20.1 起兼容**行尾 DOI/URL**与**混排年卷写法**（`年;卷:页` / `年, 卷, 页` ACS 式 / `年:页` 无卷 / 仅年份）及**逗号制条目**（`…, et al., 标题, 期刊`）；**v2.22.0 起补全 `年;卷[(期)][:页]` 形态**（期号可选、页码可省、页前冒号/逗号均可） | `Reddy R, Adamu M, ... Title. Journal. 2025;76:107371.` / `… 2025;10:2616–32. https://doi.org/10.…` / `… Journal. 2023;24(1).` |
| `numbered_year` | 编号 + **裸年份紧跟作者**（皇家学会/SPJ 式，年份前为句点、年份后直接接标题、卷页以 `,` 分隔） | `1. Bettencourt LMA, ... West GB. 2007 Growth, innovation, ... Proc. Natl Acad. Sci. USA 104, 7301-7306. (doi:10.1073/pnas.0610172104)` |
| `gbt7714` | **GB/T 7714**（中文期刊英文著录，带 `[J]` 文献类型标识；**年份在期刊名之后**） | `[1]Learbuch K L G, Smidt H, Van Der Wielen P W J J. Influence of pipe materials ... biofilm [J]. Water Research, 2021, 194: 116922.` |
| `rsc` | **编号式**（RSC/皇家化学会「无篇名」式，年份在期刊名**之前**）：`<n>. <作者>, 期刊, 年, 卷, 页码.`——**无标题**。**v2.23.0 起兼容「有篇名」变体**（NLM/CSE 式，年份在期刊名**之后**）：`<n>.<作者>, 篇名. 期刊, 年. 卷(期): p. 页.`；**v2.26.1 起再兼容两类**：① 在线优先期刊 `期刊, 年: p. 页.`（无卷期，年份后为冒号）；② **容器条目** `作者. 篇名. in <会议录/书名>. 年. [出版社].`（期刊位放容器名） | RSC 式：`1.M. S. Dresselhaus and I. L. Thomas, Nature, 2001, 414, 332-337.`<br>NLM 式：`1.Heiskanen, S.K., J. Kim, and B.L. Lucht, Generation and Evolution of the SEI … Joule, 2019. 3(10): p. 2322-2333.`<br>容器式：`2.Xu, T.-B. and L. Zuo. Key Issues on … Developments. in International Design Engineering Technical Conferences … Conference. 2019. American Society of Mechanical Engineers.` |
| `ieee` | **编号式 IEEE house style**（Zotero 导出）：篇名带引号、卷期页以 `vol./no./pp.` 标识、年份前带月份缩写 | `[1] A. Author, \u2018Title of the paper\u2019, J. Abbrev., vol. 1, no. 2, pp. 3-4, Mar. 2020, doi: 10.xxxx/yyyy.` |
| `elsevier` | **编号式 Elsevier/SciOpen**（**v2.25.0 新增**）：作者与标题、标题与刊名之间以**逗号或句点**分隔（也可能无标点）；**年份带括号居中**、卷期连写 `卷 (期)`。以「最后一个 `(YYYY)`」为锚 + 从右往左数 Title-Case 词提刊名 | `[3] Q. Pan, ..., B. Feng, Perovskite solar cells towards industrialization: overcoming challenges with data-driven strategies, Nanoscale 18 (16) (2026) 8403-8421.`<br>无卷期：`[1] Y. Zhang, ..., N. G. Park, Octahedral connectivity reconfigures interfacial carrier-selective properties for efficient perovskite solar cells. Nat. Mater. (2026)` |
| `springer` | **编号式 Springer/CVMJ**（**v2.26.0 新增**）：作者段用**分号**分隔且**以双句点收尾**（`… Ramanan, D..`）、**标题与来源之间以句点切分**、来源尾部为 `来源, 年份, 页码.`；含 `In: Proceedings of …` / `Vol. 12` / `Art. No. xxx` / `出版社: 城市` 等变体 | `[26] Mayne, D. Q.; Rawlings, J. B.; Rao, C. V.; Scokaert, P. O. M.. Robust model predictive control: A survey. Robustness in Identification and Control, 2007, 207-226.`<br>会议：`[47] Dosovitskiy, A.; ...; Houlsby, N.. An image is worth 16x16 words: Transformers for image recognition at scale. In: Proceedings of Int. Conf. Learn. Representations, 2021.` |
| `acs` | **编号式 ACS house style**（**v2.27.0 新增**）：作者段用**分号**分隔、**年份落在刊名之后、卷号之前**（`Journal YEAR, Vol (Issue), Pages.`）、页码可为文章号（`e19006`）；含 `DOI:` 尾注、`journal article` 标签、在线优先（无卷无页、`年` 或 `n/a (n/a)`）等变体 | `(1) Jiang, A.; Xie, H.; …; et al. Nd Doping Inhibits Lattice Oxygen Loss … . Advanced Functional Materials 2026, 36 (12), e19006. DOI: https://doi.org/10.1002/adfm.202519006.` |
| `numbered_jv` | **编号式「期刊. 年, 卷(期), 页」**（**v2.30.0 新增**）：作者以**逗号**分隔（`姓, 名缩写` 组间亦用逗号，与 `acs` 的分号不同）、**刊名与年份之间多一个句点**（`Journal. YEAR, Vol(Issue), Pages.`）；年份带句点在**前**是本格式唯一稳定指纹；兼容「年 卷(期)」漏逗号、仅卷+页、仅文章号、仅页码范围、`(pp. 247-267)` 书籍章节 | `[1] Larcher, D., Tarascon, J. M. Towards greener … storage. Nature chemistry. 2015, 7(1), 19-29.`<br>`[15] Sharma, V., … photocatalysis. In Handbook of smart photocatalytic materials. Elsevier. 2020, (pp. 247-267).` |

**编号+裸年份紧跟作者支持（v2.18.2）**：形如 `N. 作者列表. YYYY 标题. 期刊 卷, 页码. (doi:…)` 的条目（**皇家学会 / Science Partner Journal 系刊常用**）此前 6 策略全部 `parse_failed`（CES 新投稿实测 30/30 全失败）：F1 要求年份在末尾、F4 要求年份前是**逗号**（本类为**句点** `West GB. 2007 Growth`）、F6 要求行尾 `年;卷`（分号，本类为 `卷, 页码`）、F2/F3/F5 要求括号年份。v2.18.2 新增第 7 策略 `numbered_year`（`scripts/parse_refs_numbered_year.py`），要点：
- 以「句点+空格+4 位年+空格」为**唯一锚点**正向切分（作者段不含 4 位数，首个命中即出版年）；
- **先提取 DOI，再删除整段 `(doi:…)` 括注**——不删则残留 `(doi:` 挂在期刊名尾部令卷页正则失配（首次实测 journal 变成 `Proc. Natl Acad. Sci. USA 104, 7301-7306. (doi:`）；
- 标题边界用「候选切点扫描」而非固定标点：`?` 既可能结束标题（`Is this scaling nonlinear?`）也可能在标题内部（`Building in or out? Examining urban expansion …`），故对每个句末标点候选**检验余段是否像期刊名**（含纯小写长词者判为正文续写）再决定切点；
- 卷页用右锚定 `期刊 卷, 页码` 提取（期刊名内部缩写句点 `Proc. Natl Acad. Sci. USA` 不被切碎）；无卷页的**报告/代码库条目**只取首个句段并剥离 `no. NN` 报告编号后缀。

**GB/T 7714 支持（v2.19.0）**：形如 `[1]作者列表. 标题 [J]. 期刊, 年, 卷(期): 页码.` 的条目（**中文期刊英文著录**，编号后紧跟作者、带 `[J]` 文献类型标识）此前 7 策略均无法正确解析——**年份在期刊名之后**（F1 要末尾、F4 要作者后逗号、F2/F3/F5 要括号年份、F7 要与作者同年句点分隔），编号后也无 `[1].` 的分隔点。CES 新投稿实测（观点文章，13 条）：`numbered` 以 **0.735** 分被选中，产出**年份全空、作者混入标题、文章号被腰斩**（`Water Research, 2021, 194: 116922` → volume=`11692` / page=`2`）的垃圾结果，而 **`parse_failed` 均为空** → Crossref 会把全部文献报成「无法定位」，制造"整篇文献不可信"的假象（与 v2.18.2 修的缺陷同类，但**成因不同**：那次是失败被当成功，这次是"错得看起来像成功"）。v2.19.0 新增第 8 策略 `gbt7714`（`scripts/parse_refs_gbt7714.py`）：
- 以 **`[J]` 类文献类型标识为锚点**切分（`[J]`/`[M]`/`[C]`/`[D]`/`[R]`/`[P]`/`[S]`/`[N]`/`[EB/OL]` 等**白名单**校验，无标识即判 `parse_failed` 交其他策略——因此不会误抢其他格式）；
- 作者/标题边界两级判定：① `et al.` 锚点，② 句点+空格候选切点（**前缀像作者列表 且 后缀像标题**）；
- 作者列表判据 `_looks_like_authors`：每 token 只能是单大写字母缩写、首字母大写词（姓氏/复姓成分）、已知小写冠词前缀（van/der/de…）或 et/al 等短词——**出现任何其他小写多字母词（of/the/and）即判否**，这是把 Title Case 标题片段挡在外面的关键；
- 标题判据 `_looks_like_title`：≥4 词 且 ≥2 个长度 ≥4 的词，且**本身不是作者列表**。**不得用「含小写长词」作条件**——Title Case 标题（`A Review of Recent Progress in…`）的小写词只有 of/in/the/for，会被误否（本稿 [10] 实测因此作者混入标题）；
- 右侧按 `期刊, 年, 卷(期): 页码` 正则提取，卷期 `11(2)` 只留卷号，**页码整体保留**（`1426-35` / `e1704` / `lxaf004` 不拆分——`numbered` 曾把 `1426-35` 拆成 volume=1426 / page=-35）；
- 已知边界：作者缩写带句点（`Learbuch K. L. G.,`）时首个候选切点会落在缩写处，该类写法需人工复核。
- 回归：依赖 `[J]` 标识，对 `numbered_year` 式（CES Constraint-Aware Urban Scaling）得 0.0 分，不干扰既有格式。

**编号式无篇名支持（v2.20.0，RSC/皇家化学会 house style）**：形如 `1.M. S. Dresselhaus and I. L. Thomas, Nature, 2001, 414, 332-337.` 的条目——**著录里根本没有标题**（RSC 期刊自引常年如此），年份夹在期刊名之前、其后直接跟「卷, 页码」。此前 8 策略无一覆盖，且失败方式**不是报错而是错位**：旧策略把整条解析成 `title='…Nature 2001'`、`journal='414'`、`volume='332'`、`year=''`，`parse_failed` 仍为空（EMD20260066 实测 116 条中 114 条全错位）。v2.20.0 新增第 9 策略 `rsc`（`scripts/parse_refs_rsc.py`）：
- **以「`, 年份`」为唯一锚点**（正则 `,\s*((?:19|20)\d{2})\s*(?:[,.]|$)`，出版年后必须有逗号/句点/行尾边界）正向切分：锚点**左**为「编号 + 作者列表」（按逗号切段，末段即期刊名），锚点**右**为「卷, 页码」；
- **期刊名判据用否证法**：末段若命中出版社/地名/`eds.`/`preprint`/`Inc.` 等词即判**非期刊条目**，改为反向扫描找篇名（书籍章节、报告、网页等非期刊文献因此不会被强行套成"期刊"）；
- 页段清洗新增剥 `pp.` 前缀（书籍章节 `pp. 33-53` → `33-53`），保证与 Crossref 起始页可比；
- 输出 `no_title_format=True` 标记（**确无标题**，区别于"标题解析失败"），并带 `ref_nonjournal` / `ref_kind` 供后续判定；
- **`ref_common.is_healthy` / `field_completeness` 已按此标记分流**：健康判据改为「有年份 且（期刊 or 标题 or 页码）」，完整度只考核 `year`/`journal`/`authors` 三字段——否则 116 条正确结果会被判成"字段不完整"而压低策略得分；
- 实测 EMD20260066：`rsc` 得分 **0.995** 自动选中、116/116 全解析、`parse_failed` 为空、字段抽查全对（对照组 `numbered` 仅 0.735 且输出错位）。

**RSC 策略的「有篇名」变体支持（v2.23.0，NLM/CSE 式：`作者, 篇名. 期刊, 年. 卷(期): p. 页`）**：
`rsc` 的「, 年」锚点法**只对"年份在期刊名之前"的 RSC 式成立**；当稿件改用 **NLM/CSE 式**——**有篇名**、年份落在「篇名. 期刊, 年.」的期刊名之后——锚点会**落在篇名内部**，导致「作者 + 整条篇名」被并进 `journal`、`volume` 为空、`title` 全空，而 **`parse_failed` 为空、`rsc` 得分虚高 1.0**（第四类静默失败：既非"失败被当成功"、也非"错得看起来像成功"，而是**满分假象下的系统性列错位**）。EMD20260070 实测 41/42 条 `title` 全空（Crossref 被迫全部走 `bibliographic` 路径，`journal_mismatch` 假警风险陡增）。v2.23.0 起 `parse_line` 在锚点切分**之前**先调 `_detect_title_variant(head)` 判定结构：
- **判据（双条件）**：① `head` 内存在「句点 + 空格 + 大写/左括号」边界（篇名/期刊交界，而纯作者列表的段间分隔是「逗号 + 空格」）；② 该边界**右侧**（即期刊名）短（≤7 词）、无句点、无作者式缩写串（`\b[A-Z]\.` 出现 ≥2 次即判否）。
- **作者/篇名的切分锚点**（三条回退，按序尝试）：① `et al.` 锚点（`…, et al., 篇名…`）；② `and <缩写> <姓>,` 锚点（单作者+合著者式，EMD20260070 [15] `Asl, H.Y. and A. Manthiram, Reining in …`）；③ 首个「≥4 词且 ≥20 字符的长段」即篇名起点（**篇名内部可含逗号**——`Mechanism, Detection, and Mitigation in …`，EMD20260070 [6] 实测，故不能用"首个非作者段"作终点）。
- **命中变体时不置 `no_title_format`**（`False`），使 Crossref 走**标题核验**（比 `bibliographic` 更可靠）。
- **`_split_tail_volume_page` 新增 NLM 尾式**：`卷(期): 页` / `卷(期): 页.`（`3(10): p. 2322-2333`、`172(4): p. 040506`）——卷号只留卷本体、期号丢弃（与 `gbt7714` 口径一致），页段剥 `p.`/`pp.` 前缀。
- **无「, 年」锚点的非期刊条目**（在线专著/数据库/报告，写作 `标题. 2006: 出版社`）：若同时命中 `book|database|report|press|online|…` 词，走 `_extract_nonjournal` 反向取篇名，置 `ref_nonjournal=True`（EMD20260070 [40] `Liao, Y., Practical electron microscopy and database. 2006: An Online Book.`）。
- **反向保险（不可删）**：`_detect_title_variant` 不命中时**完全回退**原 RSC 路径，故真 RSC 式（无篇名）输出逐字不变。
- **A/B 回归（v2.23.0 实测）**：`EMD20260066`（RSC 式 116 条）计数、策略、得分 **0.995 完全一致**，`title` 非空数仍为 8（均为本身带篇名的非期刊条目）——**零回归**；另 14 份历史稿件（apa/noidx_apa/vancouver/nature/numbered/noidx_vancouver/gbt7714 各式）条目数与策略**逐份一致**。**改动前后本稿 0→42/42 全解析**，Crossref 由 `bibliographic` 全败转为 40/42 标题级核验通过。**A/B 方法**：`git checkout-index -a -f --prefix=<临时目录>/` 导出 HEAD 版全部脚本对同一批稿件逐条对照（比 `git stash` 安全，不动工作树）。

**Elsevier 编号式支持（v2.25.0）**：形如 `[n] 作者列表, 标题. 期刊 卷 (期) (年) 页码.` 的条目（**Elsevier / SciOpen 系投稿常见**，EMD20260073 与 CESCI-S-26-00038 实测）此前 10 策略最高仅 `numbered` **0.78** 分且字段**系统性错位**——`title` 空、`year` 空、`journal` 尾部挂上标题或卷期（本稿 42 条中 [1][2] 即典型），而 **`parse_failed` 仍为空**（第三类静默失败的新变体：「错得看起来像成功」）。成因：`numbered` 假定「作者, 标题, 期刊, 卷 (年) 页」**全逗号分隔、年份在行尾**，而本格式年份**带括号居中**、卷期连写 `18 (16)`、标题与刊名之间为**句点或干脆无标点**、作者段还含 `and X.` 形式（其 AUTHOR_RE 不认）。v2.25.0 新增第 11 策略 `elsevier`（`scripts/parse_refs_elsevier.py`）：
- 以**最后一个 `(YYYY)` 为唯一年份锚点**，右侧残段 tail 为页码/文章号；
- **门控（防误抢）**：tail 须短（≤40 字符）且不含 `. `，否则判失败交其他策略——正是靠这一条挡住 APA「作者 (年). 标题. 期刊」这类同样「年份在括号里」的格式；
- 左侧依次剥「卷 (期)」/「卷, 期」/「卷」（要求卷号前为字母或右括号，避免吃掉以数字结尾的刊名）；
- **刊名用「从右往左连续 Title-Case 词」提取**（允许 of/in/and/for/de 等连接词、允许 `Measurement: Energy` 的冒号与 `J. Mater. Chem. C` 的缩写点），遇小写实词或含逗号/括号的词即停 —— 因此**标题与刊名之间即使完全没有标点也能切准**（[6] `… solar cells Chemical Engineering Journal 519 (2025) 165415` 实测）；
- 作者/标题按逗号分段判定，**兼容无缩写点的作者名**（`Marc Al Atem`）——该宽松判据**仅在已确认 ≥1 位作者后启用**，避免吞掉 Title Case 标题片段；
- 页码字符类含 **U+2212 数学减号**（`802−806`，与 `citation_stats` 的 `_DASH` 同源教训）。

**实测（EMD20260073）**：`elsevier` 得分 **1.0** 自动选中、**42/42 全解析、0 失败**、字段抽查全对（对照组 `numbered` 0.78 且输出错位）。**A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD 版全部脚本，21 份历史稿件逐条对照）：**19 份计数与策略完全一致**；`EMD20260073` 41 → 42（预期改进）；`CESCI-S-26-00038` 由 `numbered` 改判 `elsevier`，**条目数不变（40）但救回 2 条真实期刊论文（[1][3]：此前因 `and` 作者段与卷期连写而 `parse_failed`），同时把 2 条网络资源/报告（[7][9]）由「错位解析」改为显式失败**（此前 `numbered` 给出的 title 分别是 `(May 2019)`、`workforce survey analysis, Tech. rep., A` 之类垃圾文本）—— **净改进，无回归**。

**Springer/CVMJ 编号式支持（v2.26.0）+ 编号识别脱折行（CRITICAL）**：形如 `[n] Surname, A. B.; Surname, B. C.. Title. Source, YEAR, pages.` 的条目（Springer 系**分号作者 + 双句点收尾**，CVMJ/Tsinghua 系刊常见）此前 11 策略全部不匹配，最高仅 `rsc` **0.9** 分且输出系统性错位（`title` 空、`journal` 挂整串），而 `parse_failed` 仍为空（「错得看起来像成功」）。**但本稿真正的元凶不是缺策略，而是编号识别**——见下「第五类静默失败」。

**新增第 12 策略 `springer`（`scripts/parse_refs_springer.py`）**：
- **标题边界 = 双句点**（`_DBL_DOT = re.compile(r'\.\.\s')`）：作者段以缩写句点收尾后再加一个句点（`… Ramanan, D..`），这是本格式最稳定的锚；无缩写点时回退 IEEE 引号边界（`, “Title…`）；
- **来源切分**：标题右侧 `来源, 年份, 页码.`——年份取**最后一个「非页码端点」的 4 位年**（`_last_year`：跳过与数字/破折号相邻者，否则 `3354–3361` 的端点会被读成年份，实测曾产出 `year=2087`/`2050`/`2011`）；
- **变体归一**：`_SRC_PREFIX` 剥 `In:`/`In ` 前缀（含 `inProc.` 粘连写法）；`_VOL_RE` 收 `Vol. 12`；`_ARTNO_RE` 收 `Art. No. 102877`（当页码使）；`_PUBLISHER_SEG` 截掉 `出版社: 城市` 尾段（否则书籍条目 `journal` 变成城市名 `Berlin`）；
- **连字符还原**：`_dehyphen` 合并 PDF 断词（`atten-tion` → `attention`）。

**① 编号识别脱折行（CRITICAL，第五类静默失败）**：`detect_numbering` 原判据是**逐行**统计行首编号命中率 ≥30%。**窄栏 PDF（双栏期刊，页宽 612pt）中一条文献常折行 4–6 行**——本稿前 40 行里条目起始行只有 9 行（9/40 = **22.5% < 30%**）→ 误判 `unnumbered` → `split_entries(unnumbered=True)` 把整篇文献区切成 **9 大块串行文本**（实际 89 条）→ 各策略在这堆垃圾上打分，`rsc` 反而拿 **1.0** → 产出「条目数 9 + 字段串行错位 + `parse_failed` 为空 + 得分满分」的**三重假成功**。修法：`BRACKET_NUM_RE = ^\s*\[\d{1,4}\]` 命中 **≥3 行即判 `numbered`**（强证据，脱离折行统计）——方括号编号在文献区不会出现在折行续行行首，正文引用 `[12]` 也不会单独成行，故绝对条数判定安全；裸编号（`1.`/`1)`）仍沿用 30% 判据（与年份、章节号易混，放宽会反向误判）。
**② `SECTION_STOP_RE` 补 `author\s+biograph\w*`**：本稿文末作者简介紧接文献区，原终止标记不含 biography → 简介被并进末条文献 [89]。
**③ Crossref 会议容器豁免（`is_conference_container`）**：稿内 65 条会议论文（CVPR/ICCV/ECCV/NeurIPS/ICLR 等）此前被 strict 刊名核对判 `journal_mismatch`（稿内写 `Proceedings of …`、Crossref 记 `2022 IEEE/CVF Conference on …`）→ **65 条假警**。新增容器识别（`proceedings|conference|symposium|workshop|congress|neurips|iclr|icml|cvpr|iccv|eccv|wacv|acl|emnlp|lecture notes|tech. rep|thesis|arxiv` 等），命中则降级为 `info["conference_container"]`（**期刊核对只对「期刊论文」有意义**），假警 65 → 1（仅剩 1 条书籍容器差异）。**注意**：`arxiv` 必须在列（预印本条目本来就无期刊名）；曾试图加入 `in\s+robustness` 以捉书籍章节，反而误伤书籍标题 *Robustness in Identification and Control*，已回退。

**实测（CVMJ-26-00445，89 条）**：`springer` 得分 **1.0** 自动选中、**89/89 全解析、0 失败**、字段抽查全对；对照 `rsc` 0.9（标题空）、`numbered` 0.63 且均输出错位。**A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD 版全部脚本，22 份历史稿件逐条对照）：**21 份条目数与策略零变化**，仅本稿 9 → 89 条（预期改进，即修复目标）。**单元回归**：`springer` 对 89 条逐条解析 OK 89 / FAIL 0。

**ACS 编号式支持（v2.27.0，新第 13 策略 `acs`）**：形如 `(n) Surname, A. B.; Surname, C. D.; …; et al. Title. Journal YEAR, Volume (Issue), Pages. DOI: …` 的条目（**ACS 期刊模板导出**，EMD/ACS 系刊常见）此前 **12 策略全部失效**——EMD20260084 实测最高 `vancouver` 仅 **0.095** 分、48 条中 46 条报 `no year`。成因：本格式**年份在刊名之后、卷号之前**（`Advanced Functional Materials 2026, 36 (12), e19006`），与所有既有锚点都不合——`numbered` 要年份在行尾、`numbered_year` 要年份紧跟作者、`gbt7714` 要 `[J]` 标识、`rsc` 要 `, 年` 逗号锚点（本式年份前是空格）、`elsevier` 要年份带括号。新增 `scripts/parse_refs_acs.py`：
- **DOI 先摘**（`DOI:` 标签残留须一并清除——否则 `e19006. DOI:` 整段无法当页码匹配）；
- **右侧「年 + 卷(期) + 页」尾式**为锚（`YEAR, Vol (Issue), Pages.`），页码兼容文章号（`e19006`/`2103005`）；
- **刊名从右往左扫描提取**：Title-Case 词 / 缩写白名单（`Mater.` `Chem.` `J.` `Soc.`）/ 连接词（`of` `and` `&`）连续收集，遇「句点收尾且非缩写」即停（该词是标题末词）。**缩写判据必须是白名单 + 全大写短词，不可用「Title-Case 短词+句点」**——否则标题末词 `Route.` 会被吞进刊名（实测 [22] 刊名变成 `Long- Time Molten-Salt Route. Small Methods`）；
- **刊名切分按 token 下标、不按字符串定位**：PDF 把化学式下标提成独立行后，刊名在原文里**不是连续串**（`… batteries. Chemical 0.8 0.1 0.1 2 Engineering Journal 2021,`），字符串 `find` 必然失配 → 标题会把刊名整段吞掉（实测 [46]）；
- **连续数字 token 跳过**（上述下标残留），最多 8 个；
- **标题下标残留清洗 `_clean_title_debris()`**：判据从严——**连续 ≥2 个纯数字 token 且其中 ≥2 个带小数点**（下标指纹）才整段丢弃，单个数字（`4.5 V`、年份）一律保留。不清洗则与 Crossref 标题的 token 重叠率被拉低而误报 `title_mismatch`（实测 [21][22][27] 由 `issues_found` 转 `verified`）；
- **作者段按 `;` 消费**，末段可能是 `et al. 标题…` 或 `Surname, X. 标题…`，单独二次切分；兼容多词姓（`Thien Nguyen` / `Van Tendeloo`）与小写缩写（`Zaman, F. u.` / `Hao, S.-m.`）；
- **在线优先条目**：`Journal n/a (n/a), e1523894.` 无年份（year 留空属正常）。
**实测（EMD20260084，48 条）**：`acs` 得分 **1.0** 自动选中、**48/48 全解析、0 失败**；Crossref 核验 **48/48 通过**（45 条逐项一致 + 3 条年份差 1 年）。**A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD=v2.26.2 全部脚本，30 份历史稿件逐条对照）：**29 份条目数与策略零变化**，仅本稿 46 → 48（预期改进）。

**`split_entries` 期号误判（v2.27.0，CRITICAL，第六类静默失败）**：ACS 条目跨行时卷号留在上行、**期号 `(48)` 落到下一行行首**（`(48), 2103005. DOI: …`），该形态被 `ENTRY_NUM_RE` 命中、又被 `_is_new_entry` 的「小幅跳跃 ≤3」放行 → **伪条目**产生、后续真条目被并进这条 → 条目数由 48 掉到 46，且跨度的两条（46、47）消失、其内容混入伪条目 48。**判据：`(数字)` 后紧接逗号**（`^\s*\(\d{1,4}\)\s*,`）即期号续段——文献条目起点绝不会是 `(n),`。**排查口诀：条目数与正文最大引用编号对不上、且末段条目出现「(n), 页码」式开头时，先查是否为期号被误判为编号。**

**无编号 NLM/Vancouver 支持（v2.18.1）**：形如 `Reddy R, Adamu M, Raut A, ... Title. Journal. 2025;76:107371.` 的条目（作者为「姓 名缩写」且以逗号分隔、年份在期刊名后、卷页以 `;` 分隔）此前 5 策略全部解析失败——常规无编号切分要求作者起始为 `Surname, I.`（`Nguyen, L. T.`）形式，本格式首词 `Reddy R,` 不命中 → 0 条目报 error（CESCI-D-26-00016R1 实测 54/54 全失败）。v2.18.1 修复：① `ref_common.split_entries` 常规无编号切分 0 命中时自动回退 `split_entries_nlm`（双重条件判定新条目：首词形似姓氏[大写词或 de/van/der 等西欧冠词前缀] **且** 行内含 `\d{4};` 年;卷锚点）；② 新增第 6 策略 `noidx_vancouver`（从行尾倒推切分：剥 年;卷:页 → 剥 DOI/URL → 按 `. ` 段拆分 作者/标题/期刊，作者段尾部 `et al` 剥离）。已知边界：期刊名内部含缩写句点（`J. Constr. Steel Res.`）会被 `. ` 切碎；PDF 折行条目若续行恰好含 `\d{4};` 可能丢失首行——此类需人工复核或转 DOI 优先验证。

**预印本处理（v2.18.0）**：识别 arXiv / bioRxiv / medRxiv / SSRN / ChemRxiv / Research Square，写入 `is_preprint` / `preprint_server` / `preprint_id` 三个字段。预印本**不跳过任何检测**（撤稿检测照常执行，本地比对毫秒级）；仅在 Crossref 未收录时把状态降为 `preprint_not_indexed`（"预印本·未收录"，不计入不可信），并在报告 4.2 节给出"本文共 N 篇来自预印本"的统计提示。

**解析结果自检（必做，v2.19.0 加严）**：
- 看 stdout 的 `refs_total` 是否与正文引用最大编号一致（注意正文中的 Miller 指数 `[100]` 之类方括号数字不是引用）
- **看 `numbering` 判定与版面是否相符（v2.26.0 新增，第五类静默失败）**：**窄栏/双栏 PDF（页宽 ~612pt）里一条文献常折行 4–6 行**，若 `numbering` 判成 `unnumbered` 而稿内文献明明带 `[n]`，即命中「编号识别失败」——后果是条目被切成数量级的错误大块、策略满分但字段串行错位（CVMJ-26-00445 实测：89 条被切成 9 条）。**判据：`numbering=unnumbered` + `refs_total` 远小于正文最大引用编号**。已在 v2.26.0 修（`[n]` 行 ≥3 即判编号式）；若仍有此现象，须人工确认编号形态后再跑。
- **看 `status` 与 `error` 文案是否"阶段相符"（v2.26.1 新增）**：`no reference entries found`（报"切不出条目"）**不等于**格式问题——稿件**不写 "References" 标题**时（Elsevier / Mendeley 导出的稿件常见，正文声明段后直接起 `1.Kim, H.S., …`），定位兜底可能误落正文一级节标题 `1. Introduction` → 从正文开头切区 → 条目数 0 并报出上述文案（看着像"格式不支持"）。**排查口诀：报错文案与阶段不符（报"切不出条目"而非"找不到标题"），先打印 `locate_references()` 的位置与文献区前 20 行。** 已在 v2.26.1 修（兜底要求编号行"像文献条目"：含 4 位年份 / DOI / URL，或以「姓, 缩写」作者式开头；EMD20260076 实测 0 → 52/53）。
- 看 `numbering` 判定是否符合预期、`page_numbers_detected` 是否正确
- **不能只看 `parse_failed` 是否为空**（v2.18.2 起）：须抽查 refs.json 前几条的 `title`/`authors`/`year` 是否非空**且正确**——「条目数正确但字段全空」与「字段非空但内容错位」（年份全空、作者混入标题、文章号被腰斩）**都不会体现在 `parse_failed` 里**，是两类不同的静默失败。
- **看 `strategy` 与最高分是否够高**（v2.19.0）：最优策略得分明显低于 0.9（如本稿 `numbered` 0.735）即提示"格式未被任何策略真正覆盖"，此时选中策略的输出**不可直接采信**，须先核对字段再继续；有 `[J]` 标识的稿件应命中 `gbt7714`（1.0）。
- 若 `parse_failed` 非空，条目内含 `raw` 前 200 字，据此人工补全后再重跑
- **修正解析结果后必须重跑 `crossref_check.py verify`**，否则报告里仍是旧数据

此步骤分三个子步骤（注：报告章节编号为 4.x，见 Step 5，与本文档工作流子步骤 3.x 编号不同）：

#### 3.1 Crossref 真实性验证

**调用脚本**：
```bash
python scripts/crossref_check.py verify --refs <references_json_file>
```

**验证策略（v2.15.0）**：

1. **检索策略**：
   - **有 DOI → DOI 优先检索**：`GET /works/{DOI}`（DOI 大小写不敏感，统一小写；**v2.15.0 起 DOI 先过正则校验 `^10\.\d{4,9}/…` 并 quote 转义**，格式非法/含控制字符的 DOI 跳过 DOI 路径走标题检索，杜绝 CRLF/请求拆分注入）；命中记录后**按标题/姓名等统一打分确认**（见下），打分达标 → 接受（source=`doi(score=X/13)`）；不达标 → `issues_found` 并提示人工复核（DOI 已找到记录，不判 not_found）
   - **无 DOI（或 DOI 失败）→ 标题检索（两级并行，v2.15.0）**：
     - 首轮 `/works?query=标题+作者姓氏`（bibliographic 全字段），**rows=15**（v2.13.0 起 3→10，v2.15.0 起 10→15——rows=10 时目标排 11-15 仍可能被截；EMD20260090 实测 9 条 not_found 中 6 条因此误报）
     - 兜底 `/works?query.title=标题&rows=20`（标题字段精准匹配，救"query= 被同类文献淹没"条目，同实测 3 条）；**v2.15.0 起两级并行提交**（ThreadPool 2，慢路径等待约减半）
   - 两级候选合并逐条评分取最优；**接受条件 = 总分 ≥ 6 且标题匹配**（标题不匹配即使 7 分也拒绝，防"期刊+年份+作者=7 但标题完全不同"误配）
   - **无篇名条目（v2.20.0）→ 书目串检索路径**：`ref_title` 为空时标题检索必然全败（无标题可比），改走 `query.bibliographic=`（书目串）并单独评分——`biblio_query_string(ref)` = 「前两位作者姓 + 期刊 + 年 + 卷 + 起始页」；命中后按**满分 16** 打分（期刊 4 + 年份 2 + 卷 3 + 页起始 3 + **文章号 3** + 作者姓 1），**阈值 ≥8 且期刊名必须匹配**；首轮不达标则并发跑两档变体（B：作者姓前 4 位 + 期刊 + 年 + 卷 + 页；C：去期刊的宽松档），仍不过才判 `not_found`。命中时 `source` 记为 `biblio_search(score=N/16)`（缓存 key 后缀 `:biblio`）
   - **在线优先文献（无卷无页）靠「文章号指纹」而非卷页核验**：`_id_candidates` 对文章号做多形态归一（原串 / 去符号串 / 去 Wiley 式 `e` 前缀 / 纯数字——`e70188` ↔ `70188`），`_article_ids` 同时取 Crossref `message.article-number` 与 DOI 尾段；卷/页为空不再自动扣分。EMD20260066 实测 5 条无卷页文献经此收敛到 2 条误判（即 8、12 号），定向复核后确认 Crossref 实存
   - **v2.15.0 网络失败与"未检索到"区分（S3）**：查询网络失败（重试耗尽/异常）→ `status=error`（报告 4.3 单列「未能核验」，**非不可信**，建议重试）；只有确认无匹配记录才 `status=not_found`（不可信）。瞬时网络抖动不再制造虚假"不可信"结论。
   - **v2.15.0 响应缓存（P4）**：DOI 与标题查询结果按 TTL 7 天缓存于 `<skill>/cache/crossref_cache.json`，重跑/多稿件近零重复网络耗时。
2. **统一评分（DOI 命中确认与标题检索共用，满分 13，接受阈值 6 + 标题必要）**——权重排序 **标题 > 期刊 > 年份 > 作者名**：
   - 标题 token 重叠 ≥ 65%（v2.13.0 起 70%→65%，用户确认放宽；忽略大小写/标点，归一化后）→ **+6**
   - 期刊名匹配 → **+4**（评分用**纯字符串前缀匹配**：稿件期刊名每个单词是 Crossref 记录按序对应词的前缀/相等——"Rev" 与 "Revxxxx" 视为匹配，允许跳过 cr 中的介词词 of/the；双向；**无别名表、不判语义**）
   - 年份 |ref−cr| ≤ 1 → **+2**（±1 年视为匹配，非不可信）
   - 作者姓氏候选集合相交（宽松：允许缩写、姓名倒置、复姓取末词）→ **+1**
   - 标题为必要项（标题 0 分时即使期刊+年份+作者=7 也不接受）
   - **v2.20.0 标题内年份守卫（修一处误接受）**：`titles_match` 额外比对双方标题里的 4 位年份集合，**两边都有年份且无交集即判非同篇**。稿内引 IEA《Global EV Outlook **2024**》曾被匹配到 Crossref 的「多年份年度报告」记录（其标题带 2022 等旧年份）以 0.7 重叠被接受，守卫后改报 `issues_found`——**宁可诚实呈现"无法定位匹配版次"，也不冒充核验通过**。副作用须知：年度报告、标准、数据集等"每版标题只差年份"的文献会因此落入「需人工复核（已甄别）」而非「完全匹配」，属预期行为
   - **无篇名条目的 DOI 路径门槛（v2.20.0）**：`ref_title` 为空时把 `titles_match` 换成 `journals_match`，即 `doi_ok = 总分 ≥ 6 且 期刊名匹配`
3. **核对项（全部来源，DOI 非免检）**：
   - 标题（模糊匹配，忽略大小写/非字母符号差异）、年份、期刊名
   - **期刊核对 v2.15.0 起用 strict 匹配**（`journals_match(strict=True)`）：允许跳过停用词（of/the）与缩写展开（Chem. Mater. ↔ Chemistry of Materials），但**禁止跳过多余实词**——真实刊名差异（Nano Energy vs Nano Energy Letters、短刊名 Energy 匹配多刊）仍报 `journal_mismatch` 供人工复核；评分仍用宽松前缀匹配（v2.14.0 语义）
   - **v2.18.2 缩写形式刊名改走「顺序无关词覆盖 + 副题剥离」**：稿内使用 ISO 缩写时与 Crossref 全称既有**顺序**差异（`J. R. Stat. Soc. B` 把 `Series B` 压缩成 `B`），也有**多余/缺失**词（PNAS 全称省去 `USA`；`Eur. J. Popul` 全称带并列法文副题 `Revue européenne de Démographie`；JRSB 全称带副题 `Statistical Methodology`），原顺序消费式判定全部误报 `journal_mismatch`（CES 实测 7/30 条），与本节"期刊名允许缩写 → 非信息差异"的既有规则自相矛盾。现改为三重约束：① 仅当稿内刊名为**缩写形式**（含缩写点如 `Proc.`/`J.`、每词 ≤8 字母、≥2 词）才放宽；② 稿内未覆盖词只能是**短全大写限定词**（USA/UK）；③ Crossref **副题剥离后**（首个 `:` 或 `/` 之前）的内容词必须被稿内全覆盖。反向回归（仍必须报 `journal_mismatch`）：`Adv. Mater.` vs `Advanced Materials Interfaces`、`J. Mater. Chem. A` vs `…Chemistry B`、`Nano Energy` vs `Nano Energy Letters`、`Cell` vs `Cell Reports`。回归用例见 `work/` 下历史试验文件；改动须同步跑 `journals_match` 正反用例
   - **v2.18.2 标题比对支持 Crossref `subtitle`**：`get_crossref_title` 现拼接 `subtitle` 字段（Crossref 常把副标题单独存放），`titles_match` 增加按首个 `:` 截断的**单向**回退（覆盖"稿内只写主标题"的相反情形）——纯放宽，不会新增误报
   - **v2.14.0 差异只列差异部分**：`title_mismatch` 带词级差异片段（`title_diff`，只列差异词、相同内容省略，如 `title_mismatch: 稿内「…Buildings … Partially Beams」vs Crossref「…of Building … the Partial Beam-Column Reinforced Concrete」`）；`year_mismatch: ref=2024, crossref=2022`、`journal_mismatch: ref=…, crossref=…` 本身即只含差异，不再附加完整标题对比
4. **容差与不报规则（v2.10.0，延续）**：
   - **年份 |diff| ≤ 1** → 记入「信息差异」（非不可信，报告 4.3 由脚本自动渲染「信息差异（非不可信）」表）；**|diff| > 1** → `year_mismatch`（不可信因素）
   - **作者名**：允许缩写、姓名倒置、复姓 → 非信息差异、非不可信（不再产生 author_mismatch）
   - **标题**：允许大小写、非字母符号差异 → 非信息差异、非不可信
   - **期刊名**：允许缩写 → 非信息差异、非不可信
   - **卷期号、页码差异**：不作为信息差异或不可信信号（不再产生 volume/page mismatch）
   - 报告 4.3 只呈现：通过数汇总 +「信息差异（非不可信）」表 + 不一致/不可信问题表 + 人工复核明细（仅需复核项）

**礼貌池与并发**：请求通过 `mailto` 参数加入 Crossref 礼貌池（限速 10 req/s、并发上限 3），脚本以并发 3 执行，429/5xx 自动指数退避重试，避免限流误判 not_found。

**输入 JSON 格式**（增加字段）：
```json
{
  "index": 1,
  "title": "...",
  "authors": "Author1, Author2",
  "year": "2020",
  "journal": "Journal Name",
  "volume": "12",
  "page": "1234",
  "doi": "10.xxx/yyy"
}
```

#### 3.2 发表年份统计

**调用脚本**：
```bash
python scripts/crossref_check.py year-stats --refs <references_json_file>
```

输出按 5 年跨度的年份分布表格：
| 年份区间 | 数量 | 占比 |
|---|---|---|
| ≤2000 | N | X% |
| 2001-2005 | N | X% |
| 2006-2010 | N | X% |
| 2011-2015 | N | X% |
| 2016-2020 | N | X% |
| 2021-2025 | N | X% |
| ≥2026 | N | X% |

#### 3.3 Retraction Watch 撤稿检索

**调用脚本**：
```bash
python scripts/retraction_watch.py check-refs --refs <references_json_file>
```

匹配优先级：
1. **DOI 锚定优先**：参考文献的 `doi` 与撤稿库 `OriginalPaperDOI` 精确匹配（大小写不敏感）→ 最高置信（`match_type="doi"`, `confidence="high"`）。
2. **标题模糊匹配**：DOI 无命中时，用标题做 `token_sort_ratio` + `partial_ratio` 模糊匹配，**阈值 ≥ 90**，忽略大小写。命中项含 `match_type="title"`，`confidence` 为 `high`（≥95）或 `review`（90–95，需人工复核）。
3. **去噪过滤（共同单词数）**：标题字符数 > 3 的文献，若与撤稿库标题的共同单词数 ≤ 3（忽略大小写/标点），即使匹配分 100 也不报告——过滤「短标题子串」型误报（如撤稿库 1-3 词占位条目对长标题的 partial_ratio 高分命中，实测案例：EMD20260109 [115] 被单词条目 "Monitoring" 100 分命中）。实现见 `check_reference_titles` 内 `_common_word_count`。

**Agent 输出要求**：
- 命中的参考文献编号 + 标题 + 撤稿原因 + 匹配类型（doi/title）+ 置信度 + `retraction_doi`
- 如无命中，说明"0 篇参考文献存在撤稿记录"
- 如有命中，提示用户核实这些被撤稿文献是否影响本文论证（`confidence="review"` 的尤其需人工确认）

**Agent 综合输出结构**（报告章节编号为 4.x，见 Step 5）：
```
### 4.1 发表年份分布
[年份分布表格]

### 4.4 引用分布与著录问题（**v2.16.0 重编号：原 4.2；v2.14.0 起默认隐藏，非删除，需要时启用**）
- **默认不运行**：不执行 `citation_stats.py`、不写 `refs_citation_issues`/`citation_gaps` 字段 → 报告整节（含 h3 标题）不渲染。4.4 在末位，隐藏时 4.1 → 4.3 编号连续（v2.16.0 起不再跳号）
- **启用方式**：需要 4.4 时运行引用统计并填写这两个字段（见 Step 5 字段表），整节即渲染；旧数据 report_content.json 含字段时重渲染仍显示（向后兼容）
- 启用后内容：
  - 正文实际引用统计
  - **v2.20.0 前置检查——先确认引用标记形态**：正文若用**上标数字**标注（Word `w:vertAlign="superscript"`，纯文本提取后标记全丢），引用统计**不适用**，须跳过本子节并在 4.4 注明原因，**禁止**把 `citation_stats.py` 的 `not_applicable` 输出或全量 `uncited` 当成"文献未被引用"写入报告（EMD20260066 实测：上标式标记致 uncited = [1..116] 全量误报）
  - 未引用文献编号列表
  - 缺失 DOI 编号列表
  - ⚠️ **引用统计必须调用 `scripts/citation_stats.py`（v2.12.0 起禁止手写）**：对比方法表/实验设置表（如 "Detailed introduction of comparison methods"）常直接以 `[n]` 标注各方法出处（如 OpenMax[3]、[27]、[28]）。仅统计正文段落会漏掉这些引用、误报"文献未引用"。统计范围 = 正文段落（References 之前）+ 全部表格单元格（out_paras.json 已含表格文本）。同一文献在正文/表格多处引用属正常，**多次引用不计为问题、不报告**（v2.10.0）。脚本自动处理带空格逗号（`[49, 50]`、`[25, 29, 31, 38, 39]`）、**四种破折号**范围（hyphen `[2-5]`、en-dash `[5–7]`、em-dash、**U+2212 数学减号 `[1,16−18]`**，v2.19.2 补全）并**区间展开**（详见「运行环境陷阱」——EMD 曾因只 split 不展开误报 57 篇未引用；ECM 曾因字符类缺 U+2212 误报 [16][18] 未引用）。
  - **v2.11.0 起不写「著录不完整条目」段**（缺作者/期刊/卷页、作者缩写异常等转 `refs_verify.incomplete`，渲染到 4.2 差异明细表）
  - **4.4 末尾输出引用空洞检查**：是否有"研究表明…"类无具体出处的断言（v2.11.0 起由 AIGC 节移入；`citation_gaps` 字段渲染时自动加「引用空洞检查」加粗前缀）

### 4.2 Crossref 真实性验证
- **汇总表**（脚本自动，4 档：完全匹配/微小差异/差异较大/无法定位，含数量+占比；配色 绿/黄/黄/红）
- 核心结论段（agent 在 `refs_verify.summary` 写，结论性语言、不含文献编号）
  - **结论段的计数口径须与汇总表逐档对齐（v2.18.3）**：汇总表 4 档名（完全匹配/微小差异/差异较大/无法定位）是**档位名**，结论段与「1 检测结论摘要」要点**禁止用「N 篇与 Crossref 记录完全匹配」这类说法去描述跨档总数**——曾出现结论段写「27 篇完全匹配」而汇总表「完全匹配」档只有 24 篇（另 3 篇是年份差 1 年）的自相矛盾。正确写法是**逐档列数并保证合计 = 文献总数**，如「24 篇与 Crossref 记录逐项一致，3 篇仅年份相差 1 年；1 篇年份相差 5 年，2 篇为 Crossref 未收录的非期刊文献」；档位名仅在需要对照汇总表时可加引号直接引用
- **差异明细表**（脚本自动，3 列：文献编号/差异说明/风险度徽章；差异说明为**具体对比、不含分值**）
  - **逐条在前**（v2.12.0）：仅差异较大（issues_found）→ **需人工复核**（黄）、无法定位（not_found）→ **不可信**（红）
  - **人工甄别注记 review_note（v2.18.1）**：agent 对差异/未定位条目做定向复核后（如按期刊 ISSN 查 Crossref 确认「该刊/该年代文章未收录 = 收录盲区」，或确认 Crossref 实已定位同题记录仅刊名著录形式不同），在 `work/<稿件标识>/crossref.json` 对应条目的 `review_note` 字段写入甄别结论（如 `未在 Crossref 定位到匹配记录。已按 ISSN(...) 定向复核：该刊文章未收录于 Crossref（收录盲区），非检索失败；需人工经期刊官网核实`）——渲染时差异说明改用注记文案，**not_found 风险度由「不可信」（红）降为「需人工复核」（黄）**。依据「检测不到 ≠ 不存在」原则（中文期刊大量未入 Crossref，绝不因检索不到直接判编造）；甄别注记本身需附证据（ISSN/检索范围）
  - **4 档汇总表须与明细表口径一致（v2.18.2）**：有 `review_note` 的 not_found 条目在汇总表单列「需人工复核（已甄别）」（黄），不再计入「无法定位」（红）——否则会出现"汇总表标红不可信 / 明细表标黄需复核"的自相矛盾
  - **年份差 1 年合并行**（v2.12.0）：微小差异（verified 且有 info，如年份差 1 年）**不再逐条**，所有文献号合并为一行，差异说明固定「年份相差1年」，风险度**低风险**（黄）
  - **著录不完整（`refs_verify.incomplete`）合并为一行置尾**（v2.11.1）：所有文献号 + 问题按类型归组（如 `缺页码（4、23、25、26）；缺作者与期刊名（16、18）`），风险度需人工复核（黄）；不影响可信度
  - 同一文献既在年份合并行又在著录不完整合并行时两处都列（如 [16]）
  - not_found 有候选：显示"最接近候选 + 差异较大"；无候选：显示"未在 Crossref 定位到匹配记录（稿内标题）"
- 通过类甄别（作者姓名表达差异、起页一致仅格式差异等）一律不报告

### 4.3 Retraction Watch 撤稿检索
[命中结果或"0 命中"]
```

---

### Step 4: 检查4 — AIGC 检测

**输入**：论文全文文本（正文）

**方法（脚本算指标 + agent 判级）**：

1. **定量指标由脚本计算**（确定性、可复现，避免 agent 手算慢且易错）：
   ```bash
   python scripts/aigc_stats.py <全文文本文件>
   ```
   输出 JSON（stdout）：`word_count` / `sentence_count` / `avg_sentence_len` / `sentence_len_cv` / `ttr` / `ai_phrase_total` / `ai_phrase_strong_total` / `ai_phrase_weak_total` / `ai_phrase_density_per_1000` / `ai_phrases`（短语逐项计数）/ `ai_phrases_strong` / `ai_phrases_weak` / `first_person_count` / `near_duplicate_pairs`。脚本自动排除 References 节（独立行标题 / 带编号标题 / 回退首个 `[N]` 文献行）。
   **v2.15.0 计数与密度口径（P0-1/P1-3）**：提示语按**词边界正则**（`\b…\b`，忽略大小写）计数——"significantly" 不再吞并 "significant"（原 `.count()` 子串匹配会重复计数、密度被放大）；短语分**强/弱两档**——强 AI 标记（delve into / it is noteworthy that / underscores / pivotal role / intricate / meticulous / taken together）**×2 加权**，弱标记（overall / furthermore / moreover / in conclusion / significant 等学术高频过渡词）×1；`ai_phrase_density_per_1000` 为**加权密度**。
   **输出必须落盘**：`python scripts/aigc_stats.py <全文文本> > work/<稿件标识>/aigc.json 2> work/<稿件标识>/aigc.log`（Step 5 渲染脚本据此自动生成 AIGC 定量指标表）。

2. **agent 定性分析**（脚本无法替代的部分）：
   - **综合判级**：基于脚本指标做判断——**AI 提示语加权密度 >3/千词 可疑、>8/千词 高度可疑**（v2.15.0 重标定，配合词边界+强词×2 加权；原 >2/>5 按子串计数口径，正常学术文本易误触）；**句长 CV <0.3 = 句子长度趋同 = AI 特征**（v2.15.0 修正方向——原 "CV>0.7 异常均匀" 与统计原理相反：CV 高实为句子参差、人类特征，会反向产出错误 AI 信号）；首人称完全缺失为附加信号；命中短语是否含**强 AI 特征词**（delve into / underscores / pivotal role / intricate / meticulous / it is noteworthy that 等）
   - 结合学科特点权衡（如材料类论文 "significantly" 高发常见于非母语作者，已按弱词 ×1 降权），给出 `未见痕迹` / `轻度可疑` / `高度可疑`
   - （引用空洞检查自 v2.11.0 起移入 Step 3 参考文献检测 4.4 节末尾，AIGC 节不再包含）

**输出要求**：
- 定量指标表格（词数、句数、平均句长、句长变异系数、TTR、AI 提示语密度、首人称次数、近重复句数）——直接取脚本 JSON 填表
- 命中 AI 提示语的具体列表（脚本 `ai_phrases` 字段）
- 综合判断：`未见痕迹` / `轻度可疑` / `高度可疑`
- 附注：此为启发式筛查，非确定性判定，建议配合专业 AIGC 检测工具交叉验证
- （引用空洞检查结果自 v2.11.0 起由 `citation_gaps` 字段承载、渲染到 4.4 节末尾，AIGC 节不输出）

---

### Step 5: 生成 HTML 报告

**流程（固定渲染脚本模式）**：
1. 各检测脚本结果已按「落盘约定」写入 `<skill>/work/<稿件标识>/`（含 `aigc.json`）；
2. Agent 完成各维度**判定**（内容相关性结论、机构适配结论、引用分布、Crossref 人工甄别、AIGC 综合判级、处理建议等），写入 `work/<稿件标识>/report_content.json`（字段见下；只放判定内容，数据表格由脚本自动生成）；
3. 运行渲染脚本：
   ```bash
   python scripts/gen_report.py --work work/<稿件标识> --content work/<稿件标识>/report_content.json --out <输出目录> --msid <稿件标识>
   ```
   - **输出目录（v2.24.1 澄清规则优先级）**：**默认且必须输出到「输入稿件文件所在目录」**（见本节末「报告保存位置与数据来源标注」——该条自 v2.1.0 起为硬规则，`--out` 不可硬编码、也不可擅自改指他处）。
     - ⚠️ **v2.15.0 F-05「建议输出到隔离目录」与上条冲突，v2.24.1 起判定为：仅在用户明确要求时才采用隔离目录**（如稿件目录处于云同步/共享盘、或用户主动提出）。**Agent 不得仅凭该「建议」自行改变输出位置**——EMD20260069 曾因此把报告写到工作区 `outputs/` 而非稿件目录。
     - 采用隔离目录时，须在交付时明确告知用户报告的**实际路径**，并说明未随稿归档的原因；
     - 无论输出到何处，报告含作者等个人信息与撤稿记录（负面属性），**仅限编辑部内部使用、勿对外公开或跨境传播**；若需随稿件归档，交付后按留存期限清理 work/ 与临时文件；
   - 脚本读取 work 检测 JSON + report_content.json + `references/report_template.html` → 输出 HTML；
   - stdout 为一行机器可读 JSON：`{"status":"ok"|"warn"|"error","out_file","size","leftover"}`；`status=error` 时按 stderr 提示修复；`status=warn` 表示有残留占位符（`leftover` 列出），需检查 report_content 字段；
   - **v2.15.0（F-01）所有稿件/撤稿库/journal_scopes 动态值经 HTML 转义后注入**（含稿件标题/作者/机构/参考文献标题、撤稿库作者/标题/撤稿原因、scope URL——URL 仅作文本显示且先校验 https）；报告模板含 CSP + nosniff；**任何新增动态内容渲染时必须经过转义，禁止直接拼接**；
   - 自动生成的数据表格：稿件基本信息中「参考文献/撤稿数据库版本/检测工具(含生成日期)」、政治风险（`geo.json`）、作者撤稿检索表（`authors.json`）、发表年份分布（`refs.json`）、撤稿检索（`refs_rw.json`）、AIGC 定量指标表与提示语明细（`aigc.json`）、第 2 节起始「期刊收稿范围对照依据」块（`assets/journal_scopes.json`）。

**report_content.json 字段说明**（`schema_version: 1`；徽章用 `{"badge":"ok|warn|bad|info","verdict":"文案"}` 表达，脚本渲染徽章 HTML）：

| 字段 | 必填 | 说明 |
|---|---|---|
| `meta.manuscript_id/title/authors/affiliations/journal/manuscript_type/files` | 是 | 稿件基本信息 7 字段（机构用中文：学校+学院） |
| `manuscript_domain` | 否 | 稿件领域短语（如 `锂硫电池材料`），供作者撤稿说明自动生成 |
| `summary.relevance/author/refs/aigc` | 是 | 摘要表 ①-④ 行，各 `{badge, verdict, text}`；`verdict`=仅风险徽章文案（无风险/低风险/需修改/需修订），`text`=「要点」列全文（须以判定短语开头，如 `高度相关，…`）；未检测时 `{badge:"info", verdict:"未检测", text:"原因"}`。**v2.11.0 起 text 只写汇总数据**——禁止出现作者名、撤稿数据库版本、具体机构名、文献编号、AIGC 特征词汇（如 comprehensive×6）等细节 |
| `scope_analysis` | 是 | 第 2 节内容相关性 4 列表格数据 `[{dimension, paper_feature, journal_area, match:{badge, text}}]`（分析维度/稿件特征/对应期刊领域/匹配度徽章；脚本渲染 `{{SCOPE_ANALYSIS_TABLE}}`）；第 2 节起始的「来源+版本日期+中文概括」由脚本从 `assets/journal_scopes.json` 自动渲染（`{{SCOPE_HEADER}}`），agent 无需手写 |
| `affiliation_analysis` | 是 | 3.2 节机构适配 3 列表格数据 `[{org, basis, fit:{badge, text}}]`（机构/判断依据/适配度徽章，一行一个机构；脚本渲染 `{{AFFILIATION_TABLE}}`） |
| `author_verdicts` | 否 | **v2.19.0**：3.1 节作者撤稿表的**逐作者文案覆盖**，`{"<作者名>": {"badge":"warn","conclusion":"同名且领域相近","note":"…"}}`。**仅用于档 3（命中项机构/学科与本稿相同或相近）**——不写则用脚本默认档 2 文案「领域均非本稿相关，基本判定为同名误报」，会把需重点核实渲染成已排除风险（机制同 crossref 的 `review_note`）；`note` 须含 `retraction_doi`、撤稿日期、原因、机构/主题比对依据 |
| `refs_citation_issues` | 否 | 4.4 节引用分布与著录问题（**HTML，v2.20.1 起渲染为「先整串转义、再放行无属性白名单标签 `p/b/strong/em/i/br/ul/ol/li`」**——v2.15.0 的全局转义曾把本字段整串转义、报告里出现可见的 `&lt;p&gt;`，属文档/代码漂移，已修；v2.16.0 重编号：原 4.2）；**v2.14.0 起默认隐藏**——不写该字段（且不写 citation_gaps）→ 4.4 整节不渲染；需要时填写启用；**v2.11.0 起不再含「著录不完整条目」段**（著录信息转 `refs_verify.incomplete`，渲染到 4.2 差异明细表） |
| `citation_gaps` | 否 | 引用空洞检查结果（**纯文本；脚本自动加「引用空洞检查」加粗前缀并包 `<p>`，故本字段不要自带 `<p>` 外层**——否则会产生嵌套 `<p>`；v2.11.0 起由 AIGC 节移入）；与 refs_citation_issues 同受 v2.14.0 默认隐藏规则约束 |
| `refs_verify.summary` | 是 | 4.2 节核心结论段落（v2.16.0 重编号：原 4.3；**v2.10.1 起**写"0 篇虚构/编造文献，100% 参考文献为真实存在"等结论性语言，不含具体文献编号、不含误报甄别过程描述） |
| `refs_verify.issues` | 否 | **v2.10.1 起不再使用**（差异明细表由脚本自动从 crossref.json 渲染，无需 agent 手写） |
| `refs_verify.manual` | 否 | **v2.10.1 起不再使用**（人工复核明细列表已移除，agent 不再写该字段） |
| `refs_verify.incomplete` | 否 | **v2.11.0 新增 / v2.11.1 合并行渲染**：著录不完整条目 `[{ref, issue}]`；issue 用规范词（缺页码 / 缺作者与期刊名 / 作者名缩写异常等），脚本按规范词归组合并为**一行**（所有文献号 + 问题汇总，如 `缺页码（4、23、25、26）；缺作者与期刊名（16、18）`）置差异明细表末尾，风险度"需人工复核"（黄）；括号尾注（如"（Crossref 已验证通过）"）会被脚本剥离 |
| `refs_rw.verdicts` / `refs_rw.note` | 否 | 4.3 节每条匹配的判定（如 `误报`）与表下说明 |
| `year_stats_note` | 否 | 4.1 节年份表下总体评价（**v2.11.0 起只写一句总体评价**，如"文献发表年份集中于近十年，引用时效性良好"，不含逐档具体数据；脚本渲染为加粗 `<p><b>…</b></p>`） |
| `aigc_judgments` | 否 | AIGC 指标表「判断」列覆盖 `{metric: 文案}`（未覆盖行由脚本阈值规则自动算）。**键名以英文指标名为准**（`avg_sentence_len` / `sentence_len_cv` / `ttr` / `ai_phrase_density_per_1000` / `first_person_count` / `near_duplicate_pairs`）；v2.21.0 起**同时接受报告显示的中文指标名**（如「句长变异系数」）——此前只认英文键，按中文名书写会被静默忽略、覆盖不生效（EMD20260067 实测） |
| `aigc_note` | 是 | AIGC 节综合判断段（脚本自动在其前加「命中提示语明细」行）；**v2.11.0 起不再含引用空洞检查** |
| `rw_timeout_note` | 否 | RW 数据下载异常提示（默认空） |

**报告结构**（主节编号为「数字+空格+标题」无点号，子节为「x.y 标题」）：
```
# 稿件技术检查报告 · [稿件编号或标题摘要]

[稿件基本信息]：不编号、小号字（meta div，font-size 13px），9 字段固定顺序：
  文件名 / 期刊全名 / 标题 / 作者 / 机构（中文：中国=学校+学院，国外=国名+学校+学院，不含省市街道邮编） / 类型 / 参考文献 / 撤稿数据库版本 / 检测工具（含生成日期）

[0 政治风险]：仅命中 Taiwan/Tibet/Xizang 时显示，位于稿件基本信息之后；
  红色小字 + 表格（关键词 / 完整句子 / 所属一级标题）；未命中不显示（{{POLITICAL_RISK}} 填空串）

## 1 检测结论摘要    —— 合并摘要表（检测维度 | 结论 | 要点；结论列=仅风险徽章，未检测维度显示灰「未检测」；要点列只写汇总数据）；**v2.11.0 起无结论区（{{CONCLUSION}} 已移除）**
## 2 内容相关性
## 3 作者诚信检测
##   3.1 作者撤稿检索
##   3.2 作者机构与论文领域适配性
## 4 参考文献可靠性检测
##   4.1 发表年份分布（表下总体评价一句，加粗）
##   4.4 引用分布与著录（**v2.16.0 重编号：原 4.2；v2.14.0 默认隐藏**：report_content 缺 refs_citation_issues/citation_gaps 时整节不渲染，4.4 在末位、隐藏时 4.1→4.3 编号连续；启用时含引用空洞检查；不含「著录不完整条目」）
##   4.2 Crossref 真实性验证（4 档汇总表 + 差异明细表：真实性差异 + 著录不完整三类合并，文献编号/差异说明/风险度）
##   4.3 Retraction Watch 撤稿检索
## 7 AIGC 生成痕迹检测    （无第 5、6 节，编号直接跳 7，与已出版 skill 保持一致）
```

**样式对齐参考**：
- 蓝色主色调（`#2c6fbb` header border, `#1a4f8a` h2）
- 彩色 badge：`.ok` (绿) / `.warn` (黄) / `.bad` (红)
- `.meta` 信息块（灰底圆角，稿件基本信息为不编号 13px 小号字）、`.note` 提示块（黄底左边框）、`.mono` 代码块
- 所有数据以表格呈现

**模板占位符说明**（标注填充来源：`[脚本自动]` = gen_report.py 从检测 JSON 自动生成；`[report_content]` = 来自 report_content.json）：
- `{{MANUSCRIPT_ID}}` / `{{FILES}}` / `{{JOURNAL}}` / `{{TITLE}}` / `{{AUTHORS}}` / `{{AFFILIATIONS}}` / `{{MANUSCRIPT_TYPE}}` — `[report_content]` meta 字段
- `{{REFS_COUNT}}` — `[脚本自动]` 参考文献数量（refs.json）
- `{{RW_UPDATE_DATE}}` — `[脚本自动]` Retraction Watch 数据 `update_date`
- `{{TOOL_NAME}}` — `[脚本自动]` 脚本常量 "熊猫找茬-新稿 v2.20.0"（模板在该字段后追加 `，生成日期：{{REPORT_DATE}}`）
- `{{REPORT_DATE}}` — `[脚本自动]` 生成时间
- `{{POLITICAL_RISK}}` — `[脚本自动]` geo.json 命中时红字+表格；未命中空
- `{{SUMMARY_RELEVANCE_BADGE}}` / `{{SUMMARY_AUTHOR_BADGE}}` / `{{SUMMARY_REFS_BADGE}}` / `{{SUMMARY_AIGC_BADGE}}` — `[report_content]` summary.*.verdict 渲染为**仅风险徽章**（如 `<span class="badge ok">无风险</span>`）；未检测维度显示 `<span class="badge info">未检测</span>`
- `{{SUMMARY_RELEVANCE}}` / `{{SUMMARY_AUTHOR}}` / `{{SUMMARY_REFS}}` / `{{SUMMARY_AIGC}}` — `[report_content]` summary.*.text（「要点」列，判定短语开头；只写汇总数据，无作者名/DB 版本/机构名/文献编号/AIGC 特征词）
- `{{SCOPE_HEADER}}` — `[脚本自动]` 第 2 节起始固定块（**纯文本段落**：来源 URL + 版本日期 + 概括性中文收稿范围，读 `assets/journal_scopes.json` 的 scope_source/scope_version_date/scope_summary_zh；期刊未收录时降级提示）
- `{{SCOPE_ANALYSIS_TABLE}}` — `[report_content]` scope_analysis 4 列表格（分析维度/稿件特征/对应期刊领域/匹配度徽章）
- `{{RW_TIMEOUT_NOTE}}` — `[report_content]` rw_timeout_note（默认空）
- `{{AUTHOR_RESULTS}}` — `[脚本自动]` authors.json 逐作者撤稿表（作者/命中数/结论/说明；v2.9.0 起无「检索方法」「受检作者」说明；**v2.19.0 起档 3 作者的结论/说明由 `[report_content]` `author_verdicts` 覆盖**，未覆盖者用默认档 2 文案）
- `{{AFFILIATION_TABLE}}` — `[report_content]` affiliation_analysis 3 列表格（机构/判断依据/适配度徽章，一行一个机构）
- `{{REFS_YEAR_STATS_TABLE}}` — `[脚本自动]` refs.json 年份分桶表 + `[report_content]` year_stats_note（总体评价一句，脚本加粗 `<p><b>`）
- `{{REFS_CITATION_SECTION}}` — `[脚本自动]` 4.4 引用分布与著录**整节**（v2.14.0：report_content 缺 refs_citation_issues 且缺 citation_gaps → 返回空串整节隐藏；写任一字段 → 渲染 h3 标题 + 引用统计内容 + 引用空洞检查加粗前缀；**v2.20.1：占位符位于 `{{REFS_RETRACTION_CHECK}}` 之后**，使节号 4.1→4.4 升序，与「4.4 在末位」表述一致）
- `{{REFS_VERIFY_RESULTS}}` — `[脚本自动]` 4.2 节：summary 段落（agent 写核心结论）+ 4 档汇总表（完全匹配/微小差异/差异较大/无法定位）+ 差异明细表（逐条：差异较大需人工复核/无法定位不可信；年份差 1 年合并行：低风险；著录不完整合并行置尾：需人工复核；3 列：文献编号/差异说明/风险度徽章；差异说明为具体对比，无分值）
- `{{REFS_RETRACTION_CHECK}}` — `[脚本自动]` refs_rw.json matches（空→"0 命中"；非空→表）+ `[report_content]` refs_rw.verdicts/note
- `{{AIGC_TABLE}}` — `[脚本自动]` aigc.json 8 指标行（参考区间/判断=脚本内置，可被 aigc_judgments 覆盖）
- `{{AIGC_NOTE}}` — `[脚本自动]` ai_phrases 明细 + `[report_content]` aigc_note（不含引用空洞检查）

**脚本编码注意**：report_content.json 中的 HTML 字符串字段若含 ASCII 双引号须 `\"` 转义；建议一律用**中文引号**（`"..."`）避免转义混乱（已踩坑 3 次：EMD20260053「pivotal role」、CESCI-D-26-00011「construction industry」、CESCI-m26-00013「Allergic Bronchopulmonary Aspergillosis」）。

报告文件名格式：`manuscript_integrity_check_report_[YYMMDD]_[稿件标识].html`

**报告保存位置与数据来源标注**：
- 报告保存到**输入稿件文件所在的目录**（与 Word/PDF 输入文件同目录），运行 `gen_report.py` 时通过 `--out` 传入该目录，不可硬编码。
  - **⚠️ 本规则为默认硬规则（自 v2.1.0 起）。** Step 5 中 v2.15.0 F-05 的「建议输出到隔离目录」**与之冲突**，v2.24.1 起明确：**仅当用户明确要求时才改用隔离目录**，agent 不得自行改变输出位置；改用时须向用户告知实际路径。两处规则已互相交叉引用，**读到任一条都必须同时看另一条**。
- 报告须注明本次撤稿检测所依据的 Retraction Watch 数据更新时间：读取 `data/retraction_watch_meta.json` 的 `update_date`（数据源端数据集日期），填入稿件基本信息「撤稿数据库版本」字段（`{{RW_UPDATE_DATE}}`）。该日期由该字段承载，正文不再重复注明。

---

## 下载与更新判定（retraction_watch.csv）

- 由 `scripts/download_retraction_watch.py` 统一负责下载、新鲜度判定、完整性校验与重试；`scripts/retraction_watch.py` 的 `ensure_csv` 直接委托该脚本，避免逻辑分散。
- **两步判定（降低下载频率、减少联网）**：
  - **无条件下载**：`--force`；或 **CSV 不存在**（无可检测数据）。
  - **第 1 步（本地快筛，纯本地、不联网）**：以本地 `update_date`（数据版本日期）为基准，缺失/解析失败回退 CSV 文件 mtime；**版本日期距今 < 3 天 → 直接复用本地文件，不发任何网络请求**（因源端日期 ≤ 今天，差异必然 < 3 天，不可能触发下载）。未命中则进入第 2 步。
  - **第 2 步（联网精确判定，仅版本日期距今 ≥ 3 天时执行）**：通过 GitLab Commits API 查询 `retraction_watch.csv` 最近一次提交的日期（即**数据源端更新日期**），与本地版本日期比对：**`(gitlab_date - 本地版本日期) > 3 天` 才重新下载**；≤ 3 天 → 复用本地。
    - 该 API 仅返回几 KB JSON，**不是** 62MB CSV，开销极小。
    - **GitLab API 不可达 → 回退保守下载一次**（保证不因查不到源头而用旧数据），`update_date` 记录为旧基线或今天。
- 下载后完整性校验：字节数 **≥ 50MB** 且 行数 **≥ 55000**（v2.15.0 起 50000→55000，约 91% 完整度下限，减少漏检近 1 万条撤稿记录的可能），否则视为**不完整**。
- 失败/不完整时重试：**最多 3 次、指数退避**；先写 **唯一化临时文件**（`.tmp` 带 pid，v2.15.0 起——并行触发下载时互不覆盖），校验通过才 `os.replace` 原子覆盖正式 CSV。
- **v2.15.0（F-04）数据完整性记录**：下载后计算 SHA256 与源端 commit SHA 一并写入 `retraction_watch_meta.json`（`sha256` / `commit_sha` 字段），供审计比对——比对历史 sha256 可发现数据被篡改；GitLab Commits API 不可达时 commit_sha 记空。
- 重试耗尽仍不完整：若本地已有完整 CSV 则**保留上一版并继续检测**（source 标注 `download incomplete, kept previous version`）；仅当本地无任何 CSV 时才返回 `download_failed`（此时撤稿检测无法正常进行）。
- 下载使用标准库 `urllib` 并显式带 `User-Agent`，规避 GitLab raw 的 302 跳转与默认 UA 的 403（v2.15.0 起 UA 统一为 `panda-ms-check/2.15.0`，跨脚本一致）。
- 强制重新下载（手动刷新）：`python scripts/download_retraction_watch.py --force` 或 `python scripts/retraction_watch.py download`。
- **并发注意（CRITICAL）**：RW 数据准备（版本检查 + 判断 + 下载）须作为**前置步骤串行执行一次**（`python scripts/download_retraction_watch.py`），确保 CSV 就绪且 FRESH 快筛命中后，`check-authors` 与 `check-refs` **方可并行执行**（此时仅只读 CSV，不再触发下载）；**严禁在数据未就绪或可能触发下载时并行**运行两个 RW 查询（v2.15.0 已加 tmp 唯一化缓解，但串行纪律仍是首选）。
- 报告中撤稿相关部分按 `csv_source` 标识提示：
  - 含 `download_timeout` / `download_failed` → 标记为 "⚠ 未执行 — 撤稿数据下载失败/超时"，并提示用户从 https://gitlab.com/crossref/retraction-watch-data 手动下载；
  - 含 `incomplete` → 标注"Retraction Watch 数据最近一次更新下载不完整，已保留上一版完整数据，结果仅供参考"，建议稍后重跑或人工经 retractiondatabase.org 复核。
- 其他三项检测（内容相关性 / Crossref 验证 / AIGC）不受影响，正常完成。

## Data Safety

- `retraction_watch.csv` 存储在**本 skill 目录下** `<skill>/data/retraction_watch.csv`（首次运行自动从旧位置 `~/.workbuddy/data` 迁移，成功后旧文件删除，避免双份）
- `retraction_watch_meta.json` 存储在同目录 `<skill>/data/retraction_watch_meta.json`，字段：`update_date`（**数据源端数据集日期**，来自 GitLab Commits API；用作第 1 步快筛基准与源端比对基线；不可达/首次时回退为本地日期）、`downloaded_at`（精确 ISO 时间戳，供溯源）、`bytes`（下载字节数）、`rows`（数据行数）、`source`、`commit_sha`（源端 commit 指纹，v2.15.0）、`sha256`（本地文件哈希，v2.15.0，比对历史可发现篡改）
- **期刊记录双层数据源（v2.17.0）**：`assets/journal_scopes.json` 为**用户文件**（个人积累的期刊缩写-全称-网页记录；**禁止进分享包、升级永不覆盖**，见打包规范）；`assets/journal_scopes_template.json` 为**内置模板**（进分享包、随版本更新，含官方内置期刊记录）；读取统一走 `scripts/journal_scopes.py` 的 `load_all()` = **模板 ∪ 用户合并、同缩写冲突时用户优先**（内容一致静默；同缩写不同全称才提示）；用户文件缺失时首次运行自动从模板初始化；`save_scope()` 只写用户文件
- Crossref API 通过 `mailto` 参数加入礼貌池（10 req/s、并发 3），脚本以并发 3 执行，429/5xx 自动指数退避；`mailto` 可用环境变量 `PANDA_MAILTO` 覆盖为编辑部真实邮箱（便于服务端归因），附 `User-Agent: panda-ms-check/2.15.0` header
- **scope URL 安全（v2.15.0 F-02）**：`preflight.py` 对 `--scope-url` 做 SSRF 防护——仅允许 https；解析主机后拒绝私有/环路/链路本地/保留地址（10./172.16-31./192.168./127./169.254.169.254/::1 等）；`allow_redirects=False` 防外站 302 跳内网。
- **docx 安全解析（v2.15.0 F-06）**：`extract_docx.py` / `preflight.py` 用 defusedxml 解析（防 billion-laughs 实体膨胀），zip 成员数（≤1000）与 document.xml 解压大小（≤50MB）设上限（防 zip 炸弹）。
- **个人信息留存（v2.15.0 F-05）**：稿件作者、被引作者、撤稿记录（负面属性）属个人信息，处理遵循**目的限定 + 最小必要 + 限期留存**：检测完成后 `work/<稿件标识>/` 与临时文件按编辑部留存政策清理（建议完成归档后 30 天内）；报告默认输出隔离目录；报告头/尾含「含个人信息，勿随意传播」提示；若后续将报告上传至境外合作方/系统，须另行评估个人信息跨境传输义务。
- **PIPL 澄清**：本 skill 是**从境外 GitLab 镜像下载**公开撤稿数据（数据入境），**不构成** PIPL 第 38-40 条"个人信息出境"义务；合规重心在"处理"环节（存储期限、最小必要、敏感属性最小化），现有「signal not verdict」框架已对齐。
- 不做任何 paywall 绕过或爬虫行为

---

## 版本与变更记录

| 版本 | 日期 | 变更 |
|---|---|---|
| v2.30.1 | 2026-11-17 | **修复 Elsevier 编号式（作者以逗号分隔、无句点收尾）三处静默解析缺陷 + Crossref 标题「下标被沉积成空格」误判（EMD20260096 实测驱动，135 条全部 verified 由 123 提升）**。**① 作者名正则挡不住两类合法写法 → 整段作者列表被并入 `title`**：`parse_refs.py` 的 `AUTHOR_RE` 要求首字母缩写簇形如 `[A-Z][A-Z.\-]*\.`，且姓的字符类只到 U+024F。实测两类写法使其在**首个作者段即失配**，`in_title` 提前置真 → 该作者之后的全部作者 + 标题被 `' '.join` 压成无逗号的 `title`（`authors` 为空）→ Crossref 拿这串"作者+标题"去比对，必然 `title_mismatch` + `doi_low_score`（本稿 9 条：38/41/51/54/57/60/77/81/99/126）：(a) **组合附加符号**——PDF/EndNote 把 `ç/å/Č/ó` 存成「基字母 + U+0300–U+036F 组合符」（`Koç` / `Sångeland` / `Černe` / `López`），属"重音字母"但不落在 `\u00C0-\u024F`；(b) **缩写簇含小写**——EndNote 把「Jin-Cheng」类名字导成 `J.i.` / `J.-c.` / `J.r.` / `J.-s.`。修复：姓的字符类补 `\u0300-\u036F`（并拆成"首字符 / 后续字符"两个类，使组合符可跟在基字母后）；缩写簇改 `_INIT = [A-Z][A-Z]*(?:[.\-]+[A-Za-z])*\.`（允许小写、允许 `.-` 连续分隔）。**姓仍须以大写起首且 ≥2 字符**，标题片段（`Toward Optimization…` / `Metal-organic frameworks`）不受影响。**② "卷期缺失"占位符滞留刊名**：Elsevier 在线优先条目写作 `Advanced Materials Interfaces n/a(n/a) (2025) e00705` / `… n/a(n/a)  e5372994`，`n/a(n/a)` 被并入 `journal`、`volume` 判空 → strict 刊名核对必败 → `journal_mismatch` 假警（[48][129]）。`ref_common.clean_journal` 新增规则：剥尾部 `n/a` / `n/a(n/a)`（**只认含斜杠的占位写法**，避免误删真实刊名末词）。**③ Crossref 侧化学式下标被"沉积成空格"**：`_title_variants` 的 A/B 两变体只处理 Crossref 带 `<sub>` 标签的情形；而 Elsevier 等出版方常直接沉积成 `TiS 2 /Li-In` … `Li 10 GeP 2 S 12`（**无标签、纯空格**），两侧分词不一致 → 实质相同的标题被判 `title_mismatch`（[62]）。新增**变体 C（化式紧贴式）**：在 B 之上删去「字母↔数字」之间的空白（`(?<=[a-z])\s+(?=\d)` 与反向各一遍），两侧同法处理后精确对齐。**④ A/B 回归**：解析层（`git` 快照基线 vs 修改版，42 份历史稿件逐条对照条目数/策略/字段）——**40 份零变化**，本稿 135 条上 28 处字段改进、`EMD20260072` [68] 由「作者并入标题」改为正确切分（`M.B.a.K. Huang` → 作者），**无一例回归**；标题比对层（用历史 `crossref.json` 已存的 `crossref_title` 做零网络全量重算，**3495 组比对：3492 组一致、3 组 False→True、0 组 True→False**），3 组翻转均经人工核对为**同一篇**（本稿 [51][62]，EMD20260056 [13] 的 `CO\n<sub>2</sub>` 跨行式）。**⑤ TOOL_NAME/config/frontmatter 升 v2.30.1**。**本稿实战结论**：内容相关性 **高度相关**（固态锂电池层状电解质的跨层 Li+ 传输、界面演化与设计，直接落于 Batteries，且属本刊接受的 Review 类型）；作者 3 位——2 位 0 命中，Hao Liu 30 条同名命中（环境地球化学/肿瘤医学/海洋/体育/经济金融，机构含中国地质大学、蚌埠医学院、宁波大学等），**无一条为北京大学深圳研究生院、无一条涉电池或电解质主题 → 档 2 同名误报**（已用 `author_verdicts` 写明证据）；机构（北京大学深圳研究生院新材料学院）与稿件领域**适配**；参考文献 135 条——**127 条逐项一致、8 条仅年份差 1 年（在线首发年 vs 正式卷期年）、0 条无法定位、0 条撤稿、0 条伪造**；正文（含表格）引用覆盖 [1]–[135]，**0 条未引用、0 条越界**；3 条在线优先文献卷期/页码未著录齐全（[48][122][129]，均有 DOI）；AIGC **未见明显痕迹**（加权密度 1.20/千词且全为弱词 overall、强特征 0、句长变异系数 0.573、首人称 1、近重复 0）。 |
| v2.30.0 | 2026-11-17 | **新增第 14 策略 `numbered_jv`（编号式「期刊. 年, 卷(期), 页」）+ 修复 Crossref 标题「跨行下标富文本」致真文献误判 `not_found`（EMD20260093 实测驱动，两处均为静默失败）**。**① 缺策略（第三类静默失败：满分/高分假象下的系统性列错位）**：本稿 104 条为 EndNote 导出的**逗号作者**编号式 `[n] Surname, A. B., Surname, C. D. 标题. 期刊. 年, 卷(期), 页.`。`acs` 以 **0.96** 分被自动选中，但 `acs` 的刊名提取要求「刊名直接接年份」——本格式刊名与年份之间**多一个句点**（`Nature chemistry. 2015,`）→ 右起第一个词 `chemistry.` 被当成「标题末词」→ **刊名整段放弃**；且 `acs` 按 `;` 消费作者 → 只切出第一位作者，其余作者连同标题、刊名一起塞进 `title`。实测 **`journal` 覆盖率 16/102、`parse_failed` 却只有 2 条**，Crossref 因此在缺失刊名下大面积假报 `journal_mismatch`。**② 新增 `scripts/parse_refs_numbered_jv.py`**：以「**句点 + 4 位年**」为唯一年份锚点（取最右；年份后须接 `,` `(` `空格+数字` 或行尾），句点在年份**之前**是本格式唯一稳定指纹；锚点左侧刊名用「右起连续 Title-Case 词」扫描，失败时回退「**末句整体作刊名**」（处理 `Nature chemistry`/`Chemical reviews`/`Advanced materials`/`Scientific reports`/`Inorganic chemistry` 这类**刊名自带小写实词**的写法，实测 5 条）；作者段循环消费「姓(+复姓成分), 名缩写」组、组间以 `,`/`and`/`&` 连接；右侧兼容「年 卷(期)」漏逗号、仅卷+页、仅文章号、仅页码范围、`(pp. 247-267)` 书籍章节；`In <容器>` 形态先切容器名再剥出版社。**③ 两处防御性细节**：(a) 句点锚点**无命中**时才启用逗号退化锚点（`期刊, 年` 手误写法，本稿 [53][56]），避免抢走 `acs`/`noidx_vancouver` 的逗号锚点格式；(b) 作者姓允许「小写起首词 + 大写姓」（本稿 [18] `kun Liu, H.` 打字错误），停用词表（of/in/for…）挡住标题碎片。**④ Crossref 标题归一化双变体（CRITICAL 假警源）**：见「运行环境陷阱」新增条目——`titles_match` 现同时产出「紧贴式」与「留白式」两种归一化，任一通过即匹配；本稿 [82][90] 由 `not_found` 转为 `verified`。**⑤ A/B 回归**：`git` 快照（v2.29.0 工作树）导出基线，**40 份历史稿件**逐条对照条目数/策略/字段完整度——**39 份零变化**（仅多出 `numbered_jv` 的评分数值），`numbered_jv` 在他稿最高 0.9（CVMJ，低于 `springer` 1.0）、最低 0.1，**未抢走任何既有格式**；本稿 `acs`→`numbered_jv`、`journal` 覆盖率 **16 → 103**。`titles_match` 单测 8 例（跨行下标 ×2、In2Se3 紧贴、副标题、报告年份守卫、年度报告、主题不同）**7/8 通过**，唯一 FAIL 为「Nano Energy vs Nano Energy Letters」——该对属**刊名**差异用例，作为标题二者重叠 2/3 本就 ≥0.65（改动前后同样为 True），非回归。**⑥ TOOL_NAME/config/frontmatter 升 v2.30.0**。**本稿实战结论**：内容相关性 **高度相关**（MXene 基异质结构的钠离子存储 + 电催化氮转化，直落 EMD 收稿范围 Batteries；电催化制氨属能量转换外延，判部分匹配）；作者 4 位——3 位 0 命中，Xiaohong Jiang 1 条同名命中（扬州大学农学院/华中农业大学，农业与植物生物学），**机构与领域均不重合 → 档 2 同名误报**（已用 `author_verdicts` 写明证据）；机构（阿尔法拉比国立大学化学物理与材料科学系 / 燃烧问题研究所 / 南京理工大学国际中白真空等离子体技术实验室 / 米尔韦斯·汗·尼卡大学化学系）与稿件主题**适配**；参考文献 **104 条中 103 条完成自动核验**——89 条逐项一致、9 条仅年份差 1 年、3 条刊名/版别著录差异（Angew 国际版与德文版双记录、专著章节容器名、`Eco Energy` vs `EcoEnergy`）、2 条检索层未定位（均经 DOI/官网独立核验真实存在：10.1039/c7ta02689g、10.1080/15435075.2025.2610200）、1 条为 IEA 机构报告未能自动解析；**0 条撤稿、0 条伪造、0 条未引用**；**唯一实质著录缺陷：[70] 标题被截断成「…electroreduction of arole of electron transfer」，缺失整段中间文字，建议要求作者补全**；AIGC **未见明显痕迹**（加权密度 2.47/千词、强特征 1 处、句长变异系数 0.659、首人称 4、近重复 0）。 |
| v2.29.0 | 2026-11-17 | **修复无编号 APA 尾式「卷(期)」未剥离致 Crossref 批量假报 `journal_mismatch`（EMD20260091 实测驱动，CRITICAL 假警源）**。**① 问题**：本稿 25 条为无编号 APA（`Surname, A. B., Surname, C. D. (2025). 标题. 期刊 卷(期), 页码. https://doi.org/…`）。`parse_refs_noidx_apa.py` 的尾正则 `^(.*?)\s+(\d+),?\s*([\w\-–—]*)\.?\s*$` **没有「期号」位**，遇 `期刊 卷(期), 页码` 时 `\s+(\d+)` 只能吃到末尾页码 → `journal="Scientific Reports 15(1)"`、`volume=39225`（实为页码/文章号）、`page=""`。Crossref 侧 **DOI 解析成功、标题逐字匹配、评分 13/13**，但 strict 刊名核对必然失败 → **25 条中 15 条假报 `journal_mismatch`**（全稿 16 条「差异较大」），若照单全收会把一篇文献全部真实的稿件渲染成「刊名普遍著录错误」。**识别特征：`journal_mismatch` 批量出现 + 稿内 journal 尾部带 `NN(N)` + volume 恰等于页码。****② 修复**：尾正则增加可选期号组 `(?:\s*\(\s*\d+(?:\s*[–\-]\s*\d+)?\s*\))?`，期号丢弃（口径同 `gbt7714`/`acs`，volume 只留卷本体）。**实测**：修后 CrossRef 24/25 verified、`has_issues=0`、仅 1 条 `not_found`（无 DOI 的冷门刊文献，建议要求作者补 DOI）。**③ A/B 回归（39 份历史稿件，`git` 快照 vs 修改版逐条对照，仅解析层零网络）**：**34 份条目数/策略/字段零变化**；5 份 `noidx_apa` 稿件全部为净改进——本稿 50 处、EMD20260090 147 处、EMD_DigitalTwin 42 处、EMD20260088 40 处、CESCI-D-26-00022 32 处，均把「`volume`=页码起页 + `page`=『–页码止页』」纠正为「`volume`=卷号 + `page`=完整页域」，即本手册 v2.26.2 记录的「刊名以数字结尾的无编号 APA 条目…page 以 – 开头」同源缺陷一并根治。**无一处回归**。**④ 文档**：「运行环境陷阱」中 APA 二次清理条目补根因与识别特征；TOOL_NAME/config/frontmatter 升 v2.29.0。**本稿实战结论**：内容相关性 **偏离收稿范围**（非隔离 DC-DC 变换器拓扑 + TDO 整定 PI 控制 + 微电网仿真，属电力电子/电力系统方向；EMD 收稿范围为电池、太阳电池、燃料电池、超级电容器、能量收集器件等能源材料与器件，本稿无材料体系、器件制备或电化学表征，建议编辑部做 scope 判断或建议转投）；作者 3 位——2 位 0 命中，V. Suresh 2 条同名命中（聚合物纤维复合材料力学，机构为印度 Kalaignar Karunanidhi 理工学院机械工程系与沙特 Ha'il 大学），与本稿机构及领域均不重合 → **档 2 同名误报**（已用 `author_verdicts` 写明证据）；机构（戈达瓦里全球大学 电气与电子工程系 / 新视野工程学院 电子与通信工程系）与稿件主题**适配**；参考文献 25 条——**24 条逐项一致、1 条无法定位、0 条撤稿、0 条伪造**，正文与表 1 引用覆盖 [1]—[25]、**0 条未引用**；AIGC **未见明显痕迹**（加权密度 3.68/千词但强特征 0、句长变异系数 0.821、首人称 4、近重复 0）。**⑤ 提取侧备忘**：本稿正文含 177 处 OMML 行内公式、30 段独立公式，表 1 的 44 个参数值亦为公式对象 → `extract_docx` 后表现为「参数表全空、句中数值消失」，**属提取假象、不是稿件缺陷**（判据：`document.xml` 里 `<m:oMath>` 计数、且表格内公式数≈空单元格数）。 |
| v2.28.0 | 2026-11-09 | **修复 `nature` 策略（第 5 策略）三处作者/期刊边界缺陷：单字母缩写刊名被吞、无点缩写刊名吞掉整条标题、作者列表未切出（EMD20260087 实测驱动）**。**① 表现**：本稿 24 条为 Nature house style（`1.Rana, M. M. et al. 标题. 期刊 卷, 页 (年).`），`nature` 以 1.0 分自动选中、24/24 全解析、`parse_failed` 为空——**但 6/24 条字段错位**（仍属「错得看起来像成功」）。具体三类：(a) **单字母缩写刊名被切走**——`…battery pack. J. Energy Storage 76, 109812 (2024).` 中 `_SEG_RE`（`\.\s+(?=[A-Z][a-z]|[A-Z]{2,}\b)`）要求句点后为「大写+小写」或「≥2 位大写」，`. J.` 两者都不满足 → 边界退到 `. Energy` → `journal='Energy Storage'`（丢 `J.`）、`title` 尾部挂 `J`，5 条全部被 Crossref 误报 `journal_mismatch`（评分实为 13/13，纯属解析假警）；(b) **无点缩写刊名吞掉标题**——`…environments. J Therm Anal Calorim 147, 13699–13710 (2022).` 中无第二个可识别边界 → 整条标题被并入 `journal`、`title` 变成作者串 `Zhu, Y. et al`（Crossref 因此匹配到完全无关的 PRL 记录，`year_mismatch` 2022 vs 2019 + `journal_mismatch`）；(c) **作者列表未切出**——`E, J., Xiao, H., Tian, S. & Huang, Y. A comprehensive review …` 中作者末缩写 `Y.` 后是单词标题首字母 `A`，两条边界判据都不命中 → `authors=''`、`title` 整串含作者。**② 修复（三处定向修补，均在原逻辑之后追加、不触碰既有路径）**：修复 A——`auth_title` 以「`. X`」/「`. X.`」结尾且 journal 非空时，把该缩写移回期刊并重切作者/标题；修复 B——journal 含 `. `、末段短（≤45 字）、**前半段长（>45 字，反向保险：防止把修复 A 的结果再拆开）** 且 title 为空或仍呈作者串形态时，交换 title 与 journal，并把原 title（作者串）归位为 authors；修复 C——`authors` 为空时扫描「句点+空白」边界：先处理 `et al.` 延续（把 `et al.` 归入作者、标题从其后续段起算，并 `lstrip(',;:')` 去掉 `,Strong …` 的残留逗号），再以「大写实词/冠词 A/An 开头 + 长度 ≥25 + 含 ≥5 字母实词」认定标题起点（据此 `S. & Huang, Y. A comprehensive …` 不会切在 `& Huang`）。**③ A/B 回归**（当前工作树快照为基准，**33 份历史稿件**逐条对照条目数/策略/字段完整度/得分）：**33 份全部 SAME**；字段级差异仅出现在 2 份 `nature` 稿件——本稿 15 处（6 条期刊名与标题归位、第 18 条标题/刊名/作者全归位、第 16 条作者切出）、`EMD20260060` 6 处（第 22 条刊名 `Electrochem. Soc` → `J. Electrochem. Soc`，第 42/44 条作者与标题归位），**逐条核查全部为改进，无一处回归**。修复后本稿 Crossref **24/24 全部定位通过**（原 18 verified + 6 issues_found 假警），仅剩 1 条年份差 1 年。**④ 教训**：`nature` 的「句点+大写开头词」边界法**天然不识别单字母缩写**（`J.`/`E.`/`A.`），而「J. Energy Storage」「J Therm Anal Calorim」正是 EMD 系刊高频著录式；遇 `journal` 丢首字母缩写、或 `title` 尾部挂单个大写字母、或 `authors` 为空时应先怀疑此坑。**⑤ TOOL_NAME/config/frontmatter 升 v2.28.0**。**本稿实战结论**：内容相关性 **高度相关**（电解质气溶胶改变高压电场放电阈值、耦合电池热失控排气与绝缘失效，直落 EMD 收稿范围 Batteries / Safety assessment）；作者 6 位——4 位 0 命中，Ying Yang 24 条同名命中（医学/护理/商科为主，1 条属能源电气但为山西某交通研究院的微电网需求管理）、Haiyun Luo 1 条（南方医院口腔科骨再生），**机构与学科均不重合，全部判档 2 同名误报**（已用 `author_verdicts` 覆盖以写明证据）；机构（清华大学电机工程与应用电子技术系）与稿件主题**适配**，中国地质大学（北京）人工智能学院标注「待人工确认」；参考文献 24 条——**23 条逐项一致、1 条年份差 1 年、0 条伪造、0 条撤稿**；**新增发现：正文 1 处引用编号（26）超出文献表范围（仅 24 条）**，因正文用**上标式引用标记**（`w:vertAlign=superscript`）致 `citation_stats` 判 `not_applicable`，改由 docx XML 提取上标逐段人工核对——8 组上标（1,2 / 3–9 / 10–12 / 13–17 / 13–22 / 11,12,23 / 24 / 24）展开后覆盖 1—24、无未引用文献，可写入 4.4 节；AIGC **未见明显痕迹**（加权密度 1.65/千词、强特征 1 处、句长变异系数 0.542、首人称 14、近重复 0）。**⑥ 已知残留**：`rich()` 白名单不含 `<sup>`，4.4 节正文若写上标标签会被转义成可见文本，应改用文字描述（"上标 1,2"）。|
| v2.27.0 | 2026-11-06 | **新增第 13 策略 `acs`（编号式 ACS house style）+ 修复 `split_entries` 把期号误判为条目编号（EMD20260084 实测驱动）**。**① 缺策略（第三类静默失败）**：本稿 48 条为 ACS 模板导出式 `(n) 作者（分号）; et al. 标题. 期刊 年, 卷 (期), 页. DOI: …`——**年份在刊名之后、卷号之前**。12 策略全部失效，最高 `vancouver` **0.095** 分、46/48 报 `no year`，仅 2 条被 `vancouver` 误配（`title='journal article'`、`year='1060'`）→ 若不干预，Crossref 会把整篇文献报成「无法定位」。新增 `scripts/parse_refs_acs.py`：DOI 先摘（含清 `DOI:` 标签残留）→ 右侧 `年, 卷 (期), 页` 尾式为锚（页兼容文章号 `e19006`）→ 刊名从右往左扫描（Title-Case / **缩写白名单** / 连接词），遇「句点收尾且非缩写」即停；**三处设计勿破坏**：(a) 缩写判据必须是**白名单 + 全大写短词**，用「Title-Case 短词+句点」会把标题末词 `Route.` 吞进刊名（[22] 刊名变 `Long- Time Molten-Salt Route. Small Methods`）；(b) 刊名切分**按 token 下标、不按字符串定位**——PDF 把化学式下标提成独立行后刊名在原文中不是连续串（`… Chemical 0.8 0.1 0.1 2 Engineering Journal 2021,`），`find` 必失配致标题吞掉刊名（[46]）；(c) `_clean_title_debris()` 清洗标题内下标残留，判据从严（**连续 ≥2 个纯数字 token 且 ≥2 个带小数点**），单个数字（`4.5 V`）保留——不清洗则 [21][22][27] 因 token 重叠率被拉低误报 `title_mismatch`。**② `split_entries` 期号误判（第六类静默失败）**：ACS 条目跨行时期号 `(48)` 落到行首（`(48), 2103005. DOI: …`），被 `ENTRY_NUM_RE` 命中且被 `_is_new_entry` 的「跳跃 ≤3」放行 → 产生伪条目、真实 46/47 条被并吞，条目数 **48 → 46**（跨度的两条消失）。修：新增 `ISSUE_CONT_RE = ^\(\s*\d{1,4}\s*\)\s*,`——`(n)` 后紧接逗号必为期号续段，判非新条目。**③ A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD=v2.26.2 全部脚本，30 份历史稿件逐条对照）：**29 份条目数与策略零变化**，仅本稿 46 → 48、strategy `vancouver` → `acs`（预期改进）。**④ TOOL_NAME/config/frontmatter 升 v2.27.0**。**本稿实战结论**：内容相关性 **高度相关**（无钴富镍单晶正极 + Sr-Ti 位点选择性共掺杂，直落 EMD 收稿范围 Batteries）；作者 9 位 **0 撤稿命中**（5 位有同名命中，逐条核对机构与学科均不重合，全部判档 2 同名误报），机构（中南大学冶金与环境学院 / 有色金属资源循环工程研究中心 / 先进电池材料教育部工程研究中心 / 中色正元新能源）与稿件领域**适配**；参考文献 48 条——**45 条与 Crossref 逐项一致、3 条仅年份相差 1 年**（ACS 卷期年与在线首发年不同，属正常著录差异），**0 条撤稿、0 条伪造**；AIGC **未见明显痕迹**（强特征短语 0、句长变异系数 0.695、加权密度 5.39/千词且全为弱过渡词）。|
| v2.26.2 | 2026-10-12 | **修复机构提取「同行邮箱致机构行整行被丢」（EMD20260076 实测驱动）+ 顺带切断文献区与剥离数字上标**。**① 问题（辅助信息静默失真）**：本刊及大量 Elsevier/MDPI 模板把作者邮箱写在**机构行同一行**末尾——`1 Department of Mechanical Engineering and Aerospace, Old Dominion University, Norfolk, VA, USA; bzhao004@odu.edu (B.Z.); txxu@odu.edu (T.X.)`。而 `_NOISE_RE` 含**裸 `@`** → 整行被判噪声**丢弃** → 真实机构**一行都取不到**；更糟的是**文献区**里含 `laboratory` 的条目 `27.Chen, C., … highway traffic–Design analysis and **laboratory** validation. Applied Energy, 2020.` 反而被 `looks_like_affiliation` 命中 → **全文唯一输出就是这条参考文献**（aff.json 只喂给 agent 做语义判断，不直接进报告，但足以把 agent 引向错误机构）。**② 修复（`scripts/affiliation_check.py`）**：(a) 新增 `strip_contacts()`——先剥离行内邮箱与其后紧跟的姓名缩写括注 `(B.Z.)`、按 `;` 分量丢弃空段，**再对剥离后的文本**做噪声判定与机构判定（纯邮箱行剥离后为空自然落空；`* Corresponding author: x@y.edu` 剥离后仍命中 `corresponding`）；输出亦用剥离后的文本归一化，报告不再带邮箱；(b) 新增 `refs_cut()`——**机构只可能出现在题名页/正文，不可能出现在参考文献条目里**，故复用 `ref_common.locate_references()`（含"无 References 标题"兜底）切掉文献区后再扫描，仅在定位点落在全文 25% 之后时采用（避免异常定位把标题页一并切掉）；(c) `normalize()` 的上标前缀正则原**只认小写字母式**（`a`/`a1`），**数字式上标 `1 Department …` 不剥离**（而数字恰是最常见形式）→ 扩为 `(?:[a-z][0-9]?|[0-9]{1,2})(?:,[a-z0-9]{1,3})*`。**③ A/B 回归**（HEAD 版 vs 修改版，23 份含 `full_text.txt` 的历史稿件逐条对照 `affiliations`）：**5 份零变化，18 份有差异且经逐条核查全部为净改进**——(i) **剔除参考文献条目**（CESCI-S-26-00038 5 条 NIOSH/AGC/Cambridge UP、CESCI-D-26-00022 1 条 MSc thesis、EMD20260060/65、CESCI-S-26-00049、EMD20260071 `204 Netherlands: North-Holland…`、EMD_DigitalTwin `ChargeX Consortium, Idaho National Laboratory. (2023–2025)`）；(ii) **剔除作者简介碎片**（CVMJ-26-00445 **24 → 4**，删掉的 20 条全是 `Wuhan University in 2024. He is currently…` 之类断行残句；SES20250021 **19 → 9** 同因）；(iii) **剔除正文断行噪声**（BUIL-D-25-00483 保留同理）；(iv) **剥离数字上标**（EMD20260058/61/66/67/72、SES20250021）；(v) **找回因同行邮箱而被整行丢弃的真实机构**——CESCI-D-26-00022 新增 `Beijing University of Civil Engineering and Architecture, Beijing`（即该稿第一单位！），本稿新增 `Department of Mechanical Engineering and Aerospace, Old Dominion University, Norfolk, VA`。**无一例真实机构被误删**。**④ TOOL_NAME/config/frontmatter 升 v2.26.2**。**本稿实战结论**：机构适配判断——(美国) 老道明大学 机械工程与航空航天系，与稿件压电能量收集器件实验研究**适配**。|
| v2.26.1 | 2026-10-12 | **修复「稿件无 References 标题」致文献区定位落到正文一级节标题（第六类静默失败）+ `rsc` 补两类变体 + 兜底策略结果加合理性闸门（EMD20260076 实测驱动）**。**① 定位兜底误落一级节标题（CRITICAL，阻塞性）**：EMD20260076 的正文**根本没有 "References" 标题**（Elsevier / Mendeley 导出的稿件常见——声明段 `Funding: …` 之后直接以 `1.Kim, H.S., …, International Journal of Precision Engineering and Manufacturing, 2011. 12(6): p. 1129-1141.` 起列表）。`REF_HEADING_RE` 无命中 → 走「首个编号行」兜底 → 命中正文一级节标题 **`1. Introduction`** → 从正文开头切"文献区"（其实是全文）→ `split_entries`/`split_entries_nlm` 双双 0 命中 → 报 **`no reference entries found`**（**阶段不符**：报的是"切不出条目"，实为定位错；极易误判为"格式不支持"而白跑格式适配）。v2.20.1 只补了跳过 `x.y` 小节号，**漏掉一级节标题**。修复：新增 `_looks_like_ref_start()`——兜底要求编号行**像文献条目**（去编号后满足其一：含 4 位年份 / 含 DOI 或 URL / 以「姓, 名缩写」作者式开头），正文节标题（`Introduction` / `Experiment setup` / `CONCLUSION`）三者皆不满足。**实测 0 → 52/53 条**。**② `rsc` 补两类变体**（仅作用于原先 `parse_failed` 的条目，不触碰任何已能解析的条目）：(a) **在线优先期刊**写作 `… Sensors and Actuators A: Physical, 2025: p. 116185.`——年份后是**冒号**，原 `_YEAR_RE` 的 `(?:[,.]\|$)` 失配 → `_YEAR_RE` 补冒号；(b) **容器条目**（会议论文 / 书籍章节）`作者. 篇名. in <会议录/书名>. 年. [出版社].` 与 `作者, 篇名, in <书名>. 年, 出版社. p. 页.`——年份前是**句点**（不是逗号）故 `_YEAR_RE` 必然失配；新增 `_IN_MARKER_RE`（`[.,]\s+in\s+(?=[A-Z0-9])`，避开 `in situ`）+ `_split_authors_title()`（句点式：首个「句点+空格+大写」且**句点前词长 ≥2**，排除 `M., A. Rahman` 的 `A.` 被误当交界；逗号式：逐段消费姓名段、首个长段即篇名）+ `_extract_container_entry()`，**期刊位放容器名**（与 Crossref container-title 同口径，会议录差异由 `is_conference_container` 降级为注记）。**③ 兜底策略结果加合理性闸门 `_recovery_ok()`（防"错得看起来像成功"）**：`rc.is_healthy` 只要求「title ≥8 字符 且 (year 或 journal)」，故主策略失败后由次优策略"救回"的条目可以是**误配**产物——EMD20260076 实测 6 条会议/书籍条目被 `numbered` 误配，产出「year 全空 + volume=11618（页码腰斩）+ page=-1141（负号）」并进入 refs。闸门：**原文含 4 位年份、而结果 year 为空 → 显式判错**（原文本无年份的资源不受影响）。**④ A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD=v2.25.0 全部脚本，35 份历史稿件逐条对照）：**32 份条目数与策略零变化**；`CVMJ-26-00445` 9 → 89 系 v2.26.0 既有修复（预期）；`CESCI-S-26-00038` 40 → 32、`CESCI-S-26-00049` 151 → 134 **经逐条核查全部为垃圾字段被移除**（`V:'10417' P:'3'` 页码腰斩、`P:'–392'`、作者混入标题、`J:'Cambridge University Press'` 而 year 空——即闸门要拦的对象），属净改进；同批 `rsc` 得分在 CESCI-S-26-00049 由 0.7 升至 0.8、EMD20260076 由 0.9 升至 **1.0**。**⑤ Crossref 核验口径两处修复**：(a) **会议容器豁免改为双向判定**——原只判断「稿内刊名」是否为会议/书籍容器；本稿 [2][29][47] 稿内写 `International Design Engineering Technical Conferences…` / `Active and Passive Smart Structures…`（**不含** proceedings/conference/symposium 等容器词），而 Crossref 记 `Volume 8: 31st Conference on Mechanical Vibration and Noise` / `SPIE Proceedings`（**含**）→ 单向判定放行不了，`journal_mismatch` 假警使 `has_issues=5`；改为 `is_conference_container(ref_journal) or is_conference_container(cr_journal)` 后 **降到 1**（`verified 50 / has_issues 1 / not_found 2`）。(b) **`_journal_tokens` 剥尾部纯大写缩写括注**——稿内 `… (IJPEDS)` 式括注残留会破坏逐词覆盖判定、误报刊名不符；现剥 `\(([A-Z0-9&\- ]{2,12})\)$`（**要求括注内含至少 1 个大写字母**，避免误伤正常括注）。**⑥ `aigc_stats.py` 再补文献区回退（同源缺陷的第二处，仍属"静默失真"）**：原仅以 `[N]` 编号行回退切割文献区；本稿**既无 References 标题、文献又以裸编号起** → 回退完全失效 → **整张文献表被计入正文**（字数 5.1k 被算成 5.7k、句数 221 被算成 482、句均长 21.18 被算成 11.75、句长 CV 0.529 被算成 0.978），**指标全面失真且不报错**（句均长与 CV 恰好都掉出"正常"区间，足以把无风险稿渲染成可疑）。现补第二重回退 `ref_common.locate_references()`（A/B 回归：**34 份历史稿件 AIGC 指标零变化，唯一 DIFF 即本稿自身**；修复后各指标回到正常区间）。**⑦ 文档**：Step 3 自检新增「`status`/`error` 文案须阶段相符」排查口诀；`rsc` 策略表补两类变体与样例。**本稿实战结论**：内容相关性 **高度相关**（压电能量收集器在机电激励下的动态阻抗与能量转换行为，直落 EMD 收稿范围 Energy harvesting devices）；作者 2 位 **0 撤稿命中**，机构（机械工程与航空航天系）适配；参考文献 53 条——**45 条完全匹配、5 条年份差 1 年、1 条年份差 2 年（在线优先上线年 vs 正式卷期年，已写 `review_note`）、2 条未能定位（会议演讲/NTRS 报告 + 厂商产品网页，经定向复核均真实存在，已写 `review_note` 由「不可信」降为「需人工复核」）**，**0 条撤稿、0 条伪造、0 条未引用**；AIGC **无风险**。|
| v2.26.0 | 2026-10-09 | **修复窄栏 PDF 参考文献「编号识别失败」致三重假成功（第五类静默失败）+ 新增第 12 策略 `springer`（编号式 Springer/CVMJ）+ Crossref 会议容器豁免（CVMJ-26-00445 实测驱动）**。**① 元凶不是缺策略，而是编号识别（CRITICAL）**：`detect_numbering` 原按**逐行**统计行首编号命中率（≥30%）判定。CVMJ 为**双栏窄栏排版（页宽 612pt）**，一条文献常折行 4–6 行 → 本稿前 40 行里条目起始行仅 9 行（**22.5% < 30%**）→ 被误判为 `unnumbered` → `split_entries(unnumbered=True)` 把整篇文献区切成 **9 大块串行文本**（实际 **89** 条）→ 11 种策略在这堆垃圾上打分，`rsc` 反而得 **1.0** → 产出「条目数 9（实际 89）+ 字段串行错位（title 空）+ `parse_failed` 为空 + 得分满分」的**三重假成功**——自检三件套（条目数 / 字段抽查 / 得分接近 1.0）**全部失效**，属本手册尚未记录的「第五类静默失败」。**修复**：新增 `BRACKET_NUM_RE = ^\s*\[\d{1,4}\]`，采样中**方括号编号行 ≥3 即直接判 `numbered`**（强证据、脱离折行统计；方括号编号不会出现在折行续行行首，正文 `[12]` 也不单独成行）；裸编号（`1.`/`1)`）仍沿用 30% 判据，避免把年份/章节号误判为编号。**② 新增第 12 策略 `springer`（`scripts/parse_refs_springer.py`）**：本稿 89 条为 Springer/CVMJ 式 `[n] Surname, A. B.; Surname, B. C.. Title. Source, YEAR, pages.`——**作者段分号分隔且以双句点收尾**（`… Ramanan, D..`）、**标题与来源以句点切分**、来源尾部 `来源, 年份, 页码.`。关键设计：**以「双句点」为标题左锚**（无缩写点时回退 IEEE 引号边界 `, “Title`）；**年份取最后一个「非页码端点」的 4 位年**（`_last_year` 跳过与数字/破折号相邻者——否则 `3354–3361` 的端点会被读成年份，实测曾产出 `year=2087/2050/2011`）；**变体归一** `_SRC_PREFIX` 剥 `In:`/`In `（含 `inProc.` 粘连）、`_VOL_RE` 收 `Vol. 12`、`_ARTNO_RE` 把 `Art. No. 102877` 当页码、`_PUBLISHER_SEG` 截掉 `出版社: 城市`（否则书籍条目 journal 变城市名 `Berlin`）；`_dehyphen` 合并 PDF 断词。**实测：得分 1.0 自动选中、89/89 全解析、0 失败、字段抽查全对**（对照 `rsc` 0.9 标题空、`numbered` 0.63 输出错位）。**③ Crossref 会议容器豁免（`is_conference_container`）**：稿内 65 条会议论文（CVPR/ICCV/ECCV/NeurIPS/ICLR 等）被 strict 刊名核对判 `journal_mismatch`（稿内 `Proceedings of …` vs Crossref `2022 IEEE/CVF Conference on …`）→ **65 条假警**；现命中容器词表（`proceedings|conference|symposium|workshop|congress|neurips|iclr|icml|cvpr|iccv|eccv|wacv|acl|emnlp|lecture notes|tech. rep|thesis|dissertation|arxiv`）即降级为 `info["conference_container"]`（**期刊核对只对「期刊论文」有意义**），假警 **65 → 1**（仅剩书籍容器口径差异）。**配套修 `gen_report.build_refs_verify`**：新增 `_info_is_non_difference` / `_has_real_difference`——当 `info` **只**含 `conference_container` 注记时计为**完全匹配**（既不进 4 档表「微小差异」，也不进差异明细的「年份相差1年」合并行），否则本稿 61 条实际完全匹配的文献会被误列为「有差异」。**同批两处渲染口径修正**：(a) `build_author_results` 的「学科采样」由「按字母序取 set 前 3」改为**按命中频次取前 3**——原逻辑因 ASCII 中 `(B/T)` < `(BLS)`（`/` < `L`）恒取到商业/计算机类，把以医学/生命科学为主的命中集误描述成商务类（本稿 Yan Chen 60 条实测：默认显示 `(B/T) Business - Accounting; Business - Economics`，与事实不符）；(b) ⚠️ **尝试并回退**：曾把「有 `review_note` 的 `issues_found`」并入「需人工复核（已甄别）」档，A/B 排查历史 11 份 `crossref.json` 后**回退**——历史稿件的 `review_note` 语义混杂，既有「经人工甄别为误报／文献真实存在」（EMD20260071/072），也有「DOI 无法解析（404）」「稿内 DOI 指向另一篇论文」（BUIL-D-25-00483、CESCI-D-26-00022）这类**真问题**，并入「已甄别」会把真问题渲染成"已排除"（安全级假阴性）。**结论：`review_note` 只对 `not_found` 具备「降级为需人工复核」的既定语义（v2.18.2），`issues_found` 一律保留在「差异较大」档。****踩坑**：曾加 `in\s+robustness` 想捉书籍章节，反而误伤书籍标题 *Robustness in Identification and Control*，已回退。**④ `SECTION_STOP_RE` 补 `author\s+biograph\w*`**：本稿文末作者简介紧接文献区，原终止标记不含 biography → 简介被并入末条 [89]。**⑤ 期刊库**：`assets/journal_scopes.json` 新增 **CVMJ（Computational Visual Media）** 记录（scope 取自 SciOpen 官网，8 个收稿方向，**注意官方列表无 "Geometry modeling and processing"**）→ preflight 由 `incomplete` 转 `ok`。**⑥ A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD 版全部脚本，22 份历史稿件逐条对照）：**21 份条目数与策略零变化**，仅本稿 9 → 89（即修复目标）。**⑦ TOOL_NAME/config/frontmatter 升 v2.26.0**。**本稿实战结论**：内容相关性 **高度相关**（单目度量深度估计 + 相机自提示 + 边缘引导监督，直落 CVMJ 收稿范围 Recognition and understanding of visual media / Machine learning for visual media）；作者——6 位中 2 位（Jian Chen 39 条、Yan Chen 60 条，均为极常见姓名）有大量同名命中，**Jian Chen 判档 3（1 条命中属计算机视觉同领域：Sparse Tensor CCA for Color Face Recognition，机构为江苏科技大学而非本稿单位）需重点核实**，Yan Chen 判档 2（60 条命中全为医学/生命科学/化学/护理及计算机应用类，无一属本稿研究领域，机构无一重合）基本判定为同名误报；参考文献 89 条——**71 条完全匹配、0 条伪造、0 条撤稿、0 条未引用**，7 条差异较大与 6 条无法定位**经逐条定向复核全部为会议录（NeurIPS/ICLR/ICCV/CVPR 不进入 Crossref）或预印本收录范围问题，无一条疑似编造**，已全部写 `review_note` 降级为「需人工复核」；AIGC——**无风险**（提示语加权密度 0.14/千词、强特征 0、句长变异系数 0.725、近重复 0） |
| v2.25.0 | 2026-10-04 | **新增第 11 策略 `elsevier`（编号式 Elsevier/SciOpen，年份带括号居中、卷期连写）+ 把第 10 策略 `ieee` 补进策略表（既存文档漂移）**（EMD20260073 实测驱动）。**① 问题（第三类静默失败的新变体）**：本稿 42 条为 Elsevier 编号式 `[n] 作者列表, 标题. 期刊 卷 (期) (年) 页码.`——年份**带括号居中**（非行尾）、卷期连写 `18 (16)`、标题与刊名之间为**句点或干脆无标点**（[6] `… solar cells Chemical Engineering Journal 519 (2025) 165415`）、作者段含 `and X.`。10 种既有策略全部不匹配，最高仅 `numbered` **0.78** 分且输出**系统性错位**（`title` 空、`year` 空、`journal` 尾部挂上标题/卷期），而 **`parse_failed` 仍为空** —— 若不核对字段，Crossref 会把全部文献报成「无法定位」，直接制造「整篇文献不可信」的假象。**② 新增 `scripts/parse_refs_elsevier.py`**：以**最后一个 `(YYYY)`** 为年份锚 → **门控**（右侧 tail ≤40 字符且不含 `. `，挡住同样「年份在括号里」的 APA `作者 (年). 标题. 期刊`）→ 左侧剥「卷 (期) / 卷, 期 / 卷」→ **刊名用「从右往左连续 Title-Case 词」提取**（允许 of/in/and/for/de 连接词、允许 `Measurement: Energy` 的冒号与 `J. Mater. Chem. C` 的缩写点），故**标题与刊名之间即使完全没有标点也能切准** → 作者/标题按逗号分段（兼容无缩写点作者名 `Marc Al Atem`，该宽松判据仅在已确认 ≥1 位作者后启用）；页码字符类含 **U+2212 数学减号**。实测 **42/42 全解析、0 失败、得分 1.0 自动选中**（对照 `numbered` 0.78 且输出错位）。**③ A/B 回归（`git checkout-index -a -f --prefix=` 导出 HEAD 版，21 份历史稿件逐条对照）**：**19 份计数与策略零变化**；`EMD20260073` 41 → 42（预期改进）；`CESCI-S-26-00038` 由 `numbered` 改判 `elsevier`，**救回 2 条真实期刊论文（[1][3]，此前因 `and` 作者段与卷期连写而 failed）**，同时把 2 条网络资源/报告（[7][9]）由「错位解析」改为显式失败（此前 title 为 `(May 2019)` 之类垃圾）—— **净改进，无回归**。**④ 文档口径**：Step 3 策略数「9 种」→「**11 种**」；策略表补入 `ieee`（此前仅出现在变更记录中）与 `elsevier` 行。**⑤ TOOL_NAME/config/frontmatter 升 v2.25.0**。**本稿实战结论**：内容相关性 **高度相关**（环境空气制备 MA1-xFAxPbI3 + SCAPS-1D 器件优化，直落 EMD 收稿范围 Solar cells）；作者——4 位全部 **0 撤稿命中**，机构（光伏实验室 / 工程学院）与稿件领域适配；参考文献 42 条——**41 条与 Crossref 逐项一致、1 条刊名缩写差异**（`Phys. Chem. Lett.` vs `The Journal of Physical Chemistry Letters`，标题/年/卷/页全对、评分 13/13，已写 `review_note` 甄别）、**1 条在线优先文献暂无卷期页码**（[1]，属正常著录状态）、**0 条撤稿、0 条伪造、0 条未引用**；AIGC——**轻度可疑**（提示语加权密度 5.47/千词但以弱过渡词为主、强特征仅 2 处、句长变异系数 0.618、首人称 15 处、近重复 0） |
| v2.24.1 | 2026-09-27 | **修复文档内部两处「报告输出目录」规则冲突，避免 agent 自行改指输出位置（EMD20260069 实测暴露）**。**① 问题**：SKILL.md 长期并存两条互斥规定——(a) Step 5 内 **v2.15.0（F-05）「建议输出到隔离目录」**（`<skill>/reports/` 或编辑部专用目录，理由：报告含作者个人信息与撤稿记录等负面属性，避免写在云同步/共享的稿件目录扩大外泄面）；(b) 本文档「报告保存位置与数据来源标注」**「报告保存到输入稿件文件所在的目录」**（自 **v2.1.0** 起，措辞为「不可硬编码」的强约束）。两条各自成立、互不引用，**agent 读到 (a) 便会自行把 `--out` 指向工作区 `outputs/`**，导致报告未随稿归档——EMD20260069 实测发生（报告落 `<workspace>/outputs/` 而非 `<稿件归档目录>\EMD20260069\`）。**② 判定**：以 (b) 为**默认硬规则**（v2.1.0 起一直有效、且用词更强），(a) 降级为**仅在用户明确要求时适用**（稿件目录处于云同步/共享盘、或用户主动提出隔离需求）。**③ 修复**：两处**互相交叉引用**并各自标注优先级——(a) 改为「默认且必须输出到输入稿件所在目录；⚠️ v2.15.0 F-05 的隔离目录建议与之冲突，v2.24.1 起判定为仅用户明确要求时采用；**agent 不得仅凭该『建议』自行改变输出位置**」；若确实采用隔离目录，须在交付时**明确告知用户实际路径**并说明未随稿归档的原因。(b) 补充「本规则为默认硬规则（自 v2.1.0 起）；读到任一条都必须同时看另一条」。**④ 附带口径统一**：无论输出到何处，「报告含个人信息与撤稿记录、仅限编辑部内部使用、勿对外公开或跨境传播」的合规提示保持不变（原 (a) 的 F-05 安全初衷保留为「采用隔离目录时的告知义务」）。**⑤ TOOL_NAME/config/frontmatter 升 v2.24.1**。**本稿实战结论（EMD20260069）**：内容相关性 **高度相关**（全无机 CsSnI₃ 反式钙钛矿太阳能电池，直落 EMD 收稿范围 Solar cells）；作者——**档 3，需重点核实**：通讯作者 S. Wageh 命中 **2 条撤稿**，两条命中项机构**与本稿作者单位逐字重合**（哈立德国王大学理学院物理系 + 梅努菲亚大学电子工程学院物理与工程数学系），已用 `author_verdicts` 覆盖默认档 2 文案（否则会把"需核实"渲染成"已排除"，属安全级假阴性）；撤稿论文主题（纳米纤维除铬硒 / CdS 纳米晶玻璃）与本稿光伏器件不同，属**同机构而非同领域**风险；参考文献 36 条——33 完全匹配、4 条年份差 1 年、1 条刊名写法差异（`Micromachines (Basel)` vs `Micromachines`）、2 条 not_found（**Setfos 商业模拟软件** + **ETH Zurich 2002 学位论文**，均经甄别为非期刊文献并写 `review_note` 将「不可信（红）」降为「需人工复核（黄）」，汇总表同步为「需人工复核（已甄别）2 / 无法定位 0」），**0 条撤稿、0 条伪造、0 条未引用**；AIGC——**无风险**（强特征词 0、句长变异系数 0.614、弱特征密度 2.99/千词、近重复 0；作者已声明使用 Grammarly）。**⑥ 同批交付的第 10 策略 `ieee`**（IEEE house style，见 v2.24.0） |
| v2.23.0 | 2026-09-27 | **修复 `rsc` 策略对「有篇名」变体（NLM/CSE 式）的系统性列错位——满分假象下的静默失败（EMD20260070 实测驱动）**。**① 问题（第四类静默失败）**：本稿 42 条参考文献为 **NLM/CSE 式**——`<n>.<作者>, 篇名. 期刊, 年. 卷(期): p. 页.`（**有篇名**，年份在期刊名**之后**），而非 `rsc` 策略假定的 RSC 式（**无篇名**，年份在期刊名**之前**）。`rsc` 的「首个 `, 年` 锚点」在 NLM 式中**落在篇名内部**（如 `… Batteries. Joule, 2019.`）→ 锚点左侧「作者 + **整条篇名**」被并进 `journal`、`volume` 为空、`title` 全空；**而 `parse_failed` 为空、`rsc` 得分虚高 1.0**（自检"条目数正确 + 得分近 1.0"完全失效）。实测 41/42 条 `title` 为空 → Crossref 被迫全部走 `bibliographic`（比标题核验弱）→ 埋下 `journal_mismatch` 假警（期刊名被拼成 `篇名. 期刊` 长串）。与 v2.18.2「失败被当成功」、v2.19.0「错得看起来像成功」**成因均不同**，是"**满分假象下的系统性列错位**"。**② 修复**：`parse_line` 在锚点切分**之前**先调新增的 `_detect_title_variant(head)`——双条件判定「有篇名」结构：① `head` 内存在「句点+空格+大写/左括号」边界（篇名/期刊交界；纯作者列表的段间分隔是「逗号+空格」）；② 边界右侧（期刊名）短（≤7 词）、无句点、无作者式缩写串（`\b[A-Z]\.` ≥2 次即判否）。作者/篇名切分**三级回退锚点**：`et al.` → `and <缩写> <姓>,`（单作者+合著者式，[15] `Asl, H.Y. and A. Manthiram, Reining in …`）→ 首个「≥4 词且 ≥20 字符长段」（**篇名内部可含逗号**：`Mechanism, Detection, and Mitigation in …`，[6] 实测——故不可用"首个非作者段"作终点）。命中变体时置 `no_title_format=False`，令 Crossref 走**标题核验**。**③ 两处配套**：(a) `_split_tail_volume_page` 新增 NLM 尾式 `卷(期): 页`（`3(10): p. 2322-2333`、`172(4): p. 040506`），卷只留卷本体、期号丢弃（与 `gbt7714` 口径一致）、剥 `p./pp.` 前缀；(b) 无 `, 年` 锚点的非期刊条目（在线专著/数据库，写作 `标题. 2006: 出版社`）在命中 `book\|database\|report\|press\|online\|…` 词时走 `_extract_nonjournal` 反向取篇名，置 `ref_nonjournal=True`（[40] `Liao, Y., Practical electron microscopy and database. 2006: An Online Book.`）。**④ 反向保险**：`_detect_title_variant` 不命中即**逐字回退**原 RSC 路径，真 RSC 式输出不变。**⑤ 一处既存边界修正**：候选期刊名**不再因含 `and` 而被排除**——真实刊名常含 and（`Energy Materials and Devices`、`Progress in Energy and Combustion Science`），原判据曾致 2 条漏判。**A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD 版全部脚本，17 份历史稿件逐条对照）：**`EMD20260066`（RSC 式 116 条）计数/策略/得分 0.995 完全一致、`title` 非空数仍为 8 — 零回归**；另 14 份（apa/noidx_apa/vancouver/nature/numbered/noidx_vancouver/gbt7714 各式）条目数与策略**逐份一致**（`CESCI-S-26-00047` 的 36 为 HEAD 既有行为，非本次引入——其 `refs.json` 同为 36 条、index 集合相同）。**本稿改动前后 0 字段 → 42/42 全字段**，Crossref 由全走 `bibliographic` 转为 **40/42 标题级核验通过**。**⑥ TOOL_NAME/config/frontmatter 升 v2.23.0**。**本稿实战结论**：内容相关性 **高度相关**；作者——2 位中 1 位（Guangsheng Zhang）有 1 条同名命中，机构为**沈阳农业大学经济管理学院**、学科为**商业经济/城市规划**，与本稿（阿拉巴马大学亨茨维尔分校机械与航空航天工程系 / 锂离子电池）**机构与领域均不相关 → 档 2 判定为同名误报**（无需 `author_verdicts` 覆盖）；参考文献 42 条中 **40 条逐项一致、1 条年份差 1 年且为同刊不同版本、1 条为 Crossref 未收录的在线专著**（[11] Angew 的 `anie`/`ange` 并列版本 + 在线首发年份差 1；[40] Liao 在线专著）——均经联网独立复核**确认真实存在**、**0 条撤稿、0 条伪造**；AIGC——**未见痕迹**（强特征短语 0、句长变异系数 0.465、加权密度 2.56/千词）。 |
| v2.22.0 | 2026-09-27 | **修复「逐行行号」水印的第二种排版（内联前缀）致文献全量欠解析 + 页脚水印污染字段 + 第 10 类格式的年卷尾（CESCI-S-26-00047 实测驱动）**。**① 行号水印漏判的第二种排版（CRITICAL，v2.21.0 修复的盲区）**：v2.21.0 的 `detect_line_numbering` 只认「行号独占一行/独占一列」（纯数字行占比高）这一种排版。本稿（Word 导出 PDF、带逐行行号）实测**纯数字行仅 91/1087 = 8.4%（远低于 25% 阈值）**，而**数字前缀行占 700/1087 = 64.4%**——行号与正文同列、以「`42 `+正文」的内联前缀形式出现。原判据（`detect_page_numbers` 的数字前缀覆盖率 ≥60% 已过，但 `detect_line_numbering` 的量纲是纯数字行）→ 判 False → 未剥行号 → `locate_references` 正常找到标题 `24 References`、但 `split_entries` 与 `split_entries_nlm` 双双 0 命中 → 报 `no reference entries found`，**9 种策略全 0 分**（极易误判为"格式不被支持"而白跑格式适配）。修复：把统计逻辑抽为共享助手 `_ln_stats(vals, min_inc=5, inc_ratio=0.8, drop=5)`，`detect_line_numbering` 改为**双路径判定**——Path A（原有）纯数字行 ≥10 且占比 ≥25%；**Path B（新增）数字前缀行 ≥10 且占比 ≥50%**。两路径**共用同一组行号指纹**：整数近似连续递增（步长 ≤3 占 ≥80%）**且存在 ≥5 的大幅回落**（行号每页从 1 重起）——Path B 的回落要求是**反向保险**，防止把真实编号列表（`[1]`…`[N]`，单调递增、无回落）当成行号而错误剥离。修复后 **0 → 37/37 全解析**。**② 页脚水印污染字段**：本稿每页页脚为 `Civil Engineering Sciences Manuscript Template Page N of 22`，pdfplumber 提取成独立行且**重复 22 次**，混进文献区后把期刊名尾部挂上该串（`[7]` 的 journal 被追加页脚）→ `numbered` 得分被压到 **0.07–0.14**。新增 `strip_running_headers(lines, min_repeat=3)`：以 `RUNNING_HEADER_RE`（要求含强结构 `Page N of M`）+ 数字归一化签名**重复 ≥3 次**双条件判定，命中则整行剔除；并以 `JOURNAL_FOOTER_HINT_RE` 收窄候选（`Manuscript Template`/`Running head`/`Preprint` 等）。接入 `preprocess()`，置于水印分支之前。**③ 第 10 类格式尾式：`年;卷[(期)][:页].`**：本稿 37 条为 `[n] Author(s). Title. Journal. 2025;458.` / `2023;24(1).` / `2025;10:2616–32.` 混合式（**分号连年卷、期号可选、页码可省、页前可用冒号或逗号**）。`parse_refs_noidx_vancouver._TAIL_PATTERNS[0]` 原**不含可选 `(期)` 段、页前只接受冒号** → 29/37 条报 `no year;volume tail`。修复为 `[.,;\s](\d{4})\s*;\s*(\d[\d\s·]*?)(?:\s*\(\s*\d{1,4}\s*\))?(?:\s*[:\uff1a,]\s*(页字符类+))?\s*\.?\s*$`。回归验证：新式 **21/21 命中**（旧式仅 8/21）。综合修复后 `noidx_vancouver` **36/37 解析、得分 0.8**。**④ 附带发现：行号嵌入致引用统计假 `uncited`**：正文引用组 `[5, 12,\n42 13]` 被行号 `42` 劈开，`citation_stats` 只捞到 `[5,12]` → 误报 `uncited=[12,13]`。清洗后由官方 `citation_stats.py` 复跑得 **37 cited / 0 uncited**。**教训：凡带行号水印的 PDF，引用统计必须在"已剥行号"的文本上跑，否则会出现成组引用的假缺口。** **A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD 版全部脚本，15 份历史稿件逐条对照）：14 份计数与策略完全一致；`EMD20260061` 由 `watermark=False → True`（前缀覆盖率 77.6%、计数器逐页重置）经核验为**真实改进**，且其解析输出**前后完全相同**（31 条、`apa`）→ 非回归。**本稿实战结论**：内容相关性 **高**；作者——1 条同名命中（Dong yun Luo，九江学院，计算机/电子工程）与本稿不同机构不同领域 → **档 2 判定为同名误报**；参考文献 37 条中 34 条与 Crossref 完全一致、**0 条 issue、2 条未定位**（两篇中文期刊文献经联网独立核验**确认真实存在**，属 Crossref 收录盲区）、1 条为**标准**（`[20]` GB/T 714-2015，非期刊论文）、**0 条撤稿、0 条伪造**；AIGC——**无显著痕迹**（强特征短语计数 0、句长变异系数 0.60、短语密度 3.10/千词且均为弱特征）。**⑤ TOOL_NAME/config 升 v2.22.0** |
| v2.21.0 | 2026-09-23 | **修复 PDF「逐行行号」水印漏判致文献全量欠解析（第一类静默失败新变体）+ 期刊名清洗顺序错误致 55/70 假警（BUIL-D-25-00483 实测驱动）**。**① 行号水印漏判（CRITICAL）**：本稿 PDF 由 Word 导出、带**逐行行号**（每页 1–65 循环），pdfplumber 提取为大量「纯数字行」+「数字前缀行」（纯数字行占非空行 **65%**）。原 `preprocess` 只调 `detect_page_numbers`（判据=数字前缀覆盖率 ≥60%，实测仅 **27.5%**）→ 漏判 → 70 条参考文献**只切出 3 条**，而 `parse_failed` 为空、所选策略得分 **1.0**（虚高）。新增 `detect_line_numbering()`：非空行中纯整数行 ≥10 且占比 ≥25%、整数近似连续递增（步长 ≤3 占 ≥80%）、**且存在 ≥5 的大幅回落**（行号每页从 1 重起，为区别于真实编号列表的关键指纹）→ 判行号水印，先删纯数字行再剥行首前缀。修复后 **3 → 70/70 全解析**。**② 分页标记泄漏**：提取器实际输出 `===== PAGE 40 =====`，而 `PAGE_BREAK_TOKEN` 常量写的是 `===PAGE BREAK===` → 标记未剥离，`[67]` 的 journal 尾部挂上该串；新增 `PAGE_MARKER_RE` 于 preprocess 过滤。**③ `clean_journal` 规则顺序错误（假警风暴）**：原实现**先跑尾部剥离正则、最后才去尾标点**，而 APA 式条目尾部普遍带标点（`"…, 1570."`、`"Sustainability, 16(14),"`）→ 所有尾锚定正则一律失配 → 卷/期/页**永远剥不掉** → Crossref 把 **55/70** 条报成 `journal_mismatch`（verified 仅 3 条），制造「整篇文献刊名著录错误」假象。修复：改为**先 `rstrip('.,;:')` 归一化、再跑尾锚定剥离**，并新增出版社名尾随剥离（Wiley/Elsevier/Springer/CIBSE/ASHRAE/ISO 等）与最多 6 轮迭代剥离；verified **3 → 19**。**④ 尾锚定规则过贪（修 ③ 时自造，A/B 回归抓出）**：`tail_pats[3]` 原为 `,\s*[\w\-–—]+\s*$`，会吃掉真实期刊末词（EMD20260067 [35] 的 `, Carbon` 被删）→ 收窄为须含数字 `(?=[\w\-–—]*\d)`；另 EMD20260057 的 `In: Handbook … Elsevier, pp` 在 ③ 修复后 `, pp` 不再被剥 → 新增悬挂页码标记规则 `,\s*pp?\.?\s*$`。**⑤ `aigc_judgments` 键名漂移修复（静默覆盖失效）**：`build_aigc_table` 此前 `jd.get(key)` 只认**英文指标名**，而 agent 常按报告显示的中文指标名书写（EMD20260067 用「句长变异系数」）→ 查不到即静默回退 `auto_judge`，覆盖形同虚设；现接受 key 与中文 label 两种写法，字段说明同步。**⑥ TOOL_NAME/config 升 v2.21.0**。**A/B 回归**（`git checkout-index -a -f --prefix=` 导出 HEAD 版全部脚本，对 20 份历史稿件逐条对照，比 `git stash` 安全、不动工作树）：13 份计数与期刊字段完全一致，多份为改进（EMD20260057/61/65、EMD_DigitalTwin 期刊字段更干净）；`EMD20260110` 由 0 → 164/165（与 v2.20.1 同源，非本次引入）。**待办**：`CESCI-S-26-00038` 由 5 → 40 条（HEAD 严重欠解析、CUR 更完整）但新切分产生 4 条 parse_failed，其 full_text.txt 无独立 `reference` 标题行、定位走兜底分支，**尚需单独核查**。**本稿实战结论**：70 条文献中仅 19 条与 Crossref 完全匹配，17 条 DOI 真实存在但指向完全无关的论文、7 篇期刊论文无法定位、3 条重复著录、2 篇主题无关的施工管理文献；另检出 1 位作者存在**同机构同领域**的同名撤稿命中（档 3，走 `author_verdicts` 覆盖，未套用档 2 默认文案） |
| v2.20.1 | 2026-09-22 | **参考文献区定位与无编号 NLM 解析三处缺陷修复 + 4.4 节渲染两处文档/代码漂移修复（EMD20260068 实测驱动）**。**① `REF_HEADING_RE` 不容忍标题尾随冒号（CRITICAL，安全级误报链）**：原正则 `^\s*(?:\d{1,4}\s+)?(references?\|bibliography)\s*$` 要求标题行**以词结尾**，本稿标题写作 **`References:`（带冒号）** → 定位失败 → 落入「首个编号行」兜底 → 兜底把正文小节号 **`2.1. The experimental components:`** 当成文献区起点 → 从该处切出的"文献区"其实是全文，`split_entries` 与 `split_entries_nlm` 双双返回 0 → 报 `no reference entries found`。**且错误信息有误导性**（报"未找到条目"而非"未找到标题"），排查时容易误判为解析器不支持该格式（本稿 9 种策略确实全部返回 0 分，更强化了误判）。修复：标题正则改为 `\s*[:.;]?\s*$`（容忍尾随冒号/句点/分号）。**② `locate_references` 兜底误定位**：兜底循环改为**跳过章节号行**（`^\d+\.\d`，如 `2.1.`），避免正文小节号被当作文献编号起点。**③ `_is_nlm_start` 不支持混排列表**：原判定要求行内含 `年;卷` 分号锚点，而混排列表里少量条目为"作者, …, et al., 标题. 期刊 年, 卷, 页"式（年卷间用逗号/冒号）→ 这些条目被并进上一条，条目数由 41 掉到 37（本稿实测）。修复：新增 `et al.,` 与「4 位年份 + DOI/URL」两条并列判据。**④ `parse_refs_noidx_vancouver` 三处缺陷**：(a) **DOI 排在 `年;卷:页` 之后导致尾部锚定全败**——本稿 41 条几乎全部以 `… 2025;10:2616–32. https://doi.org/…` 结尾，`_TAIL_YV` 锚定在行尾故全部失配（41/41 报 `no year;volume tail`）；改为**先摘走 DOI/URL、再匹配尾部年卷**（顺序仍不可反：先提 DOI 再删链接）；(b) 年卷写法混排 4 种（`年;卷:页` / `年, 卷, 页` ACS 式 / `年:页` 无卷 / 仅年份）→ `_TAIL_PATTERNS` 四形态依次回退；(c) 页码字符类缺 **U+2212 数学减号**（`1417−1427`）致该条失配——与 `citation_stats` 的 `_DASH` 同源教训，抽出 `_DASH`/`_NUMPAGE`；另新增**逗号制条目切分 `_split_shape_b`**（`et al.,` 或 `, and X,` 锚点）与作者段判据 `_looks_like_author_seg`（挡缩写句点碎片 `S`、放行单作者 `Xin L`）。**实测**：EMD20260068 由 0 条 → **41/41 全解析、0 失败、策略 `noidx_vancouver` 1.0 分**、字段抽查全对。**A/B 回归（改动前 vs 改动后，14 份历史稿件逐条对照）**：13 份计数与策略完全一致；`EMD20260110` 由 **0 条（165 条全失败）→ 164/165 条**——该稿历史遗留失败（当时靠临时解析器救回，未固化）正是同一个「DOI 排在年卷之后」成因，本次一并根治。**⑤ `gen_report` 转义把 4.4 节 HTML 转成可见标签（文档/代码漂移）**：`refs_citation_issues`/`citation_gaps` 在本文档中定义为 HTML，但 v2.15.0 的全局转义（F-01）把二者整串转义，报告里出现可见的 `&lt;p&gt;`（EMD20260068 与历史 EMD_DigitalTwin 均实测）。新增 `rich()`：**先整串转义、再放行无属性白名单标签**（`p/b/strong/em/i/br/ul/ol/li`）——保留 XSS 防护（无法构造带属性的事件处理器或 script/style），同时恢复可读排版。**⑥ 4.4 节占位符位置**：模板原将 `{{REFS_CITATION_SECTION}}` 夹在 4.1 与 4.2 之间，渲染出「4.1 → 4.4 → 4.2 → 4.3」的非升序节号；移至 `{{REFS_RETRACTION_CHECK}}` 之后，与本文档「4.4 在末位」的表述一致（隐藏时仍为 4.1→4.3 连续）。版本号升 v2.20.1（`config.TOOL_VERSION` + frontmatter 两处） |
| v2.20.0 | 2026-09-20 | **新增第 9 策略 `rsc`（编号式无篇名／RSC 皇家化学会式）+ 三处误报治理（EMD20260066 实测驱动）**。**① 参考文献解析（新格式，第三类静默失败）**：EMD20260066 的 116 条参考文献为 RSC house style——`1.M. S. Dresselhaus and I. L. Thomas, Nature, 2001, 414, 332-337.`，**根本不著录标题**、年份夹在期刊名之前、其后直跟「卷, 页码」。8 策略无一覆盖，且失败形态是**错位而非报错**：旧策略解析出 `title='…Nature 2001'` / `journal='414'` / `volume='332'` / `year=''`，114/116 条全错位而 `parse_failed` 仍为空（v2.18.2「失败被当成功」、v2.19.0「错得看起来像成功」之后的第三例）。新增 `scripts/parse_refs_rsc.py`：以 `,\s*((?:19\|20)\d{2})\s*(?:[,.]\|$)` 的**「, 年」唯一锚点**正向切分（左＝编号+作者段，末段＝期刊名；右＝卷, 页码）；末段命中出版社/地名/`eds.`/`preprint` → 判**非期刊条目**并反向找篇名（书籍章节/报告不被硬套成期刊）；输出 `no_title_format=True`（**确无标题**，区别于"解析失败"）与 `ref_nonjournal`/`ref_kind`；页段新增剥 `pp.` 前缀。`ref_common.is_healthy`/`field_completeness` 按该标记分流（健康判据改为「有年份 且（期刊 or 标题 or 页码）」，完整度只考核 `year`/`journal`/`authors`），否则 116 条正确结果会被判"字段不完整"而压低得分。实测 `rsc` 得分 **0.995** 自动选中、116/116 全解析、`parse_failed` 为空、字段抽查全对（对照 `numbered` 仅 0.735 且输出错位）。**② Crossref 无篇名核验路径**：`ref_title` 为空时标题检索必然全败，新增 `query_crossref_by_biblio()`（`query.bibliographic`，缓存 key 后缀 `:biblio`）+ `score_biblio_result` **满分 16**（期刊 4+年份 2+卷 3+页起始 3+**文章号 3**+作者姓 1；阈值 ≥8 且期刊名必匹配），首轮不过则并发跑变体 B（作者姓前 4 位+期刊+年+卷+页）/C（去期刊的宽松档），并新增 `_id_candidates`/`_article_ids` 做**文章号多形态归一**（`e70188`↔`70188`，同时取 Crossref `message.article-number` 与 DOI 尾段）——在线优先文献无卷无页也能锚定，EMD20260066 实测由 5 条误判收敛到 2 条（8、12 号，均定向复核确认 Crossref 实存）。DOI 路径门槛同步改为「≥6 且（无篇名时改判期刊名）」，`source` 记 `biblio_search(score=N/16)`。**③ `titles_match` 标题内年份守卫（修一处误接受）**：稿内引 IEA《Global EV Outlook **2024**》曾被匹配到 Crossref 的「多年份年度报告」记录（标题带 2022 等旧年份）以 0.7 重叠接受；现比对双方标题内 4 位年份集合，**两边都有年份且交集为空即判非同篇**，改报 `issues_found`（**宁可诚实呈现"无法定位匹配版次"，也不冒充核验通过**）。副作用：年度报告/标准/数据集等"每版只差年份"的文献会落入「需人工复核（已甄别）」而非「完全匹配」，属预期。**④ `citation_stats` 上标引用护栏（CRITICAL）**：EMD20260066 正文用 Word **上标式**引用标记（`w:vertAlign="superscript"`，实测 328 处），纯文本提取后标记全丢 → 脚本 0 命中即把 `uncited` 报成 **[1..116] 全量**（即"116 篇文献全部未被引用"这种荒谬结论），而脚本本身不报错。现于 `--total-refs` 已给定而 0 命中引用标记时输出 `not_applicable: true` + warning，**明确告知"本统计不适用、勿据此判定文献未被引用"**，不再输出全量 uncited；回归两条历史稿确认不误伤（EMD20260064 cited=79/uncited=0/na=False、CES Constraint-Aware Urban Scaling cited=30/uncited=30/na=False 均未被触发）。**⑤ 版本号单点化**：`gen_report.TOOL_NAME` 原硬编码 `'熊猫找茬-新稿 v2.19.x'`，与 `config.py`、SKILL.md frontmatter 三处各写一遍、历次升版漏改（v2.17.1、v2.19.1 均踩过文档/代码漂移）→ 改由 `f'熊猫找茬-新稿 v{config.TOOL_VERSION}'` 拼接，并加注释锚定。frontmatter 版本号同步 2.19.2 → 2.20.0；TOOL_NAME/config 升 v2.20.0 |
| v2.19.2 | 2026-09-18 | **同步「已出版」v3.17.0 的引用统计破折号类修复（同源脚本，ECM20260040 实测驱动）**：`citation_stats.py` 的 `PAT_REF`/`PAT_RANGE` 原字符类只含 hyphen 与 en-dash（`[-,–]`），而 ECM 已出版稿正文出现 `[1,16−18]`，分隔符是 **U+2212 MINUS SIGN**（数学减号，PDF 排版高频，`ord()` = 0x2212）——既非 hyphen(U+002D) 也非 en-dash(U+2013)，导致**整组被当作单 token 静默丢弃**、[16][18] 被误报「未引用文献」（cited 21/23）。现抽出统一字符类 `_DASH = r'\-\u2013\u2014\u2212'`（hyphen/en-dash/em-dash/minus sign 四者齐备）供 `PAT_REF`/`PAT_RANGE` 共享，并在 `collect_cited` 内补 `if not part: continue` 防空段。**回归 9 用例×双 skill 全通过**（hyphen/en-dash/em-dash/U+2212 四种范围、`[1,16−18]` 混合组、`[49, 50]` 带空格组、长逗号组、单编号）。**教训**：凡「按引用标记切分/展开」的正则，破折号字符类必须四者齐全——缺一种就静默漏匹配且不报错。**另附自查陷阱（差点把好代码改坏）**：检查 `_DASH = r'\-\u2013\u2014\u2212'` 时 `repr(_DASH)` 显示 `'\\-\\u2013\\u2014\\u2212'`、`'\u2212' in _DASH` 为 `False`，**看起来像"raw string 使转义失效"**，实为误判——`re` 引擎会自己解释模式串里的 `\uXXXX`（与 Python 字符串层无关），验证字符类须跑 `PAT_REF.search('\u2212')` 而非查拼接变量。同批经验已回写「参考文献识别经验手册」v1.6。TOOL_NAME/config 升 v2.19.2 |
| v2.19.1 | 2026-09-17 | **同步「已出版」v3.16.0 的两处静默失真修复（同源脚本，OCE20260029 实测驱动）**：① `aigc_stats.py` 正文截断——无 References 标题时回退取「首个 `[N]` 开头行」，被分栏 PDF **折行引用标记**误触发，正文被截到该行前（实测 7196 → 640 词）且不报错，AIGC 全指标失真；现要求 `[N]` 行 ≥5、首行编号 ≤2、下降次数 ≤20% 才认定参考文献节。② `crossref_check.py` 的 `_overlap_ok` 泛用词误配——`global/report/年份` 等泛用词足以让完全不同文献达 0.65 重叠被接受（`Global wind report 2025` vs `Global Debt Report 2025` 实测以 8/13 分接受）；现加特征词守卫。**回归**：同一 body.txt 在「已出版」与本 skill 下 AIGC 输出逐项一致（7196 词 / CV 0.96 / 密度 2.36）；`titles_match` 单元用例 5/5 通过（含 `U. S.` 缩写、副标题、大小写）。③ frontmatter 版本号由陈旧 2.18.0 校正为 2.19.1（文档/代码漂移）；TOOL_NAME/config 升 v2.19.1 |
| v2.19.0 | 2026-09-16 | **新增第 8 策略 `gbt7714`（GB/T 7714 带 `[J]` 标识）+ 修复作者撤稿表格「档 3 被渲染成同名误报」的假阴性缺陷**。**① 参考文献解析（新格式）**：CES 新投稿（观点文章，13 条）参考文献为 `[1]作者列表. 标题 [J]. 期刊, 年, 卷(期): 页码.`（中文期刊英文著录，**年份在期刊名之后**、编号后紧跟作者），7 策略均无法正确覆盖——`numbered` 以 0.735 分被选中，产出**年份全空、作者混入标题、文章号被腰斩**（`Water Research, 2021, 194: 116922` → volume=`11692`/page=`2`）的垃圾结果，且 **`parse_failed` 为空**（第二类静默失败：不是"失败被当成功"，而是"错得看起来像成功"）。新增 `scripts/parse_refs_gbt7714.py`：以 **`[J]` 类文献类型标识为锚点**（`[J]/[M]/[C]/[D]/[R]/[P]/[S]/[N]/[EB/OL]` 等白名单，无标识即判 parse_failed 交其他策略，故不误抢既有格式）；作者/标题边界两级判定（`et al.` 锚点 → 句点候选切点：**前缀像作者列表 且 后缀像标题**）；作者列表判据**禁绝小写多字母词**（of/the/and 即判否，用于挡住 Title Case 标题片段），标题判据 ≥4 词且 ≥2 个长词且**本身不是作者列表**——**不得用「含小写长词」**（Title Case 标题小写词仅 of/in/the/for，本稿 [10] 因此曾被误否）；右侧 `期刊, 年, 卷(期): 页码` 提取，卷期只留卷号、**页码整体保留**（`1426-35`/`e1704`/`lxaf004`）。实测 13/13 字段全对，`gbt7714` 1.0 分自动选中。**② 作者撤稿表格假阴性修复（安全级）**：`gen_report.build_author_results` 对**任何有命中的作者**硬编码「领域均非本稿相关（如 …），基本判定为同名误报」——该文案只对应三档分类的**档 2**。本稿 Jun Ma 有 39 条同名命中，其中 1 条（`Hydrothermal modification of granular steel slag for phosphate removal`，`retraction_doi=10.1109/icbbe.2011.5780148`，撤稿日期 2011-05-31，原因 Notice - Limited or No Information）作者机构含**哈尔滨工业大学市政环境工程学院**、主题为**水中磷酸盐去除**，与本稿**同机构同领域**（档 3），默认文案会把"需重点核实"渲染成"已排除风险"。修复：新增 `author_verdicts` 覆盖机制（`[report_content]` 字段，机制同 crossref 的 `review_note`），SKILL.md 三档规则处新增 ⛔ 硬规则——判定档 3 时必须写 `author_verdicts` 覆盖并附 `retraction_doi`/机构比对依据，档 2 才可用默认文案；并明确**机构相同优先于学科分类相同**（subject 分类粒度粗，如 `(PHY) Engineering - General`，单看分类易漏判）。**③ 自检加严**：Step 3 自检新增「`parse_failed` 为空不足以判定成功」「所选策略得分须接近 1.0（明显偏低即格式未被真正覆盖）」。**④** TOOL_NAME/config 升 v2.19.0。**回归**：`numbered_year` 式（CES Constraint-Aware Urban Scaling 30 条）仍选 `numbered_year` 1.0、`gbt7714` 得 0.0，不干扰 |
| v2.18.3 | 2026-09-14 | **修复参考文献结论段与汇总表口径不一致（措辞级）**：报告「1 检测结论摘要」要点与 4.2 节核心结论段曾写「27 篇与 Crossref 记录**完全匹配**」，而 4 档汇总表「完全匹配」档实为 **24** 篇（另 3 篇是年份相差 1 年的「微小差异」）——**把档位名当成跨档总数**，同一节内自相矛盾，易让编辑误读为"全部逐项核对无误"。4.2 节新增硬规则（v2.18.3）：核心结论段与检测结论摘要要点**禁止用档位名（完全匹配/微小差异/差异较大/无法定位）描述跨档总数**，须**逐档列数且合计 = 文献总数**；档位名仅在需对照汇总表时加引号直接引用。**实测（CES 新投稿 Constraint-Aware Urban Scaling 报告重渲染）**：摘要要点与 4.2 结论段改为「24 篇逐项一致，3 篇仅年份相差 1 年；1 篇年份相差 5 年，2 篇为 Crossref 未收录的非期刊文献」，24+3+1+2=30 闭合、与汇总表逐档对齐；TOOL_NAME/config 升 v2.18.3 |
| v2.18.2 | 2026-09-14 | **修复「解析失败被当成功」缺陷 + 新增第 7 策略 `numbered_year`（皇家学会/SPJ 式）+ 缩写期刊名误报治理**。**① 关键缺陷（安全级）**：`parse_refs_auto._adapt_legacy` 弹出 `parse_failed` 后未回填，`run_strategy` 再 pop 一次得 `False` → **解析失败被误判为成功**并混入 refs，产出「字段全空的文献」，而 stdout 的 `parse_failed` 汇总仍显示为空（自检失效）→ Crossref 会把全部文献报成「无法定位」，制造"整篇文献不可信"的假象。**② 新增第 7 策略 `numbered_year`**（`scripts/parse_refs_numbered_year.py`）：编号+裸年份紧跟作者（`1. 作者. 2007 标题. 期刊 卷, 页码. (doi:…)`，皇家学会/SPJ 系刊常用），此前 6 策略全部失败（F4 要求年份前为逗号、本类为句点；F6 要求 `年;卷` 分号、本类为 `卷, 页码`）——以「句点+4 位年+空格」唯一锚点切分作者/正文，**先提 DOI 再删整段 `(doi:…)` 括注**（否则残留 `(doi:` 挂期刊尾令卷页正则失配），标题边界用「候选切点扫描 + 余段是否像期刊名」判定（同时覆盖 `Is this scaling nonlinear?` 的问号结束标题 与 `Building in or out? Examining …` 的问号在标题内部），卷页右锚定提取、报告/代码库条目剥 `no. NN` 后缀。**③ 缩写期刊名误报治理**：`journals_match(strict=True)` 对 ISO 缩写刊名改走「顺序无关词覆盖 + Crossref 副题剥离」三重约束（仅缩写形式生效、未覆盖词限短全大写限定词、Crossref 副题剥离后内容词须被全覆盖），修复 PNAS/`J. R. Stat. Soc. B`/`Eur. J. Popul` 等 7 条误报且不回归 `Adv. Mater.` vs `Advanced Materials Interfaces`、`Nano Energy` vs `Nano Energy Letters`；**④ 标题比对支持 Crossref `subtitle`**（`get_crossref_title` 拼接 subtitle + `titles_match` 按 `:` 截断单向回退）。**⑤ 报告口径一致性**：4 档汇总表把有 `review_note` 的 not_found 单列「需人工复核（已甄别）」（黄），不再计入「无法定位」（红），消除"汇总标红 / 明细标黄"的自相矛盾。**实测（CES 新投稿 Constraint-Aware Urban Scaling，docx，30 条，`numbered_year` 式）**：修复前 30/30 全空 → 修复后 30/30 全解析（策略自动选中 `numbered_year` 1.0 分、其余 6 策略 0.0）；Crossref 27 完全匹配 + 1 条年份存疑（Cybergeo 稿内 2006 vs Crossref 2011，DOI 后期补挂）+ 2 条非 Crossref 收录（欧盟出版局 DOI 返回 404、GitHub 代码仓库，均写入 review_note）；期刊/标题匹配回归用例 27/27 PASS；TOOL_NAME/config 升 v2.18.2 |
| v2.18.1 | 2026-09-09 | **参考文献解析支持无编号 NLM/Vancouver（第 6 策略）+ 差异明细人工甄别注记（review_note）**：① `ref_common.py` 新增 `split_entries_nlm` 无编号切分 fallback——常规作者起始正则（`Surname, I.` 形）0 命中时自动回退，以「首词形似姓氏（大写词或 de/van/der 等西欧冠词前缀）+ 行内含 `\d{4};` 年;卷锚点」双重条件判定条目起点（防 PDF 折行续行误判）；② 新增 `scripts/parse_refs_noidx_vancouver.py`（F6，无编号 NLM：`Reddy R, Adamu M, ... Title. Journal. 2025;76:107371.`，作者为「姓 名缩写」逗号分隔、年份在期刊名后、卷页 `;` 分隔）——从行尾倒推切分（剥 年;卷(:页) → 剥 DOI/URL → `. ` 段拆 作者/标题/期刊，作者段尾 `et al` 剥离），与既有 5 策略并列打分自动选中；③ `gen_report.py` 差异明细表支持 `review_note` 人工甄别注记字段：agent 对差异/未定位条目做 ISSN 定向复核后写入甄别结论，渲染时优先用注记文案且 **not_found 风险度由「不可信」（红）降级为「需人工复核」（黄）**——依据「检测不到≠不存在」（中文期刊大量未入 Crossref：岩土力学/岩石力学与工程学报仅收 2024/2025 年起、岩土工程学报/工程地质学报/土木与环境工程学报未收录、Techno-Press/CET 收录不全），杜绝「检索不到=疑似编造」误报；④ 版本常量 TOOL_NAME/config 升 v2.18.1。**实测（CESCI-D-26-00016R1，docx，无编号 NLM 54 条）**：v2.18.0 解析 0 条 error → 修复后 54/54 全解析、策略自动选中 noidx_vancouver（1.0 分）、字段抽查全对（含 et al 剥离/连字符缩写 `Sun Y-l`/冠词姓氏 `de Oliveira`/`dos Santos`）；Crossref 核验 42 完全匹配+1 年份差 1 年，11 条经 ISSN 定向复核全部写入 review_note（2 条实为同篇刊名著录差异、9 条收录盲区），报告无一条「不可信」误报。已出版 skill 报告渲染路径不同（差异明细走 report_content），review_note 机制不适用无需同步 |
| v2.18.0 | 2026-08-30 | **参考文献解析自动化（六种格式自适应 + 预印本处理）**：① 新增 `scripts/ref_common.py` 公共库——定位 References（容错 PDF 页码前缀）、**页码水印稳健识别**（覆盖率≥60% + 相邻差 0~2 + 首值 1~2000 三重判定，不再误删行首数字）、条目切分（支持 `[1]`/`(1)`/`1.`/`1)`/`1␣␣` 及无编号，含**编号连续性校验**，修复 `2023).` 被误判为条目编号）、统一清洗（DOI 回捞、期刊名迭代剥离卷/期/页、标题混入作者二次切分）、预印本识别；② 新增 `scripts/parse_refs_auto.py` 统一入口——采样前 10 条**多策略并行打分**（0.6×成功率 + 0.2×字段完整度 + 0.2×年份命中率）选最优策略，全量执行后失败条目用次优策略兜底；③ 新增 `parse_refs_noidx_apa.py`（无编号 APA）、`parse_refs_vancouver.py`（裸年份）、`parse_refs_nature.py`（末尾年份，含期刊名缩写链累积补齐，修复 `Nat. Mater.` 被切成 `Mater.`）三个解析器，整合原 work/ 下临时脚本；④ `parse_refs_apa.py` 定位对齐页码前缀 + **续行合并**（原逐行处理会丢弃跨行条目，PDF 稿件实测 0 条→31 条）；⑤ **预印本处理**（v2.18.0 决策：保留撤稿检测）——识别 arXiv/bioRxiv/medRxiv/SSRN/ChemRxiv/Research Square，写入 `is_preprint` 等字段；Crossref 未收录时状态降为 `preprint_not_indexed`（"预印本·未收录"，**不计入不可信**），撤稿检测照常；报告 4.2 节新增"本文共 N 篇来自预印本"统计提示；⑥ Step 3 改为调用 `parse_refs_auto.py`，删除"人工判断格式后手选脚本"的旧约定。**踩坑记录**：清洗正则禁用嵌套量词（`^(?:[A-Z]\w*(?:\s+[A-Z]\w*)*\s+et al)` 会触发灾难性回溯使进程静默退出），改用非贪婪限长 `^.{2,60}?\bet\s+al`。**实测回归**：EMD20260058（无编号APA 50 条）/059（Vancouver 27 条）/060（Nature 47 条）/061（编号APA+PDF页码 31 条）策略自动选中全部正确，解析失败 0 条；TOOL_NAME 升 v2.18.0 |
| v2.17.1 | 2026-08-24 | **修复作者撤稿表格旧措辞（文档/代码漂移）**：v2.16.1 仅改 SKILL.md 三档分类档2 规则与 agent 摘要文案，漏改实际渲染代码 `scripts/gen_report.py` 的 `build_author_results`——作者撤稿检索表格「说明」列硬编码「基本排除同名误报」，致生成报告表格仍输出旧措辞；本次统一改为「基本判定为同名误报」（与 SKILL.md 规则一致）。回归提醒：今后措辞类修改须同时覆盖 SKILL.md 规则与 gen_report.py 渲染两处；TOOL_NAME 升 v2.17.1 |
| v2.17.0 | 2026-08-21 | **期刊记录双层数据源（用户数据保护）**：① 新增 `scripts/journal_scopes.py`——`assets/journal_scopes.json` 为**用户文件**（个人积累的缩写-全称-网页记录，**禁止进分享包、升级永不覆盖**），`assets/journal_scopes_template.json` 为**内置模板**（进包、随版本更新，同步为完整 9 条内置记录）；读取统一走 `load_all()` = 模板 ∪ 用户合并、同缩写冲突时**用户优先**（full_name 一致静默、不同才提示）；用户文件缺失时首次运行自动从模板初始化；`save_scope()` 只写用户文件；② preflight.py `load_journal_scopes`/`save_journal_scope` 与 gen_report.py `load_journal_info` 全部改走公共模块（消除两处读取逻辑漂移）；③ 打包脚本 `package_skill_local.py` 增加 `EXCLUDE_FILES`（assets/journal_scopes.json 禁止进包）——解决同事安装早期版本后升级会丢失个人记录的问题（解压覆盖不触碰包外文件）；④ SKILL.md Step 0.5 首次运行判断与 Data Safety 同步双层规范；TOOL_NAME 升 v2.17.0 |
| v2.16.2 | 2026-08-21 | **期刊缩写匹配补字符子序列（EMD20260110 实战，8 条 journal_mismatch 误报修复）**：① `_word_match` 匹配条件由纯前缀扩展为「相等 / 字符串前缀 / 字符子序列（短词 ≥2 字母）」——经典缩写省略中间字母（`compd` ⊂ `compounds`、`abstr` ⊂ `abstract`）此前 startswith 前缀漏配，实测 `J Alloys Compd` vs `Journal of Alloys and Compounds` 6 条误报；② **子序列分支排除停用词**（`_SKIP_WORDS`）——停用词 `in` 是 `semicond` 的子序列会误配、破坏 strict 顺序消费，实测 `Mater Sci Semicond Process` vs `Materials Science in Semiconductor Processing` 2 条误报；修复后 EMD20260110 165/165 全通过（含 9 篇年份±1 微小差异），strict 仍拦截真实刊名差异（Nano Energy vs Nano Energy Letters）不回归。另：Vancouver 风格参考文献（`作者. 标题. 期刊 年份;卷:页码. DOI`，年份无括号）parse_refs.py 无法解析，本次用临时解析器（句点+期刊缩写启发式）164/165 成功 + 1 条手工补全——如 Vancouver 格式稿件增多可考虑固化脚本；TOOL_NAME 升 v2.16.2 |
| v2.16.1 | 2026-08-21 | **作者撤稿三档分类措辞修正**：档 2「有命中但领域不同」文案由"基本**排除**同名误报"改为"基本**判定为**同名误报"——原表述"排除"宾语缺失易误读为"排除了误报=命中的是真的、风险高"，实际语义是"判定这些命中属同名不同人（同名误报）、不构成风险"；"判定为"直接陈述判断结果，消除歧义。已生成报告（如 EMD20260090 summary.author）中的旧措辞如需同步可重渲染 |
| v2.16.0 | 2026-08-20 | **期刊名 and/& 归一化 + 报告 4.x 节重编号**：① 期刊核对修复——`_journal_tokens` 先 `html.unescape` 解码 `&amp;` → `&`、再 `&` → `and`（Crossref 返回的期刊名常带 HTML 实体，如 `Energy &amp; Environmental Science`，旧逻辑 `&amp` 成为卡死 strict 匹配的脏 token 致 journal_mismatch 误报）；"X and Y" / "X & Y" / "X &amp; Y" 视作相同，仅此差异不报告、视为无差异；真实刊名差异（Nano Energy vs Nano Energy Letters）仍报告；② 报告 4.x 节重编号（引用分布与著录默认隐藏，为保持编号连续）：原 4.2 引用分布与著录 → **4.4**、原 4.3 Crossref 真实性验证 → **4.2**、原 4.4 Retraction Watch 撤稿检索 → **4.3**；隐藏时 4.1→4.3 连续编号（不再跳号）；模板/脚本/SKILL.md 同步；TOOL_NAME 升 v2.16.0 |
| v2.15.0 | 2026-08-20 | **综合体检整改（软件工坊专家团：安全/稳定/性能/阈值 31 项发现落地）**：① **安全·F-01 XSS**——gen_report.py 所有稿件/撤稿库/journal_scopes 动态值统一 `html.escape` 转义、scope_url 校验 https 后仅作文本显示、badge class 白名单、模板加 CSP+nosniff；② **安全·F-02 SSRF**——preflight `--scope-url` 仅 https + 私有/环路/链路本地地址拒绝 + allow_redirects=False；③ **安全·F-03 依赖锁版**——requirements.txt 精确版本 ==（rapidfuzz/requests/pdfplumber/python-docx/defusedxml）；④ **安全·F-04 下载完整性**——meta 记录 commit_sha + sha256（比对历史可发现篡改）；⑤ **安全·F-05 PIPL 留存**——报告隔离目录建议、模板含隐私提示、Data Safety 增留存期限与 PIPL 澄清；⑥ **安全·F-06 docx 安全解析**——defusedxml + zip 成员/大小上限（extract_docx/preflight）；⑦ **安全·F-07 DOI 校验**——`^10\.\d{4,9}/…` 正则 + quote（防 CRLF 注入）；⑧ **安全·F-08/F-09**——下载 tmp 唯一化（带 pid）、batch 临时文件落系统 temp 隔离目录；⑨ **AIGC·P0-1**——`aigc_stats.py` 子串 `.count()` 改词边界正则（"significantly" 不再吞并 "significant"）+ 强/弱词分档（强词×2 加权）；⑩ **AIGC·P0-2**——句长 CV 判级方向修正（CV<0.3=趋同=AI 特征，原 ">0.7 异常均匀" 与统计原理相反）；⑪ **AIGC·P1-3**——密度阈值重标定 >3 可疑/>8 高度（加权口径）；⑫ **稳定·S1**——batch 子进程加 600s 超时（防卡死）；⑬ **稳定·S2**——ensure_csv 调用包 try + GitLab 日期 fromisoformat 容错（异常返回 download_failed JSON 而非裸崩溃）；⑭ **稳定·S3**——Crossref 网络失败单列 `status=error`（未能核验，非不可信）；⑮ **稳定·S4/S5**——check-refs >40 篇护栏、batch 默认 40→20（每篇 2 次 extractOne，20 篇=40 次调用低于崩溃阈值）；⑯ **稳定·S6**——batch 合并 total_references 取全量（修复只反映首批缺陷）；⑰ **稳定·S8**——preflight 复用 extract_docx 提取（消 Mendeley sdt 虚假告警）；⑱ **稳定·S9/S10**——各 CLI main 包 try + references 非 list 入口报错；⑲ **性能·P1/P2/P3/P5**——RW CSV 只加载一次 + 姓索引 + 标题倒排索引 + DOI 索引（缓存 `cache/rw_index.pkl`，作者检核 80-95% I/O 消除、标题匹配 10-50× 提速并缓解 rapidfuzz 崩溃）；⑳ **性能·P4**——Crossref 响应缓存 TTL 7 天（cache/crossref_cache.json）；㉑ **性能·P6/P2-3**——无 DOI 文献两级标题查询并行、rows 10→15；㉒ **阈值·P1-1**——短标题共同词过滤轴修正（以命中标题短为条件，不误杀真命中）；㉓ **阈值·P2-1**——期刊核对用 strict 匹配（Nano Energy vs Nano Energy Letters 报 mismatch，评分仍宽松）；㉔ **阈值·P2-2**——RW_MIN_ROWS 50000→55000；㉕ **阈值·P2-5**——affiliation_check 输出 domain_hint（供「待核实」判定）；㉖ **收敛**——新增 scripts/config.py（路径/UA/mailto 统一，PANDA_MAILTO 可覆盖）、common_stats.py（年份分桶去重）；触发词补全（撤稿排查/参考文献真实性/引用验证/送审前筛查）+ 新稿/已出版区分说明；TOOL_NAME 升 v2.15.0。验证：15 脚本 py_compile 全过、AIGC 词边界/SSRF 8 例/年份分桶/类型防护/DOI 注入/刊名 strict 全 PASS、gen_report XSS 转义渲染 PASS、真实 65MB CSV 索引化（7.1 万行 1.7s 加载、作者/标题检索毫秒级） |
| v2.14.0 | 2026-08-19 | **期刊前缀匹配 + 差异只列差异部分 + 4.2 默认隐藏**：① `journals_match` 改为**纯字符串前缀匹配**（稿件期刊名每词是 Crossref 记录按序对应词的前缀/相等，"Rev" 与 "Revxxxx" 视为匹配，允许跳过 cr 介词词，双向；**删除 JOURNAL_ALIASES 别名表与 normalize_journal**，不判语义——已知边界：前缀包含（Nano Energy vs Nano Energy Letters、J. Mate. Chem. A. 拼写错误）亦判匹配，用户确认）；② **差异只列差异部分**：新增 `title_diff` 词级 diff（difflib，只列差异词、相同内容省略，`title_mismatch: 稿内「…」vs Crossref「…」`），year_mismatch/journal_mismatch 保持只含差异；build_refs_verify issues_found desc 去掉固定完整标题前缀；③ **4.2 引用分布与著录默认隐藏（非删除）**：report_content 缺 refs_citation_issues/citation_gaps → 整节（含 h3）不渲染（4.1→4.3 跳号属预期），写字段即启用，旧数据重渲染仍显示（向后兼容）；模板 4.2 改单占位符 {{REFS_CITATION_SECTION}}，gen_report 新增 build_refs_citation_section；TOOL_NAME 升 v2.14.0 |
| v2.13.1 | 2026-08-19 | **修复 4.4 节 refs_rw 缺失降级 bug**：用户跳过文献检查时，`gen_report.py` 的 `build_refs_rw_check` 在 `refs_rw.json` 缺失（None）时误落「0 篇存在真实撤稿记录」（实际未检索，会造成「已执行撤稿检索」误导）；统一与 Crossref 一致——`refs_rw` 为 None 时降级渲染「未检测」，与其他检测 JSON 缺失→「未检测」降级规则对齐；TOOL_NAME 升 v2.13.1 |
| v2.13.0 | 2026-08-18 | **Crossref 无法定位误报修复 + 判定阈值放宽**：① 标题检索 rows **3→10**——rows=3 截断目标文献（EMD20260090 实测 9 条 not_found 中 6 条目标排第 4-7 位、rows=10 后 score=13 全匹配）；② 新增**兜底检索 `query.title=` rows=20**（`query=` bibliographic 全字段被同类文献淹没的 3 条 [30][34][46] 全部救回，目标第 1-2 位）；③ 接受条件放宽（用户确认）：总分 **≥6 且标题必要**（原 8；标题不匹配即使 7 分也拒绝，防 [3] 类"期刊+年份+作者=7 但标题完全不同"误配），titles_match token 重叠 **70%→65%**；DOI 分支同步（score≥6 且标题匹配，否则 issues_found 人工复核）；TOOL_NAME 升 v2.13.0。验证：EMD20260090 not_found 9→0、CESCI [3] 仍拒（标题不匹配）、EMD20260103 218 篇不回归 |
| v2.12.0 | 2026-08-18 | **引用统计固化为脚本 + 差异明细表年份合并行**：① 新增 `scripts/citation_stats.py`——正文+表格引用统计**强制用脚本、禁止 agent 手写**（EMD20260103 实测：手写代码只 split 不区间展开，`[2-5]` 仅计 {2,5} 致 **57 篇"未引用"全部误报**，重算实际 0 未引用）；脚本自动处理逗号列表/带空格/hyphen 与 en-dash 范围并区间展开，输出 cited/uncited/over_range；② gen_report.py 差异明细表：微小差异（年份差 1 年）**不再逐条**，合并为一行（所有文献号 + 差异说明「年份相差1年」+ 低风险徽章），位于逐条之后、著录不完整合并行之前；逐条仅剩差异较大（需人工复核）/无法定位（不可信）；TOOL_NAME 升 v2.12.0。**同日 EMD20260090 实战修复（并入本条）**：③ crossref_check normalize_journal 兼容循环修复——v2.11.1 的 k_norm 去点后**未压缩空格**（`'adv. energy mater.'` → `'adv  energy mater'` 双空格 ≠ name 单空格），导致**带点缩写键从未命中**、APA 风格文献全部 journal_mismatch 误报（EMD20260090 实测 30 条）；④ JOURNAL_ALIASES 补 EMD 系常见缩写（chem. sci./chem. commun./surf. innov./mater. today sustain./j. electrochem. soc./scr. mater./sci. china chem./int. j. appl. ceram. technol./appl. surf. sci.） |
| v2.11.1 | 2026-08-18 | **parse_refs 页码可选 + 差异明细表重构**：① parse_refs.py 删除"年份后必须有页码"要求（页码可选），缺年份条目容错（year 留空、视为不影响可信度的信息缺失），卷号组收紧为纯数字（防期刊名末词误吞）——EMD 218 篇全量解析 0 失败；② 差异明细表"著录不完整"项目合并为一行置尾（所有文献号 + 问题按规范词归组，如 `缺页码（4、23、25、26）；缺作者与期刊名（16、18）`）；③ 差异明细表加入微小差异/差异较大/无法定位逐条（含"稿件 vs 匹配记录"差异分析），微小差异风险度"低风险"（黄），[16] 类两处都列；TOOL_NAME 升 v2.11.1。**同日 EMD 实战修复（并入本条）**：parse_refs AUTHOR_RE 扩展——Unicode 字母姓（č/ü/á/ž）、多词姓（de Larramendi）、直/弯撇号（O'Malley）、多缩写（L. M. Da Silva），否则作者混入标题致 title_mismatch 误报；crossref_check JOURNAL_ALIASES 键兼容带点/无点（旧键此前从未命中致缩写失效）+ 补 Chem Rev/Adv Mater/Adv Sci (Weinh)/J Am Chem Soc；titles_match 剥离 Crossref 富文本标签（sub/sup 连同周围空白删、i/b 只删标签）；batch_check_refs 移除 unlink（沙箱 safe-delete 拦截无法兜底）+ 子进程输出无效自动重试（rapidfuzz 随机原生崩溃） |
| v2.11.0 | 2026-08-18 | **报告格式六项简化（固定格式）**：① 第 1 节摘要表要点只写汇总数据（禁作者名/DB 版本/机构名/文献编号/AIGC 特征词），**删除结论区**（{{CONCLUSION}} 与 conclusion 字段废弃）；② 4.1 年份表下 year_stats_note 只留总体评价一句、脚本加粗渲染；③ 4.2 删除「著录不完整条目」段，著录信息转 `refs_verify.incomplete` 并入 4.3 差异明细表（需人工复核/黄）——并说明 4/11/16/18/23/25/26 此前仅入 4.2 的根因（著录规范性 vs 真实性维度，[16]"无法定位"系旧版遗留表述）；④ 引用空洞检查从 AIGC 节移入 4.2 末尾（新增 {{CITATION_GAPS}}/citation_gaps）；⑤ 4.3 差异说明改具体对比、移除分值——crossref_check.py low_score 分支保留最佳候选标题供对比（source 去分值），无候选则写"未定位到匹配记录"；⑥ 4.3 差异明细表三类合并（issues_found/not_found/incomplete），按 index 归并、risk 取重；TOOL_NAME 升 v2.11.0 |
| v2.10.1 | 2026-08-18 | **4.3 Crossref 渲染重构**：① 开头新增 4 档汇总表（完全匹配/微小差异/差异较大/无法定位，含数量与占比，脚本自动从 crossref.json 算，配色绿/黄/黄/红）；② 差异较大 + 无法定位用 3 列详细表呈现（文献编号/差异说明/风险度徽章）；③ 移除 v2.10.0 "信息差异（非不可信）"逐条表（汇总表已覆盖）；④ 移除"人工复核明细"列表（agent 不再写 manual）；TOOL_NAME 升 v2.10.1 |
| v2.10.0 | 2026-08-18 | **报告敏感度与 Crossref 验证规则更新**：① 第 1 节 conclusion 只留整体评估一段（禁止分项/具体细节如文献编号）；② 4.2 不再报告"文献多次引用"（属正常）；③ 4.3 降低敏感度——作者姓名表达差异、起页一致仅格式差异等通过类一律不报告（manual 只留需复核项）；④ Crossref 验证权重改为 标题+6/期刊+4/年份+2（\|diff\|≤1 视为匹配）/作者+1（宽松：缩写/倒置/复姓），满分 13、阈值 8（标题必要）；年份差 1 年记「信息差异」（脚本自动渲染信息差异表）、差>1 年不可信；卷/页差异不作信号；⑤ 检索策略：有 DOI → DOI 检索命中后统一打分确认（<8 判 issues_found 人工复核），无 DOI → 标题检索；crossref_check.py 作者姓氏改候选集合提取、移除 author/page/volume mismatch；gen_report.py build_refs_verify 增「信息差异（非不可信）」表 |
| v2.10.0 | 2026-08-18 | **固化 CESCI20260019 实战经验 2 条（与已出版 v3.9.0 对齐）**：① 引用统计正则升级——支持带空格编号组（`[49, 50]`）与 **en-dash 范围**（`[5–7]`、`[12–15]`），正则 `\[(\d+(?:[-,–]\s*\d+)*)\]`（hyphen/en-dash 双支持），4.2 节提示同步；② refs.json 必须为纯 list 格式——crossref_check/check-refs 不接受 dict 结构（`{"refs":[...]}` 会 TypeError），解析后须单独落盘 refs 数组 |
| v2.9.1 | 2026-08-17 | **报告格式两处微调（v2.9.0 修订）**：① 第 2 节「期刊收稿范围对照依据」块由表格改为**纯文本段落**（来源 + 版本日期 + 中文收稿范围，build_scope_header 移除 table 渲染）；② 3.2 机构适配表「判断依据」列删除「（来源：Title page）」与「仅基于机构名称语义判断，未联网核实」——后者改为**表格下方固定 note**（build_affiliation_table 自动追加），机构来源不再展示；TOOL_NAME 升 v2.9.1 |
| v2.9.0 | 2026-08-17 | **输出报告格式四项更新**：① 第 2 节起始固定渲染「期刊收稿范围对照依据」块（来源 URL + 版本日期 + 概括性中文收稿范围），数据存于 `assets/journal_scopes.json`（新增 scope_source/scope_version_date/scope_summary_zh/editorial_board 字段，报告不展示编委与英文原版 scope）；② 内容相关性分析改 4 列表格（分析维度/稿件特征/对应期刊领域/匹配度徽章），`scope_content` → 结构化 `scope_analysis`，脚本渲染 `{{SCOPE_ANALYSIS_TABLE}}`；③ 3.1 作者撤稿检索删除「检索方法」「受检作者」（模板与 build_author_results note 移除，{{AUTHOR_LIST}} 删除），所有作者以表格列出；④ 3.2 机构适配改 3 列表格（机构/判断依据/适配度徽章，一行一个机构），`affiliation_results` → 结构化 `affiliation_analysis`，脚本渲染 `{{AFFILIATION_TABLE}}`；gen_report.py 新增 load_journal_info/build_scope_header/build_scope_analysis_table/build_affiliation_table，TOOL_NAME 升 v2.9.0 |
| v2.8.0 | 2026-08-17 | **同步已出版 v3.8.0 实战经验 4 条 + 2 脚本（与已出版对齐）**：运行环境陷阱新增——① rapidfuzz 累积原生崩溃（>50 篇用 batch_check_refs.py 分批）；② batch_check_refs.py 合并 total_references 只反映第一批（40/52），须核对手动合并各批 out.json；③ APA 风格参考文献须用 parse_refs_apa.py（parse_refs.py 会解析失败），且解析后须二次清理卷/页/DOI（`doi:\s*(10\.\S+)` 提取 + `^(.*?)\s+(\d+),\s*([\d\u2013-]+)$` 拆分）；④ 引用统计正则须支持带空格编号组 `\[(\d+(?:[-,]\s*\d+)*)\]`（表格引用 `[49, 50]` 漏匹配会误报未引用）；同步复制 `scripts/parse_refs_apa.py`、`scripts/batch_check_refs.py`（相对路径依赖，可移植） |
| v2.7.0 | 2026-08-17 | **报告生成脚本化（固定渲染模式，与已出版 v3.7.0 同步）**：新增 `scripts/gen_report.py`（零第三方依赖，stdout 机器可读 JSON）；新增「检测结果落盘约定」——Step 1-4 结果写入 `work/<稿件标识>/`（geo.json/refs.json/crossref.json/authors.json/refs_rw.json/aff.json，新增 aigc.json 约定）；Step 5 改为「agent 写 report_content.json（仅判定内容）→ 运行 gen_report.py」；年份分布/作者撤稿表/政治风险/撤稿检索/AIGC 指标表由脚本自动生成；`refs_verify.summary` 必须 agent 写（crossref.json 原始计数为复核前数据）；report_content 缺失字段→error，检测 JSON 缺失→对应段「未检测」降级 |
| v2.6.0 | 2026-08-17 | **摘要表结论列精简（与已出版 v3.6.0 同步）**：检测结论摘要表「结论」列仅保留风险徽章（无风险/低风险/需修改/需修订/未检测），删除「高度相关」「无撤稿记录命中」等判定徽章——判定已作为「要点」列开头文本体现，避免重复 |
| v2.5.0 | 2026-08-17 | **输出格式六项规范（与已出版 v3.5.0 同步）**：① 机构名称中文化（中国=学校+学院、国外=国名+学校+学院，不含省市街道邮编）；② 删除副标题行、生成日期并入 meta「检测工具」行（TOOL_NAME 升 v2.5.0）；③ 删除 {{COVERAGE_NOTE}} 维度覆盖清单，未检测维度改为摘要表结论列灰「未检测」+要点列写原因；④ 第 1 节合并为单表（结论列=风险徽章+判定徽章并排、要点列=判定+详情），{{CONCLUSION}} 不再含表格；⑤ 删除 {{RW_SOURCE}} 数据来源重复说明（日期由 meta「撤稿数据库版本」承载，正文不再重复）；⑥ 4.3 Crossref 通过文献仅汇总数量、信息不一致/无法定位文献列表格（页码起页一致仅格式差异按通过） |
| v2.4.1 | 2026-08-17 | **撤稿检索去噪（共同单词数过滤）**：标题模糊匹配新增过滤——文献标题字符数>3 时，与撤稿库标题共同单词数≤3 的命中不报告（即使匹配分 100），解决短标题 partial_ratio 子串误报（如 EMD20260109 [115] "Monitoring" 单词语条目 100 分命中）；实现：`check_reference_titles` 新增 `_common_word_count` 辅助函数 + 两分支汇合后插入过滤；与已出版 v3.4.1 一致 |
| v2.4.0 | 2026-08-17 | **报告章节结构统一（与已出版一致）**：稿件基本信息改为不编号小号字 9 字段（文件名/期刊全名/标题/作者/机构/类型/参考文献/撤稿数据库版本/检测工具，新增 REFS_COUNT/RW_UPDATE_DATE/TOOL_NAME）；政治风险移至稿件基本信息后（POLITICAL_RISK 条件占位符）；检测结论摘要并入维度覆盖(COVERAGE_NOTE)与总体结论(CONCLUSION)；章节重排为 2 内容相关性 / 3 作者诚信(3.1 撤稿、3.2 机构适配，AFFILIATION_RESULTS 拆出) / 4 参考文献(4.1-4.4) / 7 AIGC；模板与 SKILL.md Step 5 同步 |
| v2.3.4 | 2026-08-17 | **参考文献解析脚本化**：新增 `scripts/parse_refs.py`（[n] 编号解析，年份锚定回溯卷/页/期刊，作者标题分界；行尾 DOI 自动剥离提取，有/无 DOI 均适用；References 定位行级截断；parse_failed 供人工补全）；Step 3 输入补充解析说明，与已出版完全一致 |
| v2.3.3 | 2026-08-17 | **AIGC 检测脚本化**：新增 `scripts/aigc_stats.py`（8 项定量指标：词数/句数/平均句长/句长变异系数/TTR/AI 提示语密度 19 短语/首人称/近重复句对，自动排除 References 节，行级截断）；Step 4 改为「脚本算指标 + agent 判级」混合模式（引用空洞与综合判级仍由 agent 负责）；修复 References 排除为稳健行级截断（兼容独立行/带编号标题/首个 `[N]` 回退），与已出版完全一致 |
| v2.3.2 | 2026-08-17 | **Mendeley 解法脚本化**：新增 `scripts/extract_docx.py`（XML 递归遍历 body 覆盖 `w:sdt`/表格，输出全文 txt + 段落 JSON，保持文档顺序）——将「运行环境陷阱」第 2 条（Mendeley SDT 参考文献提取坑）的规避方法固化为可调用工具；SKILL.md 对应条目补充脚本引用，docx 文本提取一律用它 |
| v2.3.1 | 2026-08-17 | **实战经验固化（三条）**：新增「运行环境陷阱」小节——① Git Bash heredoc 传递 Python 源码会破坏反斜杠转义（`\s` 被静默改写为 `/s`，正则失效），一律改用 .py 文件运行；② docx 参考文献可能存放在 Mendeley SDT 字段中（python-docx 会漏提取），须用 XML 深度遍历；③ Crossref 核验新增 author_mismatch 三类误报甄别（多作者取末姓 / et al. 占位 / 弯直引号差异），DOI+标题+期刊一致时按误报处理；frontmatter 补 `agent_created: true` |
| v2.3.0 | 2026-08-17 | **新增政治敏感词扫描**：新增 `scripts/geo_check.py`（Taiwan/Tibet/Xizang 词干匹配，忽略大小写，含 Taiwanese/Tibetan 变体）；命中时报告开头插入第 0 条红字「潜在政治风险，请人工核查」+ 表格（关键词/完整句子/所属一级标题）；未命中完全不显示；Workflow 新增 Step 0.6 |
| v2.2.1 | 2026-08-14 | **降低 RW 下载频率 + 修复 RW 并发缺陷**：下载改为两步判定（第 1 步本地快筛：update_date 距今 <3 天不联网复用；第 2 步联网精确判定：(gitlab_date - 本地版本日期) > 3 天才下载；API 不可达回退保守下载一次）；csv_source 不再产生 `(GitLab API unreachable, source unverified)` 变体；Workflow 新增 Step 0.5 RW 数据准备前置步骤（串行执行一次），明确数据就绪后 check-authors/check-refs 可安全并行（仅只读 CSV），严禁未就绪时并行触发并发下载 |
| v2.2.0 | 2026-08-14 | **新增机构-领域适配性分析**：新增 `scripts/affiliation_check.py` 启发式提取作者机构（Title page + 正文，噪声过滤、去重）；Step 2 拆为 2a 撤稿检索 / 2b 机构适配性（两档：适配直接给结论 / 不相关附人工检查提示；检测不到机构 → 询问用户补充，不提供则报「未提供机构信息」）；**判断仅基于机构名称语义，禁止联网搜索机构信息**；报告「作者诚信」节新增机构适配子节 |
| v2.1.1 | 2026-08-14 | **实战经验固化**：has_authors 粗检正则误判提醒（"All authors declared..." 等声明字样会误判为有作者，agent 须人工确认）；page_mismatch 人工甄别规则（Crossref 仅返回起始页导致整页差异误报）；引用统计必须覆盖表格单元格（对比方法表直接以 [n] 标注出处）；journal_scopes.json 新增 CAI 期刊记录 |
| v2.1.0 | 2026-08-13 | **分享收尾**：journal_scopes.json 数据迁至 skill 内 `assets/`；preflight.py 路径改为基于 `__file__` 相对定位（可移植，无用户 home 依赖）；清理运行残留；新增 `requirements.txt` 与 `README.md`；启用 git 版本管理 |
| v2.0.0 | 2026-08-13 | **五项规格落地**：Crossref 礼貌池（mailto 入池、并发 3、429/5xx 指数退避）；check-refs DOI 锚定优先 + 标题模糊阈值 90 + 忽略大小写；check-authors 输出 Subject/撤稿 DOI 支持三档领域分类 + comma 陷阱校验；RW 数据目录迁至 skill 内 `data/`；报告保存到输入文件同目录并注明 update_date |
| v1.1.0 | - | check-refs 假阳性防护：过滤垃圾行与短标题（Guard 1/2） |
| v1.0.0 | - | 初始版本：四维检查 + 报告模板 |

## CRITICAL: signal, not verdict

本 skill 的所有发现都是**筛查信号**，不是定性结论。严禁：
- ❌ 说"这篇论文造假"、"这位作者有问题"、"这是 AI 写的"
- ❌ 用"实锤"等确定性表述
- ✅ 只报告"命中 N 条可疑模式"并建议人工核实
- ✅ 推荐走期刊编辑部 / PubPeer 等正规反馈渠道

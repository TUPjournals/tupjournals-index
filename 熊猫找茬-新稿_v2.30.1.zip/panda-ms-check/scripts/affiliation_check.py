#!/usr/bin/env python3
"""
affiliation_check.py — 作者机构信息提取

从稿件全文（含 Title page）中启发式提取作者机构信息，供「机构-领域适配性」分析使用。

Usage:
    python affiliation_check.py --text <全文文本文件>

Output (stdout): JSON
    {
      "status": "found" | "not_found",
      "affiliations": ["..."],
      "matched_lines": ["..."],
      "note": null | "未检测到机构信息"
    }
"""

import argparse
import json
import re
import sys
from pathlib import Path

# 机构关键词（英文词边界匹配，避免 "lab" 命中 "Eslab" 等子串；中文直接子串）
_ORG_EN_RE = re.compile(
    r"\b(?:university|college|school|institute|laboratory|lab|academy|"
    r"research center|research centre|department|hospital|faculty|"
    r"centre|center|corporation|company|ltd)\b",
    re.IGNORECASE,
)
ORG_CN = ["大学", "学院", "研究所", "研究院", "实验室", "医院", "中心",
          "学校", "科学院", "工程院", "集团", "公司"]

# 噪声行关键词（词边界匹配；多词短语整体匹配）
_NOISE_RE = re.compile(
    r"\b(?:supported by|funding|grant|sponsor|financed|declare|declaration|"
    r"corresponding|corresponding author|email|credit|competing|"
    r"data availability|conflicts|received|accepted|manuscript|submitted|"
    r"author details|title page)\b|@",
    re.IGNORECASE,
)

# 【v2.26.2】联系方式片段：邮箱 + 其后紧跟的姓名缩写括注（`(B.Z.)`）
# 动因：本刊及大量 Elsevier/MDPI 模板的机构行把作者邮箱写在**同一行**末尾
# （`1 Department …, Old Dominion University, Norfolk, VA, USA; bzhao004@odu.edu (B.Z.); …`）。
# 原 `_NOISE_RE` 含裸 `@` → 整行被判噪声丢弃 → 真实机构**一行都取不到**；
# 而文献区某条含 `laboratory` 的参考文献行反而被当成机构（EMD20260076 实测：
# 唯一输出是 `27.Chen, C., … laboratory validation. Applied Energy, 2020.`）。
# 现改为：先剥离联系方式片段、再对**剥离后的文本**做噪声判定与机构判定。
_EMAIL_RE = re.compile(r"[\w.\-+]+@[\w.\-]+\.\w+")
_INITIALS_PAREN_RE = re.compile(r"\(\s*[A-Z]\.(?:\s*,?\s*[A-Z]\.)*\s*\)")


def strip_contacts(line: str) -> str:
    """剥离行内邮箱与其后紧跟的姓名缩写括注，并清理残留的分隔符。"""
    s = _EMAIL_RE.sub(" ", line)
    s = _INITIALS_PAREN_RE.sub(" ", s)
    # 机构分量以 `;` 分隔，删除后可能留下空段 → 逐段过滤
    segs = [seg.strip() for seg in s.split(";")]
    segs = [seg for seg in segs if re.search(r"[A-Za-z\u4e00-\u9fff0-9]", seg)]
    return re.sub(r"\s{2,}", " ", "; ".join(segs)).strip(" ;,")


def refs_cut(text: str) -> int:
    """返回正文（含标题页）的字符截断位置，用于**排除文献区**。

    【v2.26.2 新增】机构只可能出现在题名页/正文，不可能出现在参考文献条目里；
    不切断文献区时，形如 `… laboratory validation. Applied Energy, 2020.` 的
    条目会因含 `laboratory`/`department` 等词被误判为机构行（EMD20260076 实测）。
    复用 `ref_common.locate_references()`（含「无 References 标题」的兜底），
    仅在定位结果落在全文 25% 之后时采用，避免异常定位把标题页一起切掉。
    """
    try:
        _here = str(Path(__file__).resolve().parent)
        if _here not in sys.path:
            sys.path.insert(0, _here)
        import ref_common as _rc
        pos = _rc.locate_references(text)
        if pos and pos > 0.25 * len(text):
            return pos
    except Exception:
        pass
    return len(text)

# 领域关键词（供 agent 参考，脚本不判定适配性；此处仅预置常见词便于输出提示）
DOMAIN_KEYWORDS = [
    "material", "energy", "chem", "electro", "battery", "supercapacitor",
    "solar", "fuel", "hydrogen", "catal", "physics", "mechanical", "civil",
    "electronic", "nano", "opt", "semiconductor", "environment", "bio",
    "材料", "能源", "化学", "电池", "催化", "物理", "机械", "土木",
    "电子", "纳米", "光学", "环境", "生物",
]


def is_noise(line: str) -> bool:
    return bool(_NOISE_RE.search(line))


def has_org_keyword(line: str) -> bool:
    low = line.lower()
    return bool(_ORG_EN_RE.search(low)) or any(k in low for k in ORG_CN)


def looks_like_affiliation(line: str) -> bool:
    """判断一行是否可能是机构行（两种特征满足其一）。"""
    # 特征 A：上标编号开头（a / a1 / 1 / 1,2 / b / 12 等）+ 后随机构关键词
    if re.match(r"^\s*[a-z](?:[0-9])?\s+[A-Z]", line) and has_org_keyword(line):
        return True
    # 特征 B：行内含机构关键词（排除已覆盖的噪声行）
    if has_org_keyword(line):
        # 排除过短行（<15 字符）与无实质内容的行
        if len(line.strip()) < 15:
            return False
        return True
    return False


def normalize(line: str) -> str:
    """归一化机构名：去上标前缀、去邮编、去国家后缀、压缩空白。"""
    s = line.strip()
    # 去上标编号前缀（a / a1 / 1 / 1,2 / b,c / 1,2,3）
    # v2.26.2：原正则只认小写字母式上标，**数字式上标（`1 Department …`）不剥离**——
    # 而数字上标恰恰是最常见的形式（EMD20260076 实测）→ 输出残留前导数字。
    m = re.match(r"^(?:[a-z](?:[0-9])?|[0-9]{1,2})(?:,[a-z0-9]{1,3})*\s+", s)
    if m:
        s = s[m.end():]
    # 去邮编（行尾 4-6 位数字）
    s = re.sub(r",?\s*\d{4,6}\s*$", "", s)
    # 去常见国家/地区后缀（英文结尾）
    s = re.sub(r",?\s*(China|P\.R\. China|PR China|United States|USA|US|UK|Japan|Korea|Germany|France|Australia|Canada|Singapore|Hong Kong, China|Taiwan, China|Macao, China|India|Netherlands|Switzerland|Sweden)\s*$", "", s, flags=re.IGNORECASE)
    s = re.sub(r",?\s*(中国|中华人民共和国|美国|日本|韩国|德国|英国|澳大利亚|加拿大|新加坡|中国香港|中国台湾|中国澳门|印度|荷兰|瑞士)\s*$", "", s)
    # 压缩空白
    s = re.sub(r"\s+", " ", s).strip()
    return s.strip(" ,")


def extract_affiliations(text: str) -> dict:
    """从全文提取机构行（v2.26.2：先切断文献区、再剥离联系方式片段）。"""
    cut = refs_cut(text)
    lines = [ln.strip() for ln in text[:cut].split("\n")]
    matched_lines = []
    seen = set()
    for ln in lines:
        if not ln or len(ln) > 300:   # 机构行通常较短
            continue
        clean = strip_contacts(ln)    # v2.26.2：邮箱同行不再拖垮整行
        if not clean:
            continue
        if is_noise(clean):
            continue
        if looks_like_affiliation(clean):
            key = normalize(clean)
            if not key:
                continue
            if key.lower() in seen:
                continue
            seen.add(key.lower())
            matched_lines.append(ln)

    if not matched_lines:
        return {
            "status": "not_found",
            "affiliations": [],
            "matched_lines": [],
            "domain_hint": {},
            "note": "未检测到机构信息",
        }

    # 去重并归一化输出（保留原始行供核对）
    affiliations = []
    for ln in matched_lines:
        norm = normalize(strip_contacts(ln))   # v2.26.2：输出亦剥离邮箱/缩写括注
        if norm and norm not in affiliations:
            affiliations.append(norm)

    # v2.15.0 (P2-5): 领域关键词命中提示——仅有机构通名（university/institute 等）
    # 而无领域词的机构，agent 可据此判「待核实」而非直接「不相关」，减少误报噪声
    domain_hint = {}
    for aff in affiliations:
        low = aff.lower()
        hit = [k for k in DOMAIN_KEYWORDS if k.lower() in low]
        if hit:
            domain_hint[aff] = hit

    return {
        "status": "found",
        "affiliations": affiliations,
        "matched_lines": matched_lines,
        "domain_hint": domain_hint,
        "note": None,
    }


def main():
    parser = argparse.ArgumentParser(description="Extract author affiliations from manuscript text")
    parser.add_argument("--text", required=True, help="Path to the manuscript full-text file (txt)")
    args = parser.parse_args()

    try:
        text = Path(args.text).read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "affiliations": [],
            "matched_lines": [],
            "note": f"无法读取文本文件: {e}",
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    result = extract_affiliations(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

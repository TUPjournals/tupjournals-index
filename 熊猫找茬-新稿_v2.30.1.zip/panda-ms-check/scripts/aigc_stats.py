#!/usr/bin/env python3
"""
aigc_stats.py — AIGC 启发式定量指标统计

指标：词数、句数、平均句长、句长变异系数、TTR、AI 提示语密度、首人称次数、近重复句数

v2.15.0 整改（产品官 P0-1/P1-3）：
- 提示语计数由 .count() 子串匹配改为词边界正则（\b...\b，忽略大小写），
  修复 "significantly 含 significant" 等子串重复计数导致的密度放大。
- 短语分强/弱两档：强 AI 标记（delve into / underscores / intricate 等）加权 ×2，
  弱标记（overall / furthermore / moreover / significant 等学术高频词）×1；
  加权密度 = (强×2 + 弱×1) / 千词，降低正常学术文本误报。
- 句长变异系数（CV）输出保持不变（数值本身无错），判级方向修正见
  gen_report.py / SKILL.md（CV 低 = 句子长度趋同 = AI 特征；CV 高 = 参差 = 人类特征）。
"""

import json
import re
import sys
from collections import Counter
from pathlib import Path

# 强 AI 标记（专有提示语/模板腔，加权 ×2）
STRONG_PHRASES = [
    'delve into', 'it is noteworthy that', 'underscores', 'pivotal role',
    'intricate', 'meticulous', 'taken together',
]
# 弱标记（学术写作高频过渡词，×1；阈值按加权密度重标定，见 gen_report）
WEAK_PHRASES = [
    'furthermore', 'in conclusion', 'robust', 'notably', 'crucial',
    'comprehensive', 'moreover', 'in summary', 'in this work',
    'importantly', 'significantly', 'overall',
]

# 词边界编译（v2.15.0：替代 .count() 子串匹配，杜绝 "significant" 命中 "significantly" 式膨胀）
STRONG_COMPILED = [(p, re.compile(r'\b' + re.escape(p) + r'\b', re.IGNORECASE)) for p in STRONG_PHRASES]
WEAK_COMPILED = [(p, re.compile(r'\b' + re.escape(p) + r'\b', re.IGNORECASE)) for p in WEAK_PHRASES]


def split_sentences(text: str):
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if len(s.strip()) > 2]


def main():
    text = Path(sys.argv[1]).read_text(encoding='utf-8') if len(sys.argv) > 1 else ''
    if not text:
        print(json.dumps({'error': 'no text'}, ensure_ascii=False))
        sys.exit(1)

    # 仅统计正文（排除 References 节，减少噪声）
    # 行级截断（避免 `\s*$` 贪婪吞换行跨行匹配的坑）：支持独立行标题 / 带编号标题 / 回退首个 [N] 文献行
    lines = text.split('\n')
    cut = len(lines)
    for i, ln in enumerate(lines):
        s = ln.strip().lower().rstrip('.: ')
        if s in ('references', 'reference', 'bibliography') or re.fullmatch(r'[\d.\s]*references?', s) or re.fullmatch(r'[\d.\s]*bibliography', s):
            cut = i
            break
    if cut == len(lines):
        # 回退：无明显 References 标题时，取「密集且序号递增的 [N] 行」起点。
        # v2.18.3 修复：原实现取「首个 [N] 开头行」，会被分栏 PDF 的**折行引用标记**误触发
        # （如正文明细行以 "[15] proposed using..." 开头），把正文截断到 640 词（OCE20260029 实测，
        # 正确值 7196 词）；仅当 [N] 行成规模、序号基本递增时才认定是参考文献节。
        cands = [i for i, ln in enumerate(lines) if re.match(r'^\s*\[(\d+)\]', ln)]
        if len(cands) >= 5:
            nums = [int(re.match(r'^\s*\[(\d+)\]', lines[i]).group(1)) for i in cands]
            descents = sum(1 for a, b in zip(nums, nums[1:]) if b < a)
            if nums[0] <= 2 and descents <= len(nums) * 0.2:
                cut = cands[0]
    if cut == len(lines):
        # 【v2.26.1】再回退：共用 `ref_common.locate_references()`。
        # 动因：稿件**不写 "References" 标题**（Elsevier / Mendeley 导出的稿件常见）时，
        # 文献表以**裸编号**起（`1.Kim, H.S., …`），上面只认 `[N]` 的回退完全失效 →
        # 整张文献表被计入正文，AIGC 各项指标被稀释/失真（EMD20260076 实测：正文
        # 5.1k 词被算成 5.7k，句数、TTR、提示语密度同源偏移），且**不报错**。
        # 与参考文献解析、政治风险扫描共用同一定位口径（含「编号行须像文献条目」判据）。
        try:
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            import ref_common as _rc
            pos = _rc.locate_references(text)
            if pos is not None and pos > 0:
                cut = min(cut, text[:pos].count('\n'))
        except Exception:
            pass
    body = '\n'.join(lines[:cut])

    words = re.findall(r'[A-Za-z][A-Za-z\-]*', body)
    word_count = len(words)
    sentences = split_sentences(body)
    sent_count = len(sentences)
    sent_lens = [len(re.findall(r'[A-Za-z][A-Za-z\-]*', s)) for s in sentences]
    avg_len = sum(sent_lens) / sent_count if sent_count else 0
    std = (sum((l - avg_len) ** 2 for l in sent_lens) / sent_count) ** 0.5 if sent_count else 0
    cv = std / avg_len if avg_len else 0  # 变异系数（高=参差/人类，低=趋同/AI）

    # TTR（类符/形符比，取前 2000 词）
    sample = words[:2000]
    ttr = len(set(w.lower() for w in sample)) / len(sample) if sample else 0

    # AI 提示语密度（v2.15.0：词边界 + 强/弱加权）
    def _count_phrases(compiled):
        hits = {}
        for p, rx in compiled:
            c = len(rx.findall(body))
            if c > 0:
                hits[p] = c
        return hits

    strong_hits = _count_phrases(STRONG_COMPILED)
    weak_hits = _count_phrases(WEAK_COMPILED)
    phrase_hits = dict(strong_hits)
    phrase_hits.update(weak_hits)
    strong_total = sum(strong_hits.values())
    weak_total = sum(weak_hits.values())
    phrase_total = strong_total + weak_total
    density = (strong_total * 2 + weak_total) / word_count * 1000  # 加权密度

    # 首人称
    first_person = len(re.findall(r'\b(we|our|us|i|my|me)\b', body.lower()))

    # 近重复句（>90% 相似度，抽样前 300 句）
    near_dup = 0
    sents = [s.lower() for s in sentences[:300]]
    for i in range(len(sents)):
        for j in range(i + 1, min(i + 15, len(sents))):
            a, b = sents[i], sents[j]
            if abs(len(a) - len(b)) > 30:
                continue
            ta, tb = set(a.split()), set(b.split())
            if not ta or not tb:
                continue
            sim = len(ta & tb) / len(ta | tb)
            if sim > 0.9 and len(ta) > 5:
                near_dup += 1

    print(json.dumps({
        'word_count': word_count,
        'sentence_count': sent_count,
        'avg_sentence_len': round(avg_len, 2),
        'sentence_len_cv': round(cv, 3),
        'ttr': round(ttr, 4),
        'ai_phrase_total': phrase_total,
        'ai_phrase_strong_total': strong_total,
        'ai_phrase_weak_total': weak_total,
        'ai_phrase_density_per_1000': round(density, 2),
        'ai_phrases': phrase_hits,
        'ai_phrases_strong': strong_hits,
        'ai_phrases_weak': weak_hits,
        'first_person_count': first_person,
        'near_duplicate_pairs': near_dup,
    }, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

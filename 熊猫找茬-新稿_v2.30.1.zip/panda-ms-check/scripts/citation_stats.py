#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""引用统计（v2.12.0）：正文+表格引用编号统计，支持区间展开。

用法：
    python citation_stats.py <out_paras.json 或 out_text.txt> [total_refs]

输出（stdout JSON）：
    {
      "cited_count": N,     # 被引用的不同文献数
      "cited": [...],       # 被引用编号（升序）
      "max_cited": N,       # 正文最大引用编号
      "over_range": [...],  # 超过文献列表总数 total_refs 的引用编号（total_refs 缺省时空）
      "total_refs": N,      # （传入时）文献列表总数
      "uncited": [...],     # （传入时）1..total 中未被引用的编号
      "uncited_count": N    # （传入时）未引用数量
    }

规则：
- 统计范围 = References 节之前全部正文段落 + 全部表格单元格（out_paras.json 含表格段；out_text.txt 为回退）
- 引用形式：单个 [n]、逗号列表 [49, 50]、范围 [a-b] / [a–b]（hyphen 与 en-dash 均支持、允许空格）
- 区间必须展开：range(min(a,b), max(a,b)+1)
- 踩坑记录（EMD20260103 实测 57 条全误报）：只 split 不展开 → [2-5] 仅计 {2,5}，中间 3、4 漏掉 → 误报"文献未引用"
"""

import argparse
import json
import re
import sys

# 破折号字符类：hyphen / en-dash / em-dash / minus sign(U+2212, PDF 排版高频)
# ⚠️ 缺 U+2212 会使 [1,16−18] 整组被静默丢弃 → 误报「未引用文献」(ECM20260040 实测)
_DASH = r'\-\u2013\u2014\u2212'
PAT_REF = re.compile(r'\[(\d+(?:[,' + _DASH + r']\s*\d+)*)\]')
PAT_RANGE = re.compile(r'[' + _DASH + r']')


def load_text(path: str) -> str:
    """读取统计源文本：优先 out_paras.json（含表格段），回退纯文本。"""
    if path.endswith('.json'):
        paras = json.load(open(path, encoding='utf-8'))
        texts = []
        for p in paras:
            if isinstance(p, dict):
                texts.append(p.get('text', ''))
            else:
                texts.append(str(p))
        return '\n'.join(texts)
    return open(path, encoding='utf-8').read()


def body_before_references(text: str) -> str:
    """截取 References 节之前正文。优先匹配独占一行的 References 标题，回退首次出现。"""
    m = re.search(r'\nReferences\s*\n', text)
    if m:
        return text[:m.start()]
    idx = text.find('References')
    return text[:idx] if idx >= 0 else text


def collect_cited(body: str) -> set:
    """统计被引用编号。区间展开、逗号列表、四种破折号均处理。"""
    cited = set()
    for m in PAT_REF.finditer(body):
        grp = m.group(1)
        for part in grp.split(','):
            part = part.strip()
            if not part:
                continue
            if PAT_RANGE.search(part):
                nums = PAT_RANGE.split(part)
                try:
                    a, b = int(nums[0]), int(nums[-1])
                    for n in range(min(a, b), max(a, b) + 1):
                        cited.add(n)
                except ValueError:
                    pass
            else:
                try:
                    cited.add(int(part))
                except ValueError:
                    pass
    return cited


def main():
    ap = argparse.ArgumentParser(description='正文引用统计（区间展开）')
    ap.add_argument('input', help='out_paras.json 或 out_text.txt')
    ap.add_argument('total_refs', type=int, nargs='?', default=None,
                    help='参考文献列表总数（传入时输出未引用列表）')
    args = ap.parse_args()

    try:
        text = load_text(args.input)
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'}, ensure_ascii=False))
        sys.exit(1)
    body = body_before_references(text)
    cited = collect_cited(body)

    out = {
        'cited_count': len(cited),
        'cited': sorted(cited),
        'max_cited': max(cited) if cited else 0,
        'over_range': sorted(n for n in cited
                             if args.total_refs is not None and n > args.total_refs),
    }
    if args.total_refs is not None:
        uncited = [i for i in range(1, args.total_refs + 1) if i not in cited]
        out['total_refs'] = args.total_refs
        out['uncited'] = uncited
        out['uncited_count'] = len(uncited)

    # v2.20.0 护栏：一处 [n] 式标记都没识别到、而文献列表非空 → 极可能是
    # **上标式（无方括号）引用**（RSC/APS 等排版：`…cycle lifespan.1-4 Following…`）。
    # 纯文本提取会丢失上标格式，方括号统计必然 0 命中；若照常采信 `uncited`
    # 就会得到「全部文献未被引用」的灾难性误报（EMD20260066 实测 116/116 全误报，
    # 经 docx 源码确认正文含 328 处 w:vertAlign=superscript 的引用标记）。
    # 故置 not_applicable 并给出明确警示，禁止下游据此判定未引用。
    if args.total_refs and not cited:
        out['not_applicable'] = True
        out['warning'] = ('正文未识别到任何 [n] 式引用标记，本统计不适用：'
                          '该稿可能使用上标式（无方括号）引用标记，纯文本提取会丢失'
                          '上标格式。请勿据此判定「文献未被引用」，需人工核对正文。')
    print(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    sys.exit(main())

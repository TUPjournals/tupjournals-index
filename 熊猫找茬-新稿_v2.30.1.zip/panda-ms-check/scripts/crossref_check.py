#!/usr/bin/env python3
"""
crossref_check.py — Crossref 参考文献验证

功能：
1. 验证参考文献元数据（标题/作者/年份/DOI）
2. 生成 5 年跨度的发表年份分布统计

Usage:
    python crossref_check.py verify --refs <references_json_file>
    python crossref_check.py year-stats --refs <references_json_file>

Input JSON format:
[
    {
        "index": 1,
        "raw_text": "Author A, Author B (2020). Title of paper...",
        "title": "Title of paper",
        "authors": "Author A, Author B",
        "year": "2020",
        "journal": "Journal Name",
        "doi": "10.xxx/yyy"
    },
    ...
]

Output (stdout): JSON

v2.15.0 整改：
- F-07: DOI 正则校验（^10.\\d{4,9}/...）+ urllib.parse.quote——杜绝 CRLF/请求拆分注入。
- S3: 网络失败（重试耗尽/异常）与「未检索到」区分：status=error（未能核验，非不可信），
  不再把瞬时网络故障误标为 not_found。
- P4: 响应缓存（DOI + 标题查询，TTL 7 天，落盘 cache/crossref_cache.json）——
  重跑/多稿件重复查询近零网络耗时。
- P6: 无 DOI 文献的首轮 query= 与兜底 query.title= 两查询并行提交（ThreadPool 2），
  慢路径等待约减半。
- P2-1: 期刊核对改用 strict 匹配（允许介词跳过与缩写展开，但禁止跳过多余实词，
  如 Nano Energy vs Nano Energy Letters 报 mismatch）；评分仍用宽松前缀匹配。
- P2-3: 首轮标题检索 rows 10 → 15。
- 年份分桶计算收敛到 common_stats.py（与 gen_report 共用）。
- MAILTO / User-Agent 收敛到 config.py（PANDA_MAILTO 环境变量可覆盖）。
- S9: CLI 读取输入包 try；S10: references 非 list 入口报错。

v2.16.0 整改：
- 期刊名归一化：_journal_tokens 先 html.unescape 解码 &amp; → &，再 & → and——
  仅因 "and" / "&" / "&amp;" 造成的差异不再产生 journal_mismatch（不报告，视为无差异）。
  根因：Crossref 返回的期刊名常带 HTML 实体（如 "Energy &amp; Environmental Science"），
  旧逻辑 &amp 成为卡死 strict 匹配的脏 token。
"""

import argparse
import difflib
import hashlib
import html
import json
import re
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

from config import CROSSREF_CACHE, MAILTO, USER_AGENT

import ref_common as rc   # 会议论文集/书籍容器判定（v2.26.0 起）

# Crossref API config
CROSSREF_API = "https://api.crossref.org/works"
MAX_CONCURRENCY = 3  # 礼貌池并发上限
MAX_RETRIES = 3      # 429/5xx 指数退避重试次数
DOI_RE = re.compile(r'^10\.\d{4,9}/[^\s\r\n]+$')   # F-07: DOI 格式校验（防注入）
CACHE_TTL = 7 * 86400                              # P4: 响应缓存 7 天


# ── Crossref 响应缓存（P4）──────────────────────────────────────────────

_cache = {}   # key -> {"ts": epoch, "data": ...}


def _load_cache():
    global _cache
    if not CROSSREF_CACHE.exists():
        return
    try:
        raw = json.loads(CROSSREF_CACHE.read_text(encoding='utf-8'))
        now = time.time()
        _cache = {k: v for k, v in raw.items() if now - v.get('ts', 0) <= CACHE_TTL}
    except Exception:
        _cache = {}


def _save_cache():
    try:
        CROSSREF_CACHE.parent.mkdir(parents=True, exist_ok=True)
        CROSSREF_CACHE.write_text(json.dumps(_cache, ensure_ascii=False), encoding='utf-8')
    except Exception:
        pass  # 缓存为纯优化，写失败不影响功能


def _cache_get(key):
    item = _cache.get(key)
    if item and time.time() - item.get('ts', 0) <= CACHE_TTL:
        return (True, item.get('data'))
    return (False, None)


def _cache_set(key, data):
    _cache[key] = {"ts": time.time(), "data": data}


def _title_cache_key(title):
    clean = re.sub(r'\s+', ' ', (title or '').lower()).strip()[:200]
    return 't:' + hashlib.md5(clean.encode('utf-8')).hexdigest()


# ── Crossref API ────────────────────────────────────────────────────────

def _get_with_retry(url: str):
    """GET url with 429/5xx exponential backoff. Returns response or None."""
    import requests
    for attempt in range(MAX_RETRIES):
        try:
            resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=15)
            if resp.status_code == 429 or resp.status_code >= 500:
                # 触发限流/服务端错误 → 退避后重试，避免把可恢复失败误判为 not_found
                time.sleep(2 ** attempt)
                continue
            return resp
        except requests.exceptions.RequestException:
            if attempt == MAX_RETRIES - 1:
                raise
            time.sleep(2 ** attempt)
    return None


def query_crossref_by_doi(doi: str) -> dict | None:
    """Query Crossref by DOI. Returns work data / None(404) / {"_error": ...}(网络失败)."""
    import requests
    doi = doi.rstrip('.').lower()
    # F-07: 格式非法（含控制字符/空白）→ 视为无 DOI，走标题检索
    if not DOI_RE.match(doi):
        return None
    ck = 'doi:' + doi
    hit, cached = _cache_get(ck)
    if hit:
        return cached
    url = f"{CROSSREF_API}/{urllib.parse.quote(doi, safe='')}?mailto={MAILTO}"
    try:
        resp = _get_with_retry(url)
        if resp is None:
            return {"_error": "retries exhausted"}
        if resp.status_code == 404:
            _cache_set(ck, None)
            return None
        resp.raise_for_status()
        data = resp.json()
        work = data.get("message", {})
        _cache_set(ck, work)
        return work
    except Exception as e:
        return {"_error": str(e)}


def query_crossref_by_title_author(title: str, author: str = "", year: str = "") -> list | None:
    """Query Crossref by title + author. Returns list of works / None(网络失败)."""
    import requests

    query_parts = []
    if title:
        # Clean title for query
        clean_title = re.sub(r'[^\w\s]', ' ', title)
        clean_title = re.sub(r'\s+', ' ', clean_title).strip()[:300]
        query_parts.append(clean_title)
    if author:
        # Extract surname
        author_surname = author.split(',')[0].strip().split()[-1] if author else ""
        if author_surname:
            query_parts.append(author_surname)

    query_str = ' '.join(query_parts)
    encoded = urllib.parse.quote(query_str)

    # P4: 标题查询缓存（键含作者姓，减少不同稿件间的误命中）
    ck = _title_cache_key(query_str) + ':' + hashlib.md5((author or '').encode('utf-8')).hexdigest()[:8]
    hit, cached = _cache_get(ck)
    if hit:
        return cached

    # v2.13.0: rows 3 → 10；v2.15.0 (P2-3): 10 → 15——rows=10 时目标排 11-15 仍可能被截
    url = f"{CROSSREF_API}?query={encoded}&rows=15&mailto={MAILTO}"
    if year:
        url += f"&filter=from-pub-date:{year},until-pub-date:{year}"

    try:
        resp = _get_with_retry(url)
        if resp is None:
            return None
        resp.raise_for_status()
        data = resp.json()
        items = data.get("message", {}).get("items", [])
        _cache_set(ck, items)
        return items
    except Exception:
        return None


def query_crossref_by_title_exact(title: str, rows: int = 20) -> list | None:
    """Query Crossref by title field only (query.title=), more precise than query=.

    v2.13.0 兜底检索：`query=`（bibliographic 全字段）对通用词标题排序差，
    目标文献被海量同类文献淹没（EMD20260090 实测 [30][34][46] 3 条），
    `query.title=` 只匹配标题字段，rows=20，目标排第 1-2 位。
    """
    import requests

    if not title:
        return None
    clean_title = re.sub(r'[^\w\s]', ' ', title)
    clean_title = re.sub(r'\s+', ' ', clean_title).strip()[:300]
    encoded = urllib.parse.quote(clean_title)

    ck = _title_cache_key(clean_title) + ':exact'
    hit, cached = _cache_get(ck)
    if hit:
        return cached

    url = f"{CROSSREF_API}?query.title={encoded}&rows={rows}&mailto={MAILTO}"
    try:
        resp = _get_with_retry(url)
        if resp is None:
            return None
        resp.raise_for_status()
        data = resp.json()
        items = data.get("message", {}).get("items", [])
        _cache_set(ck, items)
        return items
    except Exception:
        return None


# ── 无篇名（RSC 式）条目的书目检索核验（v2.20.0）─────────────────────────

def query_crossref_by_biblio(query_str: str, rows: int = 8) -> list | None:
    """按「作者 + 期刊 + 年 + 卷 + 页」书目串检索 Crossref。

    适用**无篇名**著录（RSC / 皇家化学会式 `<n>.<作者>, 期刊, 年, 卷, 页码.`）：
    稿内根本没有标题，`titles_match` 无条件不成立，标题检索路径必然全部落空
    （若不作处理，整篇文献会被误报「无法定位 = 不可信」）。
    EMD20260066 实测：书目串能把目标记录稳定排到第 1 位（抽测 5/5），
    故改按 期刊 / 年 / 卷 / 页 / 作者 五要素指纹核验。
    """
    import requests  # noqa: F401

    clean_q = re.sub(r'\s+', ' ', str(query_str or '')).strip()[:300]
    if not clean_q:
        return None
    encoded = urllib.parse.quote(clean_q)

    ck = _title_cache_key(clean_q) + ':biblio'
    hit, cached = _cache_get(ck)
    if hit:
        return cached

    url = f"{CROSSREF_API}?query.bibliographic={encoded}&rows={rows}&mailto={MAILTO}"
    try:
        resp = _get_with_retry(url)
        if resp is None:
            return None
        resp.raise_for_status()
        items = resp.json().get("message", {}).get("items", [])
        _cache_set(ck, items)
        return items
    except Exception:
        return None


def _norm_volume(v):
    v = str(v or '').strip().lower().rstrip('.')
    return '' if v in ('n/a', 'na') else v


def _page_start(p):
    """取页码起始值（'332-337' → '332'），兼容四种破折号（同 citation_stats）。"""
    return re.split(r'[-\u2013\u2014\u2212]', str(p or '').strip())[0].strip().lower().rstrip('.')


def _id_candidates(s):
    """归一化「文章号 / DOI 尾段」候选集合。

    Wiley 系刊常用 `e70188` 形式文章号，Crossref 分别存放在
    `page` / `article-number` 字段，而 DOI 尾段可能是 `70188`（`10.1002/eem2.70188`）
    或 `202513016`（`10.1002/smll.202513016`）。故统一产出
    {原串, 去符号串, 去前导 e, 纯数字} 四种形态做交集比对。
    """
    s = str(s or '').strip().lower()
    if not s:
        return set()
    d = re.sub(r'[^0-9a-z]', '', s)
    cands = {s, d, re.sub(r'^e', '', d), re.sub(r'[^0-9]', '', d)}
    return {c for c in cands if c}


def _article_ids(item: dict) -> set:
    """收集 Crossref 记录中可用来定位单篇文献的「文章号」形态。"""
    ids = set()
    ids |= _id_candidates(item.get('article-number'))
    doi = str(item.get('DOI') or '')
    if doi:
        ids |= _id_candidates(doi.rsplit('/', 1)[-1])
    return ids


def score_biblio_result(item: dict, ref_authors: str, ref_year: str,
                        ref_journal: str, ref_volume: str, ref_page: str) -> int:
    """无篇名条目的五要素指纹打分（满分 16；接受条件见 verify_one）。

    权重：期刊 +4 > 卷 +3 / 页起始 +3 / 文章号 +3 > 年 +2 > 作者姓 +1。
    与 `score_title_search_result`（标题 +6）并列，但**标题不参与**——
    因为稿内本就没有篇名可比。仅靠「期刊+年+作者」（=7）**不足以**接受，
    必须命中卷号 / 页码起始值 / 文章号之一，避免同名期刊同年文献误配。

    v2.20.0 补 article-number：2026 年「在线优先」文献 Crossref 常**尚无卷/页**，
    仅 `article-number`（如 Wiley 的 `e70188`）可用，否则被误判「无法定位」。
    """
    score = 0
    cr_journal = get_crossref_journal(item)
    if ref_journal and cr_journal and journals_match(ref_journal, cr_journal):
        score += 4
    cr_year = get_crossref_year(item)
    if ref_year and cr_year:
        try:
            if abs(int(re.sub(r'[^\d]', '', str(ref_year)[:4])) - cr_year) <= 1:
                score += 2
        except ValueError:
            pass
    v_ref, v_cr = _norm_volume(ref_volume), _norm_volume(get_crossref_volume(item))
    if v_ref and v_cr and v_ref == v_cr:
        score += 3
    p_ref, p_cr = _page_start(ref_page), _page_start(get_crossref_page(item))
    if p_ref and p_cr and p_ref == p_cr:
        score += 3
    # 文章号指纹（页起始值未命中时兜底）
    if p_ref and p_ref not in (p_cr,):
        cands = _id_candidates(ref_page) | _id_candidates(ref_volume)
        if cands & _article_ids(item):
            score += 3
    cr_surnames = get_crossref_surname_candidates(item)
    if ref_authors and cr_surnames:
        if extract_surname_candidates(ref_authors) & cr_surnames:
            score += 1
    return score


def biblio_query_string(ref: dict) -> str:
    """构造书目检索串：前两位作者 + 期刊 + 年 + 卷 + 页。"""
    authors = (ref.get('authors') or '').strip()
    firsts = ' '.join(p.strip() for p in authors.split(',')[:2] if p.strip())
    parts = [firsts, (ref.get('journal') or '').strip(),
             (ref.get('year') or '').strip(),
             (ref.get('volume') or '').strip(),
             (ref.get('page') or '').strip()]
    return ' '.join(p for p in parts if p)


def _surname_tokens(authors: str, limit: int = 4) -> list[str]:
    """按顺序取前 N 位作者的姓氏（末词），用于兜底书目检索。"""
    out = []
    for p in re.split(r'[,;&]|\band\b', authors or '', flags=re.IGNORECASE):
        p = p.strip()
        if not p:
            continue
        tok = p.split()
        if tok:
            out.append(tok[-1].strip('.'))
        if len(out) >= limit:
            break
    return out


def biblio_query_variants(ref: dict) -> list[str]:
    """书目检索的兜底变体（v2.20.0）。

    实测（EMD20260066 [12]/[79]，2026 在线优先文献）：首轮「前两位作者（含缩写）
    + 期刊缩写 + 年 + 卷 + 页」不足以让 Crossref 把目标排进前 20——RSC 式期刊
    缩写（`Adv. Mater.`）在 `query.bibliographic` 里权重很低。改换两种写法即可召回：
      B) 姓氏（去缩写点、取前 4 位）+ 期刊 + 年 + 卷 + 页
      C) 姓氏 + 年 + 卷 + 页（**去掉期刊**，避免缩写把相关性拉偏）
    变体只用于**扩大候选池**，接受条件不变（仍须期刊匹配 + ≥8 分），故不会放宽判定。
    """
    surnames = ' '.join(_surname_tokens(ref.get('authors') or ''))
    tail = [(ref.get('year') or '').strip(), (ref.get('volume') or '').strip(),
            (ref.get('page') or '').strip()]
    tail = [t for t in tail if t]
    if not surnames or not tail:
        return []
    v_b = ' '.join([surnames, (ref.get('journal') or '').strip()] + tail).strip()
    v_c = ' '.join([surnames] + tail).strip()
    base = biblio_query_string(ref)
    return [q for q in (v_b, v_c) if q and q != base]


# ── Field extraction ────────────────────────────────────────────────────

def extract_surname_candidates(authors_str: str) -> set:
    """Extract surname candidates from an author string.

    宽松规则（供评分，不触发 mismatch）：
    - 按 ',' ';' '&' 与 and 拆分为多个作者片段（兼容多作者逗号分隔与 "Last, First" 倒置——
      倒置时逗号两侧片段分别取末词，两侧均入候选）
    - 每个片段取末词（"Dwi Yanto" → yanto，兼容缩写 "D. Yanto"）
    - 小写、去尾点、过滤单字母
    """
    if not authors_str:
        return set()
    parts = re.split(r'[,;&]|\band\b', authors_str, flags=re.IGNORECASE)
    surnames = set()
    for p in parts:
        p = p.strip()
        if not p:
            continue
        tokens = p.split()
        if not tokens:
            continue
        s = tokens[-1].strip('.').lower()
        if len(s) > 1:
            surnames.add(s)
    return surnames


def get_crossref_surname_candidates(work: dict) -> set:
    """Get surname candidates from all Crossref authors (family name last token)."""
    authors = work.get("author", [])
    surnames = set()
    for a in authors:
        family = a.get("family", "")
        # 复姓如 "Bojórquez Mora" 取末词 "mora"
        tokens = family.split()
        if tokens:
            surnames.add(tokens[-1].strip('.').lower())
    return surnames


def get_crossref_title(work: dict) -> str:
    """Get the title from a Crossref work.

    v2.18.2：**拼接 subtitle**。Crossref 常把副标题单独放在 subtitle 字段
    （如 OECD 报告 title="Demographic change in cities"、
    subtitle="Trends, challenges and insights from G7 economies"），
    只取 title 会让"稿内完整著录 vs Crossref 主标题"误报 title_mismatch
    （CES 实测 [11]）。titles_match 已同步支持按 ':' 截断回退，
    故对"稿内只写主标题"的相反情形不会新增误报。
    """
    titles = work.get("title", []) or []
    t = titles[0] if titles else ""
    subs = work.get("subtitle", []) or []
    sub = subs[0] if subs else ""
    if t and sub and sub.lower() not in t.lower():
        return f"{t}: {sub}"
    return t


def get_crossref_year(work: dict) -> int | None:
    """Get the publication year from a Crossref work."""
    # Try issued date first
    issued = work.get("issued", {})
    date_parts = issued.get("date-parts", [[None]])[0]
    if date_parts and date_parts[0]:
        return date_parts[0]

    # Try created date
    created = work.get("created", {})
    date_parts = created.get("date-parts", [[None]])[0]
    if date_parts and date_parts[0]:
        return date_parts[0]

    return None


def get_crossref_journal(work: dict) -> str:
    """Get the journal/conference name from a Crossref work."""
    container = work.get("container-title", [])
    return container[0] if container else ""


def get_crossref_volume(work: dict) -> str:
    """Get the volume from a Crossref work."""
    return work.get("volume", "")


def get_crossref_page(work: dict) -> str:
    """Get the starting page from a Crossref work."""
    page = work.get("page", "")
    if page and "-" in page:
        return page.split("-")[0].strip()
    return page


# ── Journal name matching ───────────────────────────────────────────────

_SKIP_WORDS = frozenset({'of', 'the', 'and', 'for', 'in', 'on', 'a', 'an', 'to',
                         'with', '&', 'series'})   # v2.18.2: +series（见 journals_match）


def _journal_tokens(name: str) -> list[str]:
    """去标点小写分词（期刊名匹配专用）。

    v2.16.0: 先 html.unescape 解码 &amp; → &，再把 & 归一为 and——使
    "X and Y" / "X & Y" / "X &amp; Y" 视作相同，仅此差异不再报 journal_mismatch。
    v2.26.1: 再剥**尾部纯大写缩写括注**（`… (IJPEDS)` / `… (ACS)`）——出版社常在
    刊名后补印缩写，稿内通常省略，属规则内的**已知假警类**（SKILL.md：「期刊名
    允许缩写 → 非信息差异」）。仅当括注内容**全为**大写字母/数字/连字符/& 且至少
    含 1 个字母时才剥，故 `Journal of X (Series B)` 这类含小写的真实分册差异不受
    影响（EMD20260076 [7] 实测：标题/年/卷/页全对、评分 13/13 却报 journal_mismatch）。
    """
    s = html.unescape(name or '')
    m = re.search(r'\(([A-Z0-9&\- ]{2,12})\)\s*$', s)
    if m and re.search(r'[A-Z]', m.group(1)):
        s = s[:m.start()]
    s = re.sub(r'&', ' and ', s)          # & → and（加空格防粘连）
    s = re.sub(r'[^\w\s]', ' ', s.lower())
    return re.sub(r'\s+', ' ', s).strip().split()


def _word_match(wa: str, wb: str) -> bool:
    """期刊名单词级缩写匹配（v2.16.2 补充子序列，替代纯 startswith 前缀）。

    规则（仍为纯字符串判断，无别名表/语义）：
    1. 相等；
    2. 字符串前缀（"Rev" ↔ "Revxxxx"、"mater" ↔ "materials"）；
    3. 字符子序列（"compd" ⊂ "compounds"、"abstr" ⊂ "abstract"——经典缩写省略中间字母，
       EMD20260110 实测 "J Alloys Compd" vs "Journal of Alloys and Compounds" 因此漏配 6 条）；
       短词长度 ≥ 2 才启用子序列（单字母由前缀覆盖，防过宽）。
    """
    if not wa or not wb:
        return False
    if wa == wb:
        return True
    if wb.startswith(wa) or wa.startswith(wb):
        return True
    short, long = (wa, wb) if len(wa) <= len(wb) else (wb, wa)
    # 子序列仅对非停用词启用（v2.16.2 修复：停用词如 'in' ⊂ 'semicond' 会误配、
    # 破坏 strict 的顺序消费——EMD20260110 'Mater Sci Semicond Process' 实测 2 条误报）
    if len(short) >= 2 and short not in _SKIP_WORDS:
        it = iter(long)
        if all(ch in it for ch in short):
            return True
    return False


def _seq_prefix_match(a: list[str], b: list[str]) -> bool:
    """a 的每个词在 b 中按顺序找到缩写匹配（_word_match：前缀或字符子序列），
    允许跳过 b 中不对应的词（如 of/the 等介词）——即"缩写展开"语义，纯字符串判断。"""
    i = 0
    for wa in a:
        while i < len(b) and not _word_match(wa, b[i]):
            i += 1
        if i == len(b):
            return False
        i += 1
    return True


def _seq_prefix_match_strict(a: list[str], b: list[str]) -> bool:
    """strict 版（v2.15.0 P2-1）：a 每个词按序在 b 中匹配（_word_match）；
    仅允许跳过 b 中的停用词（of/the 等），不允许跳过实词；
    匹配结束后 b 中剩余未消费词也只能是停用词。

    效果：缩写展开（Chem. Mater. ↔ Chemistry of Materials、J Alloys Compd ↔
    Journal of Alloys and Compounds）仍匹配；多余实词差异（Nano Energy vs
    Nano Energy Letters）判不匹配。
    """
    i = 0
    for wa in a:
        while i < len(b) and not _word_match(wa, b[i]):
            if b[i] in _SKIP_WORDS:
                i += 1
                continue
            return False
        if i == len(b):
            return False
        i += 1
    for rest in b[i:]:
        if rest not in _SKIP_WORDS:
            return False
    return True


def _tokens_covered(a: list[str], b: list[str]) -> list[str]:
    """a 的每个词能否在 b 中一一找到缩写匹配（_word_match）；返回未覆盖词。

    与 _seq_prefix_match_strict 的区别：**顺序无关**。期刊缩写常把
    "Series B" 压成 "B"、把 "of the" 整段省略，顺序消费式判定会失配。
    """
    used, left = set(), []
    for wa in a:
        for j, wb in enumerate(b):
            if j not in used and _word_match(wa, wb):
                used.add(j)
                break
        else:
            left.append(wa)
    return left


# 缩写形式期刊名特征：字母后紧跟句点（"Proc." / "Eur." / "J." / "USA."）
_ABBR_DOT_RE = re.compile(r'[A-Za-z]\.')
# 限定词（USA / UK 等短全大写后缀，Crossref 全称常省略）
_QUALIFIER_RE = re.compile(r'^[A-Z]{2,4}$')
# 副题 / 并列题名分隔符（"Journal ... Series B: Statistical Methodology"、
# "European Journal of Population / Revue européenne de Démographie"）
_SUBTITLE_SEP_RE = re.compile(r'\s*[:/]\s*|\s+—\s+|\s+–\s+')


def _strip_subtitle(name: str) -> str:
    """截去期刊名的副题 / 并列题名（仅缩写形式比对使用）。"""
    return _SUBTITLE_SEP_RE.split(name or '')[0].strip()


def _is_abbr_form(original: str, tokens: list[str]) -> bool:
    """判定是否为「缩写形式」期刊名（含缩写点 + 每词 ≤8 字母 + ≥2 词）。

    限定条件刻意收紧：普通刊名（Nano Energy / Energy）不含缩写点，
    仍走原 strict 逻辑，不会因此漏报「Nano Energy vs Nano Energy Letters」。
    """
    if len(tokens) < 2 or not _ABBR_DOT_RE.search(original or ''):
        return False
    return all(len(t) <= 8 for t in tokens)


def journals_match(ref_journal: str, cr_journal: str, strict: bool = False) -> bool:
    """Check if two journal names match.

    strict=False（评分用）：纯字符串前缀 + 允许跳过任意词（v2.14.0 语义）。
    strict=True（期刊核对信号用，v2.15.0）：仅允许跳过停用词 + 剩余词限停用词，
    真实刊名差异（如 Nano Energy vs Nano Energy Letters）仍被报告。
    """
    if not ref_journal or not cr_journal:
        return False
    r = _journal_tokens(ref_journal)
    c = _journal_tokens(cr_journal)
    if not r or not c:
        return False
    if strict:
        if _seq_prefix_match_strict(r, c) or _seq_prefix_match_strict(c, r):
            return True
        # v2.18.2：缩写形式刊名改走「顺序无关词覆盖 + 副题剥离」。
        # 根因：稿内使用 ISO 缩写时与 Crossref 全称既有**顺序**差异（"Series B"
        # 压缩成 "B"），也有**多余/缺失**词（PNAS 全称省去 "USA"；EJP 全称带
        # 并列法文副题；JRSB 全称带副题），顺序消费式判定全部误报
        # journal_mismatch（CES 实测 7/30 条）。SKILL.md 明文
        # 「期刊名允许缩写 → 非信息差异」，故此处对齐文档语义。
        # 三重约束防误放宽：① 仅当 ref 为缩写形式；② ref 未覆盖词只能是短全大写
        # 限定词（USA/UK）；③ Crossref 副题剥离后的内容词必须被 ref 全覆盖
        # （保证 "Adv. Mater." vs "Advanced Materials Interfaces" 仍被判不匹配）。
        if _is_abbr_form(ref_journal, r):
            left = _tokens_covered(r, c)
            if not left or all(_QUALIFIER_RE.match(t.upper()) for t in left):
                c_main = _journal_tokens(_strip_subtitle(cr_journal))
                c_content = [w for w in c_main if w not in _SKIP_WORDS]
                if not _tokens_covered(c_content, r):
                    return True
        return False
    return _seq_prefix_match(r, c) or _seq_prefix_match(c, r)


def score_title_search_result(item: dict, ref_title: str, ref_authors: str,
                               ref_year: str, ref_journal: str) -> int:
    """Score a Crossref work against the reference.

    权重（标题 > 期刊 > 年份 > 作者）：标题 +6、期刊 +4、年份 +2（|diff|≤1 均给分）、作者 +1（宽松）；
    满分 13，接受阈值 6 且标题为必要项。DOI 命中确认与 title_search 候选选择共用本函数。
    """
    score = 0
    cr_title = get_crossref_title(item)
    cr_year_val = get_crossref_year(item)
    cr_journal = get_crossref_journal(item)
    cr_surnames = get_crossref_surname_candidates(item)
    if ref_title and cr_title and titles_match(ref_title, cr_title):
        score += 6
    if ref_journal and cr_journal and journals_match(ref_journal, cr_journal):
        score += 4
    if ref_year and cr_year_val:
        try:
            ref_yr = int(re.sub(r'[^\d]', '', str(ref_year)[:4]))
            if abs(ref_yr - cr_year_val) <= 1:
                score += 2
        except ValueError:
            pass
    if ref_authors and cr_surnames:
        ref_surnames = extract_surname_candidates(ref_authors)
        if ref_surnames & cr_surnames:
            score += 1
    return score


def _title_variants(t: str):
    """标题归一化的**两种**变体（v2.30.0）。

    背景（EMD20260093 实测 [82][90] 假 not_found）：Crossref 的标题常把化学式
    写成 `<sub>` 富文本，且**跨行排版**——`Sb\n<sub>2</sub>\nO\n<sub>3</sub>/MXene`
    （换行既是排版、也是真实词边界）。v2.11.1 起的做法是「下标标签连同周围空白
    一并删除」（为的是把 `In<sub>2</sub>Se` 粘成 `In2Se`），但遇到上述跨行记录时
    会把**真实词边界**一起吃掉：`…Ti3C2TxMXene nanosheets… ambient NH3synthesis…`
    → token 全毁，重叠率 0.643 < 0.65 → 真文献被判 `not_found`
    （[90] 与 [82] 均因此误报，独立核验 DOI 10.1039/d4cc03051f / 10.1039/c7ta02689g 均存在）。

    现同时产出多种变体，任一通过即视为匹配（**纯放宽**，阈值与特征词守卫不变）：
      A（紧贴式）：删标签**并删周围空白**——`In<sub>2</sub>Se` → `in2se`；
      B（留白式）：只删标签**保留空白**再折叠——跨行/跨词记录 → 正常分词。
      C（化式紧贴式，v2.30.1）：在 B 之上再删「字母↔数字」之间的空白——
        应对出版方**沉积时就把下标展开成空格**、Crossref 侧根本没有 `<sub>` 标签的情形
        （`TiS 2 /Li-In` … `Li 10 GeP 2 S 12`，EMD20260096 [62] 实测）：
        两侧同样处理后可精确对齐，标题实质相同却因分词差异被判 `title_mismatch`。
    """
    out = []
    for keep_space in (False, True):
        s = t or ''
        if keep_space:
            s = re.sub(r'</?(?:sub|sup)[^>]*>', '', s, flags=re.IGNORECASE)
        else:
            s = re.sub(r'\s*</?(?:sub|sup)[^>]*>\s*', '', s, flags=re.IGNORECASE)
        s = re.sub(r'</?[a-z][^>]*>', '', s, flags=re.IGNORECASE)
        s = s.lower()
        s = re.sub(r'[^\w\s]', ' ', s)
        out.append(re.sub(r'\s+', ' ', s).strip())
    # C：化学式下标被展开成空格（"TiS 2" / "Li 10 GeP 2"）→ 去掉字母↔数字之间的空白
    compact = re.sub(r'(?<=[a-z])\s+(?=\d)', '', out[-1])
    compact = re.sub(r'(?<=\d)\s+(?=[a-z])', '', compact)
    out.append(compact)
    # 去重（无 sub/sup 或两种处理结果相同时不重复计算）
    uniq = []
    for v in out:
        if v not in uniq:
            uniq.append(v)
    return uniq


def titles_match(ref_title: str, crossref_title: str) -> bool:
    """Check if two titles match (fuzzy)."""
    if not ref_title or not crossref_title:
        return False

    # v2.20.0：标题内含的 4 位年份不一致 → 判为**不同版本/不同年度报告**，不予接受。
    # 实测（EMD20260066 [9]）：稿内引 IEA《Global EV Outlook 2024》，Crossref 只有
    # 《Global EV Outlook 2023: Catching up with Climate Ambitions》——两标题的
    # 特征词完全重合，token 重叠率 ≥0.65 被误判为同一篇（仅记 year_off_by_1），
    # 实为**不同年度的两本报告**。本守卫只做拒绝、不放宽，方向安全。
    yr_ref = set(re.findall(r'\b(?:19|20)\d{2}\b', ref_title or ''))
    yr_cr = set(re.findall(r'\b(?:19|20)\d{2}\b', crossref_title or ''))
    if yr_ref and yr_cr and not (yr_ref & yr_cr):
        return False

    def _overlap_ok(a_norm, b_norm):
        a, b = set(a_norm.split()), set(b_norm.split())
        if not a or not b:
            return False
        # v2.18.3: 泛用词高重叠守卫（同「已出版」v3.16.0）——global / report / 年份这类泛用
        # token 能让**完全不同的文献**拿到 ≥0.65 重叠而误判为同一篇（OCE20260029 [1]
        # 「Global wind report 2025」被「Global Debt Report 2025」以 0.75 命中，并以 8/13 接受）。
        # 判据：稿内特征词（长度≥4、非泛用词、非纯数字）一个都无法在候选标题中找到 → 非同篇。
        GENERIC_TOKENS = {'global', 'report', 'annual', 'review', 'study', 'analysis',
                          'overview', 'survey', 'research', 'progress', 'advances',
                          'perspective', 'update', 'series', 'volume', 'part'}
        a_distinct = {t for t in a
                      if len(t) >= 4 and t not in GENERIC_TOKENS and not t.isdigit()}
        if a_distinct and not (a_distinct & b):
            return False
        return len(a & b) / max(len(a), len(b)) >= 0.65   # v2.13.0: 0.7 → 0.65

    def _cmp(ref_norm, cr_norm):
        if ref_norm == cr_norm:
            return True
        if _overlap_ok(ref_norm, cr_norm):
            return True
        # v2.18.2：副标题容错（单向放宽，只会减少误报，不会新增）。
        if ':' in (ref_title or '') or ':' in (crossref_title or ''):
            ref_main = _title_variants((ref_title or '').split(':', 1)[0])
            cr_main = _title_variants((crossref_title or '').split(':', 1)[0])
            for a_n, b_n in ((ref_norm, cr_main[0]), (ref_main[0], cr_norm),
                             (ref_main[0], cr_main[0])):
                if _overlap_ok(a_n, b_n):
                    return True
        return False

    for ref_norm in _title_variants(ref_title):
        for cr_norm in _title_variants(crossref_title):
            if _cmp(ref_norm, cr_norm):
                return True
    return False


def title_diff(ref_title: str, cr_title: str, max_common: int = 3) -> str:
    """标题显著差异的纯文本对比（v2.14.0）：只列出差异片段，相同内容省略。

    词级 diff（difflib.SequenceMatcher opcodes）：
    - equal 块 ≤ max_common 词完全省略（不列相同内容）；> max_common 词双侧追加省略号 …
    - replace/delete 取稿内差异词；insert 取 Crossref 差异词
    返回格式（纯文本、无 HTML 高亮）：`稿内「…X…」vs Crossref「…Y…」`
    """
    if not ref_title or not cr_title:
        return ''
    ro = ref_title.split()
    co = cr_title.split()
    rn = [re.sub(r'[^\w]', '', w).lower() for w in ro]
    cn = [re.sub(r'[^\w]', '', w).lower() for w in co]
    if rn == cn:
        return ''
    ref_parts, cr_parts = [], []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, rn, cn).get_opcodes():
        if tag == 'equal':
            n = i2 - i1
            if n > max_common:
                ref_parts.append('…')
                cr_parts.append('…')
        elif tag == 'replace':
            ref_parts.extend(ro[i1:i2])
            cr_parts.extend(co[j1:j2])
        elif tag == 'delete':
            ref_parts.extend(ro[i1:i2])
        elif tag == 'insert':
            cr_parts.extend(co[j1:j2])
    ref_side = ' '.join(ref_parts).strip() or '…'
    cr_side = ' '.join(cr_parts).strip() or '…'
    return f'稿内「{ref_side}」vs Crossref「{cr_side}」'


# ── Verify references ───────────────────────────────────────────────────

def verify_one(ref: dict) -> dict:
    """Verify a single reference against Crossref. Returns entry dict."""
    ref_index = ref.get("index", 0)
    doi = ref.get("doi", "").strip().rstrip('.').lower()
    ref_title = ref.get("title", "").strip()
    ref_authors = ref.get("authors", "").strip()
    ref_year = ref.get("year", "").strip()
    ref_journal = ref.get("journal", "").strip()
    ref_volume = ref.get("volume", "").strip()
    ref_page = ref.get("page", "").strip()

    entry = {
        "index": ref_index,
        "doi": doi,
        "ref_title": ref_title[:200],
        "ref_year": ref_year,
        "ref_journal": ref_journal[:100],
        # v2.18.0：预印本标记（由解析阶段 detect_preprint 写入）
        "is_preprint": bool(ref.get("is_preprint")),
        "preprint_server": ref.get("preprint_server", "") or "",
        "status": "pending",
        "issues": [],
        "info": [],
        "crossref_year": None,
        "crossref_title": None,
        "crossref_journal": None,
    }

    work = None
    source = ""
    best_score = 0
    network_error = False
    # v2.20.0：无篇名著录（RSC 式）——稿内不著录标题，标题比对无条件不成立，
    # 必须改走「期刊/年/卷/页/作者」五要素指纹（query.bibliographic）。
    no_title = not ref_title

    # 1) DOI 优先：命中后按标题/期刊/年份/作者统一打分确认
    if doi and DOI_RE.match(doi):   # F-07: 格式非法（含控制字符）跳过 DOI 路径
        w = query_crossref_by_doi(doi)
        if isinstance(w, dict) and "_error" in w:
            network_error = True    # S3: 网络失败 ≠ not_found
        elif isinstance(w, dict) and w:
            work = w
            best_score = score_title_search_result(w, ref_title, ref_authors, ref_year, ref_journal)
            source = f"doi(score={best_score}/13)"

    # 2) 无 DOI 或 DOI 失败 → 标题检索（P6: 首轮 query= rows=15 与 query.title= rows=20 并行）
    best_item = None
    if work is None and ref_title:
        with ThreadPoolExecutor(max_workers=2) as ex:
            f1 = ex.submit(query_crossref_by_title_author, ref_title, ref_authors)
            f2 = ex.submit(query_crossref_by_title_exact, ref_title)
            items, items2 = f1.result(), f2.result()
        if items is None or items2 is None:
            network_error = True    # S3: 任一查询网络失败
        candidates = list(items or [])
        if items2:
            candidates.extend(items2)
        best_score = 0
        for item in candidates:
            s = score_title_search_result(item, ref_title, ref_authors, ref_year, ref_journal)
            if s > best_score:
                best_score = s
                best_item = item

        # v2.13.0 接受条件：score ≥ 6 且标题必须匹配（标题不匹配即使 7 分也拒绝，
        # 防 "期刊+年份+作者=7 但标题完全不同" 被误接受）
        def _accepted(item):
            return (item is not None and best_score >= 6
                    and titles_match(ref_title, get_crossref_title(item)))

        if _accepted(best_item):
            work = best_item
            source = f"title_search(score={best_score}/13)"
        else:
            # 无足够好的匹配 → 视为未检索到记录；保留最佳候选标题供报告具体对比（不显示分值）
            work = None
            if best_item is not None:
                entry["crossref_title"] = (get_crossref_title(best_item) or "")[:200]
                entry["crossref_year"] = get_crossref_year(best_item)
                entry["crossref_journal"] = (get_crossref_journal(best_item) or "")[:100]
            source = "title_search(low_score)"

    # 2b) v2.20.0 无篇名条目 → 书目检索（query.bibliographic）核验
    #     稿内无标题可比，改以 期刊 + 年 + 卷 + 页起始 + 作者姓 的指纹定位；
    #     接受条件：期刊匹配 且 总分 ≥8（仅「期刊+年+作者」=7 不接受，
    #     必须命中卷号或页码起始值，防同名期刊同年文献误配）。
    if work is None and no_title and ref_journal:
        def _pick(items):
            bi, bs = None, 0
            for it in (items or []):
                s = score_biblio_result(it, ref_authors, ref_year,
                                        ref_journal, ref_volume, ref_page)
                if s > bs:
                    bs, bi = s, it
            return bi, bs

        def _accept(bi, bs):
            return (bi is not None and bs >= 8
                    and journals_match(ref_journal, get_crossref_journal(bi)))

        q = biblio_query_string(ref)
        items = query_crossref_by_biblio(q)
        if items is None:
            network_error = True
        else:
            best_item, best_score = _pick(items)
            source = "biblio_search"
            # 兜底变体：仅当首轮无合格匹配时才发起（在线优先文献召回率问题）
            if not _accept(best_item, best_score):
                variants = biblio_query_variants(ref)
                if variants:
                    with ThreadPoolExecutor(max_workers=len(variants)) as ex:
                        outs = list(ex.map(query_crossref_by_biblio, variants))
                    got_any = False
                    for o in outs:
                        if o is None:
                            continue
                        got_any = True
                        bi, bs = _pick(o)
                        if bs > best_score:
                            best_item, best_score = bi, bs
                    # 首轮与所有变体均网络失败 → 未能核验（非不可信）
                    if not got_any and not items:
                        network_error = True
            if _accept(best_item, best_score):
                work = best_item
                source = f"biblio_search(score={best_score}/16)"
            else:
                if best_item is not None:
                    entry["crossref_title"] = (get_crossref_title(best_item) or "")[:200]
                    entry["crossref_year"] = get_crossref_year(best_item)
                    entry["crossref_journal"] = (get_crossref_journal(best_item) or "")[:100]
                source = "biblio_search(low_score)"

    # S3: 网络失败单独状态（报告端标注"未能核验"，非"不可信"）
    if network_error:
        entry["status"] = "error"
        entry["error"] = "网络错误，未能核验（非不可信，请重试）"
        entry["source"] = source
        return entry

    if work is None:
        # v2.18.0：预印本（arXiv/bioRxiv/SSRN 等）未被 Crossref 收录属常见情况，
        # 不代表文献不可信 → 单列状态，不计入"无法定位"，报告中按"未验证"呈现。
        # 注意：撤稿检测照常执行（本地比对，成本极低，不因预印本身份跳过）。
        if entry.get("is_preprint"):
            entry["status"] = "preprint_not_indexed"
        else:
            entry["status"] = "not_found"
        entry["source"] = source
        return entry

    cr_title = get_crossref_title(work)
    cr_year = get_crossref_year(work)
    cr_journal = get_crossref_journal(work)

    entry["crossref_title"] = (cr_title or "")[:200]
    entry["crossref_year"] = cr_year
    entry["crossref_journal"] = (cr_journal or "")[:100]
    # v2.20.0：留存命中记录的卷/页（供「无篇名」条目的错配审计——
    # 稿内卷页 vs 命中记录卷页须逐条比对，否则无法发现「期刊+年+作者」低分误配）
    entry["crossref_volume"] = (get_crossref_volume(work) or "")[:20]
    entry["crossref_page"] = (get_crossref_page(work) or "")[:20]
    entry["source"] = source

    # 标题核对（所有来源；允许大小写/非字母符号差异，已归一化）
    # v2.14.0: title_mismatch 带词级差异片段（只列差异部分，相同内容省略）
    if ref_title and cr_title and not titles_match(ref_title, cr_title):
        diff = title_diff(ref_title, cr_title)
        entry["issues"].append(f"title_mismatch: {diff or '标题措辞差异'}")

    # 年份核对（所有来源）：|diff|≤1 → 信息差异（非不可信）；>1 → 不可信
    if ref_year and cr_year:
        try:
            ref_yr = int(re.sub(r'[^\d]', '', str(ref_year)[:4]))
            diff = abs(ref_yr - cr_year)
            if diff > 1:
                entry["issues"].append(f"year_mismatch: ref={ref_yr}, crossref={cr_year}")
            elif diff == 1:
                entry["info"].append(f"year_off_by_1: ref={ref_yr}, crossref={cr_year}")
        except ValueError:
            pass

    # 期刊核对（v2.15.0 P2-1: 用 strict 匹配——真实刊名差异仍被报告；评分仍用宽松）
    # v2.16.0: _journal_tokens 已归一化 and/&/&amp; 等价，仅此差异不会走到这里
    # v2.26.0: 会议论文集/书籍/报告/预印本容器**不参与**期刊核对——Crossref 侧
    #   同类记录的 container-title 形如 `2022 IEEE/CVF Conference on Computer
    #   Vision and Pattern Recognition (CVPR)`，与稿内 `Proceedings of IEEE/CVF
    #   Conf. …` 永远无法逐词对齐（CVMJ-26-00445 实测 65/89 条假警）。规则明文
    #   「期刊核对只对『期刊论文』有意义」→ 降级为 info，标题/年份核对照常。
    # v2.26.1: 判定改为**双向**——Crossref 侧也可能是容器：会议论文在 Crossref 里
    #   常被记为 `SPIE Proceedings` 或 `Volume 8: 31st Conference on Mechanical
    #   Vibration and Noise`，而稿内写的是会议录全名（`Active and Passive Smart
    #   Structures and Integrated Systems 2010`）——两者本是不同口径，原只查
    #   ref 侧时仍报 journal_mismatch（EMD20260076 [29][47] 实测 2 条假警）。
    if ref_journal and cr_journal and not journals_match(ref_journal, cr_journal, strict=True):
        if rc.is_conference_container(ref_journal) or rc.is_conference_container(cr_journal):
            entry["info"].append(
                f"conference_container: 会议论文集/非期刊容器，刊名不参与核对"
                f"（ref={ref_journal[:60]}, crossref={cr_journal[:60]}）")
        else:
            entry["issues"].append(f"journal_mismatch: ref={ref_journal[:80]}, crossref={cr_journal[:80]}")

    # 卷/页差异不作为信息差异或不可信信号；作者名允许缩写/姓名倒置（不核对、不评分报错）

    # DOI 命中但按标题/姓名等打分低于接受阈值 → 附加人工复核提示（非 not_found）
    # v2.13.0: 接受阈值 8 → 6 且标题必要（与 title_search 一致）
    # v2.20.0: 无篇名条目（RSC 式）用「期刊匹配」替代「标题匹配」作必要条件——
    #          稿内本无标题，若沿用 titles_match('') 会恒为 False，把本已通过
    #          期刊/年/卷/页核验的条目错报为「差异较大」。
    if "doi(" in source:
        if no_title:
            doi_ok = best_score >= 6 and journals_match(ref_journal, cr_journal)
        else:
            doi_ok = best_score >= 6 and titles_match(ref_title, cr_title)
        if not doi_ok:
            entry["issues"].append(
                f"doi_low_score: DOI 记录已找到，按标题/期刊/姓名等打分 {best_score}/13 低于接受阈值 6（或标题/期刊不匹配），建议人工复核")

    if entry["issues"]:
        entry["status"] = "issues_found"
    else:
        entry["status"] = "verified"

    return entry


def verify_references(references: list[dict]) -> dict:
    """Verify each reference against Crossref (concurrent, polite pool).

    并发上限 = 礼貌池 concurrency limit（3）；429/5xx 已在 _get_with_retry 内
    指数退避，避免把可恢复的限流误判为 not_found（相比原串行 0.5s sleep 显著提速）。
    """
    if not isinstance(references, list):
        raise ValueError('references 必须为纯 list（SKILL.md：refs.json 须为 list）')

    _load_cache()
    try:
        # 兜底补 index，保证缺失 index 的 ref 也有稳定编号
        for i, ref in enumerate(references):
            if "index" not in ref or not ref["index"]:
                ref["index"] = i + 1

        with ThreadPoolExecutor(max_workers=MAX_CONCURRENCY) as ex:
            results = list(ex.map(verify_one, references))

        verified = sum(1 for r in results if r["status"] == "verified")
        has_issues = sum(1 for r in results if r["status"] == "issues_found")
        not_found = sum(1 for r in results if r["status"] == "not_found")
        errors = sum(1 for r in results if r["status"] == "error")

        return {
            "total": len(references),
            "verified": verified,
            "has_issues": has_issues,
            "not_found": not_found,
            "errors": errors,
            "results": results
        }
    finally:
        _save_cache()


# ── Year statistics ─────────────────────────────────────────────────────

def compute_year_stats(references: list[dict]) -> dict:
    """Compute publication year distribution in 5-year bins（v2.15.0: 收敛到 common_stats）。"""
    from common_stats import compute_year_stats as _cys
    return _cys(references)


# ── CLI ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Crossref reference verifier")
    subparsers = parser.add_subparsers(dest="command", help="Command")

    p_verify = subparsers.add_parser("verify", help="Verify references against Crossref")
    p_verify.add_argument("--refs", required=True, help="Path to JSON file with reference list")

    p_stats = subparsers.add_parser("year-stats", help="Compute publication year statistics")
    p_stats.add_argument("--refs", required=True, help="Path to JSON file with reference list")

    args = parser.parse_args()

    if args.command == "verify":
        try:
            with open(args.refs, 'r', encoding='utf-8') as f:
                refs = json.load(f)
        except Exception as e:
            print(json.dumps({"status": "error", "error": f"读取 refs.json 失败: {e}"},
                             ensure_ascii=False))
            sys.exit(1)
        if not isinstance(refs, list):
            print(json.dumps({"status": "error", "error": "refs.json 必须为纯 list"},
                             ensure_ascii=False))
            sys.exit(1)
        try:
            result = verify_references(refs)
        except Exception as e:
            print(json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False))
            sys.exit(1)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "year-stats":
        try:
            with open(args.refs, 'r', encoding='utf-8') as f:
                refs = json.load(f)
        except Exception as e:
            print(json.dumps({"status": "error", "error": f"读取 refs.json 失败: {e}"},
                             ensure_ascii=False))
            sys.exit(1)
        if not isinstance(refs, list):
            print(json.dumps({"status": "error", "error": "refs.json 必须为纯 list"},
                             ensure_ascii=False))
            sys.exit(1)
        try:
            result = compute_year_stats(refs)
        except Exception as e:
            print(json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False))
            sys.exit(1)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

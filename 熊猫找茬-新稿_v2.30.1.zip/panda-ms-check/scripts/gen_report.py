#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_report.py — 熊猫找茬-新稿 报告固定渲染脚本（零第三方依赖）。

读取 work 目录检测 JSON + report_content.json（agent 判定内容）+ 模板 → HTML。
用法：
  python scripts/gen_report.py --work <work目录> --content <report_content.json> \
      [--out <输出目录>] [--msid <稿件标识>] [--date YYMMDD]
stdout 输出一行机器可读 JSON：{"status":"ok|warn|error","out_file","size","leftover"}。
退出码：0 成功；2 有残留占位符（文件仍写出）；1 致命错误。
注意：新稿为四维检测（无 ⑤ 声明完整性 / ⑥ 参考文献语义相关性），
report_content.json 不含 summary.ext 与 ext_sections 字段（区别于已出版版脚本）。

v2.15.0 整改：
- F-01（XSS）：所有来自稿件/撤稿库/journal_scopes 的动态值统一经 html.escape 后注入，
  scope_url 仅作文本显示且先校验 scheme==https；badge 的 class 走白名单。
- F-05: 报告模板头/尾增加「含个人信息，勿随意传播」提示；输出目录隔离见 SKILL.md。
- P0-2: 句长变异系数判级方向修正——CV 低（<0.3）= 句子长度趋同 = AI 特征，判"异常均匀"；
  原"CV>0.7 异常均匀"与统计原理相反（CV 高实为参差/人类特征）。
- P1-3: AIGC 密度阈值重标定（配合 aigc_stats 词边界+强/弱加权）：<=3 正常 / <=8 轻度 / >8 高度。
- S3: Crossref status=error（网络失败）单列"未能核验"（非不可信），不再混入"无法定位"。
- 年份分桶复用 common_stats.py（消除与 crossref_check 双实现分歧）。
"""
import argparse
import html
import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from common_stats import compute_year_stats
import journal_scopes
import config as _cfg

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_DIR / 'references' / 'report_template.html'
# v2.20.0：TOOL_NAME 不再硬编码版本号，改从 config.TOOL_VERSION 拼接——
# 此前本处硬编码 "熊猫找茬-新稿 v2.19.x"，与 config.py / SKILL.md frontmatter 三处各写一遍，
# 每次升版都可能只改其中一两处（文档/代码漂移，v2.17.1、v2.19.1 均踩过）。
TOOL_NAME = f'熊猫找茬-新稿 v{_cfg.TOOL_VERSION}'
RW_META = SKILL_DIR / 'data' / 'retraction_watch_meta.json'
# v2.17.0 双层数据源：JOURNAL_SCOPES 为用户文件（禁止进包、升级不覆盖），
# 读取统一走 journal_scopes.load_all()（模板 ∪ 用户合并）
JOURNAL_SCOPES = journal_scopes.USER_FILE

_BADGE_CLS = {'ok', 'warn', 'bad', 'info'}   # badge class 白名单（F-01）


def esc(v):
    """HTML 转义（F-01）：所有动态文本注入前必须经过本函数。"""
    return html.escape(str(v if v is not None else ''), quote=True)


# 4.4 两字段（refs_citation_issues / citation_gaps）在 SKILL.md 中定义为 HTML，
# 但 v2.15.0 的全局转义把它们整串转义了 —— 报告里会出现可见的 &lt;p&gt;
# （EMD20260068 与历史 EMD_DigitalTwin 均实测），属文档/代码漂移。
# v2.20.1：改为「先整串转义、再放行无属性白名单标签」——保留 XSS 防护
# （无法构造带属性的事件处理器，也无法注入 script/style），同时恢复可读排版。
_RICH_TAGS = ('p', 'b', 'strong', 'em', 'i', 'br', 'ul', 'ol', 'li')


def rich(v):
    """转义全部 HTML 后，仅放行 _RICH_TAGS 中的无属性格式标签。"""
    out = esc(v)
    for t in _RICH_TAGS:
        out = re.sub(r'&lt;(/?)%s&gt;' % t, r'<\1%s>' % t, out)
    return out


# (aigc 键, 指标名, 数值格式化, 参考区间)
AIGC_ROWS = [
    ('word_count', '正文字数', lambda v: f'{v:,}', '—'),
    ('sentence_count', '句子数', lambda v: f'{v:,}', '—'),
    ('avg_sentence_len', '平均句长', lambda v: f'{v:.2f} 词', '15-25'),
    ('sentence_len_cv', '句长变异系数', lambda v: f'{v:.3f}', '<0.3 异常均匀（AI 特征）'),
    ('ttr', '类符/形符比 TTR', lambda v: f'{v:.3f}', '0.3-0.5'),
    ('ai_phrase_density_per_1000', 'AI 提示语密度', lambda v: f'{v} / 千词', '>3 可疑，>8 高度可疑（强词×2 加权）'),
    ('first_person_count', '首人称次数', lambda v: f'{v}', '人类论文通常存在'),
    ('near_duplicate_pairs', '近重复句对数', lambda v: f'{v}', '—'),
]


def log(msg):
    print(msg, file=sys.stderr)


def load_json(path):
    """容错读取：跳过前导非 JSON 行（定位第一个 { 或 [ 再 loads）；文件缺失返回 None。"""
    if not path or not Path(path).exists():
        return None
    raw = Path(path).read_text(encoding='utf-8', errors='replace')
    i1 = raw.find('{')
    i2 = raw.find('[')
    candidates = [i for i in (i1, i2) if i >= 0]
    if not candidates:
        raise ValueError(f'no JSON object in {path}')
    return json.loads(raw[min(candidates):])


def badge(cls, verdict):
    cls = cls if cls in _BADGE_CLS else 'info'
    return f'<span class="badge {cls}">{esc(verdict)}</span>'


# info 中「不是稿内与 Crossref 记录之差异」的注记前缀（v2.26.0）
# conference_container：稿内写 `Proceedings of …`、Crossref 记 `20xx IEEE/CVF
# Conference on …`——期刊核对对非期刊文献本就无意义（见 crossref_check.
# is_conference_container）。若把它计入 4 档表的「微小差异」与差异明细的
# 「年份相差1年」合并行，会把大量实际完全匹配的文献误报成"有差异"
# （CVMJ-26-00445 实测：89 条中 61 条会被误列）。
_NONDIFF_INFO_PREFIXES = ('conference_container:',)


def _info_is_non_difference(infos):
    """info 是否**只**含非差异注记（此时该条应计入「完全匹配」而非「微小差异」）。"""
    items = [str(x).strip() for x in (infos or []) if str(x).strip()]
    if not items:
        return False
    return all(it.startswith(_NONDIFF_INFO_PREFIXES) for it in items)


def _has_real_difference(r):
    """verified 条目是否存在**真实**差异（年份±1 等），排除纯容器注记。"""
    return bool(r.get('info')) and not _info_is_non_difference(r.get('info'))


def require(content, *paths):
    for p in paths:
        node = content
        for k in p.split('.'):
            if not isinstance(node, dict) or k not in node:
                raise ValueError(f'report_content.json 缺少必填字段: {p}')
            node = node[k]


# ── 自动生成段 ──

def build_political_risk(geo):
    if not geo or geo.get('status') != 'found' or not geo.get('hits'):
        return ''
    rows = ''.join(
        f'<tr><td>{esc(h.get("keyword", ""))}</td><td>{esc(h.get("sentence", ""))}</td>'
        f'<td>{esc(h.get("section", ""))}</td></tr>'
        for h in geo['hits'])
    return ('<p style="color:#d23b3b;font-size:13px"><b>0 政治风险：潜在政治风险，请人工核查。</b></p>'
            + '<table><tr><th>关键词</th><th>完整句子</th><th>所属一级标题</th></tr>'
            + rows + '</table>')


def build_year_stats_table(refs, note=''):
    stats = compute_year_stats(refs)
    total = stats['total']
    rows = []
    for s in stats['distribution']:
        if s['range'] == 'Unknown':
            if s['count']:
                rows.append(f'<tr><td>Unknown</td><td>{s["count"]}</td><td>{s["percentage"]}%</td></tr>')
            continue
        if not s['count']:
            continue
        lab = s['range'].replace('>=', '≥').replace('<=', '≤')
        rows.append(f'<tr><td>{lab}</td><td>{s["count"]}</td><td>{s["percentage"]}%</td></tr>')
    rows.append(f'<tr><td>合计</td><td>{total}</td><td>100%</td></tr>')
    body = ('<table>\n<tr><th>年份区间</th><th>数量</th><th>占比</th></tr>\n'
            + '\n'.join(rows) + '\n</table>')
    return body + (f'<p><b>{esc(note)}</b></p>' if note else '')


def build_refs_citation_section(content):
    """4.4 引用分布与著录节（v2.16.0 重编号：原 4.2；v2.14.0：默认隐藏，字段驱动）。

    report_content 缺省 refs_citation_issues 与 citation_gaps → 返回空串（整节不渲染，
    含 h3 标题与引用空洞检查）；写任一字段 → 整节渲染。启用方式：agent 需要 4.4 时
    运行 citation_stats.py 并填写这两个字段。
    """
    content = content or {}
    issues = content.get('refs_citation_issues') or ''
    gaps = content.get('citation_gaps') or ''
    if not issues and not gaps:
        return ''
    parts = ['<h3>4.4 引用分布与著录</h3>', rich(issues)]
    if gaps:
        parts.append(f'<p><b>引用空洞检查</b>：{rich(gaps)}</p>')
    return '\n'.join(parts)


def build_author_results(authors, domain='本稿', verdicts=None):
    """作者撤稿检索表。

    默认文案（v2.17.1 起「基本判定为同名误报」）**仅对应 SKILL.md 三档分类的档 2
    （有命中但领域不同）**。档 3（有命中且机构/学科与本稿相同或相近）绝不能用默认
    文案——那会把"需重点核实"渲染成"已排除风险"，属最危险的假阴性。
    v2.19.0：新增 `verdicts` 覆盖（agent 判定档 3 时写入 report_content.json 的
    `author_verdicts`，机制同 crossref 的 review_note）。
    """
    if not authors or not authors.get('authors'):
        return f'<p>{badge("info", "未检测")} 作者撤稿检索未执行（数据缺失）。</p>'
    vd = verdicts or {}
    rows = []
    for a in authors['authors']:
        hits = a.get('hits') or []
        raw_name = a.get('name', '')
        name = esc(raw_name)
        if not hits:
            rows.append(f'<tr><td><b>{name}</b></td><td>0</td><td>{badge("ok", "无")}</td><td>无撤稿记录</td></tr>')
            continue
        ov = vd.get(raw_name) or {}
        if ov:
            b = ov.get('badge', 'warn')
            concl = esc(ov.get('conclusion', '同名命中'))
            note = esc(ov.get('note', ''))
            rows.append(f'<tr><td><b>{name}</b></td><td>{len(hits)}</td>'
                        f'<td>{badge(b, concl)}</td><td>{note}</td></tr>')
        else:
            # v2.26.0：学科采样改「按命中频次取前 3」——原按字母序取 set 前 3，
            # 因 "(B/T)" < "(BLS)"（ASCII '/' < 'L'）恒取到商业/计算机类，
            # 会把以医学/生命科学为主的命中集误描述成商务类（CVMJ-26-00445
            # 实测：Yan Chen 60 条中绝大多数为医学/生命科学，默认却显示
            # "(B/T) Business - Accounting；(B/T) Business - Economics"）。
            pref = Counter((h.get('subject') or 'N/A').split(';')[0] for h in hits)
            subs = '；'.join(k for k, _ in pref.most_common(3))
            rows.append(
                f'<tr><td><b>{name}</b></td><td>{len(hits)}</td><td>{badge("warn", "同名命中")}</td>'
                # 措辞须与 SKILL.md 三档分类档2 规则一致（v2.17.1 修复文档/代码漂移：此前仅改文档漏改此处）
                f'<td>命中 {len(hits)} 条，领域均非{esc(domain)}相关（如 {esc(subs)}），基本判定为同名误报；建议人工留意</td></tr>')
    return ('<table>\n<tr><th>作者</th><th>命中数</th><th>结论</th><th>说明</th></tr>\n'
            + '\n'.join(rows) + '\n</table>')


def build_refs_rw_check(refs_rw, total, verdicts=None, note=''):
    if refs_rw is None:
        return f'<p>{badge("info", "未检测")} 参考文献撤稿检索未执行（refs_rw.json 未生成），本维度未检测。</p>'
    matches = (refs_rw or {}).get('matches') or []
    if not matches:
        return (f'<p>基于 Retraction Watch 对 {esc(total)} 篇参考文献进行 DOI 锚定与标题模糊匹配：'
                f'<b>0 篇存在真实撤稿记录</b>。</p>')
    vd = verdicts or {}
    rows = []
    for h in matches:
        verdict = vd.get(str(h.get('ref_index')), '待人工复核')
        cls = 'ok' if '误报' in verdict else 'warn'
        rows.append(
            f'<tr><td>[{esc(h.get("ref_index"))}]</td><td>{esc(str(h.get("ref_title", ""))[:60])}</td>'
            f'<td>{esc(str(h.get("matched_title", ""))[:60])}<br><span style="color:#888;font-size:12px">'
            f'{esc(h.get("retraction_date", ""))} | {esc(str(h.get("reason", ""))[:40])}</span></td>'
            f'<td>{badge(cls, verdict)}</td></tr>')
    return ('<p>基于 Retraction Watch：<b>{} 条匹配命中，经甄别均需人工确认/误报</b>。</p>'
            + '<table><tr><th>#</th><th>稿件引用</th><th>撤稿库条目</th><th>判定</th></tr>\n'
            + '\n'.join(rows) + '\n</table>' + (esc(note) if note else '')).format(len(matches))


def auto_judge(key, val):
    if key in ('word_count', 'sentence_count'):
        return '—'
    if key == 'avg_sentence_len':
        return '正常' if 15 <= val <= 25 else '偏长/偏短（建议复核）'
    if key == 'sentence_len_cv':
        # P0-2: CV 低 = 句子长度趋同 = AI 特征（原 ">0.7 异常均匀" 方向错误，已修正）
        return '异常均匀（建议复核）' if 0 < val < 0.3 else '正常'
    if key == 'ttr':
        return '正常' if 0.3 <= val <= 0.5 else '偏离常规区间（建议复核）'
    if key == 'ai_phrase_density_per_1000':
        # P1-3: 阈值重标定（配合词边界 + 强词×2 加权）
        if val <= 3:
            return badge('ok', '正常')
        if val <= 8:
            return badge('warn', '轻度可疑')
        return badge('bad', '高度可疑')
    if key == 'first_person_count':
        return badge('warn', '缺失（附加信号）') if val == 0 else '正常'
    if key == 'near_duplicate_pairs':
        return badge('warn', '存在近重复句') if val else '正常'
    return '—'


def build_aigc_table(aigc, judgments=None):
    if not aigc:
        return f'<p>{badge("info", "未检测")} AIGC 定量指标数据缺失（aigc.json 未生成），本维度未检测。</p>'
    jd = judgments or {}
    rows = []
    for key, label, fmt, ref_range in AIGC_ROWS:
        val = aigc.get(key)
        if val is None:
            continue
        # aigc_judgments 的键：**以英文指标名为准**（如 sentence_len_cv）。
        # v2.21.0 修复静默失效：此前只查 key，而 agent 常按报告显示的中文指标名
        # （如「句长变异系数」）书写 → 查不到 → 静默回退 auto_judge，覆盖形同虚设
        # （EMD20260067 实测）。现同时接受 key 与中文 label 两种写法。
        judge = jd.get(key) or jd.get(label) or auto_judge(key, val)
        rows.append(f'<tr><td>{esc(label)}</td><td>{fmt(val)}</td><td>{esc(ref_range)}</td><td>{judge}</td></tr>')
    return ('<table>\n<tr><th>指标</th><th>数值</th><th>参考区间</th><th>判断</th></tr>\n'
            + '\n'.join(rows) + '\n</table>')


def build_aigc_phrase_list(aigc):
    phrases = (aigc or {}).get('ai_phrases') or {}
    if not phrases:
        return ''
    items = sorted(phrases.items(), key=lambda kv: (-kv[1], kv[0]))
    parts = '、'.join(f'{esc(k)} ×{v}' for k, v in items)
    return f'<p>命中提示语明细：<span class="mono">{parts}</span></p>'


def build_aigc_note(aigc, agent_note):
    note = esc(agent_note) if agent_note else ''
    return build_aigc_phrase_list(aigc) + (f'<p>{note}</p>' if note else '')


def build_refs_verify(rv, crossref=None):
    """4.2 节渲染（v2.16.0 重编号：原 4.3；v2.12.0 起）：summary 段落 + 4 档汇总表 + 差异明细表。

    4 档分类（脚本自动从 crossref.json 算）：
    - 完全匹配：status=verified 且 info 空
    - 微小差异：status=verified 且 info 非空（如 year_off_by_1）
    - 差异较大：status=issues_found（DOI 命中但 score<6 等）
    - 无法定位：status=not_found（未甄别；有 review_note 者另计「需人工复核（已甄别）」，v2.18.2）
    - 未能核验：status=error（网络失败，非不可信；v2.15.0 S3）
    差异明细表（v2.12.0）：
    - 逐条在前：issues_found → 需人工复核（warn）；not_found → 不可信（bad）
    - 年份差 1 年合并行（微小差异，v2.12.0 起不再逐条）：所有编号一行，差异说明「年份相差1年」→ 低风险（warn）
    - 著录不完整（rv.incomplete）合并为一行置尾（所有文献号 + 问题归组）→ 需人工复核（warn）
    - 同一文献两处都列（如 [16] 既有年份差异又有著录不完整），不互斥
    """
    rv = rv or {}
    parts = [esc(rv.get('summary', ''))]

    results = (crossref or {}).get('results') or []
    if not results:
        parts.append(f'<p>{badge("info", "未检测")} Crossref 核验数据缺失（crossref.json 未生成），本维度未检测。</p>')
        return '\n'.join(parts)

    # 4 档统计
    buckets = {
        ('verified', 'no_info'): 0,    # 完全匹配
        ('verified', 'with_info'): 0,  # 微小差异
        'issues_found': 0,              # 差异较大
        'not_found': 0,                 # 无法定位（未甄别）
        'reviewed': 0,                  # 已人工甄别（not_found 且有 review_note，v2.18.2）
        'error': 0,                     # 未能核验（网络失败）
        'preprint_not_indexed': 0,      # 预印本未收录（v2.18.0，不计风险）
    }
    for r in results:
        status = r.get('status')
        if status == 'verified':
            if _has_real_difference(r):
                buckets[('verified', 'with_info')] += 1
            else:
                buckets[('verified', 'no_info')] += 1
        elif status == 'issues_found':
            # ⚠️ 不可把「有 review_note 的 issues_found」并入 reviewed 档（已试过并回退，
            # v2.26.0）：历史稿件的 review_note 语义混杂——既有「经人工甄别为误报／文献
            # 真实存在」（EMD20260071/072），也有「DOI 无法解析（404）」「稿内 DOI 指向
            # 另一篇论文」（BUIL-D-25-00483、CESCI-D-26-00022）这类**真问题**。并入
            # 「已甄别」会把真问题渲染成"已排除"，属安全级假阴性。review_note 只对
            # not_found 具备"降级为需人工复核"的既定语义（v2.18.2）。
            buckets['issues_found'] += 1
        elif status == 'not_found':
            # v2.18.2：已有 review_note（agent 定向复核：收录盲区 / 非期刊文献等）
            # 的条目在明细表已降级为「需人工复核」（黄），汇总表须同步，
            # 否则出现「汇总表标红不可信 vs 明细表标黄需复核」的自相矛盾。
            if (r.get('review_note') or '').strip():
                buckets['reviewed'] += 1
            else:
                buckets['not_found'] += 1
        elif status == 'error':
            buckets['error'] += 1
        elif status == 'preprint_not_indexed':
            buckets['preprint_not_indexed'] += 1
    total = len(results)

    def pct(n):
        return round(n / total * 100, 1) if total else 0

    # 汇总表
    summary_rows = [
        (f'{badge("ok", "完全匹配")}', buckets[('verified', 'no_info')], pct(buckets[('verified', 'no_info')])),
        (f'{badge("warn", "微小差异")}', buckets[('verified', 'with_info')], pct(buckets[('verified', 'with_info')])),
        (f'{badge("warn", "差异较大")}', buckets['issues_found'], pct(buckets['issues_found'])),
    ]
    if buckets['reviewed']:
        summary_rows.append(
            (f'{badge("warn", "需人工复核（已甄别）")}', buckets['reviewed'],
             pct(buckets['reviewed'])))
    summary_rows.append(
        (f'{badge("bad", "无法定位")}', buckets['not_found'], pct(buckets['not_found'])))
    if buckets['error']:
        summary_rows.append((f'{badge("info", "未能核验")}', buckets['error'], pct(buckets['error'])))
    if buckets['preprint_not_indexed']:
        summary_rows.append((f'{badge("info", "预印本·未收录")}',
                             buckets['preprint_not_indexed'],
                             pct(buckets['preprint_not_indexed'])))
    summary_table = (
        '<table>\n<tr><th>验证结果</th><th>数量</th><th>占比</th></tr>\n'
        + ''.join(f'<tr><td>{name}</td><td>{n}</td><td>{p}%</td></tr>'
                  for name, n, p in summary_rows)
        + '</table>'
    )
    parts.append(summary_table)

    # 预印本统计提示（v2.18.0）
    preprint_n = sum(1 for r in results if r.get('is_preprint'))
    if preprint_n:
        servers = {}
        for r in results:
            if r.get('is_preprint'):
                s = r.get('preprint_server') or '其他'
                servers[s] = servers.get(s, 0) + 1
        detail = '、'.join(f'{esc(k)} {v}'
                           for k, v in sorted(servers.items(), key=lambda kv: -kv[1]))
        parts.append(
            f'<p><b>预印本提示</b>：本文共 <b>{preprint_n}</b> 篇'
            f'（{pct(preprint_n)}%）参考文献来自预印本（{detail}）。'
            f'预印本未经同行评审；其中未被 Crossref 收录者按「未验证」处理，'
            f'不计入不可信，撤稿检测照常执行。</p>')

    # 差异明细表
    # 注：preprint_not_indexed 为 info 级，不进逐条明细（其数量已在汇总表呈现）
    entries = {}
    minor_idx = []  # 年份相差 1 年条目（合并为一行，v2.12.0）
    for r in results:
        status = r.get('status')
        infos = r.get('info') or []
        is_minor = (status == 'verified' and _has_real_difference(r))
        if status not in ('issues_found', 'not_found', 'error') and not is_minor:
            continue
        idx = str(r.get('index', ''))
        if is_minor:
            minor_idx.append(idx)
            continue
        ref_title = r.get('ref_title', '')
        cr_title = r.get('crossref_title') or ''
        cr_year = r.get('crossref_year')
        cr_journal = r.get('crossref_journal') or ''
        issues_list = r.get('issues') or []
        review_note = (r.get('review_note') or '').strip()
        if status == 'issues_found':
            if review_note:
                desc = review_note
            elif issues_list:
                desc = "; ".join(issues_list)
            else:
                desc = 'Crossref 记录与稿件属性不一致'
            cls, text, w = 'warn', '需人工复核', 1
        elif status == 'error':
            desc = '网络错误，未能核验（非不可信，建议重试）'
            cls, text, w = 'info', '未能核验', 0
        else:  # not_found
            if review_note:
                # 人工甄别注记（v2.18.1）：如 Crossref 收录盲区（ISSN 定向复核
                # 确认该刊/年代未入库）等——非"检索失败"亦非"疑似编造"，
                # 风险度降为"需人工复核"（warn），不再直接标"不可信"（bad）
                desc = review_note
                cls, text, w = 'warn', '需人工复核', 1
            elif cr_title:
                desc = (f'未在 Crossref 定位到匹配记录，最接近候选「{cr_title}」'
                        f'（{cr_year}，{cr_journal}），与稿内标题差异较大')
                cls, text, w = 'bad', '不可信', 2
            else:
                desc = f'未在 Crossref 定位到匹配记录（稿内标题：「{ref_title}」）'
                cls, text, w = 'bad', '不可信', 2
        prev = entries.get(idx)
        if prev:
            prev['desc'] += f'；{desc}'
            if w > prev['w']:
                prev['cls'], prev['text'], prev['w'] = cls, text, w
        else:
            entries[idx] = {'desc': desc, 'cls': cls, 'text': text, 'w': w}

    # 著录不完整合并行（不影响可信度，所有文献号 + 问题归组，置表尾）
    merged_desc = ''
    merged_refs = []
    incomplete = rv.get('incomplete') or []
    if incomplete:
        alias = {'缺卷号/页码': '缺页码', '缺页码/卷号': '缺页码'}
        groups = {}
        for it in incomplete:
            raw = str(it.get('issue', '')).strip()
            norm = re.sub(r'[（(].*$', '', raw).strip()
            norm = alias.get(norm, norm)
            groups.setdefault(norm, []).append(str(it.get('ref', '')))
        merged_parts = []
        for norm in sorted(groups):
            refs_ = sorted(groups[norm], key=lambda x: int(x) if x.isdigit() else 0)
            merged_refs.extend(refs_)
            merged_parts.append(f'{esc(norm)}（{"、".join(esc(x) for x in refs_)}）')
        # 去重保序（文献编号列全局升序）
        seen, merged_refs_u = set(), []
        for x in sorted(merged_refs, key=lambda v: int(v) if v.isdigit() else 0):
            if x not in seen:
                seen.add(x)
                merged_refs_u.append(x)
        merged_refs = merged_refs_u
        merged_desc = '；'.join(merged_parts)

    rows = []
    for idx, e in sorted(entries.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 0):
        rows.append(f'<tr><td>[{esc(idx)}]</td><td>{esc(e["desc"])}</td><td>{badge(e["cls"], e["text"])}</td></tr>')
    # 年份相差 1 年合并行（v2.12.0：微小差异不再逐条，合并为一行，位于逐条之后）
    if minor_idx:
        minor_sorted = sorted(minor_idx, key=lambda x: int(x) if x.isdigit() else 0)
        rows.append(
            f'<tr><td>{esc("、".join(minor_sorted))}</td><td>年份相差1年</td>'
            f'<td>{badge("warn", "低风险")}</td></tr>'
        )
    if merged_desc:
        rows.append(
            f'<tr><td>{esc("、".join(merged_refs))}</td><td>著录不完整：{merged_desc}</td>'
            f'<td>{badge("warn", "需人工复核")}</td></tr>'
        )

    if rows:
        parts.append(
            '<p><b>差异明细</b>（真实性差异 + 著录不完整）：</p>'
            + '<table>\n<tr><th>文献编号</th><th>差异说明</th><th>风险度</th></tr>\n'
            + ''.join(rows) + '\n</table>'
        )
    else:
        parts.append('<p class="note">无差异较大、无法定位或著录不完整条目。</p>')

    return '\n'.join(parts)


def load_journal_info(meta):
    """从 meta.journal（如 'Civil Engineering Sciences (CES)'）提取缩写，查期刊记录
    （v2.17.0: 模板 ∪ 用户合并，用户优先）；
    返回期刊 dict；未收录或解析失败返回 None。"""
    journal = str((meta or {}).get('journal', ''))
    m = re.search(r'\(([^()]+)\)\s*$', journal.strip())
    abbrev = (m.group(1).strip().upper() if m else '')
    for j in journal_scopes.load_all():
        if abbrev and str(j.get('abbreviation', '')).upper() == abbrev:
            return j
        if journal.lower() in str(j.get('full_name', '')).lower():
            return j
    return None


def build_scope_header(jinfo):
    """第 2 节起始固定块（纯文本段落）：来源 + 版本日期 + 概括性中文收稿范围。"""
    if not jinfo:
        return ('<p class="note"><b>未收录期刊收稿范围信息</b>：本期刊尚未录入本地数据文件'
                '（assets/journal_scopes.json），请人工核对期刊官网 Aims &amp; Scope。</p>')
    src = jinfo.get('scope_source') or jinfo.get('scope_url', '')
    # F-01: URL 仅作文本显示；非 https 来源隐藏细节（防注入 + 合规）
    if isinstance(src, str) and src.startswith('http'):
        try:
            if urlparse(src).scheme != 'https':
                src = '(非 https 来源，已隐藏)'
        except ValueError:
            src = '(URL 解析失败，已隐藏)'
    ver = jinfo.get('scope_version_date', '未知')
    summ = jinfo.get('scope_summary_zh', '（未收录中文概括）')
    return (f'<p><b>期刊收稿范围对照依据：</b>来源：<span class="mono" style="background:transparent;padding:0">{esc(src)}</span>'
            f'（版本日期：{esc(ver)}）。收稿范围：{esc(summ)}</p>')


def build_scope_analysis_table(rows):
    """第 2 节内容相关性 4 列表格：分析维度 / 稿件特征 / 对应期刊领域 / 匹配度（徽章）。"""
    rows = rows or []
    if not rows:
        return f'<p>{badge("info", "未检测")} 内容相关性分析未执行（scope_analysis 数据缺失）。</p>'
    body = ''.join(
        f'<tr><td>{esc(r.get("dimension", ""))}</td><td>{esc(r.get("paper_feature", ""))}</td>'
        f'<td>{esc(r.get("journal_area", ""))}</td>'
        f'<td>{badge(r.get("match", {}).get("badge", "info"), r.get("match", {}).get("text", "未判定"))}</td></tr>'
        for r in rows)
    return ('<table>\n<tr><th>分析维度</th><th>稿件特征</th><th>对应期刊领域</th><th>匹配度</th></tr>\n'
            + body + '\n</table>')


def build_affiliation_table(rows):
    """3.2 节机构适配 3 列表格：机构 / 判断依据 / 适配度（徽章），一行一个机构；表格下附语义判断提示。"""
    rows = rows or []
    if not rows:
        return f'<p>{badge("info", "未检测")} 机构适配性分析未执行（affiliation_analysis 数据缺失）。</p>'
    body = ''.join(
        f'<tr><td>{esc(r.get("org", ""))}</td><td>{esc(r.get("basis", ""))}</td>'
        f'<td>{badge(r.get("fit", {}).get("badge", "info"), r.get("fit", {}).get("text", "未判定"))}</td></tr>'
        for r in rows)
    return ('<table>\n<tr><th>机构</th><th>判断依据</th><th>适配度</th></tr>\n'
            + body + '\n</table>'
            + '<p class="note">注：本子节判断仅基于机构名称语义，未联网核实机构信息。</p>')


# ── 主流程 ──

def main():
    ap = argparse.ArgumentParser(description='熊猫找茬-新稿 报告固定渲染脚本')
    ap.add_argument('--work', required=True, help='work 目录（含检测 JSON）')
    ap.add_argument('--content', required=True, help='report_content.json 路径')
    ap.add_argument('--out', default='.', help='HTML 输出目录（SKILL.md：建议输出到隔离目录，勿直接覆盖稿件同目录）')
    ap.add_argument('--msid', default=None, help='文件名中的稿件标识（缺省取 meta.manuscript_id）')
    ap.add_argument('--date', default=None, help='文件名日期 YYMMDD（缺省今天）')
    args = ap.parse_args()
    try:
        content = load_json(args.content)
        if not content:
            raise ValueError('report_content.json 缺失或为空')
        require(content, 'meta.manuscript_id',
                'summary.relevance', 'summary.author', 'summary.refs', 'summary.aigc',
                'refs_verify.summary')
        meta = content['meta']
        work = Path(args.work)
        refs = load_json(work / 'refs.json') or []
        authors = load_json(work / 'authors.json')
        refs_rw = load_json(work / 'refs_rw.json')
        geo = load_json(work / 'geo.json')
        aigc = load_json(work / 'aigc.json')
        crossref = load_json(work / 'crossref.json')
        if aigc is None:
            log('WARN: work 目录缺少 aigc.json，AIGC 定量指标表按「未检测」处理（请确认 aigc_stats.py 输出已落盘）')
        rw_meta = load_json(RW_META) or {}
        domain = content.get('manuscript_domain') or '本稿'
        msid = args.msid or meta.get('manuscript_id', 'manuscript')
        msid_safe = re.sub(r'[\\/:*?"<>|\s]+', '_', str(msid))[:40]
        date = args.date or datetime.now().strftime('%y%m%d')
        s = content['summary']
        repl = {
            '{{MANUSCRIPT_ID}}': esc(meta.get('manuscript_id', '')),
            '{{FILES}}': esc(meta.get('files', '')),
            '{{JOURNAL}}': esc(meta.get('journal', '')),
            '{{TITLE}}': esc(meta.get('title', '')),
            '{{AUTHORS}}': esc(meta.get('authors', '')),
            '{{AFFILIATIONS}}': esc(meta.get('affiliations', '')),
            '{{MANUSCRIPT_TYPE}}': esc(meta.get('manuscript_type', '')),
            '{{REFS_COUNT}}': str(len(refs)),
            '{{RW_UPDATE_DATE}}': esc(rw_meta.get('update_date', 'unknown')),
            '{{TOOL_NAME}}': TOOL_NAME,
            '{{REPORT_DATE}}': datetime.now().strftime('%Y-%m-%d %H:%M'),
            '{{POLITICAL_RISK}}': build_political_risk(geo),
            '{{SUMMARY_RELEVANCE_BADGE}}': badge(s['relevance']['badge'], s['relevance']['verdict']),
            '{{SUMMARY_RELEVANCE}}': esc(s['relevance'].get('text', '')),
            '{{SUMMARY_AUTHOR_BADGE}}': badge(s['author']['badge'], s['author']['verdict']),
            '{{SUMMARY_AUTHOR}}': esc(s['author'].get('text', '')),
            '{{SUMMARY_REFS_BADGE}}': badge(s['refs']['badge'], s['refs']['verdict']),
            '{{SUMMARY_REFS}}': esc(s['refs'].get('text', '')),
            '{{SUMMARY_AIGC_BADGE}}': badge(s['aigc']['badge'], s['aigc']['verdict']),
            '{{SUMMARY_AIGC}}': esc(s['aigc'].get('text', '')),
            '{{SCOPE_HEADER}}': build_scope_header(load_journal_info(meta)),
            '{{SCOPE_ANALYSIS_TABLE}}': build_scope_analysis_table(content.get('scope_analysis')),
            '{{RW_TIMEOUT_NOTE}}': esc(content.get('rw_timeout_note', '')),
            '{{AUTHOR_RESULTS}}': build_author_results(
                authors, domain, content.get('author_verdicts')),
            '{{AFFILIATION_TABLE}}': build_affiliation_table(content.get('affiliation_analysis')),
            '{{REFS_YEAR_STATS_TABLE}}': build_year_stats_table(refs, content.get('year_stats_note', '')),
            '{{REFS_CITATION_SECTION}}': build_refs_citation_section(content),
            '{{REFS_VERIFY_RESULTS}}': build_refs_verify(content.get('refs_verify'), crossref),
            '{{REFS_RETRACTION_CHECK}}': build_refs_rw_check(
                refs_rw, len(refs),
                (content.get('refs_rw') or {}).get('verdicts'),
                (content.get('refs_rw') or {}).get('note', '')),
            '{{AIGC_TABLE}}': build_aigc_table(aigc, content.get('aigc_judgments')),
            '{{AIGC_NOTE}}': build_aigc_note(aigc, content.get('aigc_note', '')),
        }
        if not TEMPLATE.exists():
            raise ValueError(f'模板缺失: {TEMPLATE}')
        html_text = TEMPLATE.read_text(encoding='utf-8')
        for k, v in repl.items():
            html_text = html_text.replace(k, v)
        leftover = re.findall(r'\{\{[A-Z_]+\}\}', html_text)
        out = Path(args.out) / f'manuscript_integrity_check_report_{date}_{msid_safe}.html'
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html_text, encoding='utf-8')
        size = out.stat().st_size
        if leftover:
            log('WARN leftover: ' + ', '.join(leftover))
            print(json.dumps({'status': 'warn', 'out_file': str(out.resolve()),
                              'size': size, 'leftover': leftover}, ensure_ascii=False))
            sys.exit(2)
        print(json.dumps({'status': 'ok', 'out_file': str(out.resolve()),
                          'size': size, 'leftover': []}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == '__main__':
    main()

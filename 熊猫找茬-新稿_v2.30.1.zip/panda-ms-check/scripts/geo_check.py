#!/usr/bin/env python3
"""
geo_check.py — 政治敏感词扫描

扫描全文，识别 Taiwan / Tibet / Xizang 关键词（词干匹配，忽略大小写）。
命中时输出完整句子与所属一级标题，供报告第 0 条「潜在政治风险，请人工核查」使用。

Usage:
    python geo_check.py --text <全文文本文件>

Output (stdout): JSON
    {
      "status": "found" | "not_found",
      "hits": [
        {
          "keyword": "Taiwan",
          "sentence": "The samples were obtained from Taiwan, China.",
          "section": "Introduction"
        }
      ],
      "note": null | "未检测到 Taiwan/Tibet/Xizang"
    }
"""

import argparse
import json
import re
import sys
from pathlib import Path

# 关键词正则（词干匹配，忽略大小写）
KEYWORD_PATTERNS = [
    ("Taiwan", r"\btaiwan\w*"),     # 覆盖 Taiwanese
    ("Tibet", r"\btibet\w*"),       # 覆盖 Tibetan
    ("Xizang", r"\bxizang\b"),      # 精确
]
COMPILED = [(name, re.compile(pat, re.IGNORECASE)) for name, pat in KEYWORD_PATTERNS]

# 一级标题词表（去掉数字编号前缀后匹配）
SECTION_TITLES = [
    "abstract", "introduction", "experimental", "experimental section",
    "methods", "methodology", "materials and methods", "results",
    "results and discussion", "discussion", "conclusion", "conclusions",
    "references", "bibliography", "acknowledgements", "acknowledgment",
    "acknowledgments", "supplementary", "appendix", "funding", "declarations",
    "摘要", "引言", "方法", "结果", "讨论", "结论", "参考文献", "致谢",
]
_HEADER_RE = re.compile(r"^\s*(?:\d+(?:\.\d+)*\s+)?(.+?)\s*$")


def extract_sentences(line: str):
    """按句号切分，返回句子列表（忽略过短片段）。"""
    parts = re.split(r"(?<=[.!?])\s+", line.strip())
    return [p.strip() for p in parts if len(p.strip()) >= 15]


def get_section(line: str) -> str | None:
    """判断一行是否是一级标题，是则返回标题文本（去掉编号前缀），否则 None。"""
    m = _HEADER_RE.match(line)
    if not m:
        return None
    title = m.group(1).strip()
    # 常见期刊标题带编号："1 Introduction"、"2. Materials and Methods"
    # _HEADER_RE 已去掉 "1 " / "2. " 前缀，此处再兼容 "1.1 " 子标题（不匹配，只认一级）
    low = title.lower().strip(" .:")
    for t in SECTION_TITLES:
        if low == t or low.startswith(t + " "):
            return title
    return None


def scan(text: str) -> dict:
    """扫描全文，返回命中结果。"""
    lines = text.split("\n")
    current_section = None
    hits = []
    seen = set()

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        # 更新当前章节
        sec = get_section(stripped)
        if sec is not None:
            current_section = sec

        # 检查关键词
        matched_kws = [name for name, rx in COMPILED if rx.search(stripped)]
        if not matched_kws:
            continue

        # 提取含关键词的句子
        for sent in extract_sentences(stripped):
            hit_kws = [name for name, rx in COMPILED if rx.search(sent)]
            if not hit_kws:
                continue
            # 去重：按句子指纹
            fp = re.sub(r"\s+", " ", sent.lower())
            if fp in seen:
                continue
            seen.add(fp)
            hits.append({
                "keyword": "、".join(hit_kws),
                "sentence": sent[:500],
                "section": current_section or "（未识别章节）",
            })

    if not hits:
        return {
            "status": "not_found",
            "hits": [],
            "note": "未检测到 Taiwan/Tibet/Xizang",
        }
    return {
        "status": "found",
        "hits": hits,
        "note": None,
    }


def main():
    parser = argparse.ArgumentParser(description="Scan manuscript for sensitive geo keywords")
    parser.add_argument("--text", required=True, help="Path to the manuscript full-text file (txt)")
    args = parser.parse_args()

    try:
        text = Path(args.text).read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "hits": [],
            "note": f"无法读取文本文件: {e}",
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    result = scan(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

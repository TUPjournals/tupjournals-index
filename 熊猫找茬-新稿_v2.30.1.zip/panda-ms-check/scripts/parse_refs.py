#!/usr/bin/env python3
"""
parse_refs.py — 从全文 References 节解析参考文献（支持 [n] 编号格式，无 DOI）

Usage:
    python parse_refs.py <fulltext.txt> <out_refs.json>

解析策略（对 EMD 风格 "作者, 标题, 期刊, 卷 (年) 页" 无 DOI 格式）：
1. 定位 References 标题之后的 [n] 条目
2. 以年份 `(YYYY)` 为锚：年份前 token 为卷号，卷号前至上一个逗号为期刊名（兼容 "Science, 334 (2011)" 与 "J. Am. Chem. Soc. 135 (2013)" 两种格式）
3. 剩余部分按 ", " 切分：作者片段形如 "X. Y" / "X.Y. Z" / "X.-Y. Z"（首字母缩写+姓），首个非缩写片段起为标题
"""

import json
import re
import sys
from pathlib import Path

# 作者名片段：首字母缩写（可多点/连字符，可空格分隔多个缩写）+ 姓
# v2.11.1：姓支持 Unicode 字母（č/ü/á 等）、多词姓（如 "de Larramendi"）、直/弯撇号（O'Malley）、
# 多缩写（如 "L. M. Da Silva"），避免重音符号/介词姓/弯撇号/多缩写被误判为标题开头
# v2.30.1 两处放宽（EMD20260096 实测：作者列表被整段并入标题）：
#   ① 姓的字符类补「组合附加符」U+0300–U+036F——PDF/EndNote 常把 ç/å/Č/ó 存成「基字母+组合符」
#      形式（Koç / Sångeland / Černe / López），原字符类只到 U+024F，遇组合符即判非作者；
#      姓的第二个字符起允许组合符单独出现，故把「首字符」与「后续字符」拆成两个字符类。
#   ② 缩写簇允许小写字母（J.i. / J.-c. / J.r. / J.-s.）——原 `[A-Z][A-Z.\-]*\.` 只认大写，
#      而 EndNote 会把「Jin-Cheng」类名字导成「J.-c.」，导致该作者起整条被当标题。
#      仅放宽"缩写簇内可含小写"，姓仍要求以大写/Unicode 大写起首，避免吞掉标题片段。
_COMB = r'\u0300-\u036F'
_AUTH_WORD = (r'[A-Za-z\u00C0-\u024F][' + r'A-Za-z\u00C0-\u024F\u2019\'\-\u0300-\u036F' + r']+')
_INIT = r'[A-Z][A-Z]*(?:[.\-]+[A-Za-z])*\.'
AUTHOR_RE = re.compile(
    r'^' + _INIT + r'(\s+' + _INIT + r')*\s+' + _AUTH_WORD + r'(\s+' + _AUTH_WORD + r')*$'
)


def parse_ref_line(line: str) -> dict | None:
    """解析单条参考文献文本，返回结构化字段；失败返回 None。"""
    m = re.match(r'^\s*\[(\d+)\]\s*(.*)$', line)
    if not m:
        return None
    index = int(m.group(1))
    rest = m.group(2).strip().rstrip('.')

    # 提取尾部 DOI（如存在），剥离后按无 DOI 格式解析
    doi_m = re.search(r'https?://(?:dx\.)?doi\.org/(\S+)', rest)
    doi = doi_m.group(1).rstrip('.,)') if doi_m else ''
    if doi_m:
        rest = rest[:doi_m.start()].strip().rstrip('., ')

    # 尾部：VOL? (YEAR) PAGE（v2.11.1 起页码可选；无年份时走缺年份回退分支）
    # 主分支：卷号(可带期号，纯数字) (YYYY) [页码可选]
    tail = re.search(r'(?:,\s*|\s+)(\d+(?:\(\d+\))?)?\s*\((\d{4})\)\s*(?:([\w\-–—]+)\s*)?$', rest)
    no_year = tail is None
    if no_year:
        # 缺年份容错：卷(期) 后直接页码/article 号（如 "Science Advances 2(1)  e1501038"）
        tail = re.search(r'(?:,\s*|\s+)(\d+(?:\(\d+\))?)?\s*(?:\(\d+\)\s*)?([\w\-–—]+)\s*$', rest)
    if not tail:
        return {'index': index, 'raw': line, 'parse_failed': True}

    pre = rest[:tail.start()].rstrip(', ')
    if no_year:
        year = ''
        page = (tail.group(2) or '')
        volume = (tail.group(1) or '')
    else:
        year = str(int(tail.group(2)))
        page = (tail.group(3) or '')
        volume = (tail.group(1) or '')
    # 卷号带期号（如 "2(1)" / "334(6058)"）剥离期号
    volume = re.sub(r'\(\d+\)$', '', volume).strip()

    # 期刊名 = pre 中最后一个逗号之后的内容（去掉卷号残留）
    segs = [s.strip() for s in pre.split(',')]
    journal = segs[-1].strip()
    # 若 volume 紧贴 journal（无逗号格式，如 "J. Am. Chem. Soc. 135"），需从 journal 中剥离卷号
    if volume:
        jpat = re.sub(r'[\s]*' + re.escape(volume) + r'\s*$', '', journal).strip()
        if jpat != journal:
            journal = jpat
    else:
        # 无卷号，journal 尾部可能残留数字 token（如 "A2093" 类页码不属于期刊）
        pass

    # 作者/标题分界
    author_parts = []
    title_parts = []
    in_title = False
    for seg in segs[:-1]:
        seg = seg.strip()
        if not in_title and seg and AUTHOR_RE.match(seg):
            author_parts.append(seg)
            continue
        in_title = True
        title_parts.append(seg)

    title = ' '.join(title_parts).strip()
    authors = ', '.join(author_parts).strip()

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal,
        'volume': volume,
        'year': str(year),
        'page': page,
        'doi': doi,
    }


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs.py <fulltext.txt> <out_refs.json>', file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'}, ensure_ascii=False))
        sys.exit(1)
    out = Path(sys.argv[2])

    # 定位 References 节（行级截断，兼容独立行/带编号标题；回退首个 [N] 行）
    lines = text.split('\n')
    start = None
    for i, ln in enumerate(lines):
        s = ln.strip().lower().rstrip('.: ')
        if s in ('references', 'reference', 'bibliography') or re.fullmatch(r'[\d.\s]*references?', s) or re.fullmatch(r'[\d.\s]*bibliography', s):
            start = i + 1
            break
    if start is None:
        for i, ln in enumerate(lines):
            if re.match(r'^\s*\[\d+\]', ln):
                start = i
                break
    if start is None:
        print('ERROR: References section not found', file=sys.stderr)
        sys.exit(1)
    ref_body = '\n'.join(lines[start:])

    refs = []
    failed = []
    for raw_line in ref_body.split('\n'):
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        parsed = parse_ref_line(raw_line)
        if parsed is None:
            continue
        if parsed.pop('parse_failed', False):
            failed.append(parsed)
            continue
        refs.append(parsed)

    refs.sort(key=lambda r: r['index'])
    out.write_text(json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({
        'refs_total': len(refs),
        'parse_failed': failed,
    }, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

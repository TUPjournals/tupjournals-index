#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_acs.py — 编号式 ACS house style（F13，v2.27.0）

适用格式（**ACS 期刊模板导出**、EMD/AIP/ACS 系投稿常见）：

    (n) Surname, A. B.; Surname, C. D.; Surname, E.; et al. Title of the Paper.
        Journal Name YEAR, Volume (Issue), startPage–endPage. DOI: 10.xxxx/yyyy.

实例（EMD20260084 实测，48 条）：
    (1) Jiang, A.; Xie, H.; …; et al. Nd Doping Inhibits Lattice Oxygen Loss to
        Enhance High-Voltage Durability of Ni-Rich Cathodes. Advanced Functional
        Materials 2026, 36 (12), e19006. DOI: https://doi.org/10.1002/adfm.202519006.
    (3) Zhou, Y.; … Development of Silicon-Based Anode … Engineered Science 2024,
        28, 1060, journal article. DOI: 10.30919/es1060.
    (16) Wang, L.; Lu, J. Marching towards cobalt-free cathode … Mater. Today 2026,
        95, 103284.
    (32) Zeng, L.; … LiNi Co Mn O cathode material. Nanoscale 2026,
        10.1039/D6NR00132G.            ← 在线优先：无卷无页，年份后直接是 DOI
    (40) Lei, X.; … Angewandte Chemie International Edition n/a (n/a), e1523894.

为什么既有 12 策略全部失败（EMD20260084 实测：最高 `vancouver` 仅 0.095，
48 条中 46 条报 `no year`）：
  · 结构是「作者**分号**分隔 + 标题 + 刊名 + **年** + 卷(期) + 页」——
    **年份在刊名之后、卷号之前**，与所有既有策略的锚点都不合：
    `numbered` 要年份在行尾、`numbered_year` 要年份紧跟作者、`gbt7714` 要
    `[J]` 标识、`rsc` 要 `, 年` 逗号锚点（本格式年份前无逗号，刊名后直接
    空格接年份）、`ieee` 要 `vol./no./pp.`、`elsevier` 要年份带括号。

本策略的定位方法：
  1. **先摘 DOI/URL**（顺序不可反：先提 DOI 再删链接，否则 DOI 随链接丢失）；
  2. 以**右侧「年 + 卷(期) + 页」尾式**为锚点（`YEAR, Vol (Issue), Pages.`），
     年份前允许空格（ACS 无逗号）也允许逗号（个别作者手写）；
  3. 左侧刊名用「从右往左扫描」提取：Title-Case 词 / 缩写词（`Mater.`
     `J.` `Chem.`）/ 连接词（`of` `and` `&`）连续收集，遇到「以句点收尾且
     不是缩写」的词即停（该词是标题末词）；**连续数字 token 跳过**（PDF
     把化学式下标提成独立行，如 `Journal 0.90 0.05 0.05 2 2021`）；
  4. 作者段按 `;` 分段，逐段用「姓, 名缩写」判据消费，末段可能挂着标题
     （`et al.` 或 `Surname, X. Title…`），单独二次切分。

输出与既有策略一致；失败返回 {'parse_failed': True, ...}。
"""

import json
import re
import sys
from pathlib import Path

# 破折号四字符类（与 citation_stats / elsevier 同源教训：缺 U+2212 会让
# `1417−1427` 这类页码静默失配）
_DASH = r'\-\u2013\u2014\u2212'

# 作者段：「姓, 名缩写」——姓可多词（Thien Nguyen / Van Tendeloo），
# 缩写含连字符与小数点（`S.-m.` / `U.-H.` / `F. u.`）
_AUTH_SEG = re.compile(
    r"^[A-Z][A-Za-z\u00C0-\u024F'’\-\.]*"
    r"(?:\s+[A-Z][A-Za-z\u00C0-\u024F'’\-\.]*)*"
    r",\s*(?:[A-Za-z]{1,2}\.\s*-?\s*)+$"
)

# 末段（挂标题的作者段）：作者前缀 + 标题正文
_AUTH_LAST = re.compile(
    r"^([A-Z][A-Za-z\u00C0-\u024F'’\-\.]*"
    r"(?:\s+[A-Z][A-Za-z\u00C0-\u024F'’\-\.]*)*"
    r",\s*(?:[A-Za-z]{1,2}\.\s*-?\s*)+)"
    r"(?:\.\s*)?(.+)$"
)

_ETAL_LAST = re.compile(r"^(?:et\s+al\.?)\s*(.+)$", re.I)

# 刊名中允许的小写连接词
_CONJ = {'of', 'the', 'and', 'in', 'on', 'for', 'de', 'del', 'der', 'van',
         'von', 'und', 'la', 'le', 'du', 'des', '&'}

# 缩写词白名单。
# ⚠️ 不可用「Title-Case 短词 + 句点」作判据——标题末词常是 `Route.` / `Cells.`
# / `Study.`，会被当缩写吞进刊名（EMD20260084 [22] 实测：刊名变成
# "Long- Time Molten-Salt Route. Small Methods"）。只认期刊缩写常见词形
# （`Mater.` `Chem.` `J.` `Am.` `Soc.` `Rev.` `Lett.` …）+ 全大写短缩写（`ACS` / `RSC`）。
_ABBREV_WORDS = frozenset("""
j am chem soc phys rev lett mater adv appl sci eng res int proc natl acad
commun energy environ electrochem acta solid state technol biotechnol polym
catal biol med nucl instrum methods anal coord cryst struct mol opt electron
power sources surf coat ind rep prog trans metall ceram compos photovolt
spectrosc chromatogr aiche inst conf symp ser bull mag mater today nano
""".split())


def _is_abbrev(word: str) -> bool:
    core = word.rstrip('.').strip()
    if not core:
        return False
    if core.isupper() and 2 <= len(core) <= 6:
        return True
    return core.lower() in _ABBREV_WORDS

# 页码 / 文章号（含连字符区间，允许 e 前缀与纯数字）
_PAGE = re.compile(r"^[A-Za-z]{0,2}\d[\w]*(?:\s*[" + _DASH + r"]\s*[A-Za-z]{0,2}\d[\w]*)?$")

_DOI_PAT = re.compile(
    r"(?:https?://(?:dx\.)?doi\.org/|doi\s*:\s*)?(10\.\d{4,9}/[^\s,;]+)", re.I)

_TAG_PAT = re.compile(
    r"\b(?:journal\s+article|research[\-\s]article|review[\-\s]article|"
    r"journal[\-\s]article)\b", re.I)


def _norm_page(p: str) -> str:
    p = re.sub(r"\s+", "", p or "")
    p = re.sub(r"[" + _DASH + r"]", "\u2013", p)
    return p.strip(".,; ")


def _extract_journal(head: str):
    """从 head 右端提取刊名，返回 (body, journal)。

    从右往左逐词收集：Title-Case 词 / 缩写词 / 连接词均纳入；
    纯数字 token **跳过但不纳入**（PDF 把化学式下标提成独立行的残留）；
    遇到「以 `.` `?` 收尾且不像缩写」的词即停（该词属标题）。
    """
    words = head.split()
    jw = []
    start = None
    skipped_num = 0
    for i in range(len(words) - 1, -1, -1):
        w = words[i]
        core = w.strip(",;")
        if not core:
            break
        # 纯数字 / 数字下标残留：跳过（最多 8 个，防跑飞）
        if re.fullmatch(r"[\d\.\u00B7]+", core) and skipped_num < 8:
            skipped_num += 1
            continue
        if re.search(r"[,;()\[\]\"]", core):
            break
        if _is_abbrev(core):
            jw.append(core)
            start = i
        elif core.endswith(('.', '?', '!')):
            break                      # 标题末词（句点收尾、非缩写）
        elif core.lower() in _CONJ:
            if not jw:
                break
            jw.append(core)
            start = i
        elif core[0].isupper():
            jw.append(core)
            start = i
        else:
            break
        if len(jw) >= 12:
            break

    journal = ' '.join(reversed(jw)).strip()
    if not journal or start is None:
        return head, ''
    # 刊名与年份之间可能夹着被 PDF 提成独立行的化学式下标
    # （`… batteries. Chemical 0.8 0.1 0.1 2 Engineering Journal 2021,`），
    # 此时刊名在 head 里**不是连续串**，不能用字符串定位切分——按 token 下标切。
    body = ' '.join(words[:start]).strip().rstrip(',;: ').strip()
    return body, journal


def _split_authors_title(body: str):
    """作者与标题的边界：按 `;` 分段消费作者，末段二次切分。"""
    segs = [s.strip() for s in body.split(';') if s.strip()]
    authors, title = [], ''
    for i, seg in enumerate(segs):
        if _AUTH_SEG.match(seg):
            authors.append(seg)
            continue
        # 末段：`et al. 标题…` 或 `Surname, X. 标题…`
        m = _ETAL_LAST.match(seg)
        if m:
            authors.append('et al.')
            title = ' '.join([m.group(1).strip()] + segs[i + 1:])
            return authors, title
        m = _AUTH_LAST.match(seg)
        if m:
            authors.append(m.group(1).strip().rstrip('.'))
            title = ' '.join([m.group(2).strip()] + segs[i + 1:])
            return authors, title
        title = ' '.join(segs[i:])
        return authors, title
    return authors, title


def _clean_title_debris(title: str) -> str:
    """清除标题中「化学式下标被 PDF 提成独立行」留下的数字串。

    PDF 把 `LiNi0.9Co0.05Mn0.05O2` 拆成 `LiNi Co Mn O` + 另起一行的
    `0.9 0.05 0.05 2`，续行合并后这串数字会落在标题中段（EMD20260084
    [21][22][27] 实测）→ 与 Crossref 标题的 token 重叠率被拉低，误报
    `title_mismatch`。

    判据从严，避免误删标题里的真实数值（如 `4.5 V`）：
      **连续 ≥2 个纯数字 token，且其中 ≥2 个带小数点**（下标指纹）。
    单个数字（`4.5`、`2026`）一律保留。
    """
    toks = title.split()
    out, i = [], 0
    while i < len(toks):
        j = i
        while j < len(toks) and re.fullmatch(r"\d+(?:\.\d+)?", toks[j].strip('.,;')):
            j += 1
        run = toks[i:j]
        if len(run) >= 2 and sum(1 for t in run if '.' in t) >= 2:
            i = j                      # 判为下标残留，整段丢弃
            continue
        out.append(toks[i])
        i += 1
    return ' '.join(out)


def parse_line(index, raw):
    """解析单条条目。raw 为 `(n)` 之后（或含 `(n)` 前缀）的文本。"""
    line = (raw or '').strip()
    if not line:
        return None

    m = re.match(r'^\s*[\(\[]\s*(\d{1,4})\s*[\)\]]\s*', line)
    if m:
        index = int(m.group(1))
        line = line[m.end():].strip()

    rest = line.strip().rstrip('.').strip()
    if not rest:
        return None

    # ---- DOI 先摘（含 `10.xxx` 裸串）；URL 一并清除
    doi = ''
    dm = _DOI_PAT.search(rest)
    if dm:
        doi = dm.group(1).rstrip('.,);')
        rest = (rest[:dm.start()] + ' ' + rest[dm.end():]).strip()
    rest = re.sub(r'https?://\S+', ' ', rest)
    # 残留的 `DOI:` / `doi:` 标签（DOI 串已被摘走，标签仍在行尾）
    rest = re.sub(r'(?i)[\s,;]*\bdoi\s*:?\s*$', ' ', rest)
    rest = re.sub(r'\s{2,}', ' ', rest).strip(' .,;')

    # 页码区间内的空格（`347– 353` → `347–353`）
    rest = re.sub(r'(\d)\s*[' + _DASH + r']\s*(\d)', '\\1\u2013\\2', rest)
    rest = _TAG_PAT.sub('', rest)
    rest = re.sub(r'\s{2,}', ' ', rest).strip(' .,;')

    # ---- 年份锚点：右侧最后一个 `年,`（或 `年 ` 后接卷）
    ym = None
    for mm in re.finditer(r'(?:^|[\s,;])((?:19|20)\d{2})\s*,', rest):
        ym = mm
    year, tail = '', ''
    if ym:
        year = ym.group(1)
        head = rest[:ym.start()].strip().rstrip(',;: ').strip()
        tail = rest[ym.end():].strip()
    else:
        # 在线优先：`… Journal n/a (n/a), e1523894.`
        mn = re.search(r'\bn\s*/\s*a\s*\(\s*n\s*/\s*a\s*\)\s*,', rest, re.I)
        if not mn:
            return {'index': index, 'raw': raw[:200] if raw else '',
                    'parse_failed': True, 'reason': 'no year anchor'}
        head = rest[:mn.start()].strip().rstrip(',;: ').strip()
        tail = rest[mn.end():].strip()

    # ---- 尾式：卷 (期), 页
    vol = issue = page = ''
    parts = [p.strip() for p in tail.split(',') if p.strip()]
    for p in parts:
        p = p.strip().strip('.').strip()
        if not p:
            continue
        mv = re.match(r'^(\d{1,5})\s*(?:\(\s*([^)]{1,12})\s*\))?$', p)
        if mv and not vol:
            vol, issue = mv.group(1), (mv.group(2) or '').strip()
            continue
        tok = p.split()[0].strip('.,;')
        if _PAGE.match(tok) and not page:
            page = _norm_page(tok)
    # 卷期可能写作 `11 (48)` 但被空格劈开 → 从句尾再找一次
    if not vol:
        mv = re.search(r'([\s,;])(\d{1,5})\s*(?:\(\s*([^)]{1,12})\s*\))?\s*$', tail)
        if mv:
            vol, issue = mv.group(2), (mv.group(3) or '').strip()

    body, journal = _extract_journal(head)
    authors, title = _split_authors_title(body)

    title = re.sub(r'\s{2,}', ' ', title).strip()
    title = _clean_title_debris(title).rstrip('.,;: ').strip()
    authors = '; '.join(authors).strip().strip(';').strip()
    if authors.lower().endswith('et al'):
        authors = authors + '.'

    if not title and not authors:
        return {'index': index, 'raw': raw[:200] if raw else '',
                'parse_failed': True, 'reason': 'no authors/title'}

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal,
        'volume': vol,
        'issue': issue,
        'year': str(year),
        'page': page,
        'doi': doi,
    }


# ------------------------------------------------------------------ CLI

def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_acs.py <fulltext.txt> <out_refs.json>',
              file=sys.stderr)
        sys.exit(1)
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import ref_common as rc

    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    start = rc.locate_references(text)
    if start is None:
        print(json.dumps({'status': 'error', 'error': 'References section not found'},
                         ensure_ascii=False))
        sys.exit(1)
    lines, _ = rc.preprocess(text[start:])
    entries = rc.split_entries(lines)

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if not isinstance(r, dict) or r.get('parse_failed'):
            failed.append(r if isinstance(r, dict) else {'index': idx, 'raw': txt[:200]})
        else:
            refs.append(rc.clean_ref(r))

    Path(sys.argv[2]).write_text(json.dumps(refs, ensure_ascii=False, indent=1),
                                encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

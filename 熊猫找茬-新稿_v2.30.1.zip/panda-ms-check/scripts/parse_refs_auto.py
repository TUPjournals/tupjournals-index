#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_auto.py — 参考文献解析统一入口（v2.18.0）

解决问题：不同投稿稿件的参考文献格式五花八门，过去靠人工判断格式再手选
解析器，失败率高、反复试错耗时。本脚本自动完成：

  1. 预处理：去分页标记、稳健识别并剥离 PDF 页码水印
  2. 编号识别：[1] / (1) / 1. / 1) / 1␣ 及无编号
  3. 格式识别：对采样条目用**多策略并行打分**，选最优策略
  4. 全量解析 + 失败条目用次优策略兜底
  5. 预印本识别与统计

CLI:
    python parse_refs_auto.py <fulltext.txt> <out_refs.json>
        [--strategy=auto|numbered|apa|noidx_apa|vancouver|nature|
                    noidx_vancouver|numbered_year|gbt7714|rsc|ieee|elsevier|
                    springer|acs|numbered_jv]
        [--sample=10]

stdout 输出机器可读 JSON（不含日志，日志走 stderr）：
    {"status", "strategy", "scores", "refs_total", "preprint",
     "page_numbers_detected", "numbering", "parse_failed"}
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import ref_common as rc                    # noqa: E402
import parse_refs                          # noqa: E402  (F1 编号式)
import parse_refs_apa                      # noqa: E402  (F2 编号 APA)
import parse_refs_noidx_apa                # noqa: E402  (F3 无编号 APA)
import parse_refs_vancouver                # noqa: E402  (F4 Vancouver)
import parse_refs_nature                   # noqa: E402  (F5 Nature)
import parse_refs_noidx_vancouver          # noqa: E402  (F6 无编号 NLM/Vancouver)
import parse_refs_numbered_year            # noqa: E402  (F7 编号+裸年份紧跟作者)
import parse_refs_gbt7714                  # noqa: E402  (F8 GB/T 7714 带 [J] 标识)
import parse_refs_rsc                      # noqa: E402  (F9 编号式无篇名，RSC 式)
import parse_refs_ieee                     # noqa: E402  (F10 编号式 IEEE house style)
import parse_refs_elsevier                 # noqa: E402  (F11 编号式 Elsevier)
import parse_refs_springer                 # noqa: E402  (F12 编号式 Springer/CVMJ)
import parse_refs_acs                      # noqa: E402  (F13 编号式 ACS house style)
import parse_refs_numbered_jv              # noqa: E402  (F14 编号式「期刊. 年, 卷(期), 页」)


# ---------------------------------------------------------------- 策略适配

def _adapt_legacy(parse_fn, name):
    """把老的 parse_ref_line(line) 适配为统一的 parse_line(index, line)。

    老脚本要求整行以 [n] 开头，这里补上编号再调用。
    """
    def wrapper(index, line):
        r = parse_fn(f'[{index}] {line}')
        if r is None:
            return {'index': index, 'raw': line[:200],
                    'parse_failed': True, 'reason': 'no match'}
        if r.pop('parse_failed', False):
            r['index'] = index
            r.setdefault('raw', line[:200])
            r.setdefault('reason', 'parse failed')
            # v2.18.2（关键修复）：必须把 parse_failed 放回。
            # 早期版本在此 pop 后未回填，run_strategy 再 pop 一次得到 False，
            # 于是**解析失败被误判为成功**并混入 refs，产出「字段全空的文献」
            # （CES 实测 30/30 全空、parse_failed 汇总却为空）→ Crossref 会把
            # 全部文献报成「无法定位」，制造"整篇文献不可信"的假象。
            r['parse_failed'] = True
            return r
        r['index'] = index
        return r
    wrapper.__name__ = name
    return wrapper


STRATEGIES = {
    # 名称: (解析函数, 说明)
    'numbered':   (_adapt_legacy(parse_refs.parse_ref_line, 'numbered'),
                   '编号式：[n] 作者, 标题, 期刊 卷 (年) 页码'),
    'apa':        (_adapt_legacy(parse_refs_apa.parse_ref_line, 'apa'),
                   '编号 APA：[n] 作者 (年). 标题. 期刊 卷, 页码'),
    'noidx_apa':  (parse_refs_noidx_apa.parse_line,
                   '无编号 APA：作者 (年). 标题. 期刊 卷, 页码'),
    'vancouver':  (parse_refs_vancouver.parse_line,
                   'Vancouver：[n]. 作者, 年. 标题. 期刊, 卷, p.页码'),
    'nature':     (parse_refs_nature.parse_line,
                   'Nature：作者 (et al/&) 标题. 期刊 卷, 页码 (年)'),
    'noidx_vancouver': (parse_refs_noidx_vancouver.parse_line,
                        '无编号 NLM/Vancouver：作者. 标题. 期刊. 年;卷:页'),
    'numbered_year': (parse_refs_numbered_year.parse_line,
                      '编号+裸年份紧跟作者（皇家学会/SPJ）：[n] 作者. 年 标题. '
                      '期刊 卷, 页码. (doi:…)'),
    'gbt7714':    (parse_refs_gbt7714.parse_line,
                   'GB/T 7714（中文期刊英文著录）：[n]作者列表. 标题 [J]. '
                   '期刊, 年, 卷(期): 页码.'),
    'rsc':        (parse_refs_rsc.parse_line,
                   '编号式无篇名（RSC/皇家化学会）：<n>.<作者>, 期刊, 年, 卷, 页码.'),
    'ieee':       (parse_refs_ieee.parse_line,
                   '编号式 IEEE house style（Zotero 导出）：[n] 作者, '
                   '\u2018篇名\u2019, 期刊缩写, vol. 卷, no. 期, pp. 页, Mon. 年, doi:…'),
    'elsevier':   (parse_refs_elsevier.parse_line,
                   '编号式 Elsevier/SciOpen：[n] 作者, 标题. 期刊 卷 (期) (年) 页码.'),
    'springer':   (parse_refs_springer.parse_line,
                   '编号式 Springer/CVMJ：[n] 作者（分号分隔、双句点结尾）.. 标题. 来源, 年, 页码.'),
    'acs':        (parse_refs_acs.parse_line,
                   '编号式 ACS：(n) 作者（分号分隔）; et al. 标题. 期刊 年, 卷 (期), 页.'),
    'numbered_jv': (parse_refs_numbered_jv.parse_line,
                    '编号式（作者逗号分隔）：[n] 作者, 标题. 期刊. 年, 卷(期), 页.'),
}


# ---------------------------------------------------------------- 打分

def score_strategy(results, total):
    """策略打分：0.6×成功率 + 0.2×字段完整度 + 0.2×年份命中率。"""
    if not total:
        return 0.0
    success = sum(1 for r in results if rc.is_healthy(r))
    rate = success / total
    completeness = sum(rc.field_completeness(r) for r in results) / total
    year_rate = sum(1 for r in results if str(r.get('year') or '').strip()) / total
    return round(0.6 * rate + 0.2 * completeness + 0.2 * year_rate, 4)


def _recovery_ok(r, txt):
    """兜底（次优策略）结果的合理性闸门 —— v2.26.1 新增。

    主策略失败后由次优策略"救回"的条目必须过闸，避免「错得看起来像成功」的
    垃圾字段混入 refs：`rc.is_healthy` 只要求「title ≥8 字符 且 (year 或 journal)」，
    故同一批条目被**误配到别的策略**时（如 NLM/CSE 式稿件被 `numbered` 误配）
    同样能通过，产出「year 全空 + volume=11618（页码被腰斩）+ page=-1141（负号）」
    的字段并进入报告（EMD20260076 实测 6 条）。

    闸门：原文含 4 位年份、而结果 year 为空 → 判错（不以垃圾充数）。
    原文本无年份（`n/a` / 纯 URL 资源）时不受影响。
    """
    if str(r.get('year') or '').strip():
        return True
    return not re.search(r'\b(?:19|20)\d{2}\b', txt or '')


def run_strategy(name, entries):
    """用指定策略解析全部条目，返回 (refs, failed)。"""
    fn = STRATEGIES[name][0]
    refs, failed = [], []
    for idx, txt in entries:
        try:
            r = fn(idx, txt)
        except Exception as e:                       # 单条异常不影响整批
            failed.append({'index': idx, 'raw': txt[:200], 'reason': f'exception: {e}'})
            continue
        if not isinstance(r, dict) or r.pop('parse_failed', False):
            r = r if isinstance(r, dict) else {}
            r.setdefault('index', idx)
            r.setdefault('raw', txt[:200])
            failed.append(r)
        else:
            refs.append(rc.clean_ref(r))
    return refs, failed


# ---------------------------------------------------------------- 主流程

def auto_parse(text, sample_size=10, forced=None):
    """自动解析全文，返回 (refs, failed, info)。"""
    start = rc.locate_references(text)
    if start is None:
        return [], [], {'status': 'error', 'error': 'References section not found'}

    lines, has_pn = rc.preprocess(text[start:])
    nonempty = [l.strip() for l in lines if l.strip()]
    mode = rc.detect_numbering(nonempty[:40])
    entries = rc.split_entries(lines, unnumbered=(mode == 'unnumbered'))
    # v2.18.1：常规无编号切分（作者起始正则）0 命中时，回退 NLM/Vancouver
    # 锚定切分（行首形似姓氏 + 行内含 年;卷），CESCI-D-26-00016R1 实测
    if not entries and mode == 'unnumbered':
        entries = rc.split_entries_nlm(lines)

    if not entries:
        return [], [], {'status': 'error', 'error': 'no reference entries found',
                        'numbering': mode}

    info = {
        'status': 'ok',
        'page_numbers_detected': has_pn,
        'numbering': mode,
        'entries': len(entries),
        'sample_size': min(sample_size, len(entries)),
    }

    # ---- 1) 指定策略：直接全量
    if forced and forced in STRATEGIES:
        refs, failed = run_strategy(forced, entries)
        info.update({'strategy': forced, 'scores': {}, 'forced': True})
        return refs, failed, info

    # ---- 2) 采样打分：多策略并行（顺序执行即可，采样量极小）
    sample = entries[:sample_size]
    scores = {}
    sample_refs = {}
    for name in STRATEGIES:
        refs_s, _ = run_strategy(name, sample)
        sample_refs[name] = refs_s
        scores[name] = score_strategy(refs_s, len(sample))

    # 篇名覆盖率：并列打分时的第二排序键（v2.27.1）
    # `rsc` 的「无篇名」通道让 is_healthy 放行、且只考核 year/journal/authors
    # 三字段，故「标题全空但年份期刊对」也能拿 1.0 分（CESCI-S-26-00053 实测：
    # IEEE 式稿件 rsc 1.0 / springer 1.0 / ieee 0.975 → 选中 rsc，输出 44 条
    # title 全空、journal 变成 "Art. no. 132336"、page 变成 "doi:"）。
    # 同分（差 <0.05）时优先取**篇名覆盖率更高**者，即"信息更完整者胜"。
    title_cov = {}
    for name in STRATEGIES:
        rs = sample_refs.get(name) or []
        title_cov[name] = (sum(1 for r in rs if str(r.get('title') or '').strip())
                           / max(1, len(sample)))

    ranked = sorted(scores.items(),
                    key=lambda kv: (kv[1], title_cov.get(kv[0], 0.0)),
                    reverse=True)

    # 并列时（分差 <0.05）优先选择与编号模式匹配的策略，让选择结果更可解释：
    # 无编号稿件的 apa 与 noidx_apa 解析结果等价，但后者才是语义上的正确归类。
    # 但**不得以牺牲篇名覆盖率为代价**（rsc 的 title 全空 vs ieee 的 title 齐全）。
    def _mode_match(name):
        if mode == 'unnumbered':
            return name in ('noidx_apa', 'nature', 'noidx_vancouver')
        return name in ('numbered', 'apa', 'vancouver', 'numbered_year',
                        'gbt7714', 'rsc', 'ieee', 'elsevier', 'springer', 'acs',
                        'numbered_jv')

    best, best_score = ranked[0]
    for name, sc in ranked:
        if (best_score - sc < 0.05 and _mode_match(name)
                and title_cov.get(name, 0.0) >= title_cov.get(best, 0.0)):
            best, best_score = name, sc
            break
    second, second_score = next(
        ((n, s) for n, s in ranked if n != best), (None, 0.0))

    # ---- 3) 全量执行最优策略
    refs, failed = run_strategy(best, entries)

    # ---- 4) 失败条目兜底：用次优策略逐个重试（应对混合格式）
    recovered = 0
    if failed and second and best_score > 0:
        retry_idx = {f.get('index') for f in failed}
        for idx, txt in entries:
            if idx not in retry_idx:
                continue
            try:
                r = STRATEGIES[second][0](idx, txt)
            except Exception:
                continue
            if (isinstance(r, dict) and not r.get('parse_failed')
                    and rc.is_healthy(r) and _recovery_ok(r, txt)):
                refs.append(rc.clean_ref(r))
                failed = [f for f in failed if f.get('index') != idx]
                recovered += 1

    refs.sort(key=lambda r: r.get('index') or 0)
    failed.sort(key=lambda f: f.get('index') or 0)

    info.update({
        'strategy': best,
        'scores': scores,
        'second': second,
        'recovered_by_second': recovered,
        'preprint': rc.summarize_preprints(refs),
    })
    return refs, failed, info


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_auto.py <fulltext.txt> <out_refs.json> '
              '[--strategy=auto|numbered|apa|noidx_apa|vancouver|nature|'
              'noidx_vancouver|numbered_year|gbt7714|rsc|ieee|elsevier|springer|'
              'acs|numbered_jv] '
              '[--sample=10]', file=sys.stderr)
        sys.exit(1)

    in_file, out_file = sys.argv[1], sys.argv[2]
    forced, sample = None, 10
    for arg in sys.argv[3:]:
        if arg.startswith('--strategy='):
            forced = arg.split('=', 1)[1]
            if forced == 'auto':
                forced = None
            elif forced not in STRATEGIES:
                print(json.dumps({'status': 'error',
                                  'error': f'unknown strategy: {forced}'},
                                 ensure_ascii=False))
                sys.exit(1)
        elif arg.startswith('--sample='):
            try:
                sample = int(arg.split('=', 1)[1])
            except ValueError:
                pass

    try:
        text = Path(in_file).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    refs, failed, info = auto_parse(text, sample_size=sample, forced=forced)

    Path(out_file).write_text(
        json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')

    info.update({'refs_total': len(refs), 'parse_failed': failed})
    print(json.dumps(info, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

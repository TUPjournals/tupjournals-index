#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_elsevier.py — 编号式 Elsevier（F11）

适用格式（Elsevier / SciOpen 系投稿常用、作者自由著录常见）：

    [n] <Author1>, <Author2>, ..., <Title>. <Journal> <Vol> (<Issue>) (<Year>) <Pages>.
    [n] <Authors>, <Title>, <Journal> <Vol> (<Year>) <ArtNo>.

实例（EMD20260073 实测）：
    [3] Q. Pan, Q. Zhong, ..., B. Feng, Perovskite solar cells towards
        industrialization: overcoming challenges with data-driven strategies,
        Nanoscale 18 (16) (2026) 8403-8421
    [1] Y. Zhang, ..., N. G. Park, Octahedral connectivity reconfigures
        interfacial carrier-selective properties for efficient perovskite solar
        cells. Nat. Mater. (2026)                    ← 无卷期
    [6] Y. Gu, ..., P. Luo, Ambient-air-processed solvent engineering for
        efficient and stable CsPbI3 inorganic perovskite solar cells
        Chemical Engineering Journal 519 (2025) 165415   ← 标题/刊名间无标点

为什么既有策略全部失败（EMD20260073 实测：10 策略最高仅 numbered 0.78
且字段错位——title 空、year 空、journal 混入标题尾部）：
  · `numbered` 假定「作者, 标题, 期刊, 卷 (年) 页」**全逗号分隔且年份在行尾**；
    本格式年份带括号居中、卷期连写 `18 (16)`、标题与刊名之间可能为**句点或
    直接空格**，且作者段含 `and X.` 形式（numbered 的 AUTHOR_RE 不认 `and`）。
  · 其余策略均要求各自的结构锚点（逗号年份 / 分号年卷 / `[J]` 标识等），不匹配。

本策略的定位方法：
  1. 以**最后一个 `(YYYY)` 为唯一锚点**（year 必带括号且位于卷期之后）；
  2. 右侧残段 tail 为页码/文章号——**门控**：tail 须短（≤40 字符）且不含
     `. `（多个句点），否则判失败交给其他策略（防止误抢 APA `作者 (年). 标题. 期刊`
     这类「年份也在括号里」的格式）；
  3. 左侧剥「卷 (期)」/「卷, 期」/「卷」；
  4. 刊名用**从右往左连续 Title-Case 词**提取（允许 of/in/and/for/de 等连接词、
     允许 `Measurement: Energy` 的冒号、允许 `J. Mater. Chem. C` 的缩写点），
     遇到小写实词或含逗号/括号的词即停 —— 这样即便标题与刊名之间**无任何标点**
     也能切准（[6] 实测）；
  5. 剩余按逗号分段做作者/标题边界判定，兼容无缩写点的作者名（`Marc Al Atem`）。

输出与既有策略一致的结构化 dict；失败返回 {'parse_failed': True, ...}。
"""

import json
import re
import sys
from pathlib import Path

# 破折号四字符类（与 citation_stats / noidx_vancouver 同源教训：
# 缺 U+2212 数学减号会让 `802−806` 这类页码静默失配）
_DASH = r'\-\u2013\u2014\u2212'

# 作者名片段：首字母缩写（可多点/连字符/空格分隔多个缩写）+ 姓
# （与 parse_refs.py 保持一致，含 Unicode 字母 / 撇号 / 多词姓）
_AUTH_WORD = r'[A-Za-z\u00C0-\u024F][A-Za-z\u00C0-\u024F\'\u2019\-]+'
AUTHOR_RE = re.compile(
    r'^[A-Z][A-Z.\-]*\.(\s+[A-Z][A-Z.\-]*\.)*\s+' + _AUTH_WORD + r'(\s+' + _AUTH_WORD + r')*$'
)

# 无缩写点的作者段：2–4 个 Title-Case 词、无小写实词（如 "Marc Al Atem"）。
# 仅在**已确认至少一位作者**后才启用（author_parts 非空），避免把 Title Case
# 标题片段误吞。
AUTHOR_RE_NODOT = re.compile(
    r'^([A-Z][\w\u00C0-\u024F\'\u2019\-]*\s+){1,3}[A-Z][\w\u00C0-\u024F\'\u2019\-]*$'
)

# 刊名中允许的小写连接词（否则会切断 "Journal of Physics and Chemistry of Solids"）
_CONJ = {'of', 'the', 'and', 'in', 'on', 'for', 'de', 'del', 'der', 'van',
         'von', 'und', '&'}

_TAIL_MAXLEN = 40


def _extract_journal(head: str) -> tuple[str, str]:
    """从 head 右侧提取刊名，返回 (body, journal)。

    刊名判据（从右往左）：连续 Title-Case 词（允许连接词与缩写点/冒号），
    遇到小写实词、含逗号/括号的词、或超过 10 词即停。
    """
    words = head.split()

    def ok_jword(w: str) -> bool:
        core = w.strip('.,')
        if not core:
            return False
        if not core[0].isupper():
            return False
        if re.search(r'[,;()\[\]"]', w):     # 刊名不含逗号/括号
            return False
        return True

    jw: list[str] = []
    for w in reversed(words):
        lw = w.strip('.,').lower()
        if ok_jword(w):
            jw.append(w)
        elif lw in _CONJ and jw:
            jw.append(w)
        else:
            break
        if len(jw) >= 10:
            break
    journal = ' '.join(reversed(jw))
    if not journal:
        return head, ''

    # 用最后一个匹配定位切点（避免 head 内双空格导致长度对齐失败）
    matches = list(re.finditer(r'(?:^|[,\s])' + re.escape(journal) + r'\s*$', head))
    if not matches:
        return head, journal
    body = head[:matches[-1].start()].strip().rstrip(',;: ')
    return body, journal


def parse_line(index, raw):
    """解析单条条目。raw 为 [n] 之后（或含 [n] 前缀）的文本。"""
    line = (raw or '').strip()
    if not line:
        return None

    m = re.match(r'^\s*\[(\d+)\]\s*(.*)$', line)
    if m:
        index = int(m.group(1))
        line = m.group(2).strip()

    rest = line.strip().rstrip('.').strip()
    if not rest:
        return None

    # ---- DOI / URL 先摘（顺序不可反：先提 DOI 再删链接，否则 DOI 随链接丢失）
    doi = ''
    dm = re.search(r'(?:https?://(?:dx\.)?doi\.org/|doi:\s*)(10\.\d{4,9}/\S+)',
                   rest, re.I)
    if dm:
        doi = dm.group(1).rstrip('.,);')
        rest = (rest[:dm.start()] + ' ' + rest[dm.end():]).strip()
        rest = re.sub(r'\s{2,}', ' ', rest)

    # ---- 年份锚点：最后一个 (YYYY)
    ym = None
    for mm in re.finditer(r'\((\d{4})\)', rest):
        ym = mm
    if ym is None:
        return {'index': index, 'raw': raw[:200] if raw else '',
                'parse_failed': True, 'reason': 'no (year) anchor'}

    year = ym.group(1)
    tail = rest[ym.end():].strip().strip('.,;: ').strip()
    head = rest[:ym.start()].strip().rstrip(',;: ').strip()

    # ---- 门控：tail 须短且不含 `. `（否则不是本格式，交其他策略）
    if len(tail) > _TAIL_MAXLEN or '. ' in tail:
        return {'index': index, 'raw': raw[:200] if raw else '',
                'parse_failed': True, 'reason': 'tail not elsevier style'}
    page = re.sub(r'^pp?\.\s*', '', tail, flags=re.I).strip()

    # ---- 剥「卷 (期)」/「卷, 期」/「卷」
    vol, issue = '', ''
    mv = re.search(r'(\d{1,5})\s*[,(]\s*(\d{1,5})\s*\)?\s*$', head)
    if mv and re.search(r'[A-Za-z.)\]]\s*$', head[:mv.start()]):
        vol, issue = mv.group(1), mv.group(2)
        head = head[:mv.start()].strip()
    else:
        mv = re.search(r'[,\s](\d{1,5})\s*$', head)
        if mv and re.search(r'[A-Za-z.)\]]\s*$', head[:mv.start()]):
            vol = mv.group(1)
            head = head[:mv.start()].strip()

    # ---- 刊名 / 标题-作者体
    body, journal = _extract_journal(head)

    # ---- 作者 / 标题边界（按逗号分段）
    segs = [s.strip() for s in body.split(',')]
    author_parts, title_parts = [], []
    in_title = False
    for seg in segs:
        if not seg:
            continue
        cand = re.sub(r'^(?:and|&)\s+', '', seg, flags=re.I).strip()
        if not in_title and cand:
            if AUTHOR_RE.match(cand) or (author_parts and AUTHOR_RE_NODOT.match(cand)):
                author_parts.append(cand)
                continue
        in_title = True
        title_parts.append(seg)

    title = ' '.join(title_parts).strip().rstrip('.,;: ')
    authors = ', '.join(author_parts).strip().rstrip(',')

    if not title and not authors:
        return {'index': index, 'raw': raw[:200] if raw else '',
                'parse_failed': True, 'reason': 'no authors/title'}

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal,
        'volume': vol,
        'year': str(year),
        'page': page,
        'doi': doi,
        'issue': issue,
    }


# ------------------------------------------------------------------ CLI

def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_elsevier.py <fulltext.txt> <out_refs.json>',
              file=sys.stderr)
        sys.exit(1)
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import ref_common as rc

    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    start = rc.locate_references(text)
    if start is None:
        print(json.dumps({'status': 'error', 'error': 'References section not found'},
                         ensure_ascii=False))
        sys.exit(1)
    lines, _ = rc.preprocess(text[start:])
    entries = rc.split_entries(lines)

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if not isinstance(r, dict) or r.get('parse_failed'):
            failed.append(r if isinstance(r, dict) else {'index': idx, 'raw': txt[:200]})
        else:
            refs.append(rc.clean_ref(r))

    Path(sys.argv[2]).write_text(json.dumps(refs, ensure_ascii=False, indent=1),
                                 encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_gbt7714.py — F8 策略：GB/T 7714（中文期刊英文著录，带 [J] 文献类型标识）

典型格式（CES 实测，2026-09-16）：
    [1]Learbuch K L G, Smidt H, Van Der Wielen P W J J. Influence of pipe
    materials on the microbial community in unchlorinated drinking water and
    biofilm [J]. Water Research, 2021, 194: 116922.

与既有 7 策略的差异（为什么都必须新增策略）：
  - **年份在期刊名之后**（`, 年, 卷(期): 页码.`）—— F1/F4 要求年份在末尾或作者后，
    F2/F3/F5 要求括号年份，F7 要求年份紧跟作者并以句点分隔。
  - 编号后**紧跟**作者（`[1]Learbuch`，无空格、无句点）—— F4 Vancouver 要求 `[1].`。
  - 标题以 `[J].` 结束；`[J]` 是 GB/T 7714 的文献类型标识（[J] 期刊 / [M] 专著 /
    [C] 会议 / [D] 学位论文 / [R] 报告 / [P] 专利 / [S] 标准 / [N] 报纸 / [Z] 其他 /
    [EB/OL] 电子资源），**是全条目最可靠的切分锚点**，本策略强依赖它。
  - 卷期写作 `11(2)`、页码可能是文章号（`116922` / `e1704` / `lxaf004`）或缩写区间
    （`1426-35`）。

失效后果（v2.18.1 前的 `numbered` 误判）：年份全空、作者混入标题、
文章号被腰斩（`194: 116922` → volume=11692 / page=2），
`parse_failed` 却为空 → Crossref 会把全部文献报成「无法定位」，
制造"整篇文献不可信"的假象（与 v2.18.2 修复的缺陷同类，但成因不同）。

已知边界（有意保留，由 `clean_ref` 与打分机制兜底）：
  - 作者缩写带句点（`Learbuch K. L. G.,`）时，首个 `. ` 边界会切在缩写处；
    本策略按「首个候选切点」定位作者/标题边界，该类写法需人工复核。
  - 无 `[J]` 类标识的条目直接判 parse_failed，交由其他策略处理。
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import ref_common as rc                    # noqa: E402

# 文献类型标识白名单（GB/T 7714 单字母码 + 电子资源双码）
_TYPE_CODES = frozenset(
    ['J', 'M', 'C', 'D', 'R', 'P', 'S', 'N', 'Z', 'A', 'G', 'W',
     'EB', 'DB', 'CP', 'CD']
)
# `[J]. ` / `[M]. ` / `[EB/OL]. ` —— 允许标识与点之间无空格
_TYPE_MARK_RE = re.compile(r'\s*\[([A-Z]{1,2}(?:/[A-Z]{1,2})?)\]\s*\.\s*')

# 编号后紧跟作者（`[1]Learbuch`），split_entries 通常已剥离，这里再兜一次
_LEADING_NUM_RE = re.compile(r'^\s*(?:\[\d+\]|\(\d+\)|\d+\s*[.\)])\s*\.?\s*')

# 作者段结束锚点：`et al.` / `et al` / `etc.`
_ETAL_RE = re.compile(r'^.{2,200}?\bet\s+al\.?(?=\s|,|$)', re.I)

# 右侧「期刊, 年, 卷(期): 页码」
_RIGHT_FULL_RE = re.compile(
    r'^(?P<journal>.+?),\s*(?P<year>(?:19|20)\d{2})\s*,\s*'
    r'(?P<vol>[^:,]+?)\s*:\s*(?P<page>.+?)\s*\.?\s*$'
)
# 右侧无卷期的退化形式「期刊, 年: 页码」
_RIGHT_NO_VOL_RE = re.compile(
    r'^(?P<journal>.+?),\s*(?P<year>(?:19|20)\d{2})\s*:\s*(?P<page>.+?)\s*\.?\s*$'
)
# 右侧仅「期刊, 年」
_RIGHT_YEAR_ONLY_RE = re.compile(
    r'^(?P<journal>.+?),\s*(?P<year>(?:19|20)\d{2})\s*\.?\s*$'
)
# `11(2)` → 卷 11 / 期 2
_VOL_ISSUE_RE = re.compile(r'^([\dA-Za-z]+)\s*\(\s*\d+[^)]*\)\s*$')

# 句点+空格候选切点
_BOUNDARY_RE = re.compile(r'\.\s+')

# 西欧姓名冠词前缀（小写出现于姓氏，如 van der Berg / de Oliveira）
_NAME_PREFIXES = frozenset(
    'van der den von de del di da la le dos du el bin abu st'.split())
# 作者列表中允许出现的短小写词（"et al"）
_SHORT_LOWER = frozenset(['et', 'al', 'etc', 'jr', 'sr'])


def _looks_like_authors(s):
    """判定片段是否像 GB/T 7714 作者列表。

    作者列表形如 `Learbuch K L G, Smidt H, Van Der Wielen P W J J`
    或 `Wang H, Masters S, Edwards M A, et al`：逗号分组，每组由
    「姓氏（首字母大写词）+ 名缩写（单大写字母）」构成。

    因此**每个 token 只允许**：单大写字母（缩写）、首字母大写的词（姓氏/
    复姓成分）、已知小写冠词前缀、或 et/al 等短小写词。任何其他小写多字母词
    （of / the / and …）都会判否——这是把 "Effect of Disinfectant" 这类
    标题片段挡在外面的关键。
    """
    s = (s or '').strip().rstrip(',').strip()
    if not s or len(s) > 240:
        return False
    groups = [g.strip() for g in s.split(',') if g.strip()]
    if not groups:
        return False
    for g in groups:
        toks = g.split()
        if not toks or len(toks) > 8:
            return False
        for tk in toks:
            core = tk.strip('.').strip()
            if not core:
                return False
            low = core.lower()
            if low in _NAME_PREFIXES or low in _SHORT_LOWER:
                continue
            if len(core) == 1 and core.isupper():      # 名缩写
                continue
            if core[0].isupper():                      # 姓氏成分
                continue
            return False                               # 其他小写词 → 不是作者
    return True


def _looks_like_title(s):
    """判定片段是否像论文标题。

    条件：≥4 个词 且 ≥2 个长度 ≥4 的词，且**本身不是作者列表**。

    不能用「含小写长词」作条件：Title Case 标题（`A Review of Recent
    Progress in …`，小写词只有 of/in/the/for）会被误否——CES 实测 [10]
    因此整条切分失败（作者混入标题）。
    改用「非作者列表」反向排除：作者列表片段（`L. G., Smidt H`）长词不足
    2 个会被挡下，而 `Learbuch K L G, Smidt H, Van Der Wielen P W J J`
    这类长作者段虽长词够多，但会被 `_looks_like_authors` 识别并排除。
    """
    s = (s or '').strip()
    if not s:
        return False
    words = s.split()
    if len(words) < 4:
        return False
    if sum(1 for w in words if len(w.strip('.,;:()[]')) >= 4) < 2:
        return False
    return not _looks_like_authors(s)


def _split_author_title(left):
    """把 `作者 + 标题` 切分为 (authors, title)；失败返回 ('', left)。"""
    left = (left or '').strip().rstrip('.').strip()
    if not left:
        return '', ''

    # ① 优先用 `et al.` 锚点（GB/T 7714 中 3 人以上一律 et al.，最常见）
    m = _ETAL_RE.match(left)
    if m:
        authors, title = m.group(0).strip(), left[m.end():].strip()
        if _looks_like_authors(authors) and _looks_like_title(title):
            return authors, title

    # ② 扫描句点+空格边界，取首个「前缀像作者 + 后缀像标题」的切点
    for m in _BOUNDARY_RE.finditer(left):
        authors = left[:m.start()].strip()
        title = left[m.end():].strip()
        if _looks_like_authors(authors) and _looks_like_title(title):
            return authors, title

    # ③ 兜底：整体作为标题（作者缺省），交由 clean_ref 二次切分
    return '', left


def _parse_right(right):
    """解析 `期刊名, 年, 卷(期): 页码.` → (journal, year, volume, page)。"""
    right = (right or '').strip()
    for pat in (_RIGHT_FULL_RE, _RIGHT_NO_VOL_RE, _RIGHT_YEAR_ONLY_RE):
        m = pat.match(right)
        if not m:
            continue
        d = m.groupdict()
        vol = (d.get('vol') or '').strip()
        mi = _VOL_ISSUE_RE.match(vol)
        if mi:                       # `11(2)` → 只留卷号，期号不进 schema
            vol = mi.group(1)
        return (d.get('journal', '').strip(), d.get('year', '').strip(),
                vol, (d.get('page') or '').strip())
    return '', '', '', ''


def parse_line(index, text):
    """解析单条 GB/T 7714 条目。失败返回带 parse_failed 的 dict。"""
    t = _LEADING_NUM_RE.sub('', (text or '').strip(), count=1).strip()
    if not t:
        return {'index': index, 'raw': (text or '')[:200],
                'parse_failed': True, 'reason': 'empty'}

    # 1) 定位文献类型标识 `[J].` —— 本格式最可靠的锚点
    mark = None
    for m in _TYPE_MARK_RE.finditer(t):
        code = m.group(1).split('/')[0]          # `EB/OL` → `EB`
        if code in _TYPE_CODES:
            mark = m
            break
    if mark is None:
        return {'index': index, 'raw': t[:200], 'parse_failed': True,
                'reason': 'no [J]-like type marker (not GB/T 7714)'}

    left, right = t[:mark.start()], t[mark.end():]

    # 2) 先提 DOI 并删除整段（防 `DOI:10.xxx` 挂到 page 尾部）
    doi = rc.extract_doi(right) or rc.extract_doi(t)
    if doi:
        right = re.sub(r'(?:doi:?\s*)?' + re.escape(doi) + r'\.?', ' ', right,
                       flags=re.I).strip()

    # 3) 切分作者 / 标题
    authors, title = _split_author_title(left)
    if not title:
        return {'index': index, 'raw': t[:200], 'parse_failed': True,
                'reason': 'title not located'}

    # 4) 切分期刊 / 年份 / 卷 / 页
    journal, year, volume, page = _parse_right(right)

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal,
        'volume': volume,
        'page': page,
        'year': year,
        'doi': doi,
    }


if __name__ == '__main__':
    # 自测：python parse_refs_gbt7714.py "<条目文本>"
    if len(sys.argv) > 1:
        import json
        print(json.dumps(parse_line(1, sys.argv[1]),
                         ensure_ascii=False, indent=1))

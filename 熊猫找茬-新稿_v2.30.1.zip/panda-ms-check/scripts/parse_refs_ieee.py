#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_ieee.py — 第 10 策略：编号式「IEEE house style」（Zotero 导出）

适用格式（EMD20260069 实测，IEEE 参考文献样式 / Zotero 的 IEEE CSL 导出）：

    [n] A. B. Author, C. D. Author, and E. F. Author, 'Paper title',
        Journal Abbrev., vol. 15, no. 27, pp. 21811-21837, Jun. 2025,
        doi: 10.1039/D5RA02730F.

关键特征（也是与已有 9 策略的区别）：
  * 编号后有**空格**（`[1] S. Soltani`，而 `gbt7714` 是 `[1]Learbuch` 无空格）；
  * **篇名用单引号包裹**（`'…'`，U+2018/U+2019）——这是全条目最可靠、
    最独特的切分锚点，本策略强依赖它；
  * **年份在末尾**，写作 `, Mon. YYYY`（IEEE 风格 `Jun. 2025`），
    少数条目省略月份直接 `, 2025`；
  * 卷期页为 `vol. 15, no. 27, pp. 21811-21837`（**带 vol./no./pp. 前缀**）；
  * 2018 年前后两代模式混排：老式 `Monthly YYYY` 无 DOI
    （`Feb. 2025`、`2026`），新式带 `doi:`。

为什么必须新增策略（EMD20260069 实测的静默失败）：
  9 种策略对本报**全部失效且无一报错**——`numbered` 得 0.0、`vancouver` 0.125、
  `rsc` 0.2 被选中，只有 11/36 条产出结果，且**字段全错位**：
    [2] → authors 混入篇名、journal='Feb. 14'、volume='Social Science Research Network'
    [3] → journal='pp. 21739-21756'、page='doi:'
  即「满分假象」之外的**第五类静默失败**：`status=ok`、`parse_failed` 只反映
  失败条数（25 条）而非"全部策略均不适用"，选中策略得分仅 0.2 却仍被采信。
  Crossref 会据此把大半个文献表报成「无法定位」。

解析策略（以单引号篇名为唯一锚点做三段切分）：
  1. 剥编号（`[n]` / `n.` / `n)`），**先摘走 DOI/URL 并删除整段**
     （顺序不可反：先提 DOI 再删链接，否则 DOI 随 URL 一起丢）
  2. 定位第一个 `'` → 前段 = 作者列表
  3. 第一个 `'` 与下一个 `'` 之间 = **篇名**
  4. 第二个 `'` 之后 = 期刊 / 卷 / 期 / 页 / 年（尾部模式依次回退）
  5. 无引号条目（在线专著、软件、数据库等）走 `_extract_nonjournal` 反向取篇名

已知边界：
  * 篇名本身含单引号（如 `'CsSnI3: Semiconductor or Metal? …'` 无内部引号，
    但 `O'Brien` 类作者名会破坏锚点）——本策略要求引号**成对**，
    并校验两引号之间像篇名（≥4 词），不成对时回退到句点边界扫描。
  * 作者列表以 `and` 结尾（`…, and N. A. Althumairi,`）为 IEEE 惯例，
    切分后统一规范为 `, and ` 连接，供 Crossref 姓氏集合提取。
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import ref_common as rc  # noqa: E402


# 编号：`[1]` / `1.` / `1)`。**编号与内容之间允许无空格**——`ref_common.split_entries`
# 切分时可能保留原行编号（本 skill 实测：docx 提取的行传入 `split_entries` 后
# 编号原样保留，`[1]S. Soltani` 无空格），故此处不可强制要求空格。
_NUM_RE = re.compile(r'^\s*\[?(\d{1,4})\]?[.)]?\s*')

# 行首编号的**保守**形式（仅用于剥编号后校验，不参与切分）
_NUM_LOOSE_RE = re.compile(r'^\s*\[(\d{1,4})\]\s*')

# 单引号（直引号 + 弯引号）
_OPEN_Q = re.compile(r'[\u2018\u2019\u201c\u201d\u0027\u0022]')

# 尾部年份：`, Jun. 2025` / `, 2025` / `, Feb. 2025` / `, 2026.`
# **须同时接受中文全角逗号 `，`（U+FF0C）**——中英混排著录（中文题录 + 英文
# 译题，CESCI-S-26-00047 实测）写作 `交通运输工程学报，2020, 20(6): 62-70`，
# 只认半角逗号会导致年份剥不掉 → `_parse_tail` 返回 j=自己、y/v/p 全空 →
# `ieee` 对这些条目产出「非期刊空字段」，进而误抢 `noidx_vancouver` 的条目。
_TAIL_YEAR_RE = re.compile(
    r'[,\uff0c\s]\s*(?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)'
    r'[a-z]*\.?\s+)?((?:19|20)\d{2})\s*[.,\uff0c]?\s*$'
)
# 年份在页码**之前**：`… 2016, pp. 785-794` / `… 2017, pp. 4765-4774.`
# IEEE 会议论文条目常见此序（CESCI-S-26-00053 [25][26] 实测：`in Proc. … , 2016,
# pp. 785-794, doi: …`）——`_TAIL_YEAR_RE` 锚定在**行尾**，遇到「年在前、页在后」
# 必然失配 → year 空、page 被截成 `785–`。故增设此中置年份兜底。
_MID_YEAR_RE = re.compile(r'[,\uff0c\s]\s*((?:19|20)\d{2})\s*[,\uff0c]?\s*(?=pp?\.)')
# 卷：`vol. 15` / `Vol. 15`
_VOL_RE = re.compile(r'\bvol\.?\s*([\dIVXLCivxlc]+)', re.I)
# 期：`no. 27`
_NO_RE = re.compile(r'\bno\.?\s*([\dA-Za-z]+)', re.I)
# 页：`pp. 21811-21837` / `p. 063526` / `pp. 21739–21756`
_PAGE_RE = re.compile(r'\bpp?\.\s*([^\s,;]+)')

# 出版社（判定非期刊条目：在线专著 / 软件手册 / 报告）
_PUBLISHER_WORDS = re.compile(
    r'\b(?:press|publisher|verlag|springer|wiley|elsevier|'
    r'academic|university press|crc|de gruyter|world scientific)\b', re.I)
_NONJOURNAL_WORDS = re.compile(
    r'\b(?:online|accessed|available|software|database|manual|'
    r'handbook|book|report|thesis|dissertation|proceedings)\b', re.I)

# 句点+空格候选切点（无引号条目回退用）
_BOUNDARY_RE = re.compile(r'\.\s+(?=[A-Z(])')

# 西欧姓名冠词前缀（小写出现于姓氏）
_NAME_PREFIXES = frozenset(
    'van der den von de del di da la le dos du el bin abu st'.split())
_SHORT_LOWER = frozenset(['et', 'al', 'etc', 'jr', 'sr', 'and'])


# ---------------------------------------------------------------- 判据

def _looks_like_authors(s):
    """判定片段是否像 IEEE 作者列表。

    形如 `S. Soltani, M. Hjiri, N. I. A. Ahmed, A. Jbeli, A. M. Aldukhayel,
    and N. A. Althumairi` 或 `C. Yu et al.`。
    每个 token 只允许：单大写字母（名缩写，可带点）、首字母大写词（姓氏）、
    已知小写冠词前缀、et/al/and 等短小写词。任何其他小写多字母词即判否。
    """
    s = (s or '').strip().rstrip(',').strip()
    if not s or len(s) > 300:
        return False
    # `et al` 可整体出现
    s = re.sub(r'\bet\s+al\.?', 'et al', s, flags=re.I)
    groups = [g.strip() for g in s.split(',') if g.strip()]
    if not groups:
        return False
    for g in groups:
        toks = g.split()
        if not toks or len(toks) > 8:
            return False
        for tk in toks:
            core = tk.strip('.').strip()
            if not core:
                return False
            low = core.lower()
            if low in _NAME_PREFIXES or low in _SHORT_LOWER:
                continue
            if len(core) == 1 and core.isupper():      # 名缩写 `S.`
                continue
            if core[0].isupper():                      # 姓氏成分
                continue
            return False                               # 其他小写词 → 不是作者
    return True


def _looks_like_title(s):
    """判定片段是否像论文篇名：≥4 词且 ≥2 个长度 ≥4 的词。"""
    s = (s or '').strip()
    if not s:
        return False
    words = s.split()
    if len(words) < 4:
        return False
    return sum(1 for w in words if len(w.strip('.,;:()[]\'"\u2018\u2019')) >= 4) >= 2


# ---------------------------------------------------------------- 尾部

def _parse_tail(tail, body=''):
    """解析「期刊 / 卷 / 期 / 页 / 年」残段。

    返回 (journal, year, volume, page)。尾部形态依次回退：
      ① IEEE 全式：`, vol. 15, no. 27, pp. 21811-21837, Jun. 2025`
      ② 无卷期：`, p. 063526, Sep. 2011`
      ③ 仅年份：`, 2026`

    `body` 为整条正文（含作者/篇名），用于期刊名缩写点回填的逗号段定位。
    """
    tail = (tail or '').strip().strip(',').strip().rstrip('.').strip()
    year = ''
    m = _TAIL_YEAR_RE.search(tail)
    if m:
        year = m.group(1)
        tail = tail[:m.start()].strip().strip(',').strip()
    else:
        # 「年在前、页在后」变体（IEEE 会议论文）：`, 2016, pp. 785-794`
        m2 = _MID_YEAR_RE.search(tail)
        if m2:
            year = m2.group(1)
            tail = (tail[:m2.start()] + ' ' + tail[m2.end():]).strip().strip(',').strip()

    volume = page = ''
    mv = _VOL_RE.search(tail)
    if mv:
        volume = mv.group(1)
    mp = _PAGE_RE.search(tail)
    if mp:
        page = mp.group(1).strip().rstrip('.')
        # 页码折行 `pp. 785– 794`：尾字符为连字符时把后一 token 接上
        # （CESCI-S-26-00053 [25] 实测：不接则 page 只剩 `785–`）
        if page and page[-1] in '-\u2010\u2011\u2012\u2013\u2014':
            mcont = re.match(r'([\w]+)', tail[mp.end():].strip())
            if mcont:
                page += mcont.group(1)

    # 期刊名 = 尾部中**第一个结构标记之前**的内容
    cut = len(tail)
    for pat in (_VOL_RE, _PAGE_RE, _NO_RE):
        mm = pat.search(tail)
        if mm and mm.start() < cut:
            cut = mm.start()
    journal = tail[:cut].strip()

    # 期刊名内部缩写句点（`J. Appl. Phys.` / `J. Phys. Chem. Lett.` /
    # `physica status solidi (a)`）会在切分时被当成句界 → 期刊名被**腰斩**
    # 或整个丢失（EMD20260069 [4]/[18]/[29]/[33] 实测）。修复：从结构标记处
    # 反向回填——只要前一段**以单字母缩写点结尾**（`J.` / `Phys.` / `Mater.`）
    # 或为已知刊名连接词，就继续把上一段并回期刊名。
    segs_all = [s.strip() for s in body.split(',') if s.strip()]
    if segs_all:
        cur = journal.strip().strip(',').strip().rstrip('.').strip()
        idx = None
        for i, sg in enumerate(segs_all):
            if cur and sg.rstrip('.') == cur.rstrip('.'):
                idx = i
                break
        if idx is None and cur:
            for i, sg in enumerate(segs_all):
                if sg.startswith(cur[:max(4, len(cur) // 2)]):
                    idx = i
                    break
        if idx is not None:
            j = idx
            while j - 1 >= 0:
                prev = segs_all[j - 1]
                # 上一段须以缩写点结尾（`J.` / `Phys.` / `Mater.` / `(Soc.`）
                # 或为刊名连接词（`in` / `of` / `and` / `&`）
                if (re.search(r'\b[A-Za-z]{1,6}\.$', prev)
                        or re.search(r'[\w)]\s*\($', prev)
                        or re.match(r'^(?:in|of|and|&|the)$', prev, re.I)):
                    j -= 1
                    continue
                break
            if j < idx:
                journal = ', '.join(s.strip() for s in segs_all[j:idx + 1])
    # 期刊名不得残留 vol./no./pp. 与年份。**注意两点**（均为 CESCI-S-26-00047
    # 实测踩过的坑）：
    #   ① 不可写 `\s*,?\s*\bvol.*$`——`\s*,?\s*` 会吃掉「Phys., 」里的逗号并
    #      回溯吞掉 `Phys.`（`J. Appl. Phys., vol. 110` → `J. Appl.`）。
    #      正确做法：只从 `vol./no./pp.` 标记**自身**起截断。
    #   ② 不可把裸 `p\.\s` 列入可截断标记——中文著录 `… 32(4): 32-49. Huang`
    #      里的**页末句点**会命中 `p\.\s`，把期刊名从「32-49」起砍掉，
    #      继而 `ieee` 误抢 `noidx_vancouver` 的条目（9/10 号）并判为非期刊。
    #      故只保留 `vol.` / `no.` / `pp.`（`p.` 单页形式由 `_PAGE_RE` 单独处理）。
    journal = re.sub(r'\b(?:vol|no|pp)\.\s.*$', '', journal, flags=re.I)
    journal = re.sub(r'\s*,?\s*(?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|'
                     r'Nov|Dec)[a-z]*\.?\s+)?(?:19|20)\d{2}\s*$', '', journal,
                     flags=re.I)
    journal = journal.strip().strip(',').strip().rstrip('.').strip()
    return journal, year, volume, page


# ---------------------------------------------------------------- 非期刊条目

def _extract_nonjournal(segs, raw):
    """非期刊条目（在线专著 / 软件 / 报告）：反向扫描出篇名。

    返回 (authors, title, kind)。
    """
    kind = 'other'
    if re.search(r'\bsoftware\b', raw, re.I):
        kind = 'software'
    elif re.search(r'\b(?:book|handbook|manual)\b', raw, re.I):
        kind = 'book'
    elif re.search(r'\breport\b', raw, re.I):
        kind = 'report'
    idx = None
    for i in range(len(segs) - 1, -1, -1):
        seg = segs[i]
        if re.match(r'^(?:accessed|available|online|https?)\b', seg, re.I):
            continue
        if _PUBLISHER_WORDS.search(seg) and not _looks_like_title(seg):
            continue
        if _looks_like_title(seg):
            idx = i
            break
    if idx is None:
        return ', '.join(segs), '', kind
    authors = ', '.join(segs[:idx])
    title = segs[idx].strip().strip('\u2018\u2019\'"').rstrip('.,').strip()
    return authors, title, kind


# ---------------------------------------------------------------- 主解析

# IEEE 格式**指纹**：满足任一条即认领——
#   ① 结构标记 `vol. <数字>` / `no. <数字>` / `pp. <页>`；
#   ② 编号 + **单引号篇名**（IEEE 最独特、最不易被其他格式命中的特征；
#      用于覆盖源稿本身著录不全、无 vol./no./pp. 的残缺条目，
#      如 EMD20260069 [9] 只有 `‘篇名’.`）。  
# 关键：② 要求「篇名被单引号包裹」——中文著录（CESCI-S-26-00047 [9]/[10]）
# 使用全角书名号 `《》`/类型标识 `[J]`，天然不命中，故仍被挡在外面，
# 不会误抢 `noidx_vancouver` 的条目（这是 0.6 反超 0.8 那次回归的根因）。
_IEEE_SIG_RE = re.compile(r'\b(?:vol|no|pp)\.\s*\d', re.I)
_QUOTED_TITLE_RE = re.compile(r'[\u2018\u2019]\s*[^\u2018\u2019]{8,}\s*[\u2018\u2019]')


def _has_ieee_signature(body):
    """判定条目是否具备 IEEE house style 结构指纹。"""
    body = body or ''
    return bool(_IEEE_SIG_RE.search(body)
                or _QUOTED_TITLE_RE.search(body))


def parse_line(index, line):
    """解析单条 IEEE 式著录。失败返回带 parse_failed 的 dict。"""
    raw = (line or '').strip()
    m = _NUM_RE.match(raw)
    body = (raw[m.end():] if m else raw).strip()
    if not body:
        return {'index': index, 'parse_failed': True,
                'raw': raw[:200], 'reason': 'empty after number'}

    # 1) 先提 DOI/URL 并删除（顺序不可反：先提 DOI 再删链接）
    doi = rc.extract_doi(body)
    body = re.sub(r'https?://(?:dx\.)?doi\.org/\S+', ' ', body)
    if doi:
        body = re.sub(r'(?:doi:?\s*)?' + re.escape(doi) + r'\.?', ' ', body, flags=re.I)
    body = re.sub(r'https?://\S+', ' ', body)
    body = re.sub(r'\s+', ' ', body).strip().rstrip(',').strip()
    if not body:
        return {'index': index, 'parse_failed': True,
                'raw': raw[:200], 'reason': 'only doi/url'}

    # 1b) 格式指纹护栏：无 `vol./no./pp.` 结构标记即非 IEEE 式，交还其他策略
    if not _has_ieee_signature(body):
        return {'index': index, 'parse_failed': True,
                'raw': raw[:200],
                'reason': 'no IEEE structure marker (vol./no./pp.)'}

    # 2) 单引号篇名锚点（成对校验 + 篇名形态校验）
    quotes = [q.start() for q in _OPEN_Q.finditer(body)]
    authors = title = ''
    tail = ''
    used_quotes = False
    if len(quotes) >= 2:
        a_end, t_start = quotes[0], quotes[1]
        cand_title = body[a_end + 1:t_start].strip()
        if len(cand_title) >= 8:
            authors = body[:a_end].strip().strip(',').strip()
            title = cand_title
            tail = body[t_start + 1:].strip().strip(',').strip()
            used_quotes = True

    # 2b) 无引号 → 用「最后一个 pp./p. 之前的段」反推篇名（见下）

    if not used_quotes:
        # 回退：句点+空格边界扫描，取首个「前缀像作者 + 后缀像标题」的切点
        best = None
        for bm in _BOUNDARY_RE.finditer(body):
            cand_a = body[:bm.start()].strip().strip(',').strip()
            rest = body[bm.end():].strip()
            if not _looks_like_authors(cand_a):
                continue
            # 后缀需以大写开头且不像期刊结构标记
            if not rest or not rest[0].isupper():
                continue
            best = (cand_a, bm.end())
            break
        if best is None:
            return {'index': index, 'parse_failed': True,
                    'raw': raw[:200], 'reason': 'no quoted title / author boundary'}
        authors, after = best[0], body[best[1]:]
        # 篇名结束于「. <刊名>」或「.', <刊名>」处：无引号时以**最后一个句点**为界
        # 更稳：把「作者之后」整体作为篇名+尾部，用尾部模式反推
        cut = None
        for bm in _BOUNDARY_RE.finditer(after):
            seg = after[:bm.start()]
            if _looks_like_title(seg):
                cut = bm.end()
        if cut is None:
            return {'index': index, 'parse_failed': True,
                    'raw': raw[:200], 'reason': 'no journal boundary after title'}
        title = after[:cut - 1].strip().strip(',').strip().rstrip('.').strip()
        tail = after[cut:].strip()

    if not title or len(title) < 8:
        return {'index': index, 'parse_failed': True,
                'raw': raw[:200], 'reason': 'title not located'}

    journal, year, volume, page = _parse_tail(tail, body)

    # 3) 非期刊条目：期刊段为空 或 尾部命中出版社/在线资源/预印本仓库词
    #    （SSRN/arXiv/Zenodo 等仓库名会被当成"期刊名"——[2] 实测
    #     journal='Feb. 14, 2025, SocialScience Research Network, Rochester, NY'）
    _repo_hit = bool(re.search(
        r'\b(?:ssrn|arxiv|biorxiv|medrxiv|chemrxiv|research\s*square|zenodo|'
        r'osf|social\s*science\s*research\s*network|preprint)\b', body, re.I))
    # 期刊结构标记（`vol. 12` / `no. 3`）存在时不得判非期刊——否则**期刊名本身
    # 含非期刊词**的条目会被误判：`Environmental Modelling & Software` 命中
    # `software` → 整条走非期刊分支 → journal 全空（CESCI-S-26-00053 [19] 实测）。
    _has_journal_struct = bool(re.search(r'\b(?:vol|no)\.\s*[\dIVXLCivxlc]', tail, re.I))
    is_nonjournal = (
        _repo_hit
        or not journal
        or bool(_PUBLISHER_WORDS.search(tail))
        or (not _has_journal_struct and bool(_NONJOURNAL_WORDS.search(body)))
    )
    if is_nonjournal:
        segs = [s.strip() for s in body.split(',') if s.strip()]
        na, nt, kind = _extract_nonjournal(segs, body)
        # 在线资源条目（软件手册/数据库/学位论文）的年份可能落成
        # `Accessed: Feb. 07, 2026`——从整条里取**最后一个** 4 位年
        if not year:
            ys = re.findall(r'(?:19|20)\d{2}', body)
            year = ys[-1] if ys else ''
        # 期刊段仅在确为刊名（非仓库/非出版社）时保留
        keep_journal = ''
        if re.search(r'\b(?:journal|letters?|transactions|review|reviews|'
                     r'advances?|materials?|energy|physics|chemistry|'
                     r'science|nature|applied|communications?)\b',
                     journal, re.I) and not _repo_hit:
            keep_journal = journal
        return {
            'index': index,
            'authors': authors or na,
            'title': title or nt,
            'journal': keep_journal, 'volume': '', 'page': page, 'year': year,
            'doi': doi, 'ref_nonjournal': True, 'ref_kind': kind,
            'no_title_format': False,
        }

    # 作者段规范：确保 `et al.` 与 `and` 形式一致
    authors = re.sub(r'\s+', ' ', authors).strip().strip(',').strip()

    return {
        'index': index,
        'authors': authors,
        'title': title.rstrip('.,').strip(),
        'journal': journal,
        'volume': volume,
        'page': page,
        'year': year,
        'doi': doi,
        'ref_nonjournal': False,
        'ref_kind': 'journal',
        'no_title_format': False,
    }


if __name__ == '__main__':
    # 自测：python parse_refs_ieee.py "<条目文本>"
    if len(sys.argv) > 1:
        import json
        print(json.dumps(parse_line(1, sys.argv[1]),
                         ensure_ascii=False, indent=1))

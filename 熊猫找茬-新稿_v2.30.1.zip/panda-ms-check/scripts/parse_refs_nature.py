#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_nature.py — F5：Nature 风格参考文献解析器（v2.18.0）

条目形如（作者用 et al. / & 分隔，**年份在条目末尾**）：
    Xu, W. et al. Lithium metal anodes for rechargeable batteries.
    Energy Environ. Sci. 7, 513–537 (2014).

    Tantratian, K., Yan, H. & Chen, L. Unraveling the Li Penetration
    Mechanism. Advanced Energy Materials 11, 2003417 (2021).

已知坑：期刊名内部缩写句点（Nat. Mater. / J. Electrochem. Soc.）会误导
"句点分隔"的朴素切分，把期刊切碎成 "Mater." / "Soc."。本实现用
"最后一个『句点 + 大写开头词』边界"定位期刊名（EMD20260060 实测 47/47）。

CLI:  python parse_refs_nature.py <fulltext.txt> <out_refs.json>
输出: 纯 list JSON
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ref_common as rc  # noqa: E402

# 句点 + 大写开头词（用于定位标题/期刊边界，避开缩写句点后的小写词）
# 同时支持全大写缩写开头的期刊名（如 ". ACS Energy Lett." → "ACS"）
_SEG_RE = re.compile(r'\.\s+(?=[A-Z][a-z]|[A-Z]{2,}\b)')


def parse_line(index, line):
    """解析单条（已剥离编号的正文）。"""
    # 年份锚定：条目末尾 (YYYY).
    ym = re.search(r'\((\d{4})\)\.?\s*$', line)
    if not ym:
        return {'index': index, 'raw': line, 'parse_failed': True, 'reason': 'no year'}

    year = ym.group(1)
    before = line[:ym.start()].strip()

    # 期刊 卷, 页码（条目末尾模式）
    jm = re.search(r'^(.*?)\s+(\d+),\s*([\w\-–—]+)\s*$', before)
    if jm and jm.group(1).strip():
        head, volume, page = jm.group(1).strip(), jm.group(2), jm.group(3)
    else:
        head, volume, page = before, '', ''

    # 期刊名 = head 中最后一个「句点+大写开头词」边界之后
    # v2.18.0：期刊名内部缩写句点（Energy Environ. Sci. / Nat. Mater.）也会被该
    # 模式匹配，导致期刊被切碎成 "Sci." / "Mater."。故向前累积补齐缩写链。
    # 累积条件（两个都要满足，缺一会把标题吞进期刊）：
    #   ① 当前片段太短（<8）或仍以缩写句点结尾（说明缩写链未取全）
    #   ② 下一候选片段长度合理（≤40，超过说明已越过标题边界）
    segs = list(_SEG_RE.finditer(head))
    if segs:
        k = len(segs) - 1
        journal = head[segs[k].end():].strip()
        while k > 0 and (len(journal) < 8 or journal.endswith('.')):
            nxt = head[segs[k - 1].end():].strip()
            if len(nxt) > 40:      # 越过标题边界，停止累积
                break
            k -= 1
            journal = nxt
        auth_title = head[:segs[k].start()].strip()
    else:
        journal, auth_title = '', head

    # 作者 = auth_title 中第一个「句点+大写开头词」边界之前
    authors, title = '', auth_title
    m1 = _SEG_RE.search(auth_title)
    if m1:
        authors = auth_title[:m1.start()].strip()
        title = auth_title[m1.end():].strip()

    # ── 修复 A（v2.28.0）：单字母缩写刊名被留在标题尾部（EMD20260087 实测）
    #   条目 "…battery pack. J. Energy Storage 76, 109812 (2024)." 中，"J." 是
    #   刊名首词缩写，但 _SEG_RE 要求句点后为「大写+小写」或「≥2 位大写」，
    #   ". J." 两者都不满足 → 边界退到 ". Energy" → journal 丢 "J."、
    #   标题尾部挂上 "J"。特征：auth_title 以「. X」/「. X.」结尾且 journal 非空。
    if journal:
        ma = re.search(r'\.\s+([A-Z])\.?$', auth_title)
        if ma:
            journal = f'{ma.group(1)}. {journal}'
            auth_title = auth_title[:ma.start()].strip()
            authors, title = '', auth_title
            m1b = _SEG_RE.search(auth_title)
            if m1b:
                authors = auth_title[:m1b.start()].strip()
                title = auth_title[m1b.end():].strip()

    # ── 修复 B（v2.28.0）：无点缩写刊名（"J Therm Anal Calorim"）导致
    #   最后一个边界退到标题内部 → 整条标题被并进 journal、title 变成作者串。
    #   特征：journal 含 ". "、最后一段短（≤45）且不以句点收尾、**前半段很长**
    #   （>45，说明它其实是标题而非刊名缩写链——这是防止把修复 A 的结果再拆开的
    #   反向保险，如 "J. Energy Storage" 的前半段仅为 "J"），且现有 title 为空或
    #   仍呈作者串形态（"et al" / "姓, 名缩写"）。
    if journal and '. ' in journal and (title == '' or (
            len(title) < 60 and re.search(r'\bet\s+al\b|^[A-Z][\w\-\']+,\s*[A-Z]\.', title))):
        parts = journal.rsplit('. ', 1)
        head_part, tail_part = parts[0].strip(), parts[1].strip()
        if len(head_part) > 45 and 0 < len(tail_part) <= 45 \
                and not tail_part.endswith('.'):
            if not authors and title:      # 原 title 实为作者串 → 归位为作者
                authors = title
            title, journal = head_part, tail_part

    # ── 修复 C（v2.28.0）：作者列表未被切出（authors 为空）
    #   条目 "E, J., Xiao, H., … & Huang, Y. A comprehensive review …" 中，作者末缩写
    #   "Y." 之后是单词标题的首字母 "A"，_SEG_RE 的 `[A-Z][a-z]` 与 `[A-Z]{2,}` 都不命中
    #   → 无边界 → authors=''、title=整串。回退：取第一个「句点+空白」边界，其右侧
    #   长度 ≥25 且含 ≥5 字母的小写实词即视为标题起点（仅在 authors 为空时启用）。
    if not authors and title:
        for mm in re.finditer(r'\.\s+', title):
            pref = title[:mm.end()].strip()
            rest = title[mm.end():].strip()
            if not rest:
                continue
            # ① 作者串延续（"Cheng, X. et al. A Review …"）：把 et al. 归入作者后
            #    标题从其后的下一段起算，避免 "et al." 被当成标题首词。
            m_etal = re.match(r'et\s+al\.?\s+(.+)$', rest, re.S)
            if m_etal:
                t = m_etal.group(1).strip().lstrip(',;:')
                authors, title = pref + ' et al.', t
                break
            # ② 标题起点：大写实词开头（含 "A/An" 冠词），长度与实词量足够
            if not rest[0].isalpha():
                continue
            if not re.match(r'^(?:[A-Z][a-z]+|A|An)\b', rest):
                continue
            if len(rest) >= 25 and re.search(r'[a-z]{5,}', rest):
                authors, title = title[:mm.start()].strip(), rest
                break

    return {'index': index, 'authors': authors, 'title': title,
            'journal': journal, 'volume': volume, 'page': page,
            'year': year, 'doi': ''}


def parse(text, entries=None):
    """解析全文 → (refs, failed)。"""
    if entries is None:
        start = rc.locate_references(text)
        if start is None:
            return [], []
        lines, _ = rc.preprocess(text[start:])
        mode = rc.detect_numbering([l for l in lines if l.strip()][:40])
        entries = rc.split_entries(lines, unnumbered=(mode == 'unnumbered'))

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if r.pop('parse_failed', False):
            r.setdefault('raw', txt[:200])
            failed.append(r)
        else:
            refs.append(rc.clean_ref(r))
    return refs, failed


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_nature.py <fulltext.txt> <out_refs.json>',
              file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    refs, failed = parse(text)
    refs.sort(key=lambda r: r.get('index') or 0)
    Path(sys.argv[2]).write_text(
        json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

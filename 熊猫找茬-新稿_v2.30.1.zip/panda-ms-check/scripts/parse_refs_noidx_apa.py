#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_noidx_apa.py — F3：无编号 APA 风格参考文献解析器（v2.18.0）

条目形如（**无 [n] 编号**，年份紧跟作者、带括号）：
    Nguyen, L. T., Cava, R. J. (2021). Hexagonal Perovskites as Quantum
    Materials. Chemical Reviews 121, 2935–2965. https://doi.org/10.1021/...

与 parse_refs_apa.py 的区别：后者要求 `[n]` 编号，无编号时解析 0 条
（EMD20260058 实测）。

CLI:  python parse_refs_noidx_apa.py <fulltext.txt> <out_refs.json>
输出: 纯 list JSON（供 crossref_check / retraction_watch 直接消费）
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ref_common as rc  # noqa: E402


def parse_line(index, line):
    """解析单条（已剥离编号的正文）。失败返回含 parse_failed 的 dict。"""
    # 年份锚定：作者后紧跟的 (YYYY)
    ym = re.search(r'\((\d{4})\)', line)
    if not ym:
        return {'index': index, 'raw': line, 'parse_failed': True, 'reason': 'no year'}

    year = ym.group(1)
    authors = line[:ym.start()].strip().rstrip(', ').strip()
    after = line[ym.end():].lstrip('. ').strip()

    # 标题：第一个 ". " 之前
    tm = re.search(r'^(.*?\.)\s+', after)
    if tm:
        title = tm.group(1).rstrip('.').strip()
        rest2 = after[tm.end():].strip()
    else:
        title, rest2 = '', after

    # 先提取 DOI 再删 URL（顺序不能反：DOI 常以 https://doi.org/... 形式挂在条尾，
    # 先删 URL 会连同 DOI 一起丢掉，导致下游只能走标题检索而匹配失败）
    doi = rc.extract_doi(rest2)
    rest2 = rc.URL_RE.sub('', rest2).strip()

    # 期刊 卷(期), 页码 / 期刊 卷, 页码 / 期刊 卷 / 期刊 卷, 文章号
    # v2.29.0：**卷号后允许带 (期号)**。原正则无期号位，遇 "Scientific Reports
    # 15(1), 39225." 时 `\s+(\d+)` 只能吃到末尾的文章号 → journal 变成
    # "Scientific Reports 15(1)"、volume 变成页码 39225、page 为空。后果：
    # Crossref strict 刊名核对把每条都判 journal_mismatch（本稿 15/25 条假警，
    # 而 DOI 与标题全部逐字匹配、评分 13/13），属"错得看起来像成功"的变体。
    # 期号只做丢弃（与 gbt7714 / acs 口径一致，volume 只留卷本体）。
    journal = volume = page = ''
    vm = re.match(
        r'^(.*?)\s+(\d+)(?:\s*\(\s*\d+(?:\s*[–\-]\s*\d+)?\s*\))?'
        r',?\s*([\w\-–—]*)\s*\.?\s*$', rest2)
    if vm and vm.group(1).strip():
        journal, volume = vm.group(1).strip(), vm.group(2)
        page = (vm.group(3) or '').strip()
    elif rest2:
        journal = rest2.rstrip('.').strip()

    return {'index': index, 'authors': authors, 'title': title,
            'journal': journal, 'volume': volume, 'page': page,
            'year': year, 'doi': doi}


def parse(text, entries=None):
    """解析全文 → (refs, failed)。entries 可由调用方预切分后传入。"""
    if entries is None:
        start = rc.locate_references(text)
        if start is None:
            return [], []
        lines, _ = rc.preprocess(text[start:])
        mode = rc.detect_numbering([l for l in lines if l.strip()][:40])
        entries = rc.split_entries(lines, unnumbered=(mode == 'unnumbered'))

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if r.pop('parse_failed', False):
            r.setdefault('raw', txt[:200])
            failed.append(r)
        else:
            refs.append(rc.clean_ref(r))
    return refs, failed


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_noidx_apa.py <fulltext.txt> <out_refs.json>',
              file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    refs, failed = parse(text)
    refs.sort(key=lambda r: r.get('index') or 0)
    Path(sys.argv[2]).write_text(
        json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

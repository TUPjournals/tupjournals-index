#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_noidx_vancouver.py — F6：无编号 NLM/Vancouver 解析器（v2.18.1）

条目形如（**无编号、期刊名后带 年;卷:页**，作者为「姓 名缩写」顺序）：
    Reddy R, Adamu M, Raut A, Ibrahim YE, Alanazi H. Laterite-GGBS geopolymer
    composites: Synthesis and thermal performance under static and cyclic
    loadings. Case Studies in Thermal Engineering. 2025;76:107371.

与 parse_refs_vancouver（F4）的区别：F4 有编号且年份紧跟作者
（`[1]. Lee, S., ..., 2025. Title. Journal, 318, p.134731.`）；
本稿（CESCI-D-26-00016R1 实测）为无编号、年份在期刊名后、卷页以
`;` 分隔 —— 5 个既有策略均不适用（F4 的 `, 年份.` 锚点缺失会全部
parse_failed）。条目起点切分见 ref_common.split_entries_nlm。

解析要点（从行尾倒推，比"作者→标题→期刊"正向切分更稳）：
  1) 尾部剥离 年;卷(:页)（如 `2025;76:107371` / `2022;45.` / `2018;2018.`）
  2) 剥 DOI / URL（顺序不可反，理由同其他解析器）
  3) 剩余按 ". " 切段：authors / title / journal 三段对应
     （期刊名为末段；作者段尾部 "et al" 剥离）

已知边界（不强行处理，CrossRef 以标题检索兜底）：
  - 期刊名内部含缩写句点（如 "J. Constr. Steel Res."）会被 ". " 切碎 → 视
    实际出现频率再决定是否增强；DOI 存在时走 DOI 优先验证不受影响。
  - 标题内部含 ". " 的条目：title 取中间各段合并（parts>=4 场景已容错）。

CLI:  python parse_refs_noidx_vancouver.py <fulltext.txt> <out_refs.json>
输出:  纯 list JSON（与既有解析器一致）
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ref_common as rc  # noqa: E402

# 页码字符类：hyphen / en-dash / em-dash / **U+2212 数学减号**（PDF 排版高频）
# —— 缺 U+2212 会让 "ACS Photonics 2026, 13, 1417−1427." 整条失配
# （EMD20260068 [12] 实测 reason="no year;volume tail"）；与 citation_stats
# 的 _DASH 同源教训。
_DASH = '\u2013\u2014\u2212\\-'
_NUMPAGE = r'[\de%s]' % _DASH

# 行尾 年;卷(:页) —— 允许 ". 2025;76:107371." / "2022;45." / "2018;2018."
# v2.20.1 起改为多形态尾部表（同一列表内混排 4 种年卷写法，EMD20260068 实测）：
#   ① NLM 分号制   "Journal 2025;10:2616–32."
#   ② ACS 逗号制   "ACS Photonics 2026, 13, 1417−1427."
#   ③ 年:页（无卷，页为文章号） "HardwareX 2021: e00242." / "… research, 2024:3397-3410."
#   ④ 仅年份（报告/无卷页） "Chemical Engineering Transactions 2023."
# v2.22.0 起 ① 补「可选期号 (N)」与「页分隔符可用逗号」——CESCI-S-26-00047 实测的
#   **第十种房式**：编号式 `[n] 作者. 标题. 期刊. 年;卷[(期)][:页].`：
#     "Building Materials. 2025;458."            → 年;卷（无期无页，14 条）
#     "Pavement Engineering. 2023;24(1)."        → 年;卷(期)（10 条）
#     "Bridge Engineering. 2012;17(3):443-53."   → 年;卷(期):页（9 条）
#   原 ① 无 `(期)` 段、页前只认冒号 → 37 条中 **29 条失配**（`no year;volume tail`），
#   策略得分被压到 0.5 以下、错误策略 `noidx_vancouver` 反而被选中。
#   ⚠️ 期号段必须**只吞数字**（`\(\s*\d{1,4}\s*\)`），不可吞字母——否则会把
#   `Journal of Testing (Part B)` 一类刊名括注吃掉。
_TAIL_PATTERNS = [
    re.compile(
        r'[.,;\s](\d{4})\s*;\s*(\d[\d\s%s]*?)'      # 年 ; 卷
        r'(?:\s*\(\s*\d{1,4}\s*\))?'                # 可选 (期)
        r'(?:\s*[:\uff1a,]\s*(%s+))?'               # 可选 页（冒号/全角冒号/逗号）
        r'\s*\.?\s*$' % (_DASH, _NUMPAGE)),
    re.compile(r'[.,;\s](\d{4})\s*,\s*(\d+)\s*,\s*(%s+)\s*\.?\s*$' % _NUMPAGE),
    re.compile(r'[.,;\s](\d{4})\s*:\s*(%s+)\s*\.?\s*$' % _NUMPAGE),
    re.compile(r'[.,;\s](\d{4})\s*\.?\s*$'),
]

# "…, et al.," —— 逗号制条目的强信号（NLM 写作 "et al. 标题"，其后无逗号）
_ETAL_COMMA_RE = re.compile(r'(?i)et\s+al\.?\s*,')


def _looks_like_author_seg(s):
    """判断 ". " 切出的首段是否为作者段（而非缩写句点造成的碎片）。

    反例：`S. Devesa , D. Cavaleiro1, …` 首个 ". " 落在缩写处，切出首段 = "S"。
    正例：`Xin L` / `Zayed ME` / `Mahfoudi N, Moummi A, Ganaoui ME` —— 均含空格或逗号。
    """
    s = (s or '').strip()
    return len(s) >= 4 and (' ' in s or ',' in s)


def _strip_ref_links(s):
    """摘走条目内的 DOI / URL，返回 (去掉链接后的文本, doi)。

    必须先摘链接再匹配尾部年卷：本类稿件常把 DOI 排在 `年;卷:页` **之后**
    （`… 2025;10:2616–32. https://doi.org/10.22059/jser.2025.406743.1670`），
    尾部锚定正则于是完全失配 —— EMD20260068 实测 41/41 全部 parse_failed
    （reason="no year;volume tail"）。顺序仍不可反：先提 DOI 再删链接，
    否则 DOI 会随 URL 一起被删掉。
    """
    doi = rc.extract_doi(s)
    out = rc.URL_RE.sub(' ', s)
    # 裸 DOI（无 https:// 前缀，如 "DOI:10.1557/s43578-024-01477-4"）
    out = re.sub(r'(?i)\bdoi\s*:?\s*10\.\d{4,9}/\S+', ' ', out)
    return re.sub(r'\s+', ' ', out).strip(), doi


def _split_shape_b(head):
    """逗号制条目（"作者, 作者, …, et al., 标题, 期刊" 或 "… and X, 标题, 期刊"）。

    混排列表里这类条目没有 NLM 的 ". " 三段结构，走 ". " 切段会得到 <3 段
    （EMD20260068 实测 4 条）。改以作者段结束锚点切分：`et al.,` 或 `, and X,`。
    """
    m = re.search(r'(?i)(?:,\s*)?et\s+al\.?\s*,', head)
    if m:
        authors = head[:m.end()].rstrip(', ').strip()
        rest = head[m.end():]
    else:
        m = re.search(r',\s*and\s+[^,]+,\s*', head)
        if not m:
            return None
        authors = head[:m.end()].rstrip(', ').strip()
        rest = head[m.end():]
    rest = rest.lstrip(',').strip()
    if not rest:
        return None
    if ', ' in rest:
        title, journal = rest.rsplit(', ', 1)
    elif '. ' in rest:
        title, journal = rest.rsplit('. ', 1)
    else:
        return None
    authors, title, journal = authors.strip(), title.strip(), journal.strip()
    if not authors or not title or not journal:
        return None
    return authors, title, journal


def parse_line(index, text):
    """解析单条（无编号 NLM 条目，index 为出现顺序）。"""
    s = text.strip()
    if not s:
        return {'index': index, 'raw': s, 'parse_failed': True,
                'reason': 'empty line'}

    # 0) 先摘走 DOI / URL（本类稿件常把 DOI 排在 年;卷:页 之后）
    s, doi = _strip_ref_links(s)

    # 1) 尾部 年;卷:页（多形态，见 _TAIL_PATTERNS）
    m = None
    for pat in _TAIL_PATTERNS:
        m = pat.search(s)
        if m:
            break
    if not m:
        return {'index': index, 'raw': s[:200], 'parse_failed': True,
                'reason': 'no year;volume tail'}
    year = m.group(1)
    if pat is _TAIL_PATTERNS[1]:          # ② 年, 卷, 页
        volume, page = m.group(2), m.group(3)
    elif pat is _TAIL_PATTERNS[2]:        # ③ 年:页（无卷）
        volume, page = '', m.group(2)
    elif pat is _TAIL_PATTERNS[3]:        # ④ 仅年份
        volume, page = '', ''
    else:                                  # ① 年;卷(:页)
        volume, page = m.group(2).replace(' ', ''), (m.group(3) or '')
    head = s[:m.start()].strip()

    # 2) 残余 DOI / URL 清理
    head = rc.URL_RE.sub('', head).strip().rstrip('.').strip()

    # 3) 切分作者/标题/期刊
    #    先判"逗号制"（含 "et al.,"）：这类条目把缩写句点写在作者名之间
    #    （"S. Devesa , D. Cavaleiro1, D. Santo1, et al., 标题, 期刊"），按 ". "
    #    切段会把 "D. Cavaleiro1" 当段边界 → 作者="S"、标题混入作者名（[14] 实测）。
    parts = [p.strip() for p in head.split('. ') if p.strip()]
    shape_b = _split_shape_b(head) if _ETAL_COMMA_RE.search(head) else None
    if shape_b:
        authors, title, journal = shape_b
    elif len(parts) >= 3 and _looks_like_author_seg(parts[0]):
        authors = parts[0].strip().rstrip(',').strip()
        # 作者段尾部可能带 ", et al"（NLM 6 作者以上省略写法）
        authors = re.sub(r',?\s+et\s+al\.?$', '', authors, flags=re.I).strip()
        journal = parts[-1].strip()
        title = ' '.join(parts[1:-1]).strip()
    else:
        shape_b = _split_shape_b(head)
        if not shape_b:
            return {'index': index, 'raw': s[:200], 'parse_failed': True,
                    'reason': 'too few dot-segments for authors/title/journal'}
        authors, title, journal = shape_b
    if not authors or not title or not journal:
        return {'index': index, 'raw': s[:200], 'parse_failed': True,
                'reason': 'empty authors/title/journal'}

    return {'index': index, 'authors': authors, 'title': title,
            'journal': journal, 'volume': volume, 'page': page,
            'year': year, 'doi': doi}


def parse(text, entries=None):
    """解析全文 → (refs, failed)。"""
    if entries is None:
        start = rc.locate_references(text)
        if start is None:
            return [], []
        lines, _ = rc.preprocess(text[start:])
        mode = rc.detect_numbering([l for l in lines if l.strip()][:40])
        if mode == 'unnumbered':
            entries = rc.split_entries(lines, unnumbered=True)
        else:
            entries = rc.split_entries(lines, unnumbered=False)
        if not entries:
            entries = rc.split_entries_nlm(lines)

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if r.pop('parse_failed', False):
            r.setdefault('raw', txt[:200])
            failed.append(r)
        else:
            refs.append(rc.clean_ref(r))
    return refs, failed


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_noidx_vancouver.py <fulltext.txt> <out_refs.json>',
              file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    refs, failed = parse(text)
    refs.sort(key=lambda r: r.get('index') or 0)
    Path(sys.argv[2]).write_text(
        json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_numbered_jv.py — F14 策略：编号式「期刊. 年, 卷(期), 页」（EMD20260093）

适用格式（**EndNote/NoteExpress 导出的"作者逗号分隔"编号式**，综述类投稿常见）：

    [n] Surname, A. B., Surname, C. D., Surname, E. Title of the Paper.
        Journal Name. YEAR, Volume(Issue), startPage-endPage.

实例（EMD20260093 实测，104 条）：
    [1] Larcher, D., Tarascon, J. M. Towards greener and more sustainable
        batteries for electrical energy storage. Nature chemistry. 2015, 7(1), 19-29.
    [12] Zhao, Y., … Wang, G. Engineering strategies … reactions.
        Chemical Society Reviews. 2023 52(9), 3215-3264.   ← 年与卷之间漏了逗号
    [21] Hussain, I., … Zhang, K. MXene-based heterostructures … devices.
        Progress in Energy and Combustion Science. 2023, 97, 101097.  ← 只有卷 + 页
    [23] Patnaik, R. K., Sen, S. From Green Routes … Applications.
        Journal of Environmental Chemical Engineering. 2026, 122174.  ← 只有文章号
    [15] Sharma, V., … Two-dimensional MXene-based heterostructures for
        photocatalysis. In Handbook of smart photocatalytic materials. Elsevier.
        2020, (pp. 247-267).                                ← 书籍章节

为什么既有 13 策略全部失效（实测：`acs` 0.96 分被自动选中，但**字段系统性错位**）：
  · `acs` 的刊名提取要求「刊名直接接年份」（`Journal YEAR, Vol (Issue)`），
    本格式刊名与年份之间**多一个句点**（`Journal. YEAR,`）→ 右起第一个词
    `chemistry.` 以句点收尾被判为"标题末词" → 刊名整段放弃；
  · `acs` 的作者段按 `;` 分段消费，本格式作者以**逗号**分隔 →
    只切出第一位作者，其余作者连同标题、刊名一起塞进 `title`。
  · 结果：`title` 混着前序作者与刊名、`journal` 全空，而 `parse_failed` 为空、
    得分 0.96 —— 属「错得看起来像成功」的静默失败（Crossref 会因刊名空而
    大面积假报 `journal_mismatch`）。
  · 其余策略均以"年份位置"失配：`numbered` 要年份在行尾括号内、`numbered_year`
    要年份紧跟作者、`gbt7714` 要 `[J]` 标识、`rsc` 要 `, 年` 逗号锚点、
    `springer` 要作者段双句点收尾、`elsevier` 要年份带括号。

定位方法（三段）：
  1. **年份锚点 = 句点 + 4 位年**（`\\.\\s*(19|20)\\d{2}`，取**最右**一个），
     且年份后必须紧跟 `,` `(` `空格+数字` 或行尾——句点在年份前是本格式最
     稳定的指纹，`numbered_year`（`作者. 2007 标题`）因年份后接大写标题词
     而不满足该前瞻，故不会被抢走；
  2. 锚点左侧 = 作者 + 标题 + 刊名：刊名用「从右往左连续 Title-Case 词」扫描
     （连接词 of/in/and/& 放行、缩写词白名单放行），遇小写实词或句末标点即停；
     **`In <容器>` 书籍章节**先按 `\\. In ` 切出容器名，容器后若是出版社则剥离；
  3. 锚点右侧 = `年` 之后的 `卷(期), 页`：兼容「年 卷(期)」缺逗号、
    仅卷+页、仅文章号、仅页码范围、`(pp. 247-267)` 四种退化形态。

作者段消费：循环匹配「姓(+空格复姓成分), 名缩写」，组间以 `,` / `and` / `&`
连接；一旦下一位不再是「姓, 缩写」形态即认为作者结束、其后为标题。这一步是
本策略与 `acs` 的第二个关键差异（逗号既分隔作者、也分隔姓与名缩写，不能只 split）。

失败返回 {'parse_failed': True, 'reason': …}，交由其他策略或人工补全。
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

# 破折号四字符类（与 citation_stats / elsevier / acs 同源教训：缺 U+2212 会让
# `1417−1427` 这类页码静默失配）
_DASH = r'\-\u2013\u2014\u2212'

# 序号前缀（`[1]` / `(1)` / `1.` / `1)`）
_NUM_PREFIX = re.compile(r'^\s*(?:[\[\(]\s*\d{1,4}\s*[\]\)]|\d{1,4}\s*[.)])\s*')

# 年份锚点：句点 + 4 位年 + （逗号/括号/空格数字/行尾）。取**最右**一个。
# 句点在年份之前是本格式最稳定的指纹：`numbered_year`（`作者. 2007 标题`）年份后
# 接大写标题词、`noidx_vancouver`（`期刊. 2025;76`）年份后是分号、APA/Elsevier
# 年份在括号内 —— 均不满足该前瞻，故不会被本策略抢走。
_YEAR_ANCHOR = re.compile(
    r'\.\s*((?:19|20)\d{2})(?=\s*[,(]|\s+\d|\s*$)')
# 退化锚点：个别条目把「刊名. 年」误打成「刊名, 年」（EMD20260093 [53][56] 实测）。
# 仅在句点锚点**完全无命中**时启用，避免抢走 `acs`/`noidx_vancouver` 的逗号锚点格式。
_YEAR_ANCHOR_COMMA = re.compile(
    r',\s*((?:19|20)\d{2})(?=\s*[,(]|\s+\d|\s*$)')

_DOI_PAT = re.compile(
    r'(?:https?://(?:dx\.)?doi\.org/|doi\s*:\s*)?(10\.\d{4,9}/[^\s,;]+)', re.I)

# 页码 / 文章号（`19-29` / `e10761` / `122174` / `1-16`）
_PAGE = re.compile(
    r'^[A-Za-z]{0,2}\d[\w]*(?:\s*[' + _DASH + r']\s*[A-Za-z]{0,2}\d[\w]*)?$')

# ---- 作者段 ----
# 姓：首字母大写词（允许 `van` `de` 等西欧冠词前缀、内部大写如 `Chandran BS`）
_NAME_PRE = r'(?:(?:van|von|der|den|de|del|di|da|la|le|dos|du|bin|el|al)\s+)?'
# 小写起首的姓：原稿打字错误（EMD20260093 [18] 实测 `kun Liu, H.`，应为 `Kun Liu`）。
# 仅放行「非停用词的小写词 + 大写姓 + 逗号 + 名缩写」这一组合，停用词表挡住标题碎片
# （`… for sodium, X.` 这类不会被误当作者）。
_LOWER_PRE = (r'(?:(?!(?:of|in|on|at|to|for|and|the|from|with|by|as|a|an|its|'
              r'their|this|these|such|via|into|over|under|between)\b)[a-z]{2,6}\s+)?')
_SURNAME = _LOWER_PRE + _NAME_PRE + r"[A-Z\u00C0-\u024F][A-Za-z\u00C0-\u024F'\u2010-\u2015\-]{0,24}"
_AUTHOR_GROUP = re.compile(
    r'(?P<sur>' + _SURNAME + r'(?:\s+' + _SURNAME + r'){0,2}),\s*'
    r'(?P<ini>(?:[A-Z]\.\s*){1,4}|[A-Z]{1,3})')
# 组间分隔符（逗号 / and / &）；**不含纯空格**——纯空格后即标题起点
_AUTHOR_SEP = re.compile(r'\s*(?:,\s*(?:and\s+|&\s*)?|and\s+|&\s*)\s*', re.I)

# ---- 刊名 ----
_CONJ = frozenset({'of', 'the', 'and', 'in', 'on', 'for', 'de', 'del', 'der',
                   'van', 'von', 'und', 'la', 'le', 'du', 'des', '&'})
# 缩写词白名单（`J.` `Am.` `Chem.` `Soc.` …）。不可用「Title-Case 短词 + 句点」
# 代替——标题末词 `Route.` / `Cells.` 会被误吞（v2.27.0 ACS 实测教训）。
_ABBREV_WORDS = frozenset("""
j am chem soc phys rev lett mater adv appl sci eng res int proc natl acad
commun energy environ electrochem acta solid state technol biotechnol polym
catal biol med nucl instrum methods anal coord cryst struct mol opt electron
power sources surf coat ind rep prog trans metall ceram compos photovolt
spectrosc chromatogr aiche inst conf symp ser bull mag today nano
""".split())

_PUBLISHERS = frozenset((
    'elsevier', 'wiley', 'wiley-vch', 'wiley-vch verlag', 'springer',
    'springer-verlag', 'crc press', 'woodhead publishing', 'academic press',
    'pearson', 'mcgraw-hill', 'taylor & francis', 'routledge',
    'world scientific', 'mit press', 'cambridge university press',
    'oxford university press', 'royal society of chemistry', 'rsc',
    'american chemical society', 'acs', 'iea', 'nova science publishers',
    'pan stanford', 'trans tech publications', 'de gruyter', 'ist press',
))


def _is_abbrev(word):
    core = (word or '').rstrip('.').strip()
    if not core:
        return False
    if core.isupper() and 2 <= len(core) <= 6:
        return True
    return core.lower() in _ABBREV_WORDS


def _norm_page(p):
    p = re.sub(r'\s+', '', p or '')
    p = re.sub(r'[' + _DASH + r']', '\u2013', p)
    return p.strip('.,; ')


def _strip_publisher(seg):
    """剥离尾部出版社（`… materials. Elsevier` → `… materials`）。"""
    for _ in range(2):
        m = re.search(r'[.,]\s*([^.,]+)\s*$', seg)
        if not m:
            break
        if m.group(1).strip().lower() in _PUBLISHERS:
            seg = seg[:m.start()].strip()
        else:
            break
    return seg


def _split_container(head):
    """处理 `… 标题. In <容器>. <出版社>` 的书籍章节形态。

    返回 (body, container)；非该形态返回 (head, '')。
    """
    m = re.search(r'[.,]\s+In\s+(?=[A-Z])', head)
    if not m:
        return head, ''
    body = head[:m.start()].strip()
    container = _strip_publisher(head[m.end():].strip())
    if len(container) < 6 or not body:
        return head, ''
    return body, container


def _extract_journal(head):
    """从 head 右端提取刊名，返回 (body_without_journal, journal)。

    两条通道：
      ① **右起连续 Title-Case 词扫描**——处理常规刊名（`Progress in Energy and
         Combustion Science`）、缩写刊名（`J. Am. Chem. Soc`）与「标题与刊名之间
         无句点只隔逗号」的形态（`… modifications, Advanced Functional Materials`）；
      ② 扫描失败时回退「**最后一个句点之后整句作刊名**」——处理刊名自带小写实词
         的写法（`Nature chemistry` / `Chemical reviews` / `Advanced materials` /
         `Scientific reports` / `Inorganic chemistry`，EMD20260093 实测 5 条）。
         ①会把这类刊名的末词当"小写实词"拒收，导致刊名整段丢失。
    """
    words = head.split()
    jw, start = [], None
    for i in range(len(words) - 1, -1, -1):
        w = words[i]
        # 只剥尾部逗号/分号：**保留冒号**，书名/会议名常含 `Composites: Fabrication`
        core = w.strip(',;').strip()
        if not core:
            break
        if re.search(r'[()\[\]"]', core):
            break
        if _is_abbrev(core):
            jw.append(core.rstrip('.'))
        elif core.endswith(('.', '?', '!')):
            break                      # 标题末词（句点收尾、非缩写）
        elif core.lower() in _CONJ:
            if not jw:
                break
            jw.append(core)
        elif core[0].isupper():
            jw.append(core)
        else:
            break                      # 小写实词 → 已进标题
        start = i
        if len(jw) >= 14:
            break
    if start is not None:
        journal = ' '.join(reversed(jw)).strip()
        body = ' '.join(words[:start]).strip().rstrip(',;:').strip()
        return body, journal

    # ② 回退：末句作刊名（≤12 词、首词大写），其余为作者+标题
    segs = re.split(r'\.\s+', head)
    if len(segs) >= 2:
        cand = segs[-1].strip().rstrip(',;:').strip()
        toks = cand.split()
        if 1 <= len(toks) <= 12 and cand and cand[0].isupper():
            body = '. '.join(segs[:-1]).strip().rstrip(',;:').strip()
            if len(body.split()) >= 3:          # 标题不能为空壳
                return body, cand
    return head, ''


def _split_authors(body):
    """消费「姓, 名缩写」作者组，返回 (authors, title)。"""
    pos, groups = 0, []
    while True:
        m = _AUTHOR_GROUP.match(body, pos)
        if not m:
            break
        groups.append(m.group(0).strip().rstrip(',').strip())
        pos = m.end()
        ms = _AUTHOR_SEP.match(body, pos)
        if not ms:
            break
        if not _AUTHOR_GROUP.match(body, ms.end()):
            break
        pos = ms.end()
    if not groups:
        return '', body.lstrip(',;: ').strip()
    title = body[pos:].lstrip(',;: ').strip()
    return ', '.join(groups), title


def _parse_tail(tail):
    """`年` 之后 → (volume, issue, page)。"""
    tail = (tail or '').strip().rstrip('.').strip().lstrip(',;:').strip()
    if not tail:
        return '', '', ''
    # `(pp. 247-267)` → `247-267`
    tail = re.sub(r'\(\s*pp?\.?\s*([^)]*)\)', r'\1', tail, flags=re.I)
    parts = [p.strip().strip('.').strip() for p in tail.split(',')]
    parts = [p for p in parts if p]

    vol = issue = page = ''
    for p in parts:
        mv = re.match(r'^(\d{1,5})\s*\(\s*([^)]{1,12})\s*\)$', p)
        if mv and not vol:
            vol, issue = mv.group(1), mv.group(2).strip()
            continue
        if re.fullmatch(r'\d{1,5}', p) and not vol and len(parts) > 1:
            vol = p
            continue
        if _PAGE.match(p.split()[0].strip('.,;')) and not page:
            page = _norm_page(p.split()[0])
            continue
        if re.fullmatch(r'\d{1,5}', p) and not vol and not page:
            # 单段纯数字：≥4 位按文章号（页码），否则按卷号
            if len(p) >= 4:
                page = p
            else:
                vol = p
    return vol, issue, page


def parse_line(index, raw):
    """解析单条条目。失败返回带 parse_failed 的 dict。"""
    line = _NUM_PREFIX.sub('', (raw or '').strip(), count=1).strip()
    if not line:
        return {'index': index, 'raw': (raw or '')[:200],
                'parse_failed': True, 'reason': 'empty'}

    m = re.match(r'^\s*[\[\(]\s*(\d{1,4})\s*[\]\)]\s*', line)
    if m:
        index = int(m.group(1))
        line = line[m.end():].strip()

    # ---- DOI 先摘（顺序不可反：先提 DOI 再删链接）
    doi = ''
    dm = _DOI_PAT.search(line)
    if dm:
        doi = dm.group(1).rstrip('.,);')
        line = (line[:dm.start()] + ' ' + line[dm.end():]).strip()
    line = re.sub(r'https?://\S+', ' ', line)
    line = re.sub(r'(?i)[\s,;]*\bdoi\s*:?\s*$', ' ', line)
    line = re.sub(r'\s{2,}', ' ', line).strip(' .,;')

    # ---- 年份锚点（优先句点式，取最右；无命中才试逗号式退化锚点）
    ym = None
    for mm in _YEAR_ANCHOR.finditer(line):
        ym = mm
    if ym is None:
        for mm in _YEAR_ANCHOR_COMMA.finditer(line):
            ym = mm
    if ym is None:
        return {'index': index, 'raw': (raw or '')[:200],
                'parse_failed': True, 'reason': 'no year anchor'}
    year = ym.group(1)
    head = line[:ym.start()].strip().rstrip(',;:').strip()
    tail = line[ym.end():].strip()
    if not head:
        return {'index': index, 'raw': (raw or '')[:200],
                'parse_failed': True, 'reason': 'empty head'}

    # ---- 书籍章节：`… 标题. In <容器>. <出版社>`
    body, journal = _split_container(head)
    if not journal:
        body, journal = _extract_journal(head)
        if journal.strip().lower() in _PUBLISHERS:
            # 刊名位落在出版社上（`… materials. Elsevier`）→ 回退再扫一层
            body2, journal2 = _extract_journal(body)
            if journal2:
                body, journal = body2, journal2

    if not journal:
        return {'index': index, 'raw': (raw or '')[:200],
                'parse_failed': True, 'reason': 'journal not located'}

    authors, title = _split_authors(body)
    title = re.sub(r'\s{2,}', ' ', title).strip().rstrip('.,;:').strip()
    if len(title) < 8:
        return {'index': index, 'raw': (raw or '')[:200],
                'parse_failed': True, 'reason': 'title not located'}

    vol, issue, page = _parse_tail(tail)

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal.strip(),
        'volume': vol,
        'issue': issue,
        'year': str(year),
        'page': page,
        'doi': doi,
    }


# ------------------------------------------------------------------ CLI

def main():
    if len(sys.argv) < 2:
        print('usage: parse_refs_numbered_jv.py "<单条文献文本>" | '
              '<fulltext.txt> <out_refs.json>', file=sys.stderr)
        sys.exit(1)
    if len(sys.argv) == 2:                      # 单条自测
        print(json.dumps(parse_line(1, sys.argv[1]), ensure_ascii=False, indent=1))
        return

    import ref_common as rc

    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    start = rc.locate_references(text)
    if start is None:
        print(json.dumps({'status': 'error',
                          'error': 'References section not found'},
                         ensure_ascii=False))
        sys.exit(1)
    lines, _ = rc.preprocess(text[start:])
    entries = rc.split_entries(lines)

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if not isinstance(r, dict) or r.get('parse_failed'):
            failed.append(r if isinstance(r, dict)
                          else {'index': idx, 'raw': txt[:200]})
        else:
            refs.append(rc.clean_ref(r))

    Path(sys.argv[2]).write_text(json.dumps(refs, ensure_ascii=False, indent=1),
                                 encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_numbered_year.py — F7：编号 + 年份紧跟作者（皇家学会/SPJ 式）

条目形如（**有编号、作者段以句点结束、裸年份、年份后直接接标题**）：
    1. Bettencourt LMA, Lobo J, Helbing D, Kuhnert C, West GB. 2007 Growth,
    innovation, scaling, and the pace of life in cities. Proc. Natl Acad.
    Sci. USA 104, 7301-7306. (doi:10.1073/pnas.0610172104)

与既有策略的区别（CES 新投稿实测，6 个策略全部 parse_failed）：
  - F1 numbered：要求年份在末尾 `...(2010).` → 不适用
  - F4 vancouver：要求年份前有**逗号**（`, 2025.`）→ 本稿为**句点**
    （`West GB. 2007 Growth`），锚点不命中
  - F6 noidx_vancouver：要求行尾 `年;卷:页`（分号）→ 本稿为 `卷, 页码`
  - F2/F3/F5（APA / 无编号 APA / Nature）：要求括号年份 `(2007)` → 不适用

解析要点（以「句点+空格+4 位年+空格」为锚点正向切分，该锚点在本类稿件中
唯一 —— 作者段不含 4 位数，故首个命中即出版年）：
  1) 锚点 `\\. 2007 ` 之前 = 作者段（尾部 `et al` 剥离）
  2) 先提取 DOI，再**删除整个 `(doi:…)` 括注**（不删则残留 "(doi:" 挂期刊尾、
     令卷页正则失配）
  3) 锚点之后按**首个句末标点**（`. ` / `? ` / `! `）切出标题
     （仅用 ". " 会在 "Is this scaling nonlinear? R. Soc. Open Sci." 处误切）
  4) 余下期刊段用右锚定正则取 `期刊 卷, 页码`
     （期刊名内部缩写句点如 "Proc. Natl Acad. Sci. USA" 不会被切碎）
  5) DOI 先提取再删 URL（顺序不可反，同其他解析器）

已知边界（不强行处理，Crossref 以标题检索兜底）：
  - 报告/代码库类条目无卷页（如 "JRC Technical Report JRC115586.
    Luxembourg: Publications Office of the European Union."）→ 仅取标题，
    期刊段交由 clean_journal 清洗
  - 标题内部含 ". " 的条目会提前截断（本类格式罕见）

CLI:  python parse_refs_numbered_year.py <fulltext.txt> <out_refs.json>
输出:  纯 list JSON（与既有解析器一致）
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ref_common as rc  # noqa: E402

# 年份锚点：句点（或逗号）→ 空白 → 4 位年（19xx/20xx）→ 空白 → 非空白
_YEAR_ANCHOR = re.compile(r'(?:\.\s*|,\s*)((?:19|20)\d{2})\s+(?=\S)')

# 期刊 卷, 页码（右锚定；期刊名可含缩写句点）
_JVP = re.compile(
    r'^(.*?)[,\s]+(\d{1,4})\s*,\s*(?:pp?\.\s*)?([\w\-–—]+)\s*\.?\s*$')

# 期刊 卷（无页码），如 "Cybergeo 343."
_JV = re.compile(r'^(.*?)[,\s]+(\d{1,4})\s*\.?\s*$')

# 候选切点：句末标点 + 空白（标题内部可能也含 ? !，故不能见标点就切）
_CUT = re.compile(r'[.!?]\s+')

# 正文散文特征：出现「纯小写且 ≥4 字母」的词（urban / expansion / across…）
_PROSE_WORD = re.compile(r'[a-z]{4,}')


def _looks_like_journal(s):
    """判断一段文字像不像期刊/出版物名（而非标题的续写）。"""
    toks = (s or '').split()
    if not (1 <= len(toks) <= 12):
        return False
    for t in toks:
        core = t.strip('.,;:()[]')
        if core and core.islower() and len(core) >= 4:
            return False
    return True


def _title_ok(t):
    """标题合法性：非空、末词不能是孤立首字母（如 "... nonlinear? R"）。"""
    toks = (t or '').split()
    if not toks:
        return False
    last = toks[-1].strip('.,;:!?()[]')
    return len(last) >= 2


def _split_title_journal(after):
    """把「标题 + 期刊 卷, 页码」拆开，返回 (title, journal, volume, page)。

    难点（CES 实测两处反例）：
      [6]  "Is this scaling nonlinear? R. Soc. Open Sci. 3, 150649."
           → 首个句末标点在标题内，须切在 "?" 处
      [17] "Building in or out? Examining urban expansion patterns ... 
            inhabitants. Habitat Int. 120, 102503."
           → "?" 却在标题内部，须切在后面那处
    单看标点无法区分，故以**余段是否像期刊名**为准：
      第一轮──余段能整体匹配「期刊 卷, 页码」且期刊段像刊名 → 采用；
      第二轮──余段整体像刊名（无卷页，如报告/代码库条目）→ 采用；
      兜底──取首个句末标点。
    """
    cands = [(m.start(), m.end()) for m in _CUT.finditer(after)]

    for cs, ce in cands:
        title = after[:cs + 1].rstrip('.').strip()
        rest = after[ce:].strip()
        if len(title) < 8 or not _title_ok(title) or not rest:
            continue
        for rx in (_JVP, _JV):
            m = rx.match(rest)
            if m and m.group(1).strip() and _looks_like_journal(m.group(1)):
                page = (m.group(3) or '').strip() if rx is _JVP else ''
                return title, m.group(1).strip(), m.group(2), page

    for cs, ce in cands:
        title = after[:cs + 1].rstrip('.').strip()
        rest = after[ce:].strip()
        if len(title) < 8 or not _title_ok(title) or not rest:
            continue
        if _looks_like_journal(rest):
            # 无卷页时（报告 / 代码库等），期刊名取首个句段，避免把出版社、
            # 城市等后续信息一并塞入（CES 实测 [11][26][30]）；并剥离
            # 报告编号后缀（"OECD Regional Development Papers no. 67" → 前段）
            jr = rest.split('. ')[0].strip() if '. ' in rest else rest
            jr = re.sub(r'\s+no\.?\s*\d*\s*$', '', jr).strip()
            return title, jr.rstrip('.').strip(), '', ''

    if cands:
        cs, ce = cands[0]
        title = after[:cs + 1].rstrip('.').strip()
        return title, after[ce:].strip().rstrip('.').strip(), '', ''
    return after.rstrip('.').strip(), '', '', ''


def parse_line(index, text):
    """解析单条（已由 ref_common 剥离条目编号）。"""
    s = text.strip()
    if not s:
        return {'index': index, 'raw': s, 'parse_failed': True,
                'reason': 'empty line'}

    m = _YEAR_ANCHOR.search(s)
    if not m:
        return {'index': index, 'raw': s[:200], 'parse_failed': True,
                'reason': 'no bare-year anchor'}

    year = m.group(1)
    authors = s[:m.start()].strip().rstrip(', ').strip()
    authors = re.sub(r',?\s+et\s+al\.?$', '', authors, flags=re.I).strip()
    after = s[m.end():].strip()

    if not authors or not after:
        return {'index': index, 'raw': s[:200], 'parse_failed': True,
                'reason': 'empty authors or body'}

    # DOI 先提取（再删 URL，顺序不可反）
    doi = rc.extract_doi(after)
    # 关键：提取后必须把 `(doi:10.x/y)` 括注整段删除，否则残留的 "(doi:"
    # 会挂在期刊名尾部，使后续「期刊 卷, 页码」正则失配（CES 首次实测：
    # journal 变成 "Proc. Natl Acad. Sci. USA 104, 7301-7306. (doi:"）
    after = re.sub(r'\(\s*(?:doi|https?://[^)]*?doi\.org)[^)]*\)', '',
                   after, flags=re.I)
    if doi:
        after = after.replace(doi, '')
    after = rc.URL_RE.sub('', after).strip()

    # 标题 = 首个句末标点（. ! ?）后跟空白之前
    # 用 [.!?] 而非仅 "."：如 "Is this scaling nonlinear? R. Soc. Open Sci."
    # 若只认 "." 会把 "R" 吞进标题、把 "Soc." 当成期刊名（CES 实测 [6]）
    title, journal, volume, page = _split_title_journal(after)

    if len(title) < 8:
        return {'index': index, 'raw': s[:200], 'parse_failed': True,
                'reason': 'title/journal split failed'}

    return {'index': index, 'authors': authors, 'title': title,
            'journal': journal, 'volume': volume, 'page': page,
            'year': year, 'doi': doi}


def parse(text, entries=None):
    """解析全文 → (refs, failed)。"""
    if entries is None:
        start = rc.locate_references(text)
        if start is None:
            return [], []
        lines, _ = rc.preprocess(text[start:])
        mode = rc.detect_numbering([l for l in lines if l.strip()][:40])
        entries = rc.split_entries(lines, unnumbered=(mode == 'unnumbered'))
        if not entries:
            entries = rc.split_entries_nlm(lines)

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if r.pop('parse_failed', False):
            r.setdefault('raw', txt[:200])
            failed.append(r)
        else:
            refs.append(rc.clean_ref(r))
    return refs, failed


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_numbered_year.py <fulltext.txt> <out_refs.json>',
              file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    refs, failed = parse(text)
    refs.sort(key=lambda r: r.get('index') or 0)
    Path(sys.argv[2]).write_text(
        json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

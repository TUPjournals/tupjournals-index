#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_springer.py — 编号式 Springer/CVMJ house style（F12，v2.26.0）

适用形态（CVMJ-26-00445 实测，89 条）：

    [n] Surname, A. B.; Surname, C. D.. Title sentence. <Source>, YEAR, pages.

来源段三种常见写法（混排）：
  ① 会议：`In: Proceedings of IEEE/CVF Conf. Comput. Vis. Pattern Recognit., 2022, 12882–12891.`
  ② 期刊：`IEEE Trans. Intell. Transp. Syst., Vol. 23, No. 10, 16940–16961, Oct. 2022.`
  ③ 预印本：`2024, arXiv:2404.15506.` / `“…” in Proc. … , 2021, pp. 16249–16259.`（IEEE 夹入式）

**识别特征（三条同时出现即命中）**：
  1. 编号式（`[n]`）；
  2. 作者段以分号 `; ` 分隔，并以**双句点** `..` 结尾（`… Ramanan, D..`）——
     这是「姓, 缩写.」后接一个句点造成的 Springer 排版特征；
  3. **年份无括号**、且位于来源段末尾附近（区别于 `numbered` 的 `(YYYY)`、
     `vancouver` 的「作者, 年.」）。

失败即返回 `parse_failed`，交其他策略处理，故不会误抢既有格式。
"""

import re

# 作者块终止符：Springer 双句点（`Ramanan, D.. Title`）
_DBL_DOT = re.compile(r'\.\.\s')
# IEEE 夹入式：`…, and J. Yang, “BEDLAM: …`
_IEEE_QUOTE = re.compile(r',\s*[\u201c"]')

# 句子结束（标题末尾候选）：标点（可带右引号）+ 空白
_SENT_END = re.compile(r'[.?!][\u201d"]?\s')

# 缩写词（其后的 ". " 不是标题结束）——仅用于防标题被切在缩写处
_ABBREV = frozenset("""
et al ieee trans intell transp syst anal mach conf comput vis pattern recognit
proc adv neural inf process sci robot mag rev lett j int eur appl stat bio med
phys chem eng univ dept tech rep ser ed eds eg ie vs fig eq ref no vol pp
""".split())

# 期刊名候选里要跳过的段
_SKIP_SEG = re.compile(
    r'(?i)^(?:vol\.?|no\.?|pp?\.?|in:?|eds?\.?|and|of|the)$')

_MONTH_YEAR = re.compile(r'(?i)^[A-Z][a-z]{2}\.?\s*\d{4}$')

# 来源段前缀（`In: ` / `in ` / `in Proc.`；Zotero 导出偶见 `,”inProc.` —— 无空格，
# 故允许零空白，但要求其后紧跟大写字母或括号，避免吃掉以 "in" 开头的真实刊名
# 缩写（`Int. Conf.` / `Innov.`））
_SRC_PREFIX = re.compile(r'(?i)^\s*in\s*:?\s*(?=[A-Z(])')

# 卷
_VOL_RE = re.compile(r'Vol\.?\s*(\d+)')

# 文章号（Elsevier/Vancouver 式 `Art. No. 102877`）
_ARTNO_RE = re.compile(r'Art\.?\s*No\.?\s*([\w.\u2013\u2014\u2212-]+)', re.I)

# 出版社标记段（`Germany: Springer` / `Berlin, Germany: Springer`）
_PUBLISHER_SEG = re.compile(r'^[A-Za-z][A-Za-z.\s]*:\s*[A-Z]')

# 年份（裸 4 位）
_YEAR_RE = re.compile(r'\b(?:19|20)\d{2}\b')

_RANGE_SEG = re.compile(r'^(\d{1,7})\s*[\u2013\u2014\u2212-]\s*(\d{1,7})$')
_BARE_SEG = re.compile(r'^\d{1,7}\.?$')
_DASHES = '\u2013\u2014\u2212-'


def _last_year(src):
    """取来源段最后一个「真正的」4 位年。

    必须排除**页范围的一端**：`… Pattern Recognit., 2018, 2002–2011.` 若不排除，
    末尾的 `2011` 会被当成出版年（CVMJ-26-00445 [7] 实测 ref=2011 vs Crossref 2018）。
    判据：年份 token 的前一位或后一位若是数字或破折号，则属于范围/长数字，弃用。
    """
    best = ''
    for m in _YEAR_RE.finditer(src):
        before = src[m.start() - 1:m.start()]
        after = src[m.end():m.end() + 1]
        if before and (before.isdigit() or before in _DASHES):
            continue
        if after and (after.isdigit() or after in _DASHES):
            continue
        best = m.group(0)
    return best


def _dehyphen(t):
    """还原排版折行断字（`estima- tion` → `estimation`）。

    仅在小写字母 + 连字符 + 空白 + 小写字母时才合并，避免误伤
    `RGB- D`（大写前置）等真实连字符用法。
    """
    return re.sub(r'(?<=[a-z])-\s+(?=[a-z])', '', t)


def _first_sentence(rest):
    """取 rest 的第一句作为标题，避开缩写点、并跳过续行的小写起首。

    例外：句点后若紧跟来源前缀（`in:` / `in Proc.`），说明标题已结束，
    不能因「下一词小写」而跳过——否则标题会吞掉整条来源段
    （Bemporad, A.; Morari, M.. Robust model predictive control: A survey.
      in Robustness in Identification and Control. … 实测）。
    """
    for m in _SENT_END.finditer(rest):
        end = m.start()
        words = re.findall(r'[A-Za-z]+', rest[:end])
        word = words[-1].lower() if words else ''
        if word in _ABBREV:
            continue
        tail = rest[m.end():]
        if not re.match(r'(?i)^in\b\s*:?', tail) and tail[:1].islower():
            continue
        return rest[:end].strip(), tail.strip()
    return rest.strip(), ''


def parse_line(index, text):
    """解析单条：返回字段 dict；无法识别时带 parse_failed=True。"""
    raw = ' '.join(str(text or '').split())
    if not raw:
        return {'index': index, 'raw': '', 'parse_failed': True, 'reason': 'empty'}

    t = _dehyphen(raw).rstrip(' ')

    # ---- 1) 摘走 DOI / URL / arXiv
    doi = ''
    m = re.search(r'https?://(?:dx\.)?doi\.org/(\S+)', t)
    if m:
        doi = m.group(1).rstrip('.,;)')
        t = t[:m.start()].rstrip(' .,;')
    arxiv = ''
    m = re.search(r'arXiv\s*:?\s*(?:abs/)?(\d{4}\.\d{4,5})', t, re.I)
    if m:
        arxiv = m.group(1)
        t = (t[:m.start()] + ' ' + t[m.end():]).strip()
    t = re.sub(r'\[Online\]\.?\s*(?:Available\s*:)?[^A-Z]*', ' ', t)
    t = re.sub(r'https?://\S+', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip(' .,;')
    if not t:
        return {'index': index, 'raw': raw[:200], 'parse_failed': True,
                'reason': 'no content after DOI/URL strip'}

    # ---- 2) 作者段 / 标题段切分
    dbl = _DBL_DOT.search(t)
    quo = _IEEE_QUOTE.search(t)
    if dbl and (quo is None or dbl.start() <= quo.start()):
        authors = t[:dbl.start() + 1].strip().rstrip(',').strip()
        rest = t[dbl.start() + 2:].strip()
        quoted = False
    elif quo is not None:
        authors = t[:quo.start()].strip().rstrip(',').strip()
        rest = t[quo.start():].lstrip(', ').lstrip('\u201c"').strip()
        quoted = True
    else:
        return {'index': index, 'raw': raw[:200], 'parse_failed': True,
                'reason': 'no author/title boundary (no double period / quote)'}

    if not authors:
        return {'index': index, 'raw': raw[:200], 'parse_failed': True,
                'reason': 'no authors'}

    # ---- 3) 标题
    if quoted:
        mq = re.search(r'[\u201d"]', rest)
        if mq:
            title = rest[:mq.start()].strip().rstrip(',').strip()
            src = rest[mq.end():].strip()
        else:
            title, src = rest.strip(), ''
    else:
        title, src = _first_sentence(rest)

    if not title or len(title) < 8:
        return {'index': index, 'raw': raw[:200], 'parse_failed': True,
                'reason': 'title too short / not found'}

    # ---- 4) 来源段
    src = _SRC_PREFIX.sub('', src).strip()
    segs = [s.strip() for s in src.split(',') if s.strip()]

    # 年份：取来源段最后一个「真正的」4 位年（排除页范围端点；arXiv id 已摘除）
    year = _last_year(src)

    # 卷
    vol = ''
    vm = _VOL_RE.search(src)
    if vm:
        vol = vm.group(1)

    # 页：先 pp./p. 显式标注 → 文章号 `Art. No. N` → 纯区间段 → 裸数字（排除年份）
    page = ''
    pm = re.search(r'\bpp?\.\s*([\w.\u2013\u2014\u2212-]*\d[\w.\u2013\u2014\u2212-]*)', src)
    if pm:
        page = pm.group(1).strip().rstrip('.')
    else:
        am = _ARTNO_RE.search(src)
        if am:
            page = am.group(1).strip().rstrip('.')
        else:
            for s in segs:
                if _RANGE_SEG.match(s):
                    page = s.replace(' ', '')
                    break
            else:
                bare = [s for s in segs
                        if _BARE_SEG.match(s) and s.strip('.') != year]
                if bare:
                    page = bare[-1].strip('.')

    # 期刊名：第一个「非卷期页年月」段；若其后紧跟出版社标记段
    # （`Berlin, Germany: Springer`），把候选尾部残留的城市名截掉
    journal = ''
    for i, s in enumerate(segs):
        ss = s.strip().rstrip('.').strip()
        if not ss or ss == year:
            continue
        if _SKIP_SEG.match(ss) or _MONTH_YEAR.match(ss):
            continue
        if _RANGE_SEG.match(s.strip().rstrip('.')) or _BARE_SEG.match(s.strip()):
            continue
        if re.fullmatch(r'Vol\.?\s*\d+', ss):
            continue
        if any(_PUBLISHER_SEG.match(x.strip()) for x in segs[i + 1:]):
            cut = s.rfind('. ')
            if cut > 0:
                ss = s[:cut].strip().rstrip('.')
        journal = ss
        break

    # 预印本：把 arXiv 号保留在 journal 字段，供 ref_common.detect_preprint 识别
    if arxiv:
        journal = f'arXiv:{arxiv}'

    return {
        'index': index,
        'authors': authors,
        'title': title,
        'journal': journal,
        'volume': vol,
        'page': page,
        'year': year,
        'doi': doi,
    }

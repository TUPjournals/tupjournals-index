#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""parse_refs_vancouver.py — F4：Vancouver 变体参考文献解析器（v2.18.0）

条目形如（**年份不带括号**，编号后带点）：
    [1]. Lee, S., Kang, S., Kim, Y. and Lee, H., 2025. Thermal design framework
    of heat pipe heat exchanger. Energy, 318, p.134731.

与编号式/APA 的区别：年份是裸的 `, 2025.`，parse_refs.py 与
parse_refs_apa.py 都要求 `(YYYY)`，故均不适用（EMD20260059 实测）。

CLI:  python parse_refs_vancouver.py <fulltext.txt> <out_refs.json>
输出: 纯 list JSON
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ref_common as rc  # noqa: E402


def parse_line(index, line):
    """解析单条（已剥离编号的正文）。"""
    # 年份锚定：作者后的裸年份 ", 2025." / ", 2025,"
    ym = re.search(r',\s*(\d{4})\s*[.,]', line)
    if not ym:
        # v2.18.0：预印本（SSRN / arXiv 等）条目常无年份，各策略都会解析失败，
        # 导致字段整体错乱（标题被塞进 journal）。此处按预印本模式回退解析：
        # 作者 = 首个句点前；标题 = 其后至 "Available at / SSRN / arXiv" 之前。
        is_pp, server, pid = rc.detect_preprint(line)
        if is_pp:
            m = re.match(r'^(.*?\.)\s+(.*?)$', line)
            if m:
                authors = m.group(1).strip().rstrip(', ')
                rest = m.group(2)
                cut = re.search(r'\s*(?:Available at|SSRN|arXiv)\b', rest, re.I)
                title = (rest[:cut.start()] if cut else rest).strip().rstrip('.')
                if len(title) >= 10:
                    return {'index': index, 'authors': authors, 'title': title,
                            'journal': server or '', 'volume': '', 'page': '',
                            'year': '', 'doi': ''}
        return {'index': index, 'raw': line, 'parse_failed': True, 'reason': 'no year'}

    year = ym.group(1)
    authors = line[:ym.start()].strip().rstrip(', ').strip()
    after = line[ym.end():].strip()

    # 标题：第一个 ". " 之前
    tm = re.search(r'^(.*?\.)\s+', after)
    if tm:
        title = tm.group(1).rstrip('.').strip()
        rest2 = after[tm.end():].strip()
    else:
        title, rest2 = '', after

    # 先提取 DOI 再删 URL（顺序不能反，理由同 parse_refs_noidx_apa）
    doi = rc.extract_doi(rest2)
    rest2 = rc.URL_RE.sub('', rest2).strip()

    # 期刊 卷(期), pp.页码 / 期刊 卷, p.页码 / 期刊 卷, 页码
    journal = volume = page = ''
    vm = re.match(
        r'^(.*?),\s*(\d+)(?:\((\d+)\))?,\s*(?:pp?\.\s*)?([\w\-–—]+)?\s*\.?\s*$',
        rest2)
    if vm and vm.group(1).strip():
        journal, volume = vm.group(1).strip(), vm.group(2)
        page = (vm.group(4) or '').strip()
    elif rest2:
        journal = rest2.rstrip('.').strip()

    return {'index': index, 'authors': authors, 'title': title,
            'journal': journal, 'volume': volume, 'page': page,
            'year': year, 'doi': doi}


def parse(text, entries=None):
    """解析全文 → (refs, failed)。"""
    if entries is None:
        start = rc.locate_references(text)
        if start is None:
            return [], []
        lines, _ = rc.preprocess(text[start:])
        mode = rc.detect_numbering([l for l in lines if l.strip()][:40])
        entries = rc.split_entries(lines, unnumbered=(mode == 'unnumbered'))

    refs, failed = [], []
    for idx, txt in entries:
        r = parse_line(idx, txt)
        if r.pop('parse_failed', False):
            r.setdefault('raw', txt[:200])
            failed.append(r)
        else:
            refs.append(rc.clean_ref(r))
    return refs, failed


def main():
    if len(sys.argv) < 3:
        print('usage: parse_refs_vancouver.py <fulltext.txt> <out_refs.json>',
              file=sys.stderr)
        sys.exit(1)
    try:
        text = Path(sys.argv[1]).read_text(encoding='utf-8')
    except Exception as e:
        print(json.dumps({'status': 'error', 'error': f'读取输入失败: {e}'},
                         ensure_ascii=False))
        sys.exit(1)

    refs, failed = parse(text)
    refs.sort(key=lambda r: r.get('index') or 0)
    Path(sys.argv[2]).write_text(
        json.dumps(refs, ensure_ascii=False, indent=1), encoding='utf-8')
    print(json.dumps({'refs_total': len(refs), 'parse_failed': failed},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
preflight.py — 前置输入校验

检查用户提供的论文文件和 scope 信息是否完整，返回结构化校验结果。

Usage:
    python preflight.py --paper <论文路径> [--scope-url <URL>] [--journal <期刊全名>] [--abbrev <缩写>]

Output (stdout): JSON

v2.15.0 整改：
- F-02（SSRF 防护）：--scope-url 仅允许 https；解析主机后拒绝私有/环路/链路本地/
  保留地址（10./172.16-31./192.168./127./169.254.169.254/::1 等）；allow_redirects=False
  防止外站 302 跳内网；超时保持 10/15s。
- F-06: docx XML 解析改 defusedxml（回退 xml.etree 并警告）+ zip 成员/大小上限。
- S8: docx 文本提取复用 extract_docx.extract_paras（递归覆盖 sdt/表格），
  与正式提取逻辑一致，消除 preflight 对 Mendeley/Zotero（sdt 内文献）的虚假告警。
"""

import argparse
import ipaddress
import json
import os
import re
import socket
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import journal_scopes

# Config
# 数据存 skill 目录内（可移植：基于脚本自身位置定位，不依赖用户 home）
SKILL_DIR = Path(__file__).resolve().parent.parent   # panda-ms-check/
DATA_DIR = SKILL_DIR / "assets"                      # journal scope 缓存
# v2.17.0 双层数据源：SCOPES_FILE 为用户文件（禁止进包），内置模板见 journal_scopes.TEMPLATE_FILE
SCOPES_FILE = journal_scopes.USER_FILE

REQUEST_TIMEOUT = 10   # HEAD 超时（秒）
FETCH_TIMEOUT = 15     # GET 超时（秒）


# ── helpers ────────────────────────────────────────────────────────────

def extract_text_from_file(filepath: str) -> str:
    """Extract readable text from .docx or .txt files."""
    fp = Path(filepath)
    if not fp.exists():
        return ""

    if fp.suffix.lower() == '.txt':
        return fp.read_text(encoding='utf-8', errors='ignore')

    if fp.suffix.lower() == '.docx':
        # S8: 复用 extract_docx.extract_paras（递归覆盖 sdt/表格，与正式提取一致）
        try:
            import extract_docx
            paras = extract_docx.extract_paras(fp)
            return '\n'.join(p for p in paras if p.strip())
        except Exception:
            return ""

    # Fallback: try reading as raw text
    try:
        return fp.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return ""


def check_paper_completeness(text: str) -> dict:
    """Check if the paper has author info and references."""
    has_authors = bool(re.search(r'(?i)(author|作者)', text))

    # Look for reference section markers
    ref_patterns = [
        r'(?i)\nreferences?\s*\n',
        r'(?i)\nbibliography\s*\n',
        r'(?i)\n参考文献\s*\n',
        r'(?i)^\s*\[\d+\]',
        r'(?i)^\s*\d+\.\s+[A-Z]',
    ]
    has_references = any(re.search(p, text, re.MULTILINE) for p in ref_patterns)

    return {
        "has_authors": has_authors,
        "has_references": has_references
    }


def load_journal_scopes() -> list:
    """Load journal scopes (v2.17.0: 模板 ∪ 用户 合并，用户优先)。"""
    return journal_scopes.load_all()


def save_journal_scope(full_name: str, abbreviation: str, scope_url: str, scope_text: str):
    """Save a new journal scope record（v2.17.0: 只写用户文件）。"""
    journal_scopes.save_scope(full_name, abbreviation, scope_url, scope_text)


def lookup_journal_by_name(journals: list, name: str) -> dict | None:
    """Look up a journal by full name or abbreviation."""
    name_lower = name.lower().strip()
    for j in journals:
        if name_lower == j["full_name"].lower():
            return j
        if j.get("abbreviation") and name_lower == j["abbreviation"].lower():
            return j
    return None


# ── SSRF 防护（F-02, v2.15.0）────────────────────────────────────────────

def _is_blocked_ip(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return True   # 无法解析的地址一律拒绝
    return (a.is_private or a.is_loopback or a.is_link_local
            or a.is_reserved or a.is_multicast or a.is_unspecified)


def validate_scope_url(url: str) -> tuple[bool, str]:
    """校验 scope URL 是否允许请求：仅 https + 非私有/环路/链路本地地址。

    返回 (ok, reason)。不通过时调用方不得发起网络请求。
    """
    if not url:
        return (False, 'URL 为空')
    try:
        p = urlparse(url)
    except ValueError:
        return (False, 'URL 解析失败')
    if p.scheme != 'https':
        return (False, '仅允许 https 协议')
    host = (p.hostname or '').lower()
    if not host:
        return (False, '缺少主机名')
    if host == 'localhost' or host.endswith('.local'):
        return (False, f'拒绝本地/保留域名: {host}')
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return (False, f'主机名解析失败: {host}')
    for info in infos:
        ip = info[4][0]
        if _is_blocked_ip(ip):
            return (False, f'拒绝私有/环路/链路本地地址: {ip}')
    return (True, '')


def verify_scope_url(url: str) -> bool:
    """Verify if a scope URL is accessible（SSRF 防护后 allow_redirects=False）。"""
    ok, reason = validate_scope_url(url)
    if not ok:
        return False
    try:
        import requests
        resp = requests.head(url, timeout=REQUEST_TIMEOUT, allow_redirects=False,
                             headers={"User-Agent": "panda-ms-check/2.16.0"})
        return resp.status_code < 400
    except Exception:
        return False


def fetch_scope_text_from_url(url: str) -> str:
    """Fetch scope description from a URL (basic extraction；SSRF 防护后 allow_redirects=False)."""
    ok, reason = validate_scope_url(url)
    if not ok:
        return ""
    try:
        import requests
        resp = requests.get(url, timeout=FETCH_TIMEOUT, allow_redirects=False,
                            headers={"User-Agent": "panda-ms-check/2.16.0"})
        resp.raise_for_status()
        # Strip HTML tags
        text = re.sub(r'<[^>]+>', ' ', resp.text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text[:5000]  # Limit to first 5000 chars
    except Exception:
        return ""


def is_first_run(journals: list) -> bool:
    """Check if this is the first run (no journal records)."""
    return len(journals) == 0


# ── main ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Preflight check for integrity-check skill")
    parser.add_argument("--paper", required=True, help="Path to the manuscript file")
    parser.add_argument("--scope-url", default=None, help="URL to journal aims & scope")
    parser.add_argument("--journal", default=None, help="Full journal name")
    parser.add_argument("--abbrev", default=None, help="Journal abbreviation")
    args = parser.parse_args()

    result = {
        "status": "ok",
        "paper": {},
        "scope": {
            "source": "none",
            "url": None,
            "text": None,
            "valid": False
        },
        "actions_required": [],
        "is_first_run": False
    }

    # 1. Check paper completeness
    paper_text = extract_text_from_file(args.paper)
    if not paper_text:
        result["paper"] = {"has_authors": False, "has_references": False, "error": "Cannot extract text from file"}
        result["status"] = "incomplete"
        result["actions_required"].append("Cannot read manuscript file. Please provide a valid .docx or .txt file.")
    else:
        result["paper"] = check_paper_completeness(paper_text)

    # 2. Check scope information
    journals = load_journal_scopes()
    result["is_first_run"] = is_first_run(journals)

    # Priority: URL > journal name lookup > none
    if args.scope_url:
        result["scope"]["source"] = "url"
        result["scope"]["url"] = args.scope_url
        ok, reason = validate_scope_url(args.scope_url)
        if not ok:
            # F-02: SSRF 防护拒绝 → 不发起任何请求
            result["scope"]["valid"] = False
            result["actions_required"].append(f"Scope URL 被安全策略拒绝（{reason}）：{args.scope_url}")
        else:
            result["scope"]["valid"] = verify_scope_url(args.scope_url)
            if result["scope"]["valid"]:
                result["scope"]["text"] = fetch_scope_text_from_url(args.scope_url)
            else:
                result["actions_required"].append(f"Scope URL is not accessible: {args.scope_url}")

    elif args.journal or args.abbrev:
        result["scope"]["source"] = "journal_lookup"
        lookup = args.journal or args.abbrev
        match = lookup_journal_by_name(journals, lookup)
        if match:
            result["scope"]["url"] = match.get("scope_url")
            result["scope"]["text"] = match.get("scope_text")
            result["scope"]["valid"] = True
            # If URL exists, try to refresh text（同样过 SSRF 防护）
            if match.get("scope_url") and not match.get("scope_text"):
                ok, reason = validate_scope_url(match["scope_url"])
                if ok:
                    result["scope"]["text"] = fetch_scope_text_from_url(match["scope_url"])
        else:
            result["scope"]["valid"] = False
            result["actions_required"].append(
                f"Journal '{lookup}' not found in local records. "
                "Please provide aims & scope URL or document."
            )
    else:
        result["scope"]["source"] = "none"
        result["actions_required"].append(
            "No aims & scope information provided. "
            "Please provide a URL to the journal's aims & scope page, or the journal name."
        )

    # 3. Check paper completeness and add actions
    if not result["paper"].get("has_authors"):
        result["actions_required"].append(
            "No author information detected in the manuscript. "
            "Would you like to proceed with available content only?"
        )
    if not result["paper"].get("has_references"):
        result["actions_required"].append(
            "No reference list detected in the manuscript. "
            "Would you like to proceed with available content only?"
        )

    # 4. Final status
    if result["scope"]["valid"]:
        # Scope is valid; paper issues are non-blocking after user confirmation
        if result["actions_required"]:
            result["status"] = "incomplete"
    else:
        result["status"] = "incomplete"

    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

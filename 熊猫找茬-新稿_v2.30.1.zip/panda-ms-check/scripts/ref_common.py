#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ref_common.py — 参考文献解析公共库（v2.18.0）

集中提供各解析器共用的能力，避免四份临时脚本各写一遍：
  1. References 节定位（容错 PDF 页码前缀）
  2. PDF 页码水印的**稳健识别**（三重判定，不误删行首数字）
  3. 条目切分（支持 [1] / (1) / 1. / 1) / 1  及无编号）
  4. 统一字段清洗（DOI、URL、期刊名残留、标题混入作者）
  5. 预印本识别（arXiv / bioRxiv / medRxiv / SSRN / ChemRxiv / Research Square）

约定：本模块只做"切分与清洗"，不做字段抽取；
      字段抽取由各策略解析器（parse_refs*.py）完成。
"""

import re

# ---------------------------------------------------------------- 常量

# 条目起始编号：[1] / (1) / 1. / 1) / 1␣␣
ENTRY_NUM_RE = re.compile(
    r'^\s*(?:\[(\d+)\]|\((\d+)\)|(\d+)\s*[.\)]|(\d+)\s{2,})\s*\.?\s*'
)

# References 节标题（允许前导 PDF 页码数字，如 "543 References"；
# 允许尾随冒号/句点/分号，如 "References:"——EMD20260068 实测该写法此前不匹配）
REF_HEADING_RE = re.compile(
    r'(?im)^\s*(?:\d{1,4}\s+)?(references?|bibliography)\s*[:.;]?\s*$')

# 行首页码数字
LINE_PAGE_NUM_RE = re.compile(r'^(\d{1,4})\s+(?=\S)')

# 纯数字行（仅由 1–2 个整数构成）：行号独占一列时被 pdfplumber 提取为独立行，
# 页码独占一行时亦然（"65 30" = 行号 65 + 页码 30）
NUM_ONLY_LINE_RE = re.compile(r'^(\d{1,4})(?:\s+\d{1,4})?$')

# 分页标记（PDF 提取时插入）
PAGE_BREAK_TOKEN = '===PAGE BREAK==='

# 分页标记（实际提取器输出形态）：`===== PAGE 12 =====`
# ⚠️ 与 PAGE_BREAK_TOKEN 不一致曾导致标记泄漏进文献字段（BUIL-D-25-00483 实测：
#    [67] 的 journal 尾部挂上 "===== PAGE 40 ====="），故两种形态都要剥。
PAGE_MARKER_RE = re.compile(r'^\s*={2,}\s*PAGE\s+\d+\s*={2,}\s*$', re.I)

# 页脚/页眉行（期刊排版：`Civil Engineering Sciences Manuscript Template Page 20 of 22`）
# ⚠️ CESCI-S-26-00047 实测：该稿每页页脚重复出现 22 次，且**未被任何既有规则剥离**，
#    直接混入文献条目——`[7]` 的期刊字段被塞进 "Civil Engineering Sciences Manuscript
#    Template Page 20 of"，年份/卷尾锚定随之失配（`numbered` 策略仅得 0.14 分、22/37
#    条报 `no year;volume tail`，且错误策略 `noidx_vancouver` 以 0.4 分被选中）。
# 判据一律要求「Page\s+\d+\s+of」这种**强结构**，并配合「同一形态重复 ≥3 次」的
# 频次判据（见 strip_running_headers），避免误删正文里偶然出现的类似短语。
RUNNING_HEADER_RE = re.compile(
    r'^\s*(?:[A-Za-z][\w .,&:\-]{0,80}?)?\s*Page\s+\d{1,4}\s*(?:of|/)\s*\d{0,4}\s*$', re.I)
# 期刊模板页脚常见形态：含以下关键词且带 Page N of M
JOURNAL_FOOTER_HINT_RE = re.compile(
    r'(Manuscript\s+Template|Manuscript\s+Draft|Running\s+head|Preprint|Page\s+\d+\s+of)',
    re.I)

# DOI：实战验证，简单形式比"匹配 https://doi.org/ 前缀"更可靠
DOI_FIND_RE = re.compile(r'10\.\d{4,9}/\S+')

# URL
URL_RE = re.compile(r'https?://\S+')

# 作者起始（无编号模式下判定新条目）："Nguyen, L. T." / "Müller, M." / "Xu, W."
# 姓允许含句点+空格（实测 "Kultz. unti, L. F." 这类带小数点的复姓）
AUTHOR_START_RE = re.compile(
    r"^[A-Z\u00C0-\u024F][A-Za-z\u00C0-\u024F'\-]*"
    r"(?:\.?\s+[A-Za-z\u00C0-\u024F'\-]+)*"
    r",\s+[A-Z]\."
)

# "名 姓. et al" 起始（实测 "Qing Ai. et al. ,Strong and brittle..."）
ETAL_START_RE = re.compile(
    r"^[A-Z][A-Za-z\u00C0-\u024F'\-]+"
    r"(?:\s+[A-Z][A-Za-z\u00C0-\u024F'\-]*\.?)*"
    r"\s+et\s+al", re.I)

# 文献区终止标记：出现即认为参考文献列表结束（防补充材料的图注/表注被吞入）
SECTION_STOP_RE = re.compile(
    r'^(?:\[TABLE\]|\[/TABLE\]|'
    r'electronic\s+supplementary|supplementary\s+(?:material|information)|'
    r'figures?\s*$|tables?\s*$|figure\s+s?\d|table\s+s?\d|'
    r'acknowledg\w*|author\s+biograph\w*|appendix|graphical\s+abstract)', re.I)

# 裸年份（Vancouver：", 2025."）
BARE_YEAR_RE = re.compile(r',\s*((?:19|20)\d{2})\s*[.,]')

# 括号年份（APA / Nature）
PAREN_YEAR_RE = re.compile(r'\((\d{4})\)')

# 预印本特征： (名称, 正则, 是否高置信)
PREPRINT_PATTERNS = [
    ('arXiv', re.compile(r'arXiv:\s*(\d{4}\.\d{4,5})', re.I), True),
    ('arXiv', re.compile(r'arxiv\.org/abs/(\d{4}\.\d{4,5})', re.I), True),
    ('bioRxiv/medRxiv', re.compile(r'10\.1101/\S+', re.I), True),
    ('SSRN', re.compile(r'10\.2139/ssrn\.?\S*', re.I), True),
    # "Available at SSRN 5576534"（无 DOI，仅有编号）形式
    ('SSRN', re.compile(r'\bSSRN[:\s]+(\d{4,})', re.I), True),
    ('SSRN', re.compile(r'ssrn\.com/abstract=?(\d+)', re.I), True),
    # 兜底：解析后 journal 字段可能只剩平台名（如 "SSRN"）
    ('SSRN', re.compile(r'\bSSRN\b', re.I), True),
    ('ChemRxiv', re.compile(r'10\.26434/chemrxiv\S*', re.I), True),
    ('Research Square', re.compile(r'researchsquare', re.I), True),
    ('bioRxiv/medRxiv', re.compile(r'www\.(?:bio|med)rxiv\.org', re.I), True),
]


# ---------------------------------------------------------------- 1. 定位 References

def _looks_like_ref_start(s):
    """判定一个「编号行」是否像参考文献条目起点（而非正文节标题）。

    【v2.26.1 新增】用于 locate_references 的兜底分支。许多投稿（尤其 Elsevier /
    Mendeley 导出的稿件）**根本不写 "References" 标题**，正文声明段之后直接以
    `1.Kim, H.S., …, Journal, 2011. 12(6): p. 1129-1141.` 起列表。此时兜底若只认
    「首个编号行」，会命中正文一级节标题 `1. Introduction`（EMD20260076 实测）→
    从正文开头切区 → 条目数 0，并报出**阶段不符**的误导错误 "no reference entries
    found"（看着像"格式不支持"，实为定位错）。v2.20.1 只补了 `x.y` 小节号的跳过，
    漏掉了一级节标题，本条补全。

    判据（去编号后满足其一即可）：
      ① 含 4 位年份（绝大多数文献条目都有出版年）；
      ② 含 DOI 或 URL；
      ③ 以「姓, 名缩写」作者式开头（`Kim, H.S., …` / `Xu, T.-B., …`）。
    正文节标题（`Introduction` / `Experiment setup` / `CONCLUSION`）三者皆不满足。
    """
    body = ENTRY_NUM_RE.sub('', s, count=1).strip()
    if not body:
        return False
    if re.search(r'\b(?:19|20)\d{2}\b', body):
        return True
    if DOI_FIND_RE.search(body) or URL_RE.search(body):
        return True
    return bool(AUTHOR_START_RE.match(body))


def locate_references(text):
    """返回 References 正文起始字符位置；未找到返回 None。"""
    if not text:
        return None
    m = REF_HEADING_RE.search(text)
    if m:
        return m.end()
    # 回退：首个「像文献条目」的编号行（[n] 或 1. 形式）
    # 注意：必须排除章节号与节标题——否则正文里的第一个节标题会被当成文献区
    # 起点，从此处切出的"文献区"其实是全文，条目数为 0：
    #  · "2.1. The experimental components:"（小节号）— EMD20260068 实测
    #  · "1. Introduction"（一级节标题，稿件无 References 标题时）— EMD20260076 实测
    for ln in text.split('\n'):
        s = ln.strip()
        if re.match(r'^\d+\.\d', s):
            continue
        if ENTRY_NUM_RE.match(s) and _looks_like_ref_start(s):
            return text.find(ln)
    return None


# ---------------------------------------------------------------- 2. 页码水印识别

def detect_page_numbers(lines, n=40):
    """稳健判定行首数字是否为 PDF 页码水印。

    三重判定全部通过才认为是页码：
      ① 覆盖率 ≥ 60%（多数行都带数字）
      ② 相邻差 0 ≤ d ≤ 2（单调非减、步长合理）
      ③ 首个数字在 1–2000 之间
    目的：避免误删以数字开头的真实内容（如 "2020. Title..."）。
    """
    sample = lines[:n] or lines
    if not sample:
        return False
    hits = []
    for ln in sample:
        s = ln.strip()
        if not s:
            continue
        m = LINE_PAGE_NUM_RE.match(s)
        hits.append(int(m.group(1)) if m else None)

    got = [h for h in hits if h is not None]
    if not got or len(got) < 0.6 * len(hits):
        return False
    if not (1 <= got[0] <= 2000):
        return False
    diffs = [b - a for a, b in zip(got, got[1:])]
    if not all(0 <= d <= 2 for d in diffs):
        return False
    return True


def strip_line_number(line, enabled):
    """按开关剥离行首页码/行号；剥离后若为空则回退原文。"""
    if not enabled:
        return line
    s = LINE_PAGE_NUM_RE.sub('', line, count=1)
    return s if s.strip() else line


def _ln_stats(vals, min_inc=5, inc_ratio=0.8, drop=5):
    """判定一个整数序列是否具备「每页重新计数」的进退特征。"""
    if len(vals) < min_inc:
        return False
    diffs = [b - a for a, b in zip(vals, vals[1:])]
    inc = [d for d in diffs if d > 0]
    if len(inc) < min_inc or sum(1 for d in inc if d <= 3) < inc_ratio * len(inc):
        return False
    # 必须出现一次大幅回落（行号每页从 1 重起 / 页码换页后跳回）
    return any(d <= -drop for d in diffs)


def detect_line_numbering(lines, min_hits=10, ratio=0.25):
    """判定是否存在「逐行行号」水印（Word 行号 / 每行带行号的 PDF）。

    与页码水印（每页 1 个数字）不同，行号列的整数是**逐行推进、跨页回落**的。
    pdfplumber 对行号的提取有**两种排版**，同一份稿件可能任选其一：

      A. **独立成行**（行号与正文分属两列）——行号被提取成独立一行（"3"）；
      B. **内联前缀**（行号与正文同处一列、紧贴文字）——提取为 "26 [1] Zhang, ..."。

    判据设计（两条路径任一命中即判为行号水印）：

      路径 A（独立成行）：纯数字行 ≥ min_hits 且占非空行 ≥ ratio，且具备进退特征。
        BUIL-D-25-00483 实测：476 非空行中 308 行（65%）为纯数字行 → 命中。

      路径 B（内联前缀）：数字前缀行占非空行 ≥ 0.5，且这些前缀数具备进退特征
        （**跨页回落 ≥5 是必要条件**）。
        CESCI-S-26-00047 实测：1087 非空行中 **700 行（64.4%）带数字前缀**，
        而纯数字行仅 91（8.4%）→ 路径 A 失配、路径 B 命中。
        该稿参考文献区 37 条因行号残留而**一条都切不出来**（报
        "no reference entries found"，且 parse_failed 为空、9 策略全 0 分），
        剥掉行首行号后 37/37 正常解析。

    ⚠️ **反向保护（不可省）**：路径 B 的「跨页回落」是必需的排除条件——
    真实编号式文献表（`[1] … [2] … [37]`）的前缀数**单调递增、无回落**，
    故不会被误判为行号水印而遭误剥（否则 `[1]` 会被当行号删掉，parse_failed
    反而暴增）。判据改动必须回归编号式稿件（含 200+ 条的长文献表）。
    """
    nonempty = [l.strip() for l in (lines or []) if l and l.strip()]
    if len(nonempty) < min_hits * 2:
        return False

    # ---- 路径 A：行号独占一行 ----
    vals_only = []
    for s in nonempty:
        m = NUM_ONLY_LINE_RE.match(s)
        if m:
            vals_only.append(int(m.group(1)))
    if len(vals_only) >= min_hits and len(vals_only) >= ratio * len(nonempty):
        if _ln_stats(vals_only):
            return True

    # ---- 路径 B：行号内联为文本前缀 ----
    #   形如 "26 [1] Zhang, ..." / "4" 之外的长行带前导数字。
    #   注意：必须排除「[1] 开头的条目行」自身（它不以裸数字开头，不受影响）。
    vals_pref = []
    for s in nonempty:
        m = LINE_PAGE_NUM_RE.match(s)
        if m:
            vals_pref.append(int(m.group(1)))
    if len(vals_pref) >= min_hits and len(vals_pref) >= 0.5 * len(nonempty):
        if _ln_stats(vals_pref):
            return True

    return False


def strip_running_headers(lines, min_repeat=3):
    """剥离**重复出现**的页脚/页眉行（期刊模板页脚）。

    判据取「强结构 + 重复」双重条件，宁可漏删不可误删：

      ① 行形如 `... Page N of M`（`RUNNING_HEADER_RE` 命中，N/M 为数字）；
         或行内含期刊页脚关键词（Manuscript Template / Manuscript Draft /
         Running head / Preprint）**且**含 `Page N` 结构。
      ② 该行去掉页码数字后的**形态签名**在全文中重复出现 ≥ min_repeat 次
         （把 `Page 20 of 22` → `Page # of #` 归一化后比较）。

    第 ② 条是关键：正文小节里偶然出现一句 "as shown on Page 3 of 5" 只会命中 1 次，
    不会被误删；而真正的页脚每页一次，必然重复。

    CESCI-S-26-00047 实测：`Civil Engineering Sciences Manuscript Template Page N of 22`
    重复 22 次（每页 1 次），泄漏进 `[7]`/`[8]` 等条目后使 `numbered` 策略得分
    由修复后的高分骤降到 0.14。剥离后条目字段恢复干净。
    """
    def sig(s):
        return re.sub(r'\d+', '#', s.strip())

    counts = {}
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        if RUNNING_HEADER_RE.match(s) or (
                JOURNAL_FOOTER_HINT_RE.search(s) and re.search(r'Page\s+\d+', s, re.I)):
            counts[sig(s)] = counts.get(sig(s), 0) + 1

    repeated = {k for k, v in counts.items() if v >= min_repeat}
    if not repeated:
        return lines

    out = []
    for ln in lines:
        s = ln.strip()
        if s and (RUNNING_HEADER_RE.match(s) or (
                JOURNAL_FOOTER_HINT_RE.search(s) and re.search(r'Page\s+\d+', s, re.I))) \
                and sig(s) in repeated:
            continue   # 该行是重复页脚/页眉，整行丢弃
        out.append(ln)
    return out


def preprocess(text, lines=None):
    """文本预处理：去分页标记 → 去重复页脚/页眉 → 判定并剥离「行首数字水印」。

    返回 (清洗后的行列表, 是否检测到数字水印)
    """
    if not text:
        return [], False
    text = text.replace(PAGE_BREAK_TOKEN, '\n')
    raw_lines = [ln.rstrip() for ln in text.split('\n')]
    # 去分页标记行（`===== PAGE 12 =====`）——不剥会挂进文献字段尾部
    raw_lines = [ln for ln in raw_lines if not PAGE_MARKER_RE.match(ln.strip())]
    # 去重复页脚/页眉（`… Manuscript Template Page 20 of 22`）——同理会挂进字段
    raw_lines = strip_running_headers(raw_lines)

    # ① 逐行行号（Word 行号 / 每行带行号的 PDF）：先删纯数字行，再剥行首前缀。
    #    必须先删纯数字行——否则 detect_page_numbers 的覆盖率判据看不到它们。
    if detect_line_numbering(raw_lines):
        kept = [ln for ln in raw_lines if not NUM_ONLY_LINE_RE.match(ln.strip())]
        return [strip_line_number(ln, True) for ln in kept], True

    # ② 页码水印（每页 1 个，与正文同行）
    has_pn = detect_page_numbers(raw_lines)
    cleaned = [strip_line_number(ln, has_pn) for ln in raw_lines]
    return cleaned, has_pn


# ---------------------------------------------------------------- 3. 条目切分

# 折行续段以「期号」开头：ACS 条目跨行时卷号「11」留在上行，期号「(48)」落到
# 下一行行首（`(48), 2103005. DOI: …`）。该形态会被 ENTRY_NUM_RE 命中并被
# `_is_new_entry` 的「小幅跳跃 ≤3」放行 → 第 46、47 条被并进这条伪条目、
# 真实条目数由 48 掉到 46（EMD20260084 实测）。判据：`(数字)` 后紧接**逗号**——
# 文献条目起点绝不会是 `(n),`，故可安全判为续段。
ISSUE_CONT_RE = re.compile(r'^\(\s*\d{1,4}\s*\)\s*,')


def _entry_index(line):
    """提取行首编号；无编号返回 None。"""
    m = ENTRY_NUM_RE.match(line)
    if not m:
        return None
    for g in m.groups():
        if g:
            return int(g)
    return None


def _is_new_entry(idx, last_idx, s):
    """判定行首编号是否真为新条目起点。

    加连续性校验的原因：Vancouver/编号式文献跨页时，续行可能以
    "2023). Numerical analysis..." 开头，其 "2023)" 会被编号正则捕获，
    导致年份被误当成条目编号（EMD20260059 实测 index=2023）。
    """
    if idx is None:
        return False
    if ISSUE_CONT_RE.match(s):        # 期号续段 `(48), 2103005.` → 非新条目
        return False
    if last_idx is None:
        return idx <= 5 or bool(AUTHOR_START_RE.match(s) or ETAL_START_RE.match(s))
    if 0 < idx - last_idx <= 3:      # 连续或小幅跳跃
        return True
    # 跳跃较大：仅在内容明显是文献开头时才接受（防年份被误判为编号）
    return bool(AUTHOR_START_RE.match(s) or ETAL_START_RE.match(s))


# 折行 DOI 粘连（v2.27.1）：PDF 提取的条目在 DOI 内部的连字符处换行时，续行以
# **空格**拼接，DOI 被切成 `10.1007/s11269-025- 04254-y.` → `extract_doi` 只取到
# `…-025-`，残余片段 `04254-y.` 留在条目尾部，令所有「年份在行尾」的尾锚定正则
# （ieee / rsc / numbered_year 等）失配 → **year 为空 + DOI 截断**，且
# parse_failed 为空（静默失败）。CESCI-S-26-00053 实测 44 条中 11 条命中。
# 判据窄化为「行尾是 DOI 且以连字符结尾」，不触碰普通断词折行（`down-` / `scaling`）。
_WRAP_DOI_TAIL_RE = re.compile(
    r'10\.\d{4,9}/\S*[-\u2010\u2011\u2012\u2013\u2014]\s*$')


def _join_continuation(cur, nxt):
    """拼接续行：DOI 内部折行时不加空格，其余情况保持「空格拼接」原语义。"""
    if _WRAP_DOI_TAIL_RE.search(cur):
        return cur + nxt
    return cur + ' ' + nxt


def split_entries(lines, unnumbered=False):
    """将行列表切分为条目，返回 [(index, text), ...]。

    unnumbered=False：以编号行为新条目起点，index 取编号（带连续性校验）。
    unnumbered=True ：以"作者起始"行为新条目起点，index 按出现顺序从 1 递增。
    其余行一律作为上一条的续行拼接（解决跨行条目被丢弃的问题）。
    """
    entries = []
    cur_idx, cur_txt = None, None
    counter = 0

    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        # 补充材料/图表注等区块开始 → 文献区结束，停止收集
        # （否则整段图注表注会被当作末条文献的续行吞入）
        if SECTION_STOP_RE.match(s):
            break

        idx = None
        if unnumbered:
            if AUTHOR_START_RE.match(s) or ETAL_START_RE.match(s):
                counter += 1
                idx = counter
        else:
            raw_idx = _entry_index(s)
            if _is_new_entry(raw_idx, cur_idx, s):
                idx = raw_idx

        if idx is not None:
            if cur_idx is not None and cur_txt:
                entries.append((cur_idx, cur_txt))
            cur_idx = idx
            cur_txt = s if unnumbered else ENTRY_NUM_RE.sub('', s, count=1).strip()
        else:
            if cur_txt is not None:
                cur_txt = _join_continuation(cur_txt, s)
            # 尚未开始第一条之前的噪音行，忽略

    if cur_idx is not None and cur_txt:
        entries.append((cur_idx, cur_txt))
    return entries


# ---------------------------------------------------------------- 3b. NLM/Vancouver 无编号切分（fallback）

# NLM/Vancouver 无编号条目行尾锚点：年;卷(:页)，如 "2025;76:107371." / "2022;45."
NLM_YEAR_VOL_RE = re.compile(r'\d{4}\s*;')

# 西欧姓氏冠词前缀（de Oliveira / van der Berg / dos Santos …），首 token 可小写
_NLM_NAME_PREFIXES = frozenset(
    'de di van der den la le von da dos du el al bin abu st'.split())


def _is_nlm_start(s):
    """判定行是否为无编号 NLM/Vancouver 条目起点行（v2.18.1 / v2.20.1 扩展）。

    条件 ① 首 token 形似姓氏（大写词 或 小写西欧冠词前缀）；
    且满足 ② 或 ③：
      ② 行内含 年;卷 锚点（`2025;76:107371` / `2022;45.`）；
      ③ 行内含 4 位年份，且另有 `et al` 或 DOI/URL——用于**混排列表**
        （大多条目为 NLM 式、少量条目为"作者, ..., et al., 标题. 期刊 年, 卷, 页"
         式，且年卷间用逗号/冒号而非分号）。
         EMD20260068 实测：33 条文献中 4 条为后者，仅靠 ② 会少切 4 条
         （被并进上一条），条目数由 33 掉到 29。
    续行（标题/期刊折行）通常不满足 ②/③：折行若以数字开头则 nameish 已为假。
    """
    if not s:
        return False
    first = s.split(None, 1)[0].rstrip('.').strip()
    if not first:
        return False
    if not (first[0].isupper() or first.lower() in _NLM_NAME_PREFIXES):
        return False
    if NLM_YEAR_VOL_RE.search(s):
        return True
    if not re.search(r'\b(?:19|20)\d{2}\b', s):
        return False
    if re.search(r'\bet\s+al\b', s, re.I):
        return True
    return bool(DOI_FIND_RE.search(s) or URL_RE.search(s))


def split_entries_nlm(lines):
    """无编号 NLM/Vancouver 条目切分（仅常规作者起始正则 0 命中时 fallback）。

    以「首词形似姓氏 + 行内含 年;卷」双重条件判定新条目，其余行并入上一条。
    典型格式（CESCI-D-26-00016R1 实测，54/54 全命中）：
        Reddy R, Adamu M, ... Title. Journal. 2025;76:107371.
    """
    entries = []
    cur_idx, cur_txt = 0, None
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        if SECTION_STOP_RE.match(s):
            break
        if _is_nlm_start(s):
            cur_idx += 1
            if cur_txt is not None:
                entries.append((cur_idx - 1, cur_txt))
            cur_txt = s
        else:
            if cur_txt is not None:
                cur_txt = _join_continuation(cur_txt, s)
    if cur_txt is not None:
        entries.append((cur_idx, cur_txt))
    return entries


# 方括号编号（`[1]`）：在参考文献区语义唯一，可直接作为「编号式」的强证据
BRACKET_NUM_RE = re.compile(r'^\s*\[\d{1,4}\]')


def detect_numbering(entries_sample):
    """判定编号模式：返回 'numbered' 或 'unnumbered'。

    规则：
      ① 采样中**方括号编号行**（`[n]`）≥3 → 判定为编号式（强证据，不受折行影响）；
      ② 其余（裸 `1.` / `1)` / `1␣␣`）沿用「行首编号命中率 ≥30%」判据——这类
         编号与年份、章节号易混，放宽会带来反向误判。

    ① 的由来（CVMJ-26-00445 实测，第五类静默失败：编号识别失败 → 满分假象）：
    原判据只看**行**命中率，而窄栏 PDF（双栏期刊、页宽 612pt）中一条文献常折行
    4–6 行 → 前 40 行里条目起始行只有 9 行（22.5% < 30%）→ 被误判为「无编号」
    → `split_entries(unnumbered=True)` 把整篇文献区切成 9 大块串行文本 → 11 种
    策略在这批垃圾上打分，`rsc` 反而得 1.0 → 产出「条目数 9 条（实际 89 条）+
    字段串行错位 + parse_failed 为空」的假成功。
    方括号编号在参考文献区不会出现在折行续行行首（正文的 `[12]` 也不会单独成行），
    故可脱离折行统计，用绝对条数判定。
    """
    if not entries_sample:
        return 'unnumbered'
    strong = sum(1 for ln in entries_sample if BRACKET_NUM_RE.match(ln.strip()))
    if strong >= 3:
        return 'numbered'
    hit = sum(1 for ln in entries_sample if _entry_index(ln.strip()) is not None)
    return 'numbered' if hit >= 0.3 * len(entries_sample) else 'unnumbered'


# ---------------------------------------------------------------- 4. 统一清洗

def extract_doi(text):
    """提取 DOI（取首个匹配，剥离尾部标点）。"""
    m = DOI_FIND_RE.search(text or '')
    if not m:
        return ''
    return m.group(0).rstrip('.,;)]}')


def clean_journal(journal):
    """期刊名清洗：去 In 前缀、卷/期/页残留、出版社地点、URL、DOI 残留。

    v2.18.0：尾部「卷(期) / 页」可能有多段（如 "Heat Transfer Engineering,
    45(20-21), pp.1836-1853"），需**迭代剥离**直到不再变化。

    v2.21.0（关键）：**必须先归一化尾部标点，再跑尾锚定剥离正则**。
    尾随的 "." / "," 会让所有「, 卷」「, 期」「, 页」尾锚定正则失配——
    BUIL-D-25-00483 实测：raw journal 为 "Atmosphere, 14(10), 1570.
    https://www.mdpi.com/…"，先剥 URL 后剩 "…, 1570."，", 1570" 因此永远剥不掉；
    "Sustainability, 16(14),"（尾逗号）同理。后果是 70 条文献里 **55 条**被
    Crossref 以 `journal_mismatch` 报出（strict 刊名核对必然失败），
    制造"整篇文献刊名著录错误"的假象——与 v2.18.2 修的同类假警同源。
    """
    j = (journal or '').strip()
    if not j:
        return ''
    # ① 尾部标点归一化（必须在尾锚定剥离之前，见 docstring）
    j = j.rstrip('.,;:').strip()
    j = re.sub(r'^In\s+', '', j)                              # In Proceedings of...
    # ①b 「卷期缺失」占位符（v2.30.1）：Elsevier 在线优先条目写作
    #     "Advanced Materials Interfaces n/a(n/a) (2025) e00705" / "… n/a(n/a)  e5372994"，
    #     占位符会滞留在 journal 尾部（volume 字段被判空）→ Crossref strict 刊名核对失败 →
    #     `journal_mismatch` 假警（EMD20260096 [48][129] 实测）。只认含斜杠的占位形式
    #     （n/a、n.a. 的斜杠写法），避免误删真实刊名末词（如 "… na"）。
    j = re.sub(r'\s+n\s*/\s*a(?:\s*\(\s*n\s*/\s*a\s*\))?$', '', j, flags=re.I).strip()
    # ② URL 及其后的孤儿残片：从首个 http(s):// 起整段丢弃（刊名不含 http，安全）。
    #    原实现用 `https?://\S*$` 要求 URL 顶到行尾，DOI 被换行截断时
    #    "https://doi.org/ env.2023.111079" 这种"URL + 空格 + 残片"就漏网了。
    j = re.sub(r'\s*https?://.*$', '', j)
    j = DOI_FIND_RE.sub('', j)                                # DOI 残留
    j = j.rstrip('.,;:').strip()

    # ③ 书目尾巴截断（v2.21.0）：期刊名之后一旦出现下面任一形态，即从此处截断。
    #    真实刊名极少含「, 数字」（逗号后必为词），更不会含 "pp." / "DOI" 标注。
    #    BUIL-D-25-00483 实测未处理时残留："Behavior Research Methods, 39(2),
    #    175 – 191"（带空格的页码范围）、"Applied Energy, 88(12), 4358 – 4365.
    #    DOI: ergy.2011.05.014"（DOI 被换行截断后 `doi: 10.` 正则也失配）、
    #    "Thermal and Moisture Transport in Fibrous Materials (pp. 560–602).
    #    Woodhead Publishing"，均导致 Crossref strict 刊名核对失败 →
    #    journal_mismatch 假警（本案 8 条）。
    j = re.split(
        r'(?<=\S)\s*,\s*(?=\d)'      # , 39(2) / , 128 / , 2023
        r'|\s*\(\s*pp?\.\s*'         # (pp. 560–602)
        r'|\s*DOI\b|\s*doi:\s'       # . DOI: / , DOI
        r'|\s*\[[JMDCNR]\]\s*$',     # 尾部文献类型标识残留
        j, maxsplit=1, flags=re.I)[0].strip().rstrip('.,;:').strip()

    # 出版社名尾随（"Comprehensive Physiology. Wiley" → "Comprehensive Physiology"；
    # 允许前置 "城市: "，如 "Information Retrieval for Music and Motion. Berlin: Springer"）
    j = re.sub(
        r'[.,;:]\s*(?:[A-Z][a-z]+(?:[\s\-][A-Z][a-z]+){0,2}:\s*)?'
        r'(?:Wiley(?:-Blackwell)?|Blackwell|Elsevier|Springer(?:-Verlag)?|'
        r'CRC\s*Press|Woodhead\s+Publishing|Academic\s+Press|Pearson|McGraw-?Hill|'
        r'Taylor\s*&\s*Francis|Routledge|World\s+Scientific|MIT\s+Press|'
        r'Cambridge\s+University\s+Press|Oxford\s+University\s+Press|'
        r'CIBSE|ASHRAE|ISO)\s*$',
        '', j, flags=re.I).strip().rstrip('.,;:').strip()

    # 迭代剥离尾部的卷/期/页码片段（最多 6 轮，防死循环）
    tail_pats = [
        r',\s*pp?\.\s*[\w\-–—]+\s*$',          # , p.101237 / , pp.1836-1853
        r',\s*\d+\s*\(\d+(?:[–\-]\d+)?\)\s*$', # , 45(20-21) 期号
        r',\s*\d+\s*$',                        # , 318 卷号
        # , 118348 / , e202413927 文章号。**必须含数字**——无此约束时
        # `,\s*[\w\-–—]+\s*$` 会把真实期刊名的末词一并吃掉（EMD20260067 [35]
        # 实测 "A Raman … theoretical analysis, Carbon" 的 ", Carbon" 被误删）
        r',\s*(?=[\w\-–—]*\d)[\w\-–—]{1,16}\s*$',
        # 悬挂的页码标记（原始著录截断后只剩 ", pp" / ", p."；EMD20260057
        # 实测 "In: Handbook of Surface Improvement and Modification. Elsevier, pp"）
        r',\s*pp?\.?\s*$',
        r',\s*[^,]+,\s*p\w*\s*$',              # , Doha, p 1724
        r'\.\s*[^.:]+:\s*[^,]+,\s*p\w*\s*$',   # . Berlin: Springer, p 69
        r',\s*(?:volume|vol\.?|issue|no\.?|issn)\s*[\w\-–—]*\s*$',  # , Volume 248 / , ISSN 0360-1323
    ]
    for _ in range(6):
        before = j
        j = j.rstrip('.,;:').strip()
        for pat in tail_pats:
            j = re.sub(pat, '', j, flags=re.I).strip()
        if j == before:
            break

    # 末段若是纯数字/短编号（卷页残留），也剥离
    j = re.sub(r',\s*\d{1,7}\s*$', '', j).strip()
    j = re.sub(r'\s+', ' ', j).strip().rstrip('.,').strip()
    # 期刊名过短（如只剩 "Sci." / "Mater."）说明切分有误，返回空由上层判定
    return j


# "名 姓. et al. ,标题" 前缀（实测 "Qing Ai. et al. ,Strong and brittle lithium..."；
# 也覆盖 "Rodrigues, M.-T. F. et al. A materials perspective..."）
# 注意：必须用「非贪婪 + 限长」而非嵌套量词，否则会触发灾难性回溯导致进程挂起
ETAL_PREFIX_RE = re.compile(r'^.{2,60}?\bet\s+al\.?\s*,?\s*', re.I)


def split_author_title(text):
    """若 title 误含作者列表，剥离出作者部分。

    识别：以 "姓, 名缩写." 形式的连续片段开头（如 "Yan, H. H., Bie, Y. H. & Chen, L. "）
    返回 (authors, title)
    """
    if not text:
        return '', ''

    # 0) "Name et al. ,Title" 形式（作者在前、无逗号分隔）
    m0 = ETAL_PREFIX_RE.match(text)
    if m0 and len(text) - m0.end() > 10:
        return m0.group(0).strip().rstrip(', '), text[m0.end():].strip()

    # 1) "姓, 名缩写." 连续片段
    pat = re.compile(
        r"^((?:[A-Z\u00C0-\u024F][A-Za-z\u00C0-\u024F'\-]{1,20},\s*"
        r"(?:[A-Z]\.\s*)+)(?:,\s*|and\s+|&\s*))*"
        r"[A-Z\u00C0-\u024F][A-Za-z\u00C0-\u024F'\-]{1,20},\s*(?:[A-Z]\.\s*)+"
        r"(?:\s*(?:and|&)\s*)?"
    )
    m = pat.match(text)
    if not m:
        return '', text
    authors = m.group(0).strip().rstrip('.,&').strip()
    title = text[m.end():].strip()
    # 只有确实切出了"多个作者片段"才认为是混入
    if authors.count(',') >= 2 and len(title) > 10:
        return authors, title
    return '', text


def clean_ref(ref):
    """统一清洗：DOI 提取、期刊名清理、标题混入作者修正。

    原地修改并返回该 dict。新增 is_preprint / preprint_server / preprint_id。
    """
    if not isinstance(ref, dict):
        return ref
    # 补齐字段
    for k in ('index', 'authors', 'title', 'journal', 'volume', 'page', 'year', 'doi'):
        ref.setdefault(k, '')

    # DOI：字段为空时尝试从期刊名/标题中回捞
    if not ref.get('doi'):
        for src in (ref.get('journal', ''), ref.get('title', '')):
            d = extract_doi(src)
            if d:
                ref['doi'] = d
                break

    # 期刊名清洗（并移除其中残留的 DOI / URL）
    ref['journal'] = clean_journal(ref.get('journal', ''))

    # 标题去 URL / DOI 残留
    title = ref.get('title', '') or ''
    title = URL_RE.sub('', title)
    title = DOI_FIND_RE.sub('', title)
    title = re.sub(r'\s+', ' ', title).strip().rstrip('.,').strip()
    ref['title'] = title

    # 标题混入作者 → 二次切分
    if title:
        authors, title2 = split_author_title(title)
        if authors:
            ref['title'] = title2
            if not ref.get('authors'):
                ref['authors'] = authors

    # 预印本标记
    is_pp, server, pid = detect_preprint(ref)
    ref['is_preprint'] = is_pp
    ref['preprint_server'] = server
    ref['preprint_id'] = pid
    return ref


# ---------------------------------------------------------------- 4b. 会议论文集/书籍判定

# 会议论文集 / 书籍 / 报告类「容器名」：期刊核对对它们不适用。
# 原因（CVMJ-26-00445 实测 65/89 条假警）：稿内著录为 `Proceedings of IEEE/CVF Conf.
# Comput. Vis. Pattern Recognit.`，而 Crossref 侧该会议论文的 container-title 为
# `2022 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)`——
# 年份前缀 + 全称/缩写差异使其永远无法逐词对齐，属**已知假警类**，规则明文
# 「期刊核对只对『期刊论文』有意义，会议/书籍/报告条目应忽略」。
# 命中即跳过 strict 期刊核对（仅记 info），标题/年份/作者核对照常执行。
CONFERENCE_JOURNAL_RE = re.compile(
    r'(?i)\b(?:proceedings|conference|conf\.|proc\.|symposium|workshop|congress|'
    r'meeting|neurips|nips|iclr|icml|aaai|ijcai|cvpr|iccv|eccv|wacv|acl|emnlp|'
    r'adv\.\s*neural\s+inf|lecture\s+notes|springer\s+proc|'
    r'tech\.?\s*rep|thesis|dissertation|arxiv)\b')


def is_conference_container(journal):
    """判定刊名是否指向会议论文集/书籍/报告（非期刊论文）。"""
    j = str(journal or '')
    if not j:
        return False
    return bool(CONFERENCE_JOURNAL_RE.search(j))


# ---------------------------------------------------------------- 5. 预印本识别

def detect_preprint(ref):
    """识别预印本。返回 (is_preprint, server, preprint_id)。

    检查 title / journal / doi 三个字段的任意位置。
    """
    if isinstance(ref, dict):
        blob = ' '.join(str(ref.get(k) or '') for k in ('title', 'journal', 'doi'))
    else:
        blob = str(ref or '')
    if not blob:
        return False, '', ''

    for name, pat, _high in PREPRINT_PATTERNS:
        m = pat.search(blob)
        if m:
            pid = ''
            if m.groups():
                pid = (m.group(1) or '').rstrip('.,;)')
            elif name == 'bioRxiv/medRxiv':
                pid = m.group(0)
            return True, name, pid
    return False, '', ''


def summarize_preprints(refs):
    """统计预印本：返回 {'total': N, 'by_server': {...}}。"""
    by_server = {}
    total = 0
    for r in refs or []:
        if isinstance(r, dict) and r.get('is_preprint'):
            total += 1
            s = r.get('preprint_server') or '其他'
            by_server[s] = by_server.get(s, 0) + 1
    return {'total': total, 'by_server': by_server}


# ---------------------------------------------------------------- 6. 评分辅助

def field_completeness(ref):
    """字段完整度：关键字段非空占比（0–1）。

    v2.20.0：`no_title_format`（RSC 式无篇名著录）条目本身不含篇名，
    若仍按四字段计分，完整度被**恒定压低 25%**、与稿件质量无关。
    故该类条目改按（年份 / 期刊 / 作者）三字段计分。
    """
    keys = ('title', 'year', 'journal', 'authors')
    if not isinstance(ref, dict):
        return 0.0
    if ref.get('no_title_format'):
        keys = ('year', 'journal', 'authors')
    filled = sum(1 for k in keys if str(ref.get(k) or '').strip())
    return filled / len(keys)


def is_healthy(ref):
    """判定一条文献是否"解析健康"：有标题且至少有年份或期刊之一。

    v2.20.0：`no_title_format`（RSC 式无篇名著录）条目**本来就没有篇名**，
    若沿用"标题 ≥8 字符"判据，整批文献会全部被判不健康 → 策略得分归零、
    报告误报「解析失败」。故该类条目的判据改为：有年份 且 至少有
    期刊 / 篇名 / 页码之一（期刊条目为 年+期刊，专著/报告为 年+篇名）。
    """
    if not isinstance(ref, dict):
        return False
    title = str(ref.get('title') or '').strip()
    year = str(ref.get('year') or '').strip()
    journal = str(ref.get('journal') or '').strip()
    page = str(ref.get('page') or '').strip()
    if ref.get('no_title_format'):
        return bool(year and (journal or title or page))
    if len(title) < 8:
        return False
    return bool(year or journal)

#!/usr/bin/env python3
"""
retraction_watch.py — Retraction Watch 数据库管理

功能：
1. 下载/缓存 retraction_watch.csv
2. 作者模糊检索（surname + first-name token match）
3. 参考文献标题撤稿检索

Usage:
    python retraction_watch.py check-authors --authors "Name1,Name2,..."
    python retraction_watch.py check-refs --refs <references_json_file>
    python retraction_watch.py download  # 强制下载最新数据

Output (stdout): JSON

v2.15.0 整改：
- P1/P2/P3（性能）：CSV 只加载一次并构建「姓索引 + 标题倒排索引 + DOI 索引」，
  check-authors 每作者只查索引命中行（消除 6 万行全表扫描）；
  check-refs 先经倒排索引取候选（通常 <600 条）再跑 rapidfuzz（消除全量 6 万标题比对）；
  索引按 CSV mtime/size 缓存为 pickle（RW_CSV_CACHE 环境变量可覆盖路径），
  批量场景下多个子进程共享同一缓存（消除每批重解析 65MB）。
- S2: ensure_csv() 调用包 try——GitLab 返回异常格式等意外异常不再裸崩溃，
  统一返回 download_failed JSON，保证 stdout 必为 JSON 约定。
- S4: check-refs 入口对 >40 篇参考文献打印警告（提示用 batch_check_refs 分批）。
- S10: references 非 list（dict 等）入口直接报错，杜绝 enumerate(dict) TypeError。
- P1-1: 短标题共同词过滤轴修正——以「命中标题短」为条件，避免误杀真命中。
- 单名/缺名 RW 条目与作者 surname-only 匹配时标记 confidence=low（防同名误报）。
- S9: CLI main 读取输入包 try。
"""

import argparse
import csv
import json
import os
import pickle
import re
import sys
from collections import Counter
from pathlib import Path

from config import CSV_PATH, DATA_DIR, META_PATH, RW_INDEX_CACHE

# 手动下载入口（下载失败时提示用户从此处获取 retraction_watch.csv）
RW_REPO_URL = "https://gitlab.com/crossref/retraction-watch-data/"

# 标题倒排索引停用词（共享显著 token 是 90 分匹配的必要条件；停用词不计入候选）
_STOPWORDS = frozenset({
    'a', 'an', 'the', 'of', 'in', 'on', 'for', 'and', 'or', 'with', 'to',
    'from', 'by', 'at', 'is', 'are', 'was', 'were', 'as', 'its', 'it',
    'this', 'that', 'be', 'been', 'being', 'using', 'via', 'into', 'over',
})
_REF_BATCH_WARN = 40   # check-refs 单进程直接调用超过该数量 → 警告走 batch（S4）


# ── CSV management ─────────────────────────────────────────────────────

def ensure_csv(force_download: bool = False) -> tuple[str, bool]:
    """
    Ensure retraction_watch.csv is available locally and reasonably fresh.

    Download policy (delegated to scripts/download_retraction_watch.py):
      下载触发条件（两步判定，降低频率、减少联网）：
      - 无条件下载：--force / download 子命令；或 CSV 不存在（无可检测数据）。
      - 第 1 步（本地快筛，不联网）：以本地 update_date（数据版本日期）为基准，
        缺失回退 CSV mtime；版本日期距今 < 3 天 → 直接复用、不发任何网络请求。
      - 第 2 步（联网精确判定，仅版本日期距今 >= 3 天时）：GitLab Commits API
        查源端最新提交日期（committed_date），(gitlab_date - 本地版本日期) > 3 天
        才重新下载；<= 3 天复用。GitLab API 不可达时回退保守下载一次
        （不因查不到源头而用旧数据），update_date 记录旧基线或今天。
      - 完整性校验：下载后字节数 >= 50MB 且 行数 >= 55000，否则视为不完整并重试
        （最多 3 次，指数退避）。
      - 原子覆盖：先写 .tmp 临时文件，校验通过才 os.replace 覆盖正式 CSV。
      - 保留上一版：重试耗尽仍不完整时，若本地已有完整 CSV 则保留并继续使用，
        不删除、不阻断后续检测（仅 source 标注 incomplete 供报告提示）。
      并发注意：RW 数据准备（版本检查+判断+下载）应作为前置步骤串行执行一次；
      数据就绪（FRESH 快筛命中）后，check-authors 与 check-refs 可安全并行
      （仅只读 CSV，不再触发下载）。

    Returns (source_description, downloaded_now).
      - source_description: "cached_<日期>" / "downloaded_<日期>" /
        "cached_<日期> (download incomplete, kept previous version)" / "download_failed"
      - downloaded_now: True only when a fresh download just happened.
    """
    from download_retraction_watch import run
    status, source, downloaded_now = run(force=force_download)
    return (source, downloaded_now)


# ── RW 索引（v2.15.0：加载一次 + 索引复用）──────────────────────────────

def _title_tokens(title):
    """标题 token 化（小写、去标点、过滤停用词与单字符）。"""
    toks = re.findall(r'[a-zA-Z0-9]+', (title or '').lower())
    return [t for t in toks if len(t) >= 2 and t not in _STOPWORDS]


def _cache_key():
    try:
        st = CSV_PATH.stat()
        return f"{st.st_mtime_ns}:{st.st_size}"
    except OSError:
        return ""


def _load_rw_index(build_title=True):
    """
    加载 RW 记录与索引（records, surname_index, doi_index, title_index）。

    - records: list[dict]（精简 8 字段）
    - surname_index: {surname: set(row_idx)}
    - doi_index:    {doi_lower: row_idx}
    - title_index:  {token: set(row_idx)}（仅 build_title=True 时构建）

    索引按 CSV mtime/size 缓存为 pickle（路径取 RW_CSV_CACHE 环境变量，缺省 RW_INDEX_CACHE）；
    缓存失效（CSV 更新/损坏）自动重建。缓存为纯性能优化，读写失败静默降级。
    返回 None 表示 CSV 不存在。
    """
    if not CSV_PATH.exists():
        return None
    key = _cache_key()
    cache_path = os.environ.get('RW_CSV_CACHE') or str(RW_INDEX_CACHE)
    if cache_path:
        try:
            with open(cache_path, 'rb') as f:
                cached = pickle.load(f)
            if cached.get('key') == key and cached.get('build_title', False) == build_title:
                return (cached['records'], cached['surname_index'],
                        cached['doi_index'], cached['title_index'])
        except Exception:
            pass

    records = []
    surname_index = {}
    doi_index = {}
    title_index = {}
    with open(CSV_PATH, 'r', encoding='utf-8', errors='replace', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            title = (row.get('Title') or '').strip()
            if not title:
                continue
            # Guard 1: drop placeholder / junk rows (e.g. 1-char titles with the
            # "Copyright Claims; Date of Article and/or Notice Unknown" reason).
            if len(title) < 10:
                continue
            if (row.get('Reason') or '').strip().startswith(
                    "Copyright Claims; Date of Article and/or Notice Unknown"):
                continue
            rec = {
                "title": title,
                "author": row.get('Author') or '',
                "subject": row.get('Subject') or '',
                "retraction_date": row.get('RetractionDate') or '',
                "reason": row.get('Reason') or '',
                "institution": row.get('Institution') or '',
                "original_paper_doi": (row.get('OriginalPaperDOI') or '').strip().lower(),
                "retraction_doi": (row.get('RetractionDOI') or '').strip(),
            }
            idx = len(records)
            records.append(rec)
            doi = rec["original_paper_doi"]
            if doi:
                doi_index[doi] = idx
            if build_title:
                for tok in _title_tokens(title):
                    title_index.setdefault(tok, set()).add(idx)
            for surname, _ in tokenize_csv_author(rec["author"]):
                surname_index.setdefault(surname, set()).add(idx)

    if cache_path:
        try:
            p = Path(cache_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, 'wb') as f:
                pickle.dump({
                    'key': key, 'build_title': build_title,
                    'records': records, 'surname_index': surname_index,
                    'doi_index': doi_index, 'title_index': title_index,
                }, f, protocol=4)
        except Exception:
            pass  # 缓存为纯优化，失败不影响功能

    return records, surname_index, doi_index, title_index


# ── Author matching ────────────────────────────────────────────────────

def parse_author_name(name: str) -> tuple[str, str]:
    """
    Parse an author name into (surname, first_name_token).
    Handles:
      - "Last, First"  → ("last", "first")
      - "First Last"   → ("last", "first")
      - "First M. Last" → ("last", "first")
    """
    name = name.strip()
    if not name:
        return ("", "")

    if ',' in name:
        parts = name.split(',', 1)
        surname = parts[0].strip().lower()
        first_part = parts[1].strip() if len(parts) > 1 else ""
        # Extract first token of first name
        first_token = first_part.split()[0].rstrip('.').lower() if first_part else ""
        return (surname, first_token)
    else:
        parts = name.strip().split()
        if len(parts) == 1:
            return (parts[0].lower(), "")
        surname = parts[-1].lower()
        first_token = parts[0].rstrip('.').lower()
        return (surname, first_token)


def tokenize_csv_author(csv_author: str) -> list[tuple[str, str]]:
    """
    Tokenize a CSV author field. The CSV may contain multiple authors
    separated by ';'. Each author may be in "Last, First" or "First Last" format.
    Returns list of (surname, first_token) tuples.
    """
    if not csv_author or csv_author.strip() == '':
        return []

    authors = [a.strip() for a in csv_author.split(';') if a.strip()]
    result = []
    for author in authors:
        parsed = parse_author_name(author)
        if parsed[0]:  # has surname
            result.append(parsed)
    return result


def author_matches_paper_author(csv_author: str, paper_surname: str,
                                paper_first_token: str) -> tuple[bool, str]:
    """
    判断 CSV 作者字段是否与稿件作者匹配。返回 (matched, confidence)。

    - 姓 + 名 token 均精确相等 → (True, 'high')
    - 仅姓相同（任一方缺名 token）→ (True, 'low')：surname-only 匹配，
      常见姓氏误报率高，标记 low 置信供报告端「同名命中」提示（v2.15.0）。
    - 名 token 存在但不相等 → 不匹配。
    """
    best = None
    for csv_surname, csv_first in tokenize_csv_author(csv_author):
        if csv_surname != paper_surname:
            continue
        if paper_first_token and csv_first:
            if csv_first == paper_first_token:
                return (True, 'high')
            continue
        # surname-only：无 first token 佐证
        if best is None:
            best = 'low'
    return (best is not None, best or '')


def check_authors(author_names: list[str]) -> dict:
    """Search retraction_watch.csv for each author."""
    try:
        source, downloaded_today = ensure_csv()
    except Exception as e:
        return {
            "csv_source": "download_failed",
            "error": f"撤稿数据准备异常：{e}",
            "authors": []
        }

    if source.startswith("download_timeout"):
        return {
            "csv_source": "download_timeout",
            "error": "撤稿数据下载超时（超过5分钟），请从 https://gitlab.com/crossref/retraction-watch-data 手动下载 retraction_watch.csv 到 " + str(CSV_PATH),
            "authors": []
        }

    if source.startswith("download_failed"):
        return {
            "csv_source": "download_failed",
            "error": "撤稿数据下载失败，请检查网络或从 https://gitlab.com/crossref/retraction-watch-data 手动下载",
            "authors": []
        }

    # Parse input authors
    parsed_authors = {name: parse_author_name(name) for name in author_names}

    results = {
        "csv_source": source,
        "authors": []
    }

    # 索引化加载（v2.15.0 P1）：只加载一次，每作者查姓索引
    loaded = _load_rw_index(build_title=False)
    if loaded is None:
        return {**results, "error": "CSV 不可用，无法检索"}
    records, surname_index, _, _ = loaded

    for name, (surname, first_token) in parsed_authors.items():
        if not surname:
            results["authors"].append({
                "name": name,
                "hits": [],
                "risk": "none",
                "error": "Could not parse author name"
            })
            continue

        hits = []
        try:
            for idx in surname_index.get(surname, ()):
                rec = records[idx]
                matched, confidence = author_matches_paper_author(
                    rec["author"], surname, first_token)
                if not matched:
                    continue
                hits.append({
                    "author_in_csv": rec["author"],
                    "title": rec["title"],
                    "subject": rec["subject"],
                    "retraction_date": rec["retraction_date"],
                    "reason": rec["reason"],
                    "institution": rec["institution"],
                    "original_paper_doi": rec["original_paper_doi"],
                    "retraction_doi": rec["retraction_doi"],
                    "confidence": confidence,   # high / low（surname-only）
                })
        except Exception as e:
            results["authors"].append({
                "name": name,
                "hits": [],
                "risk": "none",
                "error": str(e)
            })
            continue

        # Determine risk level（v2.15.0 说明：risk 仅为提示，最终以 agent 三档判定为准）
        risk = "none"
        if hits:
            risk = "low"
            if len(hits) >= 3:
                risk = "medium"
            if len(hits) >= 5:
                risk = "high"

        results["authors"].append({
            "name": name,
            "hits": hits,
            "risk": risk
        })

    return results


# ── Reference title matching ───────────────────────────────────────────

def _common_word_count(title_a: str, title_b: str) -> int:
    """两标题共同单词数（忽略大小写，仅字母数字 token）。

    用于过滤「短标题子串」型误报：长文献标题与撤稿库 1-3 词占位条目的
    partial_ratio 高分命中，共同单词数必然很少。
    """
    ta = set(re.findall(r'[a-zA-Z0-9]+', (title_a or '').lower()))
    tb = set(re.findall(r'[a-zA-Z0-9]+', (title_b or '').lower()))
    return len(ta & tb)


def _candidate_idxs(title, title_index, max_cands=600):
    """倒排索引候选：取与 ref 标题共享 ≥1 个显著 token 的 RW 行，
    按共享 token 数降序取前 max_cands（90 分匹配必须共享显著 token，故不漏真命中）。"""
    toks = _title_tokens(title)
    if not toks:
        return []
    cnt = Counter()
    for t in toks:
        for i in title_index.get(t, ()):
            cnt[i] += 1
    if not cnt:
        return []
    return [i for i, _ in cnt.most_common(max_cands)]


def check_reference_titles(references: list[dict]) -> dict:
    """
    在 retraction_watch.csv 中检索每条参考文献是否对应被撤稿文献。
    匹配优先级：① DOI 锚定（refs DOI ↔ OriginalPaperDOI，最高置信）→
               ② 标题模糊（阈值 90，忽略大小写）。
    references: list of {"index": N, "title": "...", "doi": "..."} dicts.
    命中项含 match_type（doi/title）与 confidence（high/review）。
    """
    if not isinstance(references, list):
        raise ValueError('references 必须为纯 list（SKILL.md：refs.json 须为 list）')
    if len(references) > _REF_BATCH_WARN:
        print(f'WARN: references 数量 {len(references)} > {_REF_BATCH_WARN}，'
              f'建议使用 batch_check_refs.py 分批规避 rapidfuzz 累积崩溃', file=sys.stderr)

    try:
        source, _ = ensure_csv()
    except Exception as e:
        return {
            "csv_source": "download_failed",
            "total_references": len(references),
            "matches": [],
            "error": f"撤稿数据准备异常：{e}"
        }

    if source.startswith("download_timeout"):
        return {
            "csv_source": "download_timeout",
            "total_references": len(references),
            "matches": [],
            "error": "撤稿数据下载超时（超过5分钟），请从 https://gitlab.com/crossref/retraction-watch-data 手动下载 retraction_watch.csv"
        }

    if source.startswith("download_failed"):
        return {
            "csv_source": "download_failed",
            "total_references": len(references),
            "matches": [],
            "error": "撤稿数据下载失败，请检查网络或从 https://gitlab.com/crossref/retraction-watch-data 手动下载"
        }

    results = {
        "csv_source": source,
        "total_references": len(references),
        "matches": []
    }

    loaded = _load_rw_index(build_title=True)
    if loaded is None:
        return {**results, "error": "CSV 不可用，无法检索"}
    records, _, doi_index, title_index = loaded

    try:
        from rapidfuzz import fuzz, process
        HAS_RAPIDFUZZ = True
    except ImportError:
        import difflib
        HAS_RAPIDFUZZ = False

    rw_titles = [r["title"] for r in records]

    for ref in references:
        ref_title = ref.get("title", "").strip()
        ref_doi = (ref.get("doi") or "").strip().rstrip('.').lower()

        # ① DOI 锚定优先：精确匹配，最高置信
        if ref_doi and ref_doi in doi_index:
            rec = records[doi_index[ref_doi]]
            results["matches"].append({
                "ref_index": ref.get("index", "?"),
                "ref_title": ref_title[:200],
                "matched_title": rec["title"][:200],
                "match_score": 100,
                "match_type": "doi",
                "confidence": "high",
                "retraction_date": rec["retraction_date"],
                "reason": rec["reason"],
                "rw_author": rec["author"],
                "retraction_doi": rec["retraction_doi"],
            })
            continue

        if not ref_title:
            continue

        # ② 标题模糊匹配（阈值 90，忽略大小写；v2.15.0 P2：先经倒排索引取候选）
        cands = _candidate_idxs(ref_title, title_index)
        if not cands:
            continue
        choices = [rw_titles[i] for i in cands]

        if HAS_RAPIDFUZZ:
            best_s = process.extractOne(
                ref_title, choices, scorer=fuzz.token_sort_ratio,
                processor=str.lower, score_cutoff=90)
            best_p = process.extractOne(
                ref_title, choices, scorer=fuzz.partial_ratio,
                processor=str.lower, score_cutoff=90)
            cand = [c for c in (best_s, best_p) if c is not None]
            if not cand:
                continue
            matched_title, score, j = max(cand, key=lambda c: c[1])
            idx = cands[j]
            rec = records[idx]
        else:
            # difflib fallback：保持原 token_sort + partial（仅长标题）语义，阈值 90
            best_j, best_score = -1, 0
            for j, ci in enumerate(cands):
                rt = rw_titles[ci]
                ts = int(difflib.SequenceMatcher(
                    None,
                    ' '.join(sorted(ref_title.lower().split())),
                    ' '.join(sorted(rt.lower().split()))
                ).ratio() * 100)
                ps = 0
                if len(rt) >= 15:
                    ps = int(difflib.SequenceMatcher(
                        None, ref_title.lower()[:200], rt.lower()[:200]).ratio() * 100)
                s = max(ts, ps)
                if s > best_score:
                    best_score, best_j = s, j
            if best_j < 0 or best_score < 90:
                continue
            idx = cands[best_j]
            rec = records[idx]
            matched_title = rec["title"]
            score = best_score

        # 去噪（v2.15.0 P1-1）：以「命中标题短」为过滤条件——撤稿库 1-3 词占位短条
        # 对长标题 partial_ratio 高分 → 子串误报，过滤；ref 标题本身短的真命中不再误杀
        matched_tokens = re.findall(r'[a-zA-Z0-9]+', (matched_title or '').lower())
        if len(matched_tokens) <= 3 and _common_word_count(ref_title, matched_title) <= 3:
            continue

        results["matches"].append({
            "ref_index": ref.get("index", "?"),
            "ref_title": ref_title[:200],
            "matched_title": matched_title[:200],
            "match_score": int(score),
            "match_type": "title",
            "confidence": "high" if score >= 95 else "review",
            "retraction_date": rec["retraction_date"],
            "reason": rec["reason"],
            "rw_author": rec["author"],
            "retraction_doi": rec["retraction_doi"],
        })

    return results


# ── CLI ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Retraction Watch database manager")
    subparsers = parser.add_subparsers(dest="command", help="Command")

    # check-authors
    p_auth = subparsers.add_parser("check-authors", help="Check authors in retraction database")
    p_auth.add_argument("--authors", required=True, help="Comma-separated author names")

    # check-refs
    p_refs = subparsers.add_parser("check-refs", help="Check reference titles in retraction database")
    p_refs.add_argument("--refs", required=True, help="Path to JSON file with reference list")

    # download
    subparsers.add_parser("download", help="Force download of latest retraction_watch.csv")

    args = parser.parse_args()

    if args.command == "check-authors":
        # 防 comma 陷阱：本命令用逗号分隔不同作者，若姓名用了 "Last, First"
        # 格式（逗号后跟空格+大写字母）会被拆成伪作者，造成 surname-only 海量误报。
        # 仅当逗号后跟"单个词"（后面紧跟逗号或结尾）时才判定为 "Last, First" 误用；
        # 正常 "First Last" 多作者列表（逗号后是 "First Last" 两词）不受影响。
        if re.search(r',\s*[A-Z][a-zA-Z]*(?=\s*,|$)', args.authors):
            print(json.dumps({
                "csv_source": "input_error",
                "error": "作者名疑似用了 'Last, First' 格式（逗号后为单个名）。"
                         "本命令用逗号分隔不同作者，请改用 'First Last' 顺序，"
                         "如 'Dengyang Guo, Di Yang'。",
                "authors": []
            }, indent=2, ensure_ascii=False))
            sys.exit(1)
        names = [n.strip() for n in args.authors.split(",") if n.strip()]
        try:
            result = check_authors(names)
        except Exception as e:
            print(json.dumps({"csv_source": "internal_error", "error": str(e), "authors": []},
                             indent=2, ensure_ascii=False))
            sys.exit(1)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "check-refs":
        try:
            with open(args.refs, 'r', encoding='utf-8') as f:
                refs = json.load(f)
        except Exception as e:
            print(json.dumps({"status": "error", "error": f"读取 refs.json 失败: {e}"},
                             ensure_ascii=False))
            sys.exit(1)
        if not isinstance(refs, list):
            print(json.dumps({"status": "error", "error": "refs.json 必须为纯 list"},
                             ensure_ascii=False))
            sys.exit(1)
        try:
            result = check_reference_titles(refs)
        except Exception as e:
            print(json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False))
            sys.exit(1)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "download":
        source, downloaded = ensure_csv(force_download=True)
        print(json.dumps({"source": source, "downloaded": downloaded}, indent=2))

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

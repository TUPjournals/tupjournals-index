# PDF 诊断、批注写入与验收

脚本使用 `pypdf` 与 `pypdfium2`，优先选用宿主已有的 PDF 工作环境。以下命令从技能目录运行。先创建当前任务的 `work/`，实际文件路径按本次任务替换。

```bash
python scripts/review_pdf.py inspect 校样.pdf work/inventory.json
python scripts/review_pdf.py build 校样.pdf work/plan.json 校样_审校.pdf --list 校样_问题清单.md
python scripts/review_pdf.py validate 校样.pdf work/plan.json 校样_审校.pdf
```

## 从诊断到计划

1. 使用 `inventory.json` 中的物理页、页框、旋转、文字、字符坐标和原批注清单。原意见按 `p1-a1` 这类页内编号标识。结合源页图识别栏序、图内文字和 OCR 假象。可使用 [审读台账](../assets/page-review.example.md) 记录覆盖范围及原意见处置。
2. 复制 [批注计划示例](../assets/annotation-plan.example.json)，填入诊断清单中的 `source_sha256` 和已核定问题。由编辑按物理页及实际阅读顺序排好 `issues`。每项填写 `page`、`position`、`kind`、`message` 和 `anchors`。文字锚点填写 `expected`。同页原批注的关联可以填入 `sources`，必要时补 `evidence`。
3. 文字锚点可用 `text`，重复时提供 `prefix`、`suffix`、`occurrence` 或明确的 `char_indices`。用 `select` 缩小选取范围。文字索引锚点还需在该锚点内填写 `expected`。图像位置可填写左下原点坐标 `rect: [x0, y0, x1, y1]`，同时给出 `visually_verified: true`、`image_only: true` 和核实依据 `reason`。结合页面渲染人工验看。详见 [定位规范](pdf-annotations.md)。
4. 确定修改用 `kind: edit`，存疑用 `kind: verify`。脚本在批注与清单中同步编号，保留源批注并增写计划中的问题。复核阶段需改写、迁移或合并旧批注时，另用支持对应批注结构的 PDF 编辑工具操作，并按台账整理最终清单。脚本生成的清单仅记录本次计划新增的事项。

## 核验与适用边界

- 核查几何、页序、页内容流、旧批注摘要及新增问题的数量与编号。全文任务补充各页审读记录，复检任务核对原意见去向。以页面渲染和阅读器的选区反馈核验实际观感。
- 文本高亮写入适用于常规无旋转、原点为零、裁切框与页面框相同的页面。遇到旋转、裁切、竖排文字或字符几何无法可靠判定时，可继续使用诊断结果，切换支持相应坐标的 PDF 工具完成。区分无法可靠选字和无法读取页面的问题。
- 已有输出路径时使用新名称。扫描页的文字识别和排版核对依赖宿主的渲染和 OCR 能力，脚本仍可用已核实的图像区域定位。

"""PDFium glyph geometry: precise semantic anchors and complete character selection."""
from __future__ import annotations
import ctypes
import math
import re
import pypdfium2 as pdfium
from pypdfium2 import raw


def compact(text, aliases=None):
    for before, after in (aliases or {}).items():
        text = text.replace(before, after)
    return ''.join(c for c in text if not c.isspace() and c != '\x00')


def contains(rect, box, eps=0.02):
    return rect[0]-eps <= box[0] and rect[1]-eps <= box[1] and rect[2]+eps >= box[2] and rect[3]+eps >= box[3]


def union(boxes):
    return [min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes)]


def page_chars(textpage):
    """Keep explicit PDFium indices; text string offsets are not character indices."""
    chars = []
    i = 0
    while i < textpage.count_chars():
        u = raw.FPDFText_GetUnicode(textpage, i)
        indices = [i]
        if 0xD800 <= u <= 0xDBFF and i+1 < textpage.count_chars():
            low = raw.FPDFText_GetUnicode(textpage, i+1)
            if 0xDC00 <= low <= 0xDFFF:
                u = 0x10000 + ((u-0xD800) << 10) + low-0xDC00
                indices.append(i+1)
        value = chr(u) if u and not 0xD800 <= u <= 0xDFFF else ''
        tight = [list(textpage.get_charbox(j)) for j in indices]
        nonzero = [b for b in tight if b[2] > b[0] and b[3] > b[1]]
        box = union(nonzero or tight)
        loose = union([list(textpage.get_charbox(j, loose=True)) for j in indices])
        x, y = ctypes.c_double(), ctypes.c_double()
        raw.FPDFText_GetCharOrigin(textpage, i, ctypes.byref(x), ctypes.byref(y))
        size = float(raw.FPDFText_GetFontSize(textpage, i))
        angle = float(raw.FPDFText_GetCharAngle(textpage, i))
        chars.append({'index': i, 'indices': indices, 'text': value, 'box': box,
                      'loose_box': loose, 'origin': [x.value, y.value], 'size': size,
                      'angle': angle})
        i += len(indices)
    # Baseline grouping is used for line membership, never for glyph height.
    groups = []
    for c in sorted((c for c in chars if c['text'] and not c['text'].isspace()),
                    key=lambda c: (-c['origin'][1], c['origin'][0])):
        if not groups or abs(groups[-1]['y']-c['origin'][1]) > 1.8:
            groups.append({'y': c['origin'][1], 'chars': [c]})
        else:
            groups[-1]['chars'].append(c)
    for g in list(groups):
        if len(g['chars']) <= 3 and max(c['size'] for c in g['chars']) <= 8:
            near = [h for h in groups if h is not g and len(h['chars']) > 3
                    and abs(h['y']-g['y']) <= 5]
            if near:
                h = min(near, key=lambda h: abs(h['y']-g['y']))
                h['chars'].extend(g['chars']); groups.remove(g)
    for row, g in enumerate(sorted(groups, key=lambda g: -g['y'])):
        for c in g['chars']:
            c['line'] = row
    return chars


def page_record(page, number):
    tp = page.get_textpage()
    try:
        return {'page': number, 'width': page.get_width(), 'height': page.get_height(),
                'chars': page_chars(tp)}
    finally:
        tp.close()


def normalized_chars(chars, aliases=None):
    text, mapping = '', []
    for c in chars:
        value = compact(c['text'], aliases)
        text += value
        mapping.extend([c['index']] * len(value))
    return text, mapping


def read_rects(quads):
    if len(quads) % 8:
        raise ValueError('QuadPoints must contain groups of eight numbers')
    return [[min(quads[j:j+8:2]), min(quads[j+1:j+8:2]),
             max(quads[j:j+8:2]), max(quads[j+1:j+8:2])]
            for j in range(0, len(quads), 8)]


def selected_by_center(chars, rects):
    chosen = []
    for rect in rects:
        row = [c for c in chars if c['text'] and not c['text'].isspace()
               and rect[0]-0.3 <= (c['box'][0]+c['box'][2])/2 <= rect[2]+0.3
               and rect[1]-0.5 <= (c['box'][1]+c['box'][3])/2 <= rect[3]+0.5]
        chosen.extend(sorted(row, key=lambda c: (c.get('line', 0), c['box'][0])))
    return list({c['index']: c for c in chosen}.values())


def resolve_anchor(page, anchor, aliases=None):
    chars = page['chars']; by_id = {c['index']: c for c in chars}
    if 'rect' in anchor:
        rect = [float(x) for x in anchor['rect']]
        if len(rect) != 4 or not anchor.get('visually_verified'):
            raise ValueError('A manual rectangle needs four coordinates and visually_verified=true')
        if anchor.get('image_only'):
            if not anchor.get('reason'):
                raise ValueError('Image-only anchor requires an explicit reason')
            return [], [rect]
        chosen = selected_by_center(chars, [rect])
        expected = anchor.get('expected')
        if not expected or compact(''.join(c['text'] for c in chosen), aliases) != compact(expected, aliases):
            raise ValueError('Manual text rectangle does not select its complete expected text')
    elif 'char_indices' in anchor:
        if not anchor.get('expected'):
            raise ValueError('Explicit character indices require expected text')
        ids = list(anchor['char_indices'])
        if len(ids) != len(set(ids)) or any(i not in by_id for i in ids):
            raise ValueError('Invalid or duplicate PDFium character indices')
        chosen = [by_id[i] for i in ids]
        if compact(''.join(c['text'] for c in chosen), aliases) != compact(anchor['expected'], aliases):
            raise ValueError('Character indices do not match expected text')
    else:
        query = compact(anchor.get('text', ''), aliases)
        if not query:
            raise ValueError('Text anchor is empty')
        text, mapping = normalized_chars(chars, aliases)
        hits = [m.start() for m in re.finditer(re.escape(query), text)]
        prefix = compact(anchor.get('prefix', ''), aliases)
        suffix = compact(anchor.get('suffix', ''), aliases)
        if prefix:
            hits = [i for i in hits if text[max(0, i-len(prefix)):i] == prefix]
        if suffix:
            hits = [i for i in hits if text[i+len(query):i+len(query)+len(suffix)] == suffix]
        if len(hits) != 1 and 'occurrence' not in anchor:
            raise ValueError(f'Anchor {anchor.get("text")!r} has {len(hits)} matches; disambiguate explicitly')
        occurrence = anchor.get('occurrence', 1)
        if not isinstance(occurrence, int) or occurrence < 1 or occurrence > len(hits):
            raise ValueError(f'Anchor {anchor.get("text")!r}: invalid occurrence {occurrence}, {len(hits)} matches')
        select = compact(anchor.get('select', query), aliases)
        if not select or query.count(select) != 1:
            raise ValueError('select must be a unique nonempty substring of anchor text')
        start = hits[occurrence-1] + query.index(select)
        ids = list(dict.fromkeys(mapping[start:start+len(select)]))
        chosen = [by_id[i] for i in ids]
        if compact(''.join(c['text'] for c in chosen), aliases) != select:
            raise ValueError('Resolved selection is incomplete')
    chosen = [c for c in chosen if c['text'] and not c['text'].isspace()]
    if not chosen:
        raise ValueError('Anchor contains no selectable text')
    if any(abs(c['angle']) > 0.02 for c in chosen):
        raise ValueError('Rotated text requires adapted quad geometry')
    rects = []
    chosen_ids = {c['index'] for c in chosen}
    for line in sorted({c['line'] for c in chosen}):
        group = [c for c in chosen if c['line'] == line]
        ink = union([c['box'] for c in group])
        # Keep a line-level full-character highlight height, even for punctuation.
        # Ink containment remains authoritative when a glyph extends beyond it.
        peers = [c for c in chars if c.get('line') == line and c['text']
                 and not c['text'].isspace() and abs(c['size']-max(g['size'] for g in group)) < 0.8]
        cjk = [c for c in peers if any('\u3400' <= ch <= '\u9fff' for ch in c['text'])
               and c['box'][3]-c['box'][1] >= c['size']*0.75]
        if cjk:
            bottoms = sorted(c['box'][1] for c in cjk)
            tops = sorted(c['box'][3] for c in cjk)
            band_bottom = bottoms[len(bottoms)//2]
            band_top = tops[len(tops)//2]
        else:
            font_size = max(c['size'] for c in group)
            baseline = sorted(c['origin'][1] for c in group)[len(group)//2]
            band_bottom, band_top = baseline-font_size*0.15, baseline+font_size*0.85
        ink[1] = min(ink[1], band_bottom)
        ink[3] = max(ink[3], band_top)
        # Loose bounds are used horizontally only: malformed font-wide vertical
        # ascent/descent can cover adjacent lines. Full glyph ink is used vertically.
        left = min(min(c['box'][0], c['loose_box'][0]) for c in group)
        right = max(max(c['box'][2], c['loose_box'][2]) for c in group)
        valid = None
        for px, py in [(0.35, 0.55), (0.15, 0.3), (0.0, 0.1)]:
            rect = [left-px, ink[1]-py, right+px, ink[3]+py]
            if not all(contains(rect, c['box']) for c in group):
                continue
            extra = [c for c in chars if c['text'] and not c['text'].isspace()
                     and c['index'] not in chosen_ids and contains(rect, c['box'])]
            if not extra:
                valid = rect; break
        if valid is None:
            raise ValueError('Highlight would select extra neighbouring characters; refine the anchor')
        rects.append(valid)
    return chosen, rects


def resolve_item(page, item, aliases=None):
    all_chars, rects = [], []
    for anchor in item.get('anchors', []):
        chosen, boxes = resolve_anchor(page, anchor, aliases)
        all_chars.extend(chosen); rects.extend(boxes)
    if not rects:
        raise ValueError(f'Item {item.get("id")}: no anchor')
    expected = item.get('expected')
    if all_chars:
        if not expected or compact(''.join(c['text'] for c in all_chars), aliases) != compact(expected, aliases):
            raise ValueError(f'Item {item.get("id")}: selection differs from expected text')
        if len({c['index'] for c in all_chars}) != len(all_chars):
            raise ValueError('The same character occurs twice in one annotation')
    for b in rects:
        if not all(math.isfinite(x) for x in b) or not (0 <= b[0] < b[2] <= page['width'] and 0 <= b[1] < b[3] <= page['height']):
            raise ValueError('Highlight geometry exceeds the page or is degenerate')
    return all_chars, rects

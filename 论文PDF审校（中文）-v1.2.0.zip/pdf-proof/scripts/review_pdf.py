#!/usr/bin/env python3
"""Inventory PDF pages, write approved highlights, and verify the resulting PDF."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from pathlib import Path

import pypdfium2 as pdfium
from pypdf import PdfReader, PdfWriter
from pypdf.annotations import Highlight
from pypdf.generic import ArrayObject, DecodedStreamObject, DictionaryObject, FloatObject, NameObject, NumberObject, TextStringObject

from geometry import page_record, read_rects, resolve_item, union

COLORS = {"edit": (1.0, 0.94, 0.58), "verify": (0.72, 0.86, 1.0)}
LABELS = {"edit": "可修改", "verify": "待核查"}


def source_digest(source):
    with source.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def reader_for(source):
    reader = PdfReader(source)
    if reader.is_encrypted:
        raise ValueError("Use an authorized, readable working copy of the PDF")
    return reader


def note_refs(page):
    refs = page.get("/Annots")
    return [] if refs is None else list(refs.get_object())


def object_id(ref):
    return getattr(ref, "idnum", None)


def inventory(source, reader):
    pages = []
    doc = pdfium.PdfDocument(source)
    try:
        for index, page in enumerate(reader.pages):
            number = index + 1
            pdfium_page = doc[index]
            try:
                record = page_record(pdfium_page, number)
            finally:
                pdfium_page.close()
            record.update({
                "rotation": page.rotation,
                "mediabox": list(map(float, page.mediabox)),
                "cropbox": list(map(float, page.cropbox)),
                "annotations": [],
            })
            for position, ref in enumerate(note_refs(page), 1):
                note = ref.get_object()
                record["annotations"].append({
                    "id": f"p{number}-a{position}",
                    "subtype": str(note.get("/Subtype", "")),
                    "text": str(note.get("/Contents", "")),
                    "rect": list(map(float, note.get("/Rect", []))),
                    "quads": list(map(float, note.get("/QuadPoints", []))),
                    "xref": object_id(ref),
                    "parent_xref": object_id(note.raw_get("/Parent")) if "/Parent" in note else None,
                    "reply_to_xref": object_id(note.raw_get("/IRT")) if "/IRT" in note else None,
                })
            record["text"] = "".join(char["text"] for char in record["chars"])
            pages.append(record)
    finally:
        doc.close()
    return pages


def inspect(source, output):
    reader = reader_for(source)
    result = {"source_sha256": source_digest(source), "pages": inventory(source, reader)}
    with output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def prepare(source, plan):
    digest = source_digest(source)
    if plan.get("source_sha256") != digest:
        raise ValueError("The annotation plan does not match the source PDF")
    issues = plan.get("issues")
    if not isinstance(issues, list):
        raise ValueError("The plan requires an issues array")

    reader = reader_for(source)
    pages = inventory(source, reader) if issues else []
    rows = []
    previous = 0
    for number, item in enumerate(issues, 1):
        page_number = item.get("page")
        if type(page_number) is not int or not previous <= page_number <= len(pages) or page_number < 1:
            raise ValueError(f"Issue {number} has an invalid or out-of-order physical page")
        previous = page_number
        page = pages[page_number - 1]
        if page["rotation"] or page["mediabox"][:2] != [0, 0] or page["cropbox"] != page["mediabox"]:
            raise ValueError(f"Page {page_number} needs a coordinate-aware PDF annotation tool")
        if item.get("kind") not in COLORS:
            raise ValueError(f"Issue {number} needs kind edit or verify")
        for key in ("position", "message"):
            if not isinstance(item.get(key), str) or not item[key].strip():
                raise ValueError(f"Issue {number} requires {key}")
        try:
            _, rects = resolve_item(page, item)
        except ValueError as error:
            raise ValueError(f"Issue {number}, page {page_number}: {error}") from error
        original_ids = {annotation["id"] for annotation in page["annotations"]}
        if any(source_id not in original_ids for source_id in item.get("sources", [])):
            raise ValueError(f"Issue {number} has an unknown source note on this page")
        rows.append({
            "key": f"pdf-proof-{digest[:12]}-{number:04d}",
            "page": page_number,
            "rects": rects,
            "content": f"{number}. {LABELS[item['kind']]}\n{item['message'].strip()}",
            "item": item,
        })
    by_page = [set(str(ref.get_object().get("/NM", "")) for ref in note_refs(page)) for page in reader.pages]
    if any(row["key"] in by_page[row["page"] - 1] for row in rows):
        raise ValueError("This annotation plan would duplicate an existing issue identifier")
    return reader, rows


def floats(values):
    return ArrayObject([FloatObject(value) for value in values])


def make_highlight(writer, row):
    bounds = union(row["rects"])
    points = []
    for x0, y0, x1, y1 in row["rects"]:
        points.extend((x0, y1, x1, y1, x0, y0, x1, y0))
    note = Highlight(rect=bounds, quad_points=floats(points), printing=True)
    color = COLORS[row["item"]["kind"]]
    note.update({
        NameObject("/Contents"): TextStringObject(row["content"]),
        NameObject("/NM"): TextStringObject(row["key"]),
        NameObject("/C"): floats(color),
    })

    appearance = DecodedStreamObject()
    commands = ["q /GS0 gs " + " ".join(map(str, color)) + " rg"]
    commands.extend(f"{x0} {y0} {x1-x0} {y1-y0} re f" for x0, y0, x1, y1 in row["rects"])
    commands.append("Q")
    appearance.set_data("\n".join(commands).encode("ascii"))
    blend = DictionaryObject({NameObject("/BM"): NameObject("/Multiply")})
    ext_states = DictionaryObject({NameObject("/GS0"): blend})
    appearance.update({
        NameObject("/Type"): NameObject("/XObject"),
        NameObject("/Subtype"): NameObject("/Form"),
        NameObject("/FormType"): NumberObject(1),
        NameObject("/BBox"): floats(bounds),
        NameObject("/Resources"): DictionaryObject({NameObject("/ExtGState"): ext_states}),
    })
    note[NameObject("/AP")] = DictionaryObject({NameObject("/N"): writer._add_object(appearance)})
    return note


def content_bytes(page):
    stream = page.get_contents()
    return b"" if stream is None else stream.get_data()


def note_signature(ref):
    note = ref.get_object()
    return tuple(str(note.get(key, "")) for key in (
        "/Subtype", "/NM", "/Contents", "/Rect", "/QuadPoints", "/T", "/M", "/CreationDate", "/C",
    ))


def validate(reader, rows, output):
    final = reader_for(output)
    if len(reader.pages) != len(final.pages):
        raise ValueError("Page count changed")
    expected_by_page = {}
    for row in rows:
        expected_by_page.setdefault(row["page"], []).append(row)
    for physical_page, (original, result) in enumerate(zip(reader.pages, final.pages), 1):
        if (original.rotation != result.rotation or original.mediabox != result.mediabox
                or original.cropbox != result.cropbox or content_bytes(original) != content_bytes(result)):
            raise ValueError(f"Physical page {physical_page} content or geometry changed")
        old_refs = note_refs(original)
        all_refs = note_refs(result)
        if [note_signature(ref) for ref in old_refs] != [note_signature(ref) for ref in all_refs[:len(old_refs)]]:
            raise ValueError(f"Original annotation changed on physical page {physical_page}")
        fresh_refs = all_refs[len(old_refs):]
        expected = expected_by_page.get(physical_page, [])
        if len(fresh_refs) != len(expected):
            raise ValueError(f"Unexpected number of new notes on physical page {physical_page}")
        for ref, row in zip(fresh_refs, expected):
            note = ref.get_object()
            if (note.get("/Subtype") != "/Highlight" or note.get("/NM") != row["key"]
                    or note.get("/Contents") != row["content"]):
                raise ValueError(f"Annotation does not match plan: {row['key']}")
            actual = read_rects(list(map(float, note.get("/QuadPoints", []))))
            if len(actual) != len(row["rects"]) or any(
                abs(a - b) > 0.001
                for box_a, box_b in zip(actual, row["rects"])
                for a, b in zip(box_a, box_b)
            ):
                raise ValueError(f"Annotation geometry differs from plan: {row['key']}")
    return {"pages": len(final.pages), "added_notes": len(rows)}


def make_listing(rows):
    lines = ["# PDF 审校问题清单", ""]
    if not rows:
        lines.extend(["本计划未列出需新增批注的问题。", ""])
    for number, row in enumerate(rows, 1):
        item = row["item"]
        lines.extend([
            f"## {number}. 第 {row['page']} 页 · {item['position']} · {LABELS[item['kind']]}",
            "",
            item["message"].strip(),
            "",
        ])
        if item.get("expected"):
            lines.extend([f"选取文字为「{item['expected']}」。", ""])
        if item.get("sources"):
            lines.extend([f"对应原批注 {'、'.join(item['sources'])}。", ""])
        if item.get("evidence"):
            lines.extend([str(item["evidence"]), ""])
    return "\n".join(lines)


def build(reader, rows, output, listing):
    if output.resolve() == listing.resolve() or output.exists() or listing.exists():
        raise ValueError("Use separate new paths for the annotated PDF and listing")
    writer = PdfWriter(clone_from=reader)
    for row in rows:
        writer.add_annotation(row["page"] - 1, make_highlight(writer, row))
    with tempfile.TemporaryDirectory(dir=output.parent) as folder:
        staged = Path(folder) / "annotated.pdf"
        writer.write(staged)
        summary = validate(reader, rows, staged)
        with listing.open("x", encoding="utf-8") as handle:
            try:
                handle.write(make_listing(rows))
                handle.flush()
                os.link(staged, output)
            except Exception:
                listing.unlink()
                raise
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    read = commands.add_parser("inspect")
    read.add_argument("source", type=Path)
    read.add_argument("inventory", type=Path)
    for action in ("build", "validate"):
        command = commands.add_parser(action)
        command.add_argument("source", type=Path)
        command.add_argument("plan", type=Path)
        command.add_argument("output", type=Path)
        if action == "build":
            command.add_argument("--list", required=True, type=Path, dest="listing")
    args = parser.parse_args()
    if args.command == "inspect":
        inspect(args.source, args.inventory)
        return
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    reader, rows = prepare(args.source, plan)
    if args.command == "build":
        summary = build(reader, rows, args.output, args.listing)
    else:
        summary = validate(reader, rows, args.output)
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()

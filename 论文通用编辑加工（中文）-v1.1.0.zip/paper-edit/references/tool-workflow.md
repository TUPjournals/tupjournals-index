# Word 工具流程

这些脚本适合常见 OOXML Word 文档中的普通文本。涉及复杂域、现代批注线程、修订交叠、受保护内容或特殊的编排部件时，用保留原生审阅结构的 Word 工具继续处理，并按 [Word 写入与验收](word-review.md) 复核。Python 脚本使用 `lxml`，优先选用宿主已有的文档工作环境。

以下命令从技能目录运行。先创建当前任务的 `work/`，实际文件路径按本次任务替换。

```bash
python scripts/inspect_docx.py 工作底稿.docx -o work/inventory.json
python scripts/add_precise_comments.py 工作底稿.docx work/comments.json work/含批注.docx
python scripts/apply_atomic_edits.py work/含批注.docx work/edits.json 论文_编辑加工.docx
python scripts/audit_docx.py 论文_编辑加工.docx --base 工作底稿.docx -o work/audit.json
```

有需要时运行 `inspect_docx.py` 的 `--include-deletions` 读取含删除文字的视图，以辅助理解历史修订。写入仍以普通诊断输出的最终可见文字为准。含批注底稿仍应在 Word 审阅界面核对批注状态及上下文。两项写入按实际需要分别使用。两项都使用且范围有交叠时，按审阅工具的能力重新确认锚点及操作次序。

## 写入计划

- 用 [修订示例](../assets/edits.example.json) 和 [批注示例](../assets/comments.example.json) 建立计划。定位符、起止偏移和 `expected` 按诊断结果填写。偏移以 Unicode 字符从 0 起算，结束位置不含末字符。插入用相同起止位置及空 `expected`，删除用空 `replacement`。
- 记录 [编辑台账](../assets/review-log.example.md) 中本任务需要的字段。每个问题先回到上下文裁决，再确定最小修改范围。一个段落的多项改动以同一次诊断的偏移为基础，须彼此独立。脚本遇到不安全的选区、原文不匹配、已有输出或不支持的结构会停止，请核对位置或切换编辑途径。
- 写入普通文本替换时，新插入内容沿用选区起始文字的字符格式。格式差异具有语义时，缩小选区到相同格式范围，或用 Word 工具处理。脚注及尾注的普通文字可以使用定位符进行修订。新增批注脚本用于主文档中的普通文本范围，脚注相关批注的替代锚点见 [Word 写入与验收](word-review.md)。

## 核验报告

检查 `warnings`、底稿与成品的结构差异、原有修订和批注是否有缺失，以及改变了哪些包部件。按编辑计划解释真实的结构变化，复核保留的意见与修订能否在 Word 中查看。报告只反映脚本可检查的结构，逐项核对最终正文、样式、引注和版面，必要时在验收副本测试接受和拒绝修订。

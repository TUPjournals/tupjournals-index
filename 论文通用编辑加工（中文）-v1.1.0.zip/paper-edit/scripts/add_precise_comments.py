#!/usr/bin/env python3
"""Add exact-range Word comments without changing selected text."""

from __future__ import annotations

import argparse
from lxml import etree as ET

from docx_common import (
    parse_xml,
    CT_NS,
    plain_span,
    REL_NS,
    clone_run_with_text,
    load_json_array,
    paragraph_elements,
    paragraph_top_level_map,
    parse_locator,
    qn,
    read_package,
    run_text,
    write_package,
    xml_bytes,
)

COMMENTS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
COMMENTS_CT = "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml"


def _next_comment_id(files: dict[str, bytes]) -> int:
    maximum = -1
    if "word/comments.xml" in files:
        root = parse_xml(files["word/comments.xml"])
        for comment in root.iter(qn("comment")):
            raw = comment.get(qn("id"))
            if raw and raw.isdigit():
                maximum = max(maximum, int(raw))
    return maximum + 1


def _ensure_comments_package(files: dict[str, bytes]) -> ET.Element:
    if "word/comments.xml" in files:
        comments_root = parse_xml(files["word/comments.xml"])
    else:
        comments_root = ET.Element(qn("comments"))

    rels_name = "word/_rels/document.xml.rels"
    if rels_name not in files:
        raise ValueError("word/_rels/document.xml.rels is missing")
    rels = parse_xml(files[rels_name])
    if not any(rel.get("Type") == COMMENTS_REL for rel in list(rels)):
        used = []
        for rel in list(rels):
            raw = rel.get("Id", "")
            if raw.startswith("rId") and raw[3:].isdigit():
                used.append(int(raw[3:]))
        relationship = ET.SubElement(rels, f"{{{REL_NS}}}Relationship")
        relationship.set("Id", f"rId{max(used, default=0) + 1}")
        relationship.set("Type", COMMENTS_REL)
        relationship.set("Target", "comments.xml")
        files[rels_name] = xml_bytes(rels)

    types_name = "[Content_Types].xml"
    types = parse_xml(files[types_name])
    if not any(
        node.get("PartName") == "/word/comments.xml" for node in list(types)
    ):
        override = ET.SubElement(types, f"{{{CT_NS}}}Override")
        override.set("PartName", "/word/comments.xml")
        override.set("ContentType", COMMENTS_CT)
        files[types_name] = xml_bytes(types)
    return comments_root


def _reference_run(comment_id: int) -> ET.Element:
    run = ET.Element(qn("r"))
    props = ET.SubElement(run, qn("rPr"))
    style = ET.SubElement(props, qn("rStyle"))
    style.set(qn("val"), "CommentReference")
    ref = ET.SubElement(run, qn("commentReference"))
    ref.set(qn("id"), str(comment_id))
    return run


def anchor_comment(paragraph: ET.Element, item: dict, comment_id: int) -> None:
    text, records = paragraph_top_level_map(paragraph)
    start, end = item.get("start"), item.get("end")
    if not isinstance(start, int) or not isinstance(end, int) or start < 0 or end <= start or end > len(text):
        raise ValueError(f"Comment requires a non-empty valid span; got {start}:{end}")
    expected = item.get("expected")
    if not isinstance(expected, str) or text[start:end] != expected:
        raise ValueError(
            f"expected mismatch: wanted {expected!r}, found {text[start:end]!r}"
        )
    affected = plain_span(paragraph, records, start, end)

    first = affected[0]["element"]
    last = affected[-1]["element"]
    affected_by_element = {id(r["element"]): r for r in affected}
    start_marker = ET.Element(qn("commentRangeStart"), {qn("id"): str(comment_id)})
    end_marker = ET.Element(qn("commentRangeEnd"), {qn("id"): str(comment_id)})
    new_children = []
    for child in list(paragraph):
        record = affected_by_element.get(id(child))
        if record is None:
            new_children.append(child)
            continue
        original = run_text(child)
        local_start = max(start, record["start"]) - record["start"]
        local_end = min(end, record["end"]) - record["start"]
        before = original[:local_start]
        selected = original[local_start:local_end]
        after = original[local_end:]
        if before:
            new_children.append(clone_run_with_text(child, before))
        if child is first:
            new_children.append(start_marker)
        new_children.append(clone_run_with_text(child, selected))
        if child is last:
            new_children.extend((end_marker, _reference_run(comment_id)))
        if after:
            new_children.append(clone_run_with_text(child, after))

    for child in list(paragraph):
        paragraph.remove(child)
    for child in new_children:
        paragraph.append(child)


def add_comments(input_docx: str, comments_json: str, output_docx: str) -> dict:
    files = read_package(input_docx)
    items = load_json_array(comments_json)
    extended_parts = {name for name in files if name.startswith(("word/commentsExtended", "word/commentsIds", "word/commentsExtensible"))}
    if extended_parts:
        raise ValueError("Use a Word-compatible editor to extend existing modern review threads")
    comments_root = _ensure_comments_package(files)
    next_id = _next_comment_id(files)
    roots: dict[str, ET.Element] = {}
    added = []
    grouped: dict[str, list[dict]] = {}
    for item in items:
        if not isinstance(item.get("locator"), str) or not isinstance(item.get("comment"), str):
            raise ValueError("Every comment requires locator and comment strings")
        if not item["comment"].strip() or any(ch in item["comment"] for ch in "\r\n\t"):
            raise ValueError("Empty comments are not allowed")
        grouped.setdefault(item["locator"], []).append(item)

    for loc, loc_items in grouped.items():
        part, index = parse_locator(loc)
        if part != "word/document.xml":
            raise ValueError(f"Use a Word-compatible editor to add comments outside the main story: {loc}")
        if part not in roots:
            roots[part] = parse_xml(files[part])
        root = roots[part]
        paragraphs = paragraph_elements(root)
        if index >= len(paragraphs):
            raise ValueError(f"Paragraph index out of range: {loc}")
        ordered = sorted(loc_items, key=lambda item: (item["start"], item["end"]), reverse=True)
        for item in ordered:
            comment_id = next_id
            next_id += 1
            anchor_comment(paragraphs[index], item, comment_id)
            comment = ET.SubElement(comments_root, qn("comment"))
            comment.set(qn("id"), str(comment_id))
            comment.set(qn("author"), "")
            p = ET.SubElement(comment, qn("p"))
            run = ET.SubElement(p, qn("r"))
            text_node = ET.SubElement(run, qn("t"))
            text_node.text = item["comment"].strip()
            added.append({"locator": loc, "comment_id": comment_id, "comment": item["comment"].strip()})

    for part, root in roots.items():
        files[part] = xml_bytes(root)
    files["word/comments.xml"] = xml_bytes(comments_root)
    write_package(files, output_docx)
    return {"output": output_docx, "added_count": len(added), "added": added}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_docx")
    parser.add_argument("comments_json")
    parser.add_argument("output_docx")
    args = parser.parse_args()
    result = add_comments(args.input_docx, args.comments_json, args.output_docx)
    print(f"Added {result['added_count']} comment(s) -> {result['output']}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Apply deterministic, character-offset tracked changes to plain DOCX runs."""

from __future__ import annotations

import argparse
from lxml import etree as ET

from docx_common import (
    parse_xml,
    clone_run_with_text,
    plain_span,
    word_story_parts,
    load_json_array,
    next_revision_id,
    paragraph_elements,
    paragraph_top_level_map,
    parse_locator,
    qn,
    read_package,
    run_text,
    write_package,
    xml_bytes,
)


def revision_wrapper(tag: str, revision_id: int) -> ET.Element:
    node = ET.Element(qn(tag))
    node.set(qn("id"), str(revision_id))
    node.set(qn("author"), "")
    return node


def _insertion_record(records: list[dict], position: int) -> dict | None:
    editable = [record for record in records if record["editable"]]
    for record in editable:
        if record["start"] <= position <= record["end"]:
            return record
    return editable[-1] if editable and position == editable[-1]["end"] else None


def apply_one(
    paragraph: ET.Element,
    edit: dict,
    revision_id: int,
) -> None:
    text, records = paragraph_top_level_map(paragraph)
    start = edit.get("start")
    end = edit.get("end")
    replacement = edit.get("replacement")
    if type(start) is not int or type(end) is not int or not isinstance(replacement, str):
        raise ValueError("start/end must be integers and replacement must be a string")
    if start < 0 or end < start or end > len(text):
        raise ValueError(f"Invalid span {start}:{end} for paragraph length {len(text)}")
    expected = edit.get("expected")
    if not isinstance(expected, str) or text[start:end] != expected:
        raise ValueError(
            f"expected mismatch: wanted {expected!r}, found {text[start:end]!r}"
        )
    if start == end and replacement == "":
        raise ValueError("No-op edit is not allowed")
    if text[start:end] == replacement:
        raise ValueError("Replacement is identical to selected text")

    if any(ch in replacement for ch in "\r\n\t"):
        raise ValueError("Use an editor for changes that introduce breaks or tabs")
    if any(node.tag in {qn("fldChar"), qn("instrText")} for node in paragraph.iter()):
        raise ValueError("Use a Word-compatible editor for paragraphs containing fields")
    children = list(paragraph)
    if start == end:
        target = _insertion_record(records, start)
        if target is None:
            if text or any(child.tag != qn("pPr") for child in children):
                raise ValueError("Insertion point is inside unsupported content")
            ins = revision_wrapper("ins", revision_id)
            ins.append(clone_run_with_text(None, replacement))
            paragraph.append(ins)
            return
        run = target["element"]
        local = start - target["start"]
        original = run_text(run)
        before, after = original[:local], original[local:]
        new_items = []
        if before:
            new_items.append(clone_run_with_text(run, before))
        ins = revision_wrapper("ins", revision_id)
        ins.append(clone_run_with_text(run, replacement))
        new_items.append(ins)
        if after:
            new_items.append(clone_run_with_text(run, after))
        index = children.index(run)
        children[index : index + 1] = new_items
    else:
        affected = plain_span(paragraph, records, start, end)
        last = affected[-1]["element"]
        template = affected[0]["element"]
        affected_by_element = {id(record["element"]): record for record in affected}
        new_children = []
        deletion = revision_wrapper("del", revision_id)
        for child in children:
            record = affected_by_element.get(id(child))
            if record is None:
                new_children.append(child)
                continue
            original = run_text(child)
            local_start = max(start, record["start"]) - record["start"]
            local_end = min(end, record["end"]) - record["start"]
            before = original[:local_start]
            deleted = original[local_start:local_end]
            after = original[local_end:]
            if before:
                new_children.append(clone_run_with_text(child, before))
            deletion.append(clone_run_with_text(child, deleted, deleted=True))
            if child is last:
                new_children.append(deletion)
                if replacement:
                    insertion = revision_wrapper("ins", revision_id + 1)
                    insertion.append(clone_run_with_text(template, replacement))
                    new_children.append(insertion)
            if after:
                new_children.append(clone_run_with_text(child, after))
        children = new_children

    for child in list(paragraph):
        paragraph.remove(child)
    for child in children:
        paragraph.append(child)


def apply_edits(input_docx: str, edits_path: str, output_docx: str) -> dict:
    files = read_package(input_docx)
    edits = load_json_array(edits_path)
    grouped: dict[str, list[dict]] = {}
    for edit in edits:
        if not isinstance(edit.get("locator"), str) or any(type(edit.get(key)) is not int for key in ("start", "end")):
            raise ValueError("Every edit requires a locator")
        grouped.setdefault(edit["locator"], []).append(edit)

    roots: dict[str, ET.Element] = {}
    next_id = next_revision_id(files)
    applied = []
    for loc, loc_edits in grouped.items():
        part, index = parse_locator(loc)
        if part not in word_story_parts(files):
            raise ValueError(f"Missing DOCX part for {loc}")
        if part not in roots:
            roots[part] = parse_xml(files[part])
        root = roots[part]
        paragraphs = paragraph_elements(root)
        if index >= len(paragraphs):
            raise ValueError(f"Paragraph index out of range: {loc}")
        ordered = sorted(loc_edits, key=lambda item: (item["start"], item["end"]), reverse=True)
        previous_start = None
        for edit in ordered:
            if previous_start is not None and (edit["end"] > previous_start or edit["start"] == previous_start):
                raise ValueError(f"Overlapping edits at {loc}")
            apply_one(paragraphs[index], edit, next_id)
            applied.append({"locator": loc, "revision_id": next_id, "edit": edit})
            next_id += 2
            previous_start = edit["start"]

    for part, root in roots.items():
        files[part] = xml_bytes(root)
    write_package(files, output_docx)
    return {"output": output_docx, "applied_count": len(applied), "applied": applied}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_docx")
    parser.add_argument("edits_json")
    parser.add_argument("output_docx")
    args = parser.parse_args()
    result = apply_edits(args.input_docx, args.edits_json, args.output_docx)
    print(f"Applied {result['applied_count']} tracked edit(s) -> {result['output']}")


if __name__ == "__main__":
    main()

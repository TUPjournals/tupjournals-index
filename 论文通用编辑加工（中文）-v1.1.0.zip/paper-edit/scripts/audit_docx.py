#!/usr/bin/env python3
"""Audit a reviewed DOCX and optionally compare it to its editing base."""
from argparse import ArgumentParser
from collections import Counter

from docx_common import json_dump, parse_xml, qn, read_package, word_story_parts

STRUCTURAL = {
    qn(name) for name in (
        "p", "tbl", "tr", "tc", "pStyle", "numPr", "footnote", "endnote",
        "footnoteReference", "endnoteReference", "drawing", "object", "fldChar", "instrText",
        "hyperlink", "bookmarkStart", "bookmarkEnd",
    )
}
MATH = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"


def inventory(files):
    structures = {}
    revisions = Counter()
    markers = {kind: Counter() for kind in ("commentReference", "commentRangeStart", "commentRangeEnd")}
    for part in word_story_parts(files):
        root = parse_xml(files[part])
        structures[part] = [
            (node.tag, sorted(node.attrib.items()), node.text)
            for node in root.iter()
            if isinstance(node.tag, str) and (node.tag in STRUCTURAL or node.tag.startswith(MATH))
        ]
        for kind in markers:
            markers[kind].update(node.get(qn("id")) for node in root.iter(qn(kind)))
        for kind in ("ins", "del", "moveFrom", "moveTo"):
            revisions.update((part, kind, node.get(qn("id"))) for node in root.iter(qn(kind)))

    definition_data = files.get("word/comments.xml")
    definitions = Counter()
    if definition_data:
        definitions.update(node.get(qn("id")) for node in parse_xml(definition_data).iter(qn("comment")))
    warnings = []
    for name, counts in markers.items():
        unknown = sorted(str(key) for key in counts.keys() - definitions.keys())
        if unknown:
            warnings.append({"kind": "undefined_comment_marker", "marker": name, "ids": unknown})
    if markers["commentRangeStart"] != markers["commentRangeEnd"]:
        warnings.append({"kind": "unpaired_comment_ranges"})
    if definitions.keys() - markers["commentReference"].keys():
        warnings.append({"kind": "unreferenced_comment", "ids": sorted(
            str(key) for key in definitions.keys() - markers["commentReference"].keys()
        )})
    if any(count > 1 for count in definitions.values()):
        warnings.append({"kind": "duplicate_comment_ids"})
    if None in definitions or any(None in counts for counts in markers.values()):
        warnings.append({"kind": "missing_comment_id"})

    if definitions:
        rels = files.get("word/_rels/document.xml.rels")
        types = files.get("[Content_Types].xml")
        if not rels or not any(
            rel.get("Type", "").endswith("/comments") and rel.get("Target") in ("comments.xml", "/word/comments.xml")
            for rel in parse_xml(rels)
        ):
            warnings.append({"kind": "missing_comment_relationship"})
        if not types or not any(
            node.get("PartName") == "/word/comments.xml"
            and node.get("ContentType") == "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml"
            for node in parse_xml(types)
        ):
            warnings.append({"kind": "missing_comment_content_type"})
    return structures, revisions, definitions, warnings


def audit(path, base=None):
    files = read_package(path)
    structures, revisions, definitions, warnings = inventory(files)
    report = {
        "story_parts": sorted(structures),
        "revision_elements": sum(revisions.values()),
        "comment_definitions": sum(definitions.values()),
        "warnings": warnings,
    }
    if base:
        prior = read_package(base)
        prior_structures, prior_revisions, prior_definitions, _ = inventory(prior)
        report["structural_differences"] = [
            part for part in sorted(structures.keys() | prior_structures.keys())
            if structures.get(part) != prior_structures.get(part)
        ]
        report["missing_prior_revision_elements"] = sum((prior_revisions - revisions).values())
        report["missing_prior_comment_definitions"] = sum((prior_definitions - definitions).values())
        report["package_changes"] = [
            name for name in sorted(files.keys() | prior.keys()) if files.get(name) != prior.get(name)
        ]
    return report


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("docx")
    parser.add_argument("--base")
    parser.add_argument("-o", "--output")
    args = parser.parse_args()
    json_dump(audit(args.docx, args.base), args.output)


if __name__ == "__main__":
    main()

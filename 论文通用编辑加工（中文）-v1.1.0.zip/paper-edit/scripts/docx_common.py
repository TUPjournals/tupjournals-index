#!/usr/bin/env python3
"""Shared, deterministic OOXML helpers for manuscript editing."""

from __future__ import annotations

import copy
import json
import os
import re
import tempfile
import zipfile
from pathlib import Path
from lxml import etree as ET

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
XML_NS = "http://www.w3.org/XML/1998/namespace"

NS = {"w": W_NS, "r": R_NS}

ET.register_namespace("w", W_NS)
ET.register_namespace("r", R_NS)


def parse_xml(data: bytes) -> ET._Element:
    parser = ET.XMLParser(resolve_entities=False, no_network=True)
    root = ET.fromstring(data, parser)
    if root.getroottree().docinfo.doctype:
        raise ValueError("Unexpected XML document type")
    return root


def qn(local: str, namespace: str = W_NS) -> str:
    return f"{{{namespace}}}{local}"


def xml_bytes(root: ET.Element) -> bytes:
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def read_package(path: str | os.PathLike[str]) -> dict[str, bytes]:
    with zipfile.ZipFile(path, "r") as package:
        bad = package.testzip()
        if bad:
            raise ValueError(f"DOCX ZIP CRC error: {bad}")
        names = package.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate DOCX package entries")
        files = {name: package.read(name) for name in names}
    if "word/document.xml" not in files:
        raise ValueError("Missing main DOCX document part")
    if parse_xml(files["word/document.xml"]).tag != qn("document"):
        raise ValueError("Use a Word-compatible editor for this OOXML variant")
    return files


def write_package(
    files: dict[str, bytes], output: str | os.PathLike[str]
) -> None:
    output_path = Path(output).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{output_path.stem}-", suffix=".docx", dir=output_path.parent
    )
    os.close(fd)
    try:
        with zipfile.ZipFile(temp_name, "w", zipfile.ZIP_DEFLATED) as package:
            for name, data in files.items():
                package.writestr(name, data)
        with zipfile.ZipFile(temp_name, "r") as check:
            bad = check.testzip()
            if bad:
                raise ValueError(f"Generated DOCX ZIP CRC error: {bad}")
        os.link(temp_name, output_path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def word_story_parts(files: dict[str, bytes]) -> list[str]:
    patterns = (
        r"^word/document\.xml$",
        r"^word/header\d+\.xml$",
        r"^word/footer\d+\.xml$",
        r"^word/footnotes\.xml$",
        r"^word/endnotes\.xml$",
    )
    result = []
    for name in files:
        if any(re.match(pattern, name) for pattern in patterns):
            result.append(name)
    return sorted(result, key=lambda n: (n != "word/document.xml", n))


def paragraph_elements(root: ET.Element) -> list[ET.Element]:
    return list(root.iter(qn("p")))


def locator(part: str, index: int) -> str:
    return f"{part}#p{index + 1:06d}"


def parse_locator(value: str) -> tuple[str, int]:
    match = re.fullmatch(r"(.+)#p(\d{6})", value)
    if not match or int(match.group(2)) < 1:
        raise ValueError(f"Invalid locator: {value}")
    return match.group(1), int(match.group(2)) - 1


def _text_recursive(node: ET.Element, include_deletions: bool) -> str:
    if node.tag in (qn("del"), qn("moveFrom")) and not include_deletions:
        return ""
    if node.tag in (qn("t"), qn("delText")):
        return node.text or ""
    if node.tag == qn("tab"):
        return "\t"
    if node.tag in (qn("br"), qn("cr")):
        return "\n"
    return "".join(_text_recursive(child, include_deletions) for child in node if child.tag != qn("p"))


def visible_text(paragraph: ET.Element, include_deletions: bool = False) -> str:
    return _text_recursive(paragraph, include_deletions)


def run_text(run: ET.Element) -> str:
    return "".join((node.text or "") for node in run.findall(".//w:t", NS))


def run_is_plain_text(run: ET.Element) -> bool:
    allowed = {qn("rPr"), qn("t")}
    return all(child.tag in allowed for child in list(run))


def clone_run_with_text(
    run: ET.Element | None, text: str, *, deleted: bool = False
) -> ET.Element:
    new_run = ET.Element(qn("r")) if run is None else copy.deepcopy(run)
    for child in list(new_run):
        if child.tag != qn("rPr"):
            new_run.remove(child)
    text_node = ET.SubElement(new_run, qn("delText" if deleted else "t"))
    if text[:1].isspace() or text[-1:].isspace():
        text_node.set(qn("space", XML_NS), "preserve")
    text_node.text = text
    return new_run


def paragraph_top_level_map(paragraph: ET.Element) -> tuple[str, list[dict]]:
    """Map visible offsets; only direct w:r entries are editable."""
    records: list[dict] = []
    offset = 0
    pieces: list[str] = []
    for child_index, child in enumerate(list(paragraph)):
        if child.tag in (qn("pPr"), qn("del"), qn("moveFrom")):
            continue
        text = _text_recursive(child, include_deletions=False)
        if not text:
            continue
        start = offset
        offset += len(text)
        pieces.append(text)
        records.append(
            {
                "child_index": child_index,
                "element": child,
                "start": start,
                "end": offset,
                "text": text,
                "editable": child.tag == qn("r") and run_is_plain_text(child),
            }
        )
    return "".join(pieces), records


def load_json_array(path: str | os.PathLike[str]) -> list[dict]:
    with open(path, "r", encoding="utf-8-sig") as handle:
        value = json.load(handle)
    if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
        raise ValueError("Input JSON must be an array of objects")
    return value


def next_revision_id(files: dict[str, bytes]) -> int:
    maximum = 0
    for name, data in files.items():
        if not name.startswith("word/") or not name.endswith(".xml"):
            continue
        try:
            root = parse_xml(data)
        except ET.ParseError:
            continue
        for node in root.iter():
            raw = node.get(qn("id"))
            if raw and raw.isdigit():
                maximum = max(maximum, int(raw))
    return maximum + 1


def plain_span(paragraph, records, start, end):
    if any(node.tag in {qn("fldChar"), qn("instrText")} for node in paragraph.iter()):
        raise ValueError("Use a Word-compatible editor for paragraphs containing fields")
    selected = [record for record in records if record["end"] > start and record["start"] < end]
    if not selected or any(not record["editable"] for record in selected):
        raise ValueError("Selection touches an unsupported run or existing revision")
    indices = range(selected[0]["child_index"], selected[-1]["child_index"] + 1)
    if set(indices) != {record["child_index"] for record in selected}:
        raise ValueError("Selection crosses an object or an existing review boundary")
    return selected


def json_dump(value: object, path: str | None = None) -> None:
    text = json.dumps(value, ensure_ascii=False, indent=2)
    if path:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(text + "\n")
    else:
        print(text)

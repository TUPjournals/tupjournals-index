#!/usr/bin/env python3
"""Inventory DOCX story parts and produce stable paragraph locators."""

from __future__ import annotations

import argparse
from pathlib import Path
from lxml import etree as ET

from docx_common import (
    parse_xml,
    NS,
    json_dump,
    locator,
    paragraph_elements,
    qn,
    read_package,
    visible_text,
    word_story_parts,
)


def inspect(path: str, include_deletions: bool = False) -> dict:
    files = read_package(path)
    result = {
        "source": str(Path(path).resolve()),
        "paragraph_count": 0,
        "parts": [],
        "unsupported_or_unavailable": [],
    }
    for unavailable in ("word/commentsExtended.xml", "word/glossary/document.xml"):
        if unavailable in files:
            result["unsupported_or_unavailable"].append(unavailable)

    for part in word_story_parts(files):
        root = parse_xml(files[part])
        paragraphs = []
        for index, paragraph in enumerate(paragraph_elements(root)):
            text = visible_text(paragraph, include_deletions=include_deletions)
            direct_text = "".join(
                visible_text(child, include_deletions=include_deletions)
                for child in list(paragraph)
                if child.tag == qn("r")
            )
            paragraphs.append(
                {
                    "locator": locator(part, index),
                    "text": text,
                    "style": (
                        paragraph.find("w:pPr/w:pStyle", NS).get(qn("val"))
                        if paragraph.find("w:pPr/w:pStyle", NS) is not None
                        else None
                    ),
                    "in_table": any(paragraph.iterancestors(qn("tbl"))),
                    "has_formula": any(node.tag == "{http://schemas.openxmlformats.org/officeDocument/2006/math}oMath" for node in paragraph.iter()),
                    "note_references": [
                        {"kind": node.tag.rsplit("}", 1)[-1], "id": node.get(qn("id"))}
                        for node in paragraph.iter()
                        if node.tag in (qn("footnoteReference"), qn("endnoteReference"))
                    ],
                    "has_tracked_changes": any(
                        paragraph.find(f".//w:{tag}", NS) is not None
                        for tag in ("ins", "del", "moveFrom", "moveTo")
                    ),
                    "has_hyperlink_or_content_control": any(
                        paragraph.find(f".//w:{tag}", NS) is not None
                        for tag in ("hyperlink", "sdt")
                    ),
                    "direct_text_matches": direct_text == text,
                }
            )
        result["parts"].append({"part": part, "paragraphs": paragraphs})
        result["paragraph_count"] += len(paragraphs)

    comment_parts = [name for name in files if name.startswith("word/comments") and name.endswith(".xml")]
    result["comment_parts"] = sorted(comment_parts)
    if "word/comments.xml" in files:
        comments = parse_xml(files["word/comments.xml"])
        result["comments"] = [
            {"id": node.get(qn("id")), "text": "\n".join(visible_text(p) for p in paragraph_elements(node))}
            for node in comments.iter(qn("comment"))
        ]
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_docx")
    parser.add_argument("-o", "--output")
    parser.add_argument("--include-deletions", action="store_true")
    args = parser.parse_args()
    json_dump(inspect(args.input_docx, args.include_deletions), args.output)


if __name__ == "__main__":
    main()

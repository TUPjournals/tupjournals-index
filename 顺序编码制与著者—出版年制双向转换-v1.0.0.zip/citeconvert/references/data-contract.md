# 后台数据与转换计划

工作文件留在项目私有工作区。JSON为UTF-8。脚本名是执行入口，不要求普通用户理解或填写这些数据。

## 提取快照

`inspect_docx.py`输出source/source_sha256、units、note_links、warnings、candidates。单元ID为`word/document.xml#p000012`，部件段落序号从0开始，包括表格段落和嵌套段落。最终可见文本排除删除修订、保留插入；域显示信息与上标样式另读原XML。

候选不是实际引注，样本年份、公式区间可是假阳性。没有括号的上标引用、重复叙述省年、脚注全著录须人工补查。每个初始候选保留原范围、理由和去向；误报设not_citation，实引设citation并关联occurrence_ids，不能删除候选来通过检查。

## model.json

顶层包括source、source_sha256、coverage_confirmed、mapping_confirmed、coverage、candidates、references、occurrences、bibliography_units，以及需要时的target_order。

coverage覆盖快照全部unit_id，每项写state=checked或excluded和reason。图内、不可提取部分另记录人工检查；无法读清且影响引注映射时不设mapping_confirmed。脚注引用顺序与表图次序核对后给occurrences分配全局order，不能直接按units数组位置编号。

文献结构示意（字段内容由实际原题录填写，不是格式默认值）：

```json
{
  "id": "r01", "mapping_verified": true,
  "authors": ["person:001", "person:002"],
  "author_label": "核准的目标显示形式", "year": "2020",
  "source_numbers": [7],
  "fields": {"authors": "完整目标作者字段", "title": "原题名", "source": "原来源"},
  "blocks": [{"unit_id": "word/document.xml#p000050", "template_key": "期刊论文"}]
}
```

mapping_verified表示版本身份和原引文指向已核准，不表示完成真实性审查。authors是完整著者组合的身份键，author_label是按用户规则生成且已消歧的显示形式，二者不可混用。无日期/待刊的year使用核准的目标表述。source_numbers记录原顺序编码制中该版本的编号；不同原号是否同版须先确认，不能为合并而猜测。

每个条目可有多个blocks（例如中英配对两个段落），每段选择自己的模板。bibliography_units必须按源稿顺序包含恰好全部blocks，且不含其后的英文摘要/附录。脚本仅对同一容器内连续文献段落重排；否则使用原生编辑。

引注出现结构：

```json
{
  "id": "o01", "unit_id": "word/document.xml#p000012",
  "start": 4, "end": 7, "raw": "[7]", "order": 0,
  "source_system": "numeric", "form": "narrative",
  "atoms": [{"ref_id": "r01", "source_number": 7, "locator": "12—15"}]
}
```

start/end是未经规范化的可见文本Unicode偏移，end不含末字符。raw必须完整等于原范围。上述locator仅示意独立定位信息；它必须来自实际原文范围或明确的关联位置，不能为了示例给无页码原引文增加页码。

form=narrative表示作者已在替换范围之外承担正文成分，只替换引注标签；parenthetical表示需完整括注。原文有年份叙述时，保留承担时间意义的正文。数字引注的每个atom记录source_number并与原题录source_numbers对应；纯数字括号还与区间展开结果逐项比对。

target_order是经核准的**全部文献ID**排列，用于著者—出版年制列表排序，也可用于同组多篇首次出现的优先次序。排序必须按用户配置核中文音序、语种和姓名，不是让模型随意排列。

## profile.json

从assets空模板复制，填写profile_id、status=ready、target_system=numeric/author_year、materials和rule_evidence，规则证据至少能定位用户样例的页/段落及适用对象。未配置null不传给执行器；不使用内置样例自动补值。

- numeric：open/close、separator、range、compress_min（至少2；设置足够大可禁用）、sort_group、superscript、first_group_order=source/explicit、locator_template、item_template。模板有`{number}`与`{locator}`；显式first_group_order须提供target_order。
- author_year：open/close、separator、item_template（`{author}`、`{year}`、`{locator}`）、narrative_item_template（`{year}`、`{locator}`）、locator_template、group_order=source/bibliography、suffix_order=bibliography/first_citation。特定目标用其他排序时先形成核准的显式顺序，再适配渲染器，不能硬套。
- bibliography：uncited_policy=retain_append/review；number_template；templates为按文献类型区分的片段数组，每片有template及可选italic/bold/font/east_asia/size_pt。required_fields按模板列必需字段。paragraph_format可明确left_indent_pt/hanging_pt/space_before_pt/space_after_pt；未给时沿用段落基础格式。

模板占位符只允许普通字段名，不执行表达式。日期可用year（基础日期）或year_suffix（含消歧后缀）；著者—出版年制有同年多作时文末模板必须显示year_suffix。目标字段缺失时不能默默删掉占位符；先核原始来源，必要时经用户规则设立缺项变体模板并批注。

并引有共同前导文字、不同层级上标、同作者多年份合写或特殊叙述结构时，可给occurrence设置override_runs（显式格式片段）、override_basis及override_atoms（与原atoms完全相同）。这只是安全适配通道，仍须人工核对片段没有丢作者、年份、定位或正文语义，不能用它绕过未决身份。

目标要求移动引注与句号的前后关系时，将需要联动的最小标点范围一并纳入原跨度，在override_runs中明确改后次序；完整句子代入后再读，不扩大成整句重写。上下标只作用于目标指定片段，外侧标点与页码是否上标分别配置。

## plan.json与验收

生成器输出edits、bibliography_blocks、reference_order、numbers、suffixes、原子数及输入哈希。每项edit带原文范围和atoms，用于复核前后引用对象及页码。只有模型与配置完整才写计划。

apply脚本在内存中完成全部操作，任一关键锚点或复杂结构不支持便拒绝写文件，不产生半成品。verify重新从核准模型及配置生成计划，确认成品只有计划允许的精确改动。它不证明人工样例判断正确，也不把override_runs视为内容支持证据。

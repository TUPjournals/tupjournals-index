# 执行入口与依赖

Python 3.10+，lxml用于保持DOCX命名空间和结构。先使用环境现有依赖；不把开发机用户名、运行时绝对路径或真实稿件写入分发包。普通用户只需提供稿件与样例，无须运行命令。

```bash
python SKILL_DIR/scripts/inspect_docx.py 稿件.docx -o work/citeconvert-private/snapshot.json
```

按data-contract.md将人工核准的映射写入model.json，将用户样例对应规则写入profile.json，再执行：

```bash
python SKILL_DIR/scripts/plan.py work/citeconvert-private/model.json work/citeconvert-private/profile.json work/citeconvert-private/snapshot.json -o work/citeconvert-private/plan.json
python SKILL_DIR/scripts/apply_docx.py 稿件.docx work/citeconvert-private/plan.json -o 转换稿.docx --receipt work/citeconvert-private/receipt.json
python SKILL_DIR/scripts/verify.py 稿件.docx 转换稿.docx work/citeconvert-private/plan.json work/citeconvert-private/model.json work/citeconvert-private/profile.json work/citeconvert-private/snapshot.json -o work/citeconvert-private/verification.json
```

“SKILL_DIR”替换为当前技能目录；示意文件名不是真实输入。脚本不自动判断期刊、不自动套国标/APA、不擅自搜索整篇稿件。缺失元数据只在转换需要时定向查公开题录，并记录来源，不上传用户完整稿件或私有配置。

复杂字段管理器、动态编号、已有修订重叠、跨容器文末列表等参见document-editing.md，用原生编辑能力补位；不能静默跳过。用户明确要修订痕迹时以原生修订实现，普通写入器不会假装生成修订稿。

测试：`python -m unittest discover -s SKILL_DIR/tests -v`。只使用合成稿、显式合成配置和本地临时目录，不联网、不依赖真实刊物。测试覆盖两个方向、同年后缀、连续区间、叙述式、引文页码、重复引用同号、原号错配拒绝、范围外文字保持与结构失败不写半成品。测试一次通过后不扩大到无关审校。

# 理解任务所用的公共资料

资料核对日期：2026-11-16。以下来源仅帮助理解引用机制与易混情形，不构成本技能默认目标配置，不将其例式作为用户期刊的规则。

- [GB/T 7714—2025官方信息](https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=C6CE52E55AC09B9C79A20AEA77CEDD14)：官方页面确认标准名称、版本及实施信息；页面提示版权原因不提供文本阅读。本包不声称已逐条核准正式全文条款，不把旧版或征求意见稿冒充现行条款。
- [APA当前官方手册页面](https://apastyle.apa.org/products/publication-manual-7th-edition)：本次核对的官方手册为第7版；后续任务涉及版本应再核官方页面。
- [APA著者—日期制说明](https://apastyle.apa.org/style-grammar-guidelines/citations/basic-principles/author-date)：用于理解文内标签与对应条目、日期以及消歧的关系，不默认采用其作者省略或排序。
- [APA括注与叙述式区别](https://apastyle.apa.org/style-grammar-guidelines/citations/basic-principles/parenthetical-versus-narrative)：用于识别作者已经承担句子成分时，不能在转换中机械删掉或重复该作者。

转换的具体括号、标点、字体、上标、作者形式、年份位置、列表著录与排序，只取用户当前材料及明确要求。需要引用标准具体条款时取得可核准的正式文本或官方公开说明；无法核实不编条号。

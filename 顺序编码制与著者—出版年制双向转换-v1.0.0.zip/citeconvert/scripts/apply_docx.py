#!/usr/bin/env python3
"""Apply verified citation spans and bibliography block moves to a DOCX copy."""
from __future__ import annotations
import argparse
import copy
import io
import zipfile
from pathlib import Path
from lxml import etree as E
from common import q, visible, load, digest, atomic, write, require_new

def text_run(text, props=None, formatting=None):
    r=E.Element(q('r'))
    rp=copy.deepcopy(props) if props is not None else E.Element(q('rPr'))
    r.append(rp)
    fmt=formatting or {}
    for key,tag in [('italic','i'),('bold','b')]:
        if key in fmt:
            for n in list(rp.findall(q(tag))):
                rp.remove(n)
            E.SubElement(rp,q(tag)).set(q('val'),'1' if fmt[key] else '0')
    if 'superscript' in fmt:
        for n in list(rp.findall(q('vertAlign'))):
            rp.remove(n)
        E.SubElement(rp,q('vertAlign')).set(q('val'),'superscript' if fmt['superscript'] else 'baseline')
    if fmt.get('font') or fmt.get('east_asia'):
        fonts=rp.find(q('rFonts'))
        if fonts is None:
            fonts=E.SubElement(rp,q('rFonts'))
        if fmt.get('font'):
            for k in ('ascii','hAnsi'):
                fonts.set(q(k),fmt['font'])
        if fmt.get('east_asia'):
            fonts.set(q('eastAsia'),fmt['east_asia'])
    if fmt.get('size_pt') is not None:
        for n in list(rp.findall(q('sz'))):
            rp.remove(n)
        E.SubElement(rp,q('sz')).set(q('val'),str(round(fmt['size_pt']*2)))
    # Soft line breaks stay inside one reference block.
    for i,line in enumerate(text.split('\n')):
        if i:
            E.SubElement(r,q('br'))
        t=E.SubElement(r,q('t'))
        t.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
        t.text=line
    return r

def simple_run(r):
    return r.tag==q('r') and all(n.tag in {q('rPr'),q('t')} for n in r)

def replace_span(p,start,end,expected,runs):
    raw=visible(p)
    if not (type(start) is int and type(end) is int and 0<=start<end<=len(raw)) or raw[start:end]!=expected:
        raise ValueError('Source range does not equal expected text')
    result=[]
    cursor=0
    inserted=False
    for child in list(p):
        if child.tag==q('pPr'):
            result.append(child)
            continue
        text=visible(child)
        length=len(text)
        a,b=cursor,cursor+length
        if length==0:
            if start<cursor<end:
                raise ValueError('Target crosses a bookmark, comment, field or other inline object')
            result.append(child)
        elif b<=start or a>=end:
            result.append(child)
        else:
            if not simple_run(child):
                raise ValueError('Target contains hyperlink, revision, field or non-text object; use native editing')
            props=child.find(q('rPr'))
            left=max(0,start-a)
            right=min(length,end-a)
            if left:
                result.append(text_run(text[:left],props))
            if not inserted:
                for segment in runs:
                    result.append(text_run(segment['text'],props,segment))
                inserted=True
            if right<length:
                result.append(text_run(text[right:],props))
        cursor=b
    if not inserted:
        raise ValueError('No safe target runs found')
    for child in list(p):
        p.remove(child)
    for child in result:
        p.append(child)
    rendered=''.join(s['text'] for s in runs)
    if visible(p)!=raw[:start]+rendered+raw[end:]:
        raise ValueError('Replacement affected text outside planned span')

def format_paragraph(p,fmt):
    if not fmt:
        return
    pp=p.find(q('pPr'))
    if pp is None:
        pp=E.Element(q('pPr'));p.insert(0,pp)
    attrs={'left_indent_pt':('ind','left'),'hanging_pt':('ind','hanging'),
           'space_after_pt':('spacing','after'),'space_before_pt':('spacing','before')}
    for key,value in fmt.items():
        if value is None:
            continue
        if key not in attrs or not isinstance(value,(int,float)):
            raise ValueError('Unsupported paragraph format; use native editing')
        tag,attr=attrs[key]
        node=pp.find(q(tag))
        if node is None:
            node=E.SubElement(pp,q(tag))
        node.set(q(attr),str(round(value*20)))

def transform(source,plan):
    if digest(source)!=plan['source_sha256']:
        raise ValueError('Source differs from plan hash')
    with zipfile.ZipFile(source) as z:
        entries=[(info,z.read(info.filename)) for info in z.infolist()]
    files={info.filename:data for info,data in entries}
    roots={}
    nodes={}
    requested={e['unit_id'] for e in plan['edits']} | set(plan['bibliography_units'])
    for uid in requested:
        part,index=uid.rsplit('#p',1)
        if part not in files:
            raise ValueError('Target story part missing')
        if part not in roots:
            roots[part]=E.fromstring(files[part])
        ps=list(roots[part].iter(q('p')))
        i=int(index)
        if not 0<=i<len(ps):
            raise ValueError('Paragraph index out of range')
        nodes[uid]=ps[i]
    grouped={}
    for edit in plan['edits']:
        grouped.setdefault(edit['unit_id'],[]).append(edit)
    for uid,edits in grouped.items():
        for e in sorted(edits,key=lambda x:x['start'],reverse=True):
            replace_span(nodes[uid],e['start'],e['end'],e['expected'],e['runs'])
    biblio=plan['bibliography_blocks']
    if len({b['unit_id'] for b in biblio})!=len(biblio) or {b['unit_id'] for b in biblio}!=set(plan['bibliography_units']):
        raise ValueError('List block coverage mismatch')
    if not biblio:
        raise ValueError('Reference list is empty or not identified')
    original=[nodes[uid] for uid in plan['bibliography_units']]
    parent=original[0].getparent()
    if any(n.getparent() is not parent for n in original):
        raise ValueError('Reference list spans different containers; use native structured editing')
    indexes=[parent.index(n) for n in original]
    if indexes!=list(range(min(indexes),max(indexes)+1)):
        raise ValueError('List range has unaccounted paragraphs/objects or wrong source order')
    for block in biblio:
        node=nodes[block['unit_id']]
        if visible(node)!=block['expected']:
            raise ValueError('Stale bibliography source text')
        if any(c.tag!=q('pPr') and not simple_run(c) for c in node):
            raise ValueError('Reference contains a field, hyperlink, bookmark or review object; use native editing')
        if any(n.tag==q('numPr') for n in node.iter()):
            raise ValueError('Automatic list numbering needs native numbering handling')
        pp=node.find(q('pPr'))
        for c in list(node):
            if c is not pp:
                node.remove(c)
        for segment in block['runs']:
            node.append(text_run(segment['text'],formatting={'superscript':False,**segment}))
        format_paragraph(node,block.get('paragraph_format',{}))
    insertion=min(indexes)
    for n in original:
        parent.remove(n)
    for i,block in enumerate(biblio):
        parent.insert(insertion+i,nodes[block['unit_id']])
    for part,root in roots.items():
        files[part]=E.tostring(root,encoding='utf-8',xml_declaration=True)
    return entries,files

def apply(source,plan,output):
    require_new(source,output)
    entries,files=transform(source,plan)
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        for info,_ in entries:
            z.writestr(info,files[info.filename])
    atomic(output,buf.getvalue())
    return {'source_sha256':digest(source),'output_sha256':digest(output),
            'occurrences':len(plan['edits']),'references':len(plan['reference_order']),
            'changed_parts':[i.filename for i,raw in entries if files[i.filename]!=raw],
            'visual_review_required':True}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source');p.add_argument('plan');p.add_argument('-o','--output',required=True)
    p.add_argument('--receipt',required=True)
    a=p.parse_args()
    write(a.receipt,apply(a.source,load(a.plan),a.output))

if __name__=='__main__':
    main()

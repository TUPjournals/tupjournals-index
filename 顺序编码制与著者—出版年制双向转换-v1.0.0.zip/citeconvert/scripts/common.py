"""Local package utilities. All writing uses an explicit destination."""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
from pathlib import Path

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}

def q(name):
    return '{' + W + '}' + name

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.citeconvert-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)

def write(path, value):
    atomic(path, (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode())

def require_new(source, output):
    if Path(source).resolve() == Path(output).resolve():
        raise ValueError('Refusing to overwrite source')

def visible(node):
    result = []
    def visit(n, root=False):
        if n.tag in {q('del'), q('moveFrom')}:
            return
        if not root and n.tag == q('p'):
            return
        if n.tag == q('t'):
            result.append(n.text or '')
        elif n.tag == q('tab'):
            result.append('\t')
        elif n.tag in {q('br'), q('cr')}:
            result.append('\n')
        else:
            for child in n:
                visit(child)
    visit(node, True)
    return ''.join(result)

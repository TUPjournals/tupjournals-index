#!/usr/bin/env python3
"""Inspect DOCX text, notes and candidate markers; no conversion decisions."""
from __future__ import annotations
import argparse
import re
import zipfile
from pathlib import Path
from lxml import etree as E
from common import q, visible, digest, write

PAREN = re.compile(r'\[[^\[\]\r\n]{1,200}\]|［[^［］\r\n]{1,200}］|\([^()\r\n]{1,200}\)|（[^（）\r\n]{1,200}）')
YEAR = re.compile(r'(?<!\d)(?:1\d{3}|20\d{2}|21\d{2})[a-z]?(?!\d)|\bn\.?\s*d\.?\b|待刊|in press',re.I)
NUMERIC = re.compile(r'[\[［]\s*\d+(?:\s*[,，、;；—–\-]\s*\d+)*\s*[\]］]')

def inspect_docx(source):
    units, warnings, note_links = [], [], []
    with zipfile.ZipFile(source) as z:
        for name in sorted(z.namelist(), key=lambda x: (x != 'word/document.xml',x)):
            if not re.fullmatch(r'word/(document|footnotes|endnotes|header\d+|footer\d+)\.xml',name):
                continue
            root = E.fromstring(z.read(name))
            for i, p in enumerate(root.iter(q('p'))):
                if any(n.tag in {q('del'),q('moveFrom')} for n in p.iterancestors()):
                    continue
                if any(n.get(q('type')) in {'separator','continuationSeparator'} for n in p.iterancestors()):
                    continue
                uid = f'{name}#p{i:06d}'
                text = visible(p)
                kinds = []
                tags = {n.tag for n in p.iter()}
                for tag, label in [('fldChar','field'),('instrText','field'),('ins','revisions'),('del','revisions'),
                                   ('hyperlink','hyperlink'),('txbxContent','textbox'),('drawing','image'),
                                   ('commentRangeStart','existing_comment')]:
                    if q(tag) in tags:
                        kinds.append(label)
                region = 'textbox' if any(n.tag == q('txbxContent') for n in p.iterancestors()) else (
                    'table' if any(n.tag == q('tc') for n in p.iterancestors()) else Path(name).stem)
                units.append({'id':uid,'part':name,'paragraph':i,'region':region,'text':text,'complex':sorted(set(kinds))})
                for typ in ('footnoteReference','endnoteReference'):
                    for marker in p.iter(q(typ)):
                        note_links.append({'anchor_unit':uid,'type':typ,'note_id':marker.get(q('id'))})
                if kinds:
                    warnings.append({'unit_id':uid,'kinds':sorted(set(kinds))})
    result = {'source':str(Path(source).resolve()),'source_sha256':digest(source),
              'units':units,'note_links':note_links,'warnings':warnings}
    result['candidates'] = scan_candidates(result)
    return result

def scan_candidates(snapshot):
    out = []
    for u in snapshot['units']:
        for m in PAREN.finditer(u['text']):
            if YEAR.search(m.group()) or NUMERIC.fullmatch(m.group()):
                out.append({'id':f'c{len(out)+1:06d}','unit_id':u['id'],'start':m.start(),
                            'end':m.end(),'raw':m.group(),'decision':'pending'})
    return out

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source')
    p.add_argument('-o','--output',required=True)
    a = p.parse_args()
    if Path(a.source).suffix.lower() != '.docx':
        raise ValueError('Provide an editable DOCX; PDF needs an explicit restoration workflow')
    write(a.output, inspect_docx(a.source))

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Render a conversion plan from verified IDs and an explicitly learned profile."""
from __future__ import annotations
import argparse
import copy
import re
from collections import defaultdict
from pathlib import Path
from string import Formatter
from common import load, write, digest

def parse_numbers(marker):
    value = marker.strip().strip('[]［］').strip()
    result = []
    for item in re.split(r'[,，、;；]',value):
        m = re.fullmatch(r'\s*(\d+)(?:\s*[-—–]\s*(\d+))?\s*',item)
        if not m:
            raise ValueError('Not a numeric citation marker')
        a, b = int(m[1]), int(m[2] or m[1])
        if a < 1 or b < a or b-a > 10000:
            raise ValueError('Invalid or unsafe citation number range')
        result.extend(range(a,b+1))
    return result

def fill(template, values):
    if not isinstance(template,str):
        raise ValueError('Target template not configured')
    for _, field, spec, conv in Formatter().parse(template):
        if field is None:
            continue
        if not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',field) or spec or conv:
            raise ValueError('Only plain named placeholders are supported')
        if field not in values or values[field] is None:
            raise ValueError(f'Missing field: {field}')
    return template.format_map(values)

def suffix(i):
    out = ''
    while True:
        out = chr(97+i%26)+out
        i = i//26-1
        if i < 0:
            return out

def check_profile(p):
    if p.get('status') != 'ready' or not p.get('materials') or not p.get('rule_evidence'):
        raise ValueError('Target profile requires user sample evidence and ready status')
    if p.get('target_system') not in {'numeric','author_year'}:
        raise ValueError('Target system not confirmed')
    b = p['bibliography']
    if b.get('uncited_policy') not in {'retain_append','review'}:
        raise ValueError('Confirm uncited-entry policy; separate sections require explicit native editing')
    cfg = p[p['target_system']]
    required = ['open','close','separator','locator_template','item_template']
    required += ['range','compress_min','sort_group','superscript','first_group_order'] if p['target_system']=='numeric' else ['narrative_item_template','group_order','suffix_order']
    for k in required:
        if cfg.get(k) is None:
            raise ValueError(f'Target rule not configured: {k}')
    if p['target_system']=='numeric':
        if type(cfg['superscript']) is not bool or type(cfg['sort_group']) is not bool:
            raise ValueError('Superscript and group sorting must be explicit booleans')
        if type(cfg['compress_min']) is not int or cfg['compress_min'] < 2:
            raise ValueError('Compression threshold must be >=2; use a large number to disable')
        if cfg['first_group_order'] not in {'source','explicit'}:
            raise ValueError('Unknown first-group ordering')
        if '{number}' not in b.get('number_template','') or '{number}' not in cfg['item_template']:
            raise ValueError('Numeric labels require a number placeholder')
    else:
        if cfg['group_order'] not in {'source','bibliography'} or cfg['suffix_order'] not in {'bibliography','first_citation'}:
            raise ValueError('Unsupported ordering; provide verified explicit target order')
        if '{author}' not in cfg['item_template'] or '{year}' not in cfg['item_template'] or '{year}' not in cfg['narrative_item_template']:
            raise ValueError('Author-year templates must retain author/year')
    if '{locator}' not in cfg['locator_template'] or '{locator}' not in cfg['item_template']:
        raise ValueError('Templates must carry per-atom locators')
    if p['target_system']=='author_year' and '{locator}' not in cfg['narrative_item_template']:
        raise ValueError('Narrative template must retain locator')

def check_model(m, snapshot):
    if digest(m['source']) != m['source_sha256'] or snapshot['source_sha256'] != m['source_sha256']:
        raise ValueError('Source changed or snapshot belongs to another document')
    if not m.get('coverage_confirmed') or not m.get('mapping_confirmed'):
        raise ValueError('Full scope and identity mapping must be confirmed')
    units = {u['id']:u for u in snapshot['units']}
    coverage = m.get('coverage',[])
    if {x['unit_id'] for x in coverage} != set(units) or len(coverage)!=len(units):
        raise ValueError('Coverage omits or duplicates source units')
    if any(x.get('state') not in {'checked','excluded'} or not x.get('reason') for x in coverage):
        raise ValueError('Every unit needs a reviewed disposition and reason')
    cand = {c['id']:c for c in m.get('candidates',[])}
    occids = {o['id'] for o in m['occurrences']}
    for initial in snapshot['candidates']:
        cur = cand.get(initial['id'],{})
        if any(cur.get(k)!=initial[k] for k in ('unit_id','start','end','raw')) or not cur.get('reason'):
            raise ValueError('Candidate omitted, changed or lacks disposition')
        if cur.get('decision') not in {'citation','not_citation'}:
            raise ValueError('Candidate unresolved')
        if cur['decision']=='citation' and (not cur.get('occurrence_ids') or not set(cur['occurrence_ids'])<=occids):
            raise ValueError('Candidate missing citation occurrence links')
    refs = m['references']
    if len({r['id'] for r in refs}) != len(refs) or len(occids)!=len(m['occurrences']):
        raise ValueError('Duplicate reference or occurrence IDs')
    rids = {r['id'] for r in refs}
    if any(not r.get('mapping_verified') for r in refs):
        raise ValueError('Reference identity/version is not confirmed')
    original_number_map={}
    for r in refs:
        for n in r.get('source_numbers',[]):
            if type(n) is not int or n<1:
                raise ValueError('Source reference number must be a positive integer')
            if n in original_number_map and original_number_map[n]!=r['id']:
                raise ValueError('One original number identifies multiple unresolved versions')
            original_number_map[n]=r['id']
    bibunits = [b['unit_id'] for r in refs for b in r['blocks']]
    if len(bibunits)!=len(set(bibunits)) or set(bibunits)!=set(m['bibliography_units']) or not set(bibunits)<=set(units):
        raise ValueError('Bibliography blocks do not cover exactly the declared list')
    if len(m['bibliography_units'])!=len(set(m['bibliography_units'])):
        raise ValueError('Duplicate list unit')
    orders = [o['order'] for o in m['occurrences']]
    if any(type(x) is not int or x<0 for x in orders) or len(set(orders))!=len(orders):
        raise ValueError('Citation reading order must be explicit and unique')
    spans = defaultdict(list)
    for o in m['occurrences']:
        u = units.get(o['unit_id'])
        if not u or o['unit_id'] in bibunits:
            raise ValueError('Citation outside declared text scope')
        a,b = o['start'],o['end']
        if not (type(a) is int and type(b) is int and 0<=a<b<=len(u['text'])) or u['text'][a:b]!=o['raw']:
            raise ValueError('Stale or invalid citation anchor')
        if o.get('form') not in {'parenthetical','narrative'} or not o.get('atoms'):
            raise ValueError('Citation form/atoms missing')
        if o.get('source_system') not in {'numeric','author_year'}:
            raise ValueError('Source citation system missing')
        if any(a['ref_id'] not in rids or not isinstance(a.get('locator',''),str) for a in o['atoms']):
            raise ValueError('Unresolved reference ID or locator')
        if o['source_system']=='numeric':
            ref_lookup={r['id']:r for r in refs}
            numbers=[a.get('source_number') for a in o['atoms']]
            if any(type(n) is not int or n not in ref_lookup[a['ref_id']].get('source_numbers',[]) for a,n in zip(o['atoms'],numbers)):
                raise ValueError('Original numeric marker does not map to its approved source entry')
            if re.fullmatch(r'[\[［]\s*\d+(?:\s*[,，、;；—–\-]\s*\d+)*\s*[\]］]',o['raw']):
                if parse_numbers(o['raw'])!=numbers:
                    raise ValueError('Expanded original citation numbers differ from mapped atoms')
        spans[o['unit_id']].append((a,b))
    for values in spans.values():
        values.sort()
        if any(a[1]>b[0] for a,b in zip(values,values[1:])):
            raise ValueError('Overlapping occurrence ranges')
    return units

def render_numeric(atoms,numbers,cfg):
    values = [(numbers[a['ref_id']],a.get('locator','')) for a in atoms]
    if cfg['sort_group']:
        values.sort(key=lambda x:x[0])
    parts,i = [],0
    while i<len(values):
        n,loc = values[i]
        j=i+1
        if not loc:
            while j<len(values) and not values[j][1] and values[j][0]==values[j-1][0]+1:
                j+=1
        if j-i>=cfg['compress_min']:
            first=fill(cfg['item_template'],{'number':n,'locator':''})
            last=fill(cfg['item_template'],{'number':values[j-1][0],'locator':''})
            parts.append(first+cfg['range']+last)
            i=j
        else:
            rendered_loc = fill(cfg['locator_template'],{'locator':loc}) if loc else ''
            parts.append(fill(cfg['item_template'],{'number':n,'locator':rendered_loc}))
            i+=1
    return [{'text':cfg['open']+cfg['separator'].join(parts)+cfg['close'],'superscript':cfg['superscript']}]

def build(m,p,snapshot):
    check_profile(p)
    units = check_model(m,snapshot)
    refs = {r['id']:r for r in m['references']}
    occurrences = sorted(m['occurrences'],key=lambda o:o['order'])
    cited=[]
    for o in occurrences:
        for a in o['atoms']:
            if a['ref_id'] not in cited:
                cited.append(a['ref_id'])
    uncited = [rid for rid in refs if rid not in cited]
    if uncited and p['bibliography']['uncited_policy']=='review':
        raise ValueError('Uncited entries need an explicit disposition before global conversion')
    mode=p['target_system']
    if mode=='numeric':
        order=[]
        for o in occurrences:
            atoms=list(o['atoms'])
            if p['numeric']['first_group_order']=='explicit':
                priority=m.get('target_order',[])
                if set(priority)!=set(refs) or len(priority)!=len(refs):
                    raise ValueError('Explicit first-group priority needs every reference once')
                atoms.sort(key=lambda a:priority.index(a['ref_id']))
            for a in atoms:
                if a['ref_id'] not in order:
                    order.append(a['ref_id'])
        order+=uncited
    else:
        order=m.get('target_order',[])
        if set(order)!=set(refs) or len(order)!=len(refs):
            raise ValueError('Author-year list needs verified complete target order')
    numbers={rid:i+1 for i,rid in enumerate(order)}
    suffixes={rid:'' for rid in refs}
    if mode=='author_year':
        groups=defaultdict(list)
        for rid,r in refs.items():
            if not r.get('authors') or not r.get('year') or not r.get('author_label'):
                raise ValueError('Author-year conversion lacks identity, display label or date')
            groups[(tuple(r['authors']),r['year'])].append(rid)
        for group in groups.values():
            if len(group)>1:
                basis=order if p['author_year']['suffix_order']=='bibliography' else cited+uncited
                for i,rid in enumerate(sorted(group,key=basis.index)):
                    suffixes[rid]=suffix(i)
        labels=[(r['author_label'],r['year'],suffixes[rid]) for rid,r in refs.items()]
        if len(labels)!=len(set(labels)):
            raise ValueError('Collapsed author-year labels still ambiguous; disambiguate authors first')
    edits=[]
    for o in occurrences:
        atoms=o['atoms']
        if o.get('override_runs') is not None:
            if not o.get('override_basis') or o.get('override_atoms')!=atoms:
                raise ValueError('Custom rendering needs explicit basis and preserved atom/locator list')
            runs=copy.deepcopy(o['override_runs'])
        elif mode=='numeric':
            runs=render_numeric(atoms,numbers,p['numeric'])
        else:
            cfg=p['author_year']
            if cfg['group_order']=='bibliography':
                atoms=sorted(atoms,key=lambda a:order.index(a['ref_id']))
            if o['form']=='narrative' and len({tuple(refs[a['ref_id']]['authors']) for a in atoms})>1:
                raise ValueError('Multi-author-group narrative needs explicit safe rendering')
            items=[]
            for a in atoms:
                r=refs[a['ref_id']]
                loc=fill(cfg['locator_template'],{'locator':a.get('locator','')}) if a.get('locator') else ''
                template=cfg['narrative_item_template'] if o['form']=='narrative' else cfg['item_template']
                items.append(fill(template,{'author':r['author_label'],'year':r['year']+suffixes[r['id']],'locator':loc}))
            runs=[{'text':cfg['open']+cfg['separator'].join(items)+cfg['close'],'superscript':False}]
        edits.append({'occurrence_id':o['id'],'unit_id':o['unit_id'],'start':o['start'],'end':o['end'],
                      'expected':o['raw'],'runs':runs,'atoms':copy.deepcopy(o['atoms'])})
    blocks=[]
    for rid in order:
        r=refs[rid]
        values=dict(r.get('fields',{}))
        values.update({'year':r.get('year',''),'year_suffix':r.get('year','')+suffixes[rid],
                       'suffix':suffixes[rid],'number':numbers[rid]})
        for index,b in enumerate(r['blocks']):
            key=b['template_key']
            for required in p['bibliography'].get('required_fields',{}).get(key,[]):
                if not values.get(required):
                    raise ValueError(f'{rid}: target requires missing field {required}')
            templates=p['bibliography']['templates'].get(key)
            if not templates:
                raise ValueError(f'No learned bibliography template: {key}')
            if mode=='author_year' and suffixes[rid] and not any('{year_suffix}' in s.get('template','') for s in templates):
                raise ValueError('Target reference template would drop disambiguating year suffix')
            segments=[]
            if index==0 and mode=='numeric':
                segments.append({'text':fill(p['bibliography']['number_template'],values)})
            for segment in templates:
                s=dict(segment)
                s['text']=fill(s.pop('template'),values)
                segments.append(s)
            blocks.append({'reference_id':rid,'unit_id':b['unit_id'],'expected':units[b['unit_id']]['text'],
                           'runs':segments,'paragraph_format':p['bibliography'].get('paragraph_format',{})})
    return {'schema_version':'1.0','source':m['source'],'source_sha256':m['source_sha256'],
            'target_system':mode,'profile_id':p['profile_id'],'edits':edits,'bibliography_blocks':blocks,
            'bibliography_units':m['bibliography_units'],'reference_order':order,'numbers':numbers,
            'suffixes':suffixes,'uncited_retained':uncited,'occurrence_count':len(edits),
            'atom_count':sum(len(o['atoms']) for o in occurrences)}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('model');p.add_argument('profile');p.add_argument('snapshot')
    p.add_argument('-o','--output',required=True)
    a=p.parse_args()
    model,profile,snapshot=load(a.model),load(a.profile),load(a.snapshot)
    plan=build(model,profile,snapshot)
    plan.update({'model_sha256':digest(a.model),'profile_sha256':digest(a.profile),'snapshot_sha256':digest(a.snapshot)})
    write(a.output,plan)

if __name__=='__main__':
    main()

#!/usr/bin/env python3
"""Verify output against source, learned profile and immutable citation mapping."""
from __future__ import annotations
import argparse
import zipfile
from common import load,write,digest
from plan import build
from apply_docx import transform

def verify(source,output,plan,model,profile,snapshot):
    errors=[]
    try:
        expected_plan=build(model,profile,snapshot)
        for key,value in expected_plan.items():
            if plan.get(key)!=value:
                errors.append('Plan does not reproduce approved model/profile: '+key)
        _,expected_files=transform(source,plan)
        with zipfile.ZipFile(output) as z:
            if set(z.namelist())!=set(expected_files):
                errors.append('DOCX part inventory changed unexpectedly')
            for name,raw in expected_files.items():
                if name not in z.namelist() or z.read(name)!=raw:
                    errors.append('Output differs from exact approved transformations: '+name)
    except (ValueError,KeyError,OSError,zipfile.BadZipFile) as exc:
        errors.append(str(exc))
    return {'passed':not errors,'errors':errors,'source_sha256':digest(source),
            'output_sha256':digest(output),'occurrences':len(plan.get('edits',[])),
            'citation_atoms':plan.get('atom_count'),'references':len(plan.get('reference_order',[])),
            'note':'This checks approved transformations, not source truth or human sample interpretation. Visual review remains required.'}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','output','plan','model','profile','snapshot'):
        p.add_argument(name)
    p.add_argument('-o','--report',required=True)
    a=p.parse_args()
    plan,model,profile,snapshot=[load(x) for x in (a.plan,a.model,a.profile,a.snapshot)]
    for name,path in [('model',a.model),('profile',a.profile),('snapshot',a.snapshot)]:
        if plan.get(name+'_sha256') and plan[name+'_sha256']!=digest(path):
            raise ValueError('Backend input changed after planning: '+name)
    result=verify(a.source,a.output,plan,model,profile,snapshot)
    write(a.report,result)
    raise SystemExit(0 if result['passed'] else 2)

if __name__=='__main__':
    main()

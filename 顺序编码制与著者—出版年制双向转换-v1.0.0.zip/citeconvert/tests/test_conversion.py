"""Synthetic end-to-end and guardrail cases. No default journal styles."""
from __future__ import annotations
import copy
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from lxml import etree as E

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from common import W,q,digest,visible
from inspect_docx import inspect_docx
from plan import build,parse_numbers,render_numeric
from apply_docx import apply
from verify import verify

def make_docx(path,texts):
    root=E.Element(q('document'),nsmap={'w':W})
    body=E.SubElement(root,q('body'))
    for i,text in enumerate(texts):
        p=E.SubElement(body,q('p'))
        pp=E.SubElement(p,q('pPr'))
        E.SubElement(pp,q('spacing')).set(q('after'),'80')
        # Split runs deliberately to exercise offsets crossing run boundaries.
        for part in [text[:3],text[3:]]:
            r=E.SubElement(p,q('r'))
            rp=E.SubElement(r,q('rPr'))
            E.SubElement(rp,q('rFonts')).set(q('eastAsia'),'宋体')
            E.SubElement(r,q('t')).text=part
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('word/document.xml',E.tostring(root,xml_declaration=True,encoding='utf-8'))
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
        z.writestr('word/settings.xml','<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>')

def profile(mode):
    # Entirely artificial, explicitly supplied formats; never loaded in production.
    return {'profile_id':'synthetic-only','status':'ready','target_system':mode,
        'materials':[{'source':'synthetic-example'}],'rule_evidence':[{'basis':'synthetic-example','scope':'test'}],
        'numeric':{'open':'[','close':']','separator':',','range':'-','compress_min':3,'sort_group':True,
                   'superscript':True,'first_group_order':'source','locator_template':':{locator}','item_template':'{number}{locator}'},
        'author_year':{'open':'（','close':'）','separator':'；','locator_template':'：{locator}',
                       'item_template':'{author}，{year}{locator}','narrative_item_template':'{year}{locator}',
                       'group_order':'bibliography','suffix_order':'bibliography'},
        'bibliography':{'uncited_policy':'review','number_template':'[{number}] ',
            'required_fields':{'journal':['authors','title']},
            'templates':{'journal':[{'template':'{authors}. {title}. {year}.' if mode=='numeric' else '{authors}. {year_suffix}. {title}.',
                                     'italic':False}]}}}

class Conversion(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
    def tearDown(self):
        self.tmp.cleanup()

    def source(self):
        src=self.root/'source.docx'
        make_docx(src,['张甲（2020a：12—15）提出观点。另有研究（李乙，2019；张甲，2020b）。',
                       '再次引用（张甲，2020a：22）。','参考文献',
                       '李乙.2019.乙文.','张甲.2020a.甲文.','张甲.2020b.丙文.'])
        return src

    def model(self,source,snapshot,numeric=False):
        units=snapshot['units']
        def occ(i,unit,raw,form,atoms,order):
            start=units[unit]['text'].index(raw)
            return {'id':i,'unit_id':units[unit]['id'],'start':start,'end':start+len(raw),'raw':raw,
                    'form':form,'source_system':'numeric' if numeric else 'author_year','atoms':atoms,'order':order}
        if not numeric:
            os=[occ('o1',0,'（2020a：12—15）','narrative',[{'ref_id':'a','locator':'12—15'}],0),
                occ('o2',0,'（李乙，2019；张甲，2020b）','parenthetical',[{'ref_id':'b','locator':''},{'ref_id':'c','locator':''}],1),
                occ('o3',1,'（张甲，2020a：22）','parenthetical',[{'ref_id':'a','locator':'22'}],2)]
            refunits={'b':units[3]['id'],'a':units[4]['id'],'c':units[5]['id']}
        else:
            os=[occ('o1',0,'[1:12—15]','narrative',[{'ref_id':'a','source_number':1,'locator':'12—15'}],0),
                occ('o2',0,'[2,3]','parenthetical',[{'ref_id':'b','source_number':2,'locator':''},{'ref_id':'c','source_number':3,'locator':''}],1),
                occ('o3',1,'[1:22]','parenthetical',[{'ref_id':'a','source_number':1,'locator':'22'}],2)]
            refunits={'a':units[3]['id'],'b':units[4]['id'],'c':units[5]['id']}
        refs=[]
        for rid,author,year,title,num in [('a','张甲','2020','甲文',1),('b','李乙','2019','乙文',2),('c','张甲','2020','丙文',3)]:
            refs.append({'id':rid,'mapping_verified':True,'authors':[author],'author_label':author,'year':year,
                         'source_numbers':[num] if numeric else [],
                         'fields':{'authors':author,'title':title},
                         'blocks':[{'unit_id':refunits[rid],'template_key':'journal'}]})
        cs=copy.deepcopy(snapshot['candidates'])
        for c in cs:
            linked=[o['id'] for o in os if o['unit_id']==c['unit_id'] and o['start']==c['start'] and o['end']==c['end']]
            c.update(decision='citation' if linked else 'not_citation',reason='Synthetic reviewed disposition')
            if linked:
                c['occurrence_ids']=linked
        return {'source':str(source.resolve()),'source_sha256':digest(source),'coverage_confirmed':True,'mapping_confirmed':True,
                'coverage':[{'unit_id':u['id'],'state':'checked','reason':'Synthetic full inspection'} for u in units],
                'candidates':cs,'references':refs,'occurrences':os,'bibliography_units':[u['id'] for u in units[3:]],
                'target_order':['b','a','c']}

    def test_end_to_end_both_directions_and_locality(self):
        source=self.source();snap=inspect_docx(source);model=self.model(source,snap)
        p=profile('numeric');plan=build(model,p,snap)
        out=self.root/'numeric.docx';receipt=apply(source,plan,out)
        ns=inspect_docx(out)
        self.assertEqual(ns['units'][0]['text'],'张甲[1:12—15]提出观点。另有研究[2,3]。')
        self.assertEqual(ns['units'][1]['text'],'再次引用[1:22]。')
        self.assertEqual(plan['reference_order'],['a','b','c'])
        self.assertEqual(plan['atom_count'],4)
        self.assertTrue(verify(source,out,plan,model,p,snap)['passed'])
        with zipfile.ZipFile(out) as z:
            r=E.fromstring(z.read('word/document.xml'))
            supers=r.findall('.//'+q('vertAlign'))
            self.assertEqual(sum(x.get(q('val'))=='superscript' for x in supers),3)
            self.assertEqual(z.read('word/settings.xml'),zipfile.ZipFile(source).read('word/settings.xml'))
        nm=self.model(out,ns,True);ap=profile('author_year');back=build(nm,ap,ns)
        dest=self.root/'author-year.docx';apply(out,back,dest)
        actual=inspect_docx(dest)['units']
        self.assertEqual(actual[0]['text'],snap['units'][0]['text'])
        self.assertEqual(actual[1]['text'],snap['units'][1]['text'])
        self.assertEqual(back['suffixes'],{'a':'a','b':'','c':'b'})
        self.assertEqual([u['text'] for u in actual[3:]],['李乙. 2019. 乙文.','张甲. 2020a. 甲文.','张甲. 2020b. 丙文.'])
        self.assertTrue(verify(out,dest,back,nm,ap,ns)['passed'])

    def test_ranges_locators_and_explicit_compression(self):
        self.assertEqual(parse_numbers('[1—3,7]'),[1,2,3,7])
        for bad in ['[3-1]','[0]','[one]']:
            with self.assertRaises(ValueError):parse_numbers(bad)
        cfg=profile('numeric')['numeric'];nums={'a':1,'b':2,'c':3,'d':5}
        atoms=[{'ref_id':x,'locator':''} for x in nums]
        self.assertEqual(render_numeric(atoms,nums,cfg)[0]['text'],'[1-3,5]')
        atoms[1]['locator']='8'
        self.assertEqual(render_numeric(atoms,nums,cfg)[0]['text'],'[1,2:8,3,5]')

    def test_compressed_endpoints_use_learned_item_brackets(self):
        cfg=profile('numeric')['numeric']
        cfg.update(open='',close='',item_template='[{number}]{locator}',range='—')
        atoms=[{'ref_id':r,'locator':''} for r in ('a','b','c')]
        self.assertEqual(render_numeric(atoms,{'a':1,'b':2,'c':3},cfg)[0]['text'],'[1]—[3]')

    def test_no_default_profile_and_missing_fields(self):
        src=self.source();s=inspect_docx(src);m=self.model(src,s)
        p=profile('numeric');p['status']='unconfigured'
        with self.assertRaises(ValueError):build(m,p,s)
        p=profile('numeric');p['numeric']['open']=None
        with self.assertRaises(ValueError):build(m,p,s)
        p=profile('numeric');m['references'][0]['fields'].pop('title')
        with self.assertRaises(ValueError):build(m,p,s)

    def test_stale_source_unknown_identity_and_candidate_omission_rejected(self):
        src=self.source();s=inspect_docx(src);m=self.model(src,s);p=profile('numeric')
        changed=copy.deepcopy(m);changed['candidates']=[]
        with self.assertRaises(ValueError):build(changed,p,s)
        changed=copy.deepcopy(m);changed['occurrences'][0]['atoms'][0]['ref_id']='missing'
        with self.assertRaises(ValueError):build(changed,p,s)
        changed=copy.deepcopy(m);changed['occurrences'][0]['raw']='wrong'
        with self.assertRaises(ValueError):build(changed,p,s)
        changed=copy.deepcopy(m);changed['coverage']=[]
        with self.assertRaises(ValueError):build(changed,p,s)

    def test_original_number_mismatch_and_collapsed_author_collision(self):
        src=self.source();s=inspect_docx(src);m=self.model(src,s);plan=build(m,profile('numeric'),s)
        out=self.root/'n.docx';apply(src,plan,out);ns=inspect_docx(out);nm=self.model(out,ns,True)
        bad=copy.deepcopy(nm);bad['occurrences'][1]['atoms'][0]['source_number']=3
        with self.assertRaises(ValueError):build(bad,profile('author_year'),ns)
        bad=copy.deepcopy(nm);bad['references'][2]['authors']=['different-person']
        with self.assertRaises(ValueError):build(bad,profile('author_year'),ns)

    def test_uncited_entries_are_not_silently_deleted(self):
        src=self.source();s=inspect_docx(src);m=self.model(src,s)
        m['occurrences'][1]['atoms'].pop()
        with self.assertRaises(ValueError):build(m,profile('numeric'),s)
        p=profile('numeric');p['bibliography']['uncited_policy']='retain_append'
        result=build(m,p,s)
        self.assertIn('c',result['reference_order']);self.assertEqual(result['uncited_retained'],['c'])

    def test_one_original_number_cannot_identify_two_versions(self):
        src=self.source();s=inspect_docx(src);m=self.model(src,s)
        m['references'][0]['source_numbers']=[1]
        m['references'][1]['source_numbers']=[1,2]
        with self.assertRaises(ValueError):build(m,profile('numeric'),s)

    def test_complex_span_fails_without_partial_file(self):
        src=self.source();s=inspect_docx(src);m=self.model(src,s);plan=build(m,profile('numeric'),s)
        with zipfile.ZipFile(src) as z:files={n:z.read(n) for n in z.namelist()}
        root=E.fromstring(files['word/document.xml']);p=list(root.iter(q('p')))[0]
        run=list(p)[-1];link=E.Element(q('hyperlink'));p.replace(run,link);link.append(run)
        files['word/document.xml']=E.tostring(root)
        with zipfile.ZipFile(src,'w') as z:
            for n,raw in files.items():z.writestr(n,raw)
        plan['source_sha256']=digest(src)
        out=self.root/'should-not-exist.docx'
        with self.assertRaises(ValueError):apply(src,plan,out)
        self.assertFalse(out.exists())

    def test_verifier_detects_tampering_of_plan_and_output(self):
        src=self.source();s=inspect_docx(src);m=self.model(src,s);p=profile('numeric');plan=build(m,p,s)
        out=self.root/'out.docx';apply(src,plan,out)
        bad=copy.deepcopy(plan);bad['edits'][0]['atoms'][0]['ref_id']='b'
        self.assertFalse(verify(src,out,bad,m,p,s)['passed'])
        with zipfile.ZipFile(out,'a') as z:z.writestr('extra.txt','unexpected')
        self.assertFalse(verify(src,out,plan,m,p,s)['passed'])

if __name__=='__main__':unittest.main()
